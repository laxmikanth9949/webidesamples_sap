### Reporting ID Creation

- self-service for HTML5 Neo via Honeycomb
- email based created for all other (processed by EPAM)

### Access to Reports

- request via Reporting UI (self-service)
- "approval" by Platform CoE

### Troubleshooting

- "no data visible", "numbers don´t match expectations"
- manual support effort with single bottleneck for most questions
- 💡reduce effort via documentation / additional guides / self-service diagnosis