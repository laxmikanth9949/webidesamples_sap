# Usage Reporting - FAQ

## What´s a usage?
The usage for an application increases every time the application is opened.

## What´s a active device?
Active devices count the number of devices that opened the application at least once. Recurring usages from the same device don´t increase the count.

WEB Devices are identified using a cookie. The numbers for active devices might be higher than expected as users might use different browsers or clear their cookies.

## Why are there no users in the reports?
The usage reporting does not record the user context.

## What are the regional reports based on?
All regional information are based on the Locale setting of the device. They are not based on the actual GPS position. As a result, the numbers might differ from the expected values. Many colleagues seem to use US locale settings, therefore they are counted for US / North America.

## Why is my application not showing up in the reports?
All applications that have not send a usage in the last 2 months are hidden.

## Can I get regular updates about report numbers for my application?
We offer a simple monthly update email for device and usage numbers. You can customize it via the email button in the bottom left corner or the reporting ui.

![Reporting UI](img/manage-monthly-updates.png)

## How can I request access to other applications
To request access to other applications, open the [reporting ui](https://fiorilaunchpad.sap.com/sites#MU-Reporting), select the "Application" tab and click on the "Request Access" button in the bottom bar.

![Reporting UI](img/request-additional-access.png)

## Should I use SAP Web Analytics or the Usage Reporting
The Usage Reporting was initially developed for native mobile application tracking within SAP IT as at that time, no alternative was available. 
In the meantime, that changed with SAP Web Analytics (https://go.sap.corp/WARP).

As SAP Web Analytics is an official offering, we encourage projects to use it.

If the functionalities of the Usage Reporting are sufficient for your use case, feel free to use it.
However, please consider the following points in your decision:
- there is currently no development taking place for Usage Reporting
- we think about migrating the Usage Reporting to SAP Web Analytics - however we don´t know if that happens or not.

