### General

- ⚠️ project from 2014
- ⚠️ sideproject, mostly single developer
- ⚠️ no development since 2017
- integrated into 250+ applications
- ⚠️ no contact person for most applications

### Clients

- small libraries provided for WEB / IOS / ANDROID / ...
- integrated into application that should be tracked
- send usage data to backend

### Backend

- java based
    - jersey for rest api
    - both JDBC and Eclipselink for persistence
- running on BTP Neo
- exposes API for reporting
- exposes API for usage collection
- ⚠️ single instance for everything (usage collection, reporting)
- ⚠️ no monitoring in place

### Persistence

- HANA provided by BTP Neo
- single instance
- ⚠️ open / unknown / limited support
- ⚠️ backups? disaster recovery?

### Reporting

- custom UI5 application
- consumes API exposed by backend
- ⚠️ primitive authorization concept

### Misc Features & Integrations

- realtime visualizations (⚠️ no authentication)
- monthly update mail
- integration for "Heartbeat Project" - IoT showcase, abandoned
- integration for "Relay Bots" - abandoned
- integration for IT Showroom, unclear if still in use