## Reporting UI

- custom UI5 application
- available in the [Fiori Launchpad](https://fiorilaunchpad.sap.com/sites#MU-Reporting)
- consumes API exposed by backend
- ⚠️ primitive authorization concept
- ⚠️ access request / approval without benefit
- remembers settings from last visit
- ⚠️ no direct links with predefined settings (app selection, report, time)
- slow & overwhelming, especially for extensive app & time selection (⚠️ exchange format? chart render lib?)
- easy to break (select *every* usage)
- probably does not follow official ux recommendations
- nonsense features like realtime reports
- 💡datasource for standard solution (SAP Analytics Cloud?)

### Reports

- (mostly) simple usage count only
- very limited behavior analysis via events
- no insights into
  - target group (with some exceptions)
  - source/acquisition/retention
  - behavior (with exception custom events)

#### Global iOS / Android OS Version

- Number of usages split by OS Version
- pre-filtered to platform IOS / Android
- not exposed for platform WEB, WINDOWS, MAC
- ⚠️ confusing UX ("global", but based on selected apps)
- ⚠️ there might be better sources (MDM?)

#### Active Devices

- ⚠️ limited insights, numbers might be misleading (e.g. WEB based on cookies)

#### Location

- ⚠️ location is derived from locale settings => numbers might be misleading
- very similar to "Region Distribution" Report

#### Events

- implementation depends on the project
- can provide additional insights into usage
- ⚠️ no additional filter possibility, overwhelming when too many events are tracked

#### Device Type

- categorizes usage into `DESKTOP` and `MOBILE`

#### Version Distribution

- depends on project implementation
- ⚠️ many projects use hardcoded values

#### Region Distribution

- ⚠️ location is derived from locale settings => numbers might be misleading

#### Device Model Usage

- Number of usage split
- ... by browser version for WEB
- ... by device model for IOS/ANDROID

#### GCO

- LoB specific regional grouping

#### Realtime

- eye-catcher only
- no real value