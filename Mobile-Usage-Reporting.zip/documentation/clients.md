## Clients

- are integrated into application
- send usage data to backend (usage collection API)
- multiple variants, some developed by other departments
- ⚠️ legal questions ("cookie banner", data collection consent, opt-out / opt-in required?, ...)
- some clients use the api management -> questionable benefit
- 💡CDN based distribution

### JS

- integration guide: https://trackingshallwe.hana.ondemand.com/documentation/integration
- plain javascript implementation
- can be integrated into any web application, no framework etc required
- ⚠️ might affect or even break application in case of an issue
- 💡send usage without preflight cors request

### Component Based UI5

- integration guide: https://trackingshallwe.hana.ondemand.com/documentation/integration
- javascript based implementation as UI5 library
- ⚠️ might affect or even break application in case of an issue
- 💡send usage without preflight cors request

### sapitlibrary

- https://github.wdf.sap.corp/it-mobile/sapitlibrary/blob/master/docs/src/sapit/util/UsageTracking.md
- javascript based implementation as UI5 library
- uses Component Based UI5 internally
- added benefit?
- ⚠️ might affect or even break application in case of an issue

### iOS

- integration guide: https://trackingshallwe.hana.ondemand.com/documentation/integration
- objective-c based implementation
- ⚠️ unclear / open support
- ⚠️ might affect or even break application in case of an issue

### ABAP Steampunk

- sends usage data from Steampunk backend
- contact: Riccardo / Thomas
- ⚠️ might affect or even break application in case of an issue

### Android

- java based implementation
- unclear need
- ⚠️ unclear / open support
- ⚠️ might affect or even break application in case of an issue

### Windows Native

- (presumable) .net based implementation
- ⚠️ unclear / open support & contact
- unclear need
