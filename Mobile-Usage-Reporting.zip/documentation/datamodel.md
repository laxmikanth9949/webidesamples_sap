## Usage

| FIELD                 | TYPE            | Examples                                                   | Note                                      | Report                                 |
|-----------------------|-----------------|------------------------------------------------------------|-------------------------------------------|----------------------------------------|
| "USAGE_ID"            | BIGINT          | `970407`                                                   | 🚧 internal                               | -                                      | 
| "APPLICATION_ID"      | NVARCHAR(255)   |                                                            | ℹ️ provided by project                    |                                        |
| "PLATFORM_ID"         | NVARCHAR(255)   | `ANDROID`, `IOS`, `WEB`, `WINDOWS`, `MAC`                  | ℹ️ provided by project                    |                                        |
| "VERSION_ID"          | NVARCHAR(255)   |                                                            | ℹ️ provided by project                    |                                        |
| "USAGE_START"         | LONGDATE        |                                                            |                                           |                                        |
| "COUNTRY_CODE"        | NVARCHAR(255)   | `US`,`DE`,`BR`                                             | ⚠️ Data Quality ⚠️ Based on device locale | "Location", "Region Dsitribution"      |
| "DEVICE_ID"           | NVARCHAR(40)    |                                                            | generated value                           | "Active Devices"                       |
| "DEVICE_TYPE"         | NVARCHAR(255)   | `DESKTOP`,`MOBILE`                                         | ⚠️ binary, no other values                | "Device Type"                          |
| "MODEL_NAME"          | NVARCHAR(255)   | `Mozilla`, `IE 11`, `Chrome 84`                            |                                           | "Device Model"                         |
| "OPERATING_SYSTEM"    | NVARCHAR(255)   | `WINDOWS`, `Microsoft Windows 10 Enterprise`, `iOS 11.4.1` |                                           | "iOS OS Version", "Android OS Version" |
| "USAGE_END"           | LONGDATE        |                                                            | 🗑️ Not properly maintained               | 📊 No report                                      |
| "SCREEN_SIZE"         | DOUBLE          | `1`, `0`, `12`                                             | 🗑️ Not properly maintained               | 📊 No report                                       |
| "USER_INFORMATION_ID" | BIGINT CS_FIXED |                                                            | 🗑️ Not properly implemented              | 📊 No report                                       |
| "RAW_USER_AGENT"      | NVARCHAR(512)   |                                                            | 🚧 internal                               |                                        |
| "REFERER"             | NVARCHAR(2500)  |                                                            | 🚧 internal                               |                                        |
| "ORIGIN"              | NVARCHAR(2500)  |                                                            | 🚧 internal                               |                                        |
| "INSERTED_AT"         | LONGDATE        |                                                            | 🚧 internal                               |                                        |

## Event

| FIELD         | TYPE          | Examples    | Note                    | Report   |
|---------------|---------------|-------------|-------------------------|----------|
| "EVENT_ID"    | BIGINT        | `341668122` | 🚧 internal             |          |
| "USAGE_ID"    | BIGINT        | `970407`    | 🚧 internal             |          |
| "EVENT_NAME"  | NVARCHAR(255) |             | ℹ️ provided by project  | "Events" |
| "EVENT_DATE"  | LONGDATE      |             |                         |          |
| "INSERTED_AT" | LONGDATE      |             | 🚧 internal             |          |

## Misc

- ⚠️ unknown what data volume can be supported
- 💡support for separate tenants