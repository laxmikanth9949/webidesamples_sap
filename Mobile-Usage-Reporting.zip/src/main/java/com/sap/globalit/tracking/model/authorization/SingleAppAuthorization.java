package com.sap.globalit.tracking.model.authorization;

import com.sap.globalit.tracking.model.Application;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "T_AUTHORIZATION_SINGLE", uniqueConstraints = {@UniqueConstraint(columnNames = {"userId", "appId"})})
public class SingleAppAuthorization {

    public void setApprover(String approver) {
        this.approver = approver;
    }

    public enum Status {
        PENDING, APPROVED, REJECTED
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long authId;

    /**
     * SAP ID Service User ID which holds the authorization
     */
    @NotNull
    @Size(min = 1)
    private String userId;

    @NotNull
    @Size(min = 1)
    @Lob
    private String reason;

    private String approver;

    @Enumerated(EnumType.STRING)
    private Status status;

    @NotNull
    private long lastStatusModification;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "APPID")
    private Application app;

    public SingleAppAuthorization() {
        super();
    }

    public SingleAppAuthorization(String userId, Application app, String reason) {
        this.userId = userId;
        this.reason = reason;
        this.app = app;
        updateModificationDate();
    }

    public SingleAppAuthorization(String userId, Status status, Application app) {
        this.userId = userId;
        this.status = status;
        this.app = app;
        updateModificationDate();
    }

    public long getAuthId() {
        return authId;
    }

    public String getUserId() {
        return userId;
    }

    public String getReason() {
        return reason;
    }

    public String getApprover() {
        return approver;
    }

    public Status getStatus() {
        return status;
    }

    public long getLastStatusModification() {
        return lastStatusModification;
    }

    public Application getApp() {
        return app;
    }


    public void updateModificationDate() {
        lastStatusModification = System.currentTimeMillis();
    }

    public void setStatus(Status status) {
        this.status = status;
        updateModificationDate();
    }

    @Override
    public String toString() {
        return "SingleAppAuthorization{" +
                "authId=" + authId +
                ", userId='" + userId + '\'' +
                ", status=" + status +
                ", appId='" + app + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SingleAppAuthorization that = (SingleAppAuthorization) o;

        return authId == that.authId;

    }

    @Override
    public int hashCode() {
        return (int) (authId ^ (authId >>> 32));
    }
}