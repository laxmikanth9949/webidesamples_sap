package com.sap.globalit.tracking.api.internal;

import com.sap.globalit.tracking.model.ApplicationPlattform;
import com.sap.globalit.tracking.model.reporting.Chart;
import com.sap.globalit.tracking.model.reporting.Table;
import com.sap.security.um.UMException;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.sql.SQLException;

public interface ReportAPI {

    enum TimeInterval {
        HOUR, DAY, WEEK, MONTH, QUARTER, YEAR
    }

    /**
     * Usage
     *
     * @throws Exception
     */

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/Usage/ByApp")
    Chart get_Usage_ByApp(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter) throws Exception;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/Usage/ByApp/Table")
    Table get_Usage_ByApp_AsTable(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter) throws Exception;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/Usage/ByApp/Table/csv")
    Response get_Usage_ByApp_AsTable_CSV(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws Exception;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/Usage/ByApp/Bar")
    Chart get_Usage_ByApp_Bar(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/Usage/ByRegionGCO/Table")
    Table get_Usage_ByRegionGCO_AsTable(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces("text/csv")
    @Path("/Usage/ByRegionGCO/Table/csv")
    Response get_Usage_ByRegionGCO_AsTable_csv(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    /**
     * Active Users
     */

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/ActiveDevices/ByApp")
    Chart get_ActiveUser_ByApp(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter) throws Exception;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/ActiveDevices/ByApp/Table")
    Table get_ActiveUser_ByApp_AsTable(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter) throws Exception;

    @POST
    @Produces("text/csv")
    @Path("/ActiveDevices/ByApp/Table/csv")
    Response get_ActiveUser_ByApp_AsTable_CSV(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws Exception;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/ActiveDevices/ByApp/Bar")
    Chart get_ActiveUser_ByApp_Bar(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/ActiveDevices/ByRegionGCO/Table")
    Table get_ActiveDevices_ByRegionGCO_AsTable(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces("text/csv")
    @Path("/ActiveDevices/ByRegionGCO/Table/csv")
    Response get_ActiveDevices_ByRegionGCO_AsTable_CSV(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    /**
     * App Detail
     *
     * @throws UMException
     */

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/AppDetail/Events")
    Chart get_Events_ForApplication(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/AppDetail/Events/Table")
    Table get_Events_ForApplication_AsTable(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces("text/csv")
    @Path("/AppDetail/Events/Table/csv")
    Response get_Events_ForApplication_AsTable_CSV(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/AppDetail/DeviceType")
    Chart get_DeviceType_ForApplication(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/AppDetail/DeviceType/Table")
    Table get_DeviceType_ForApplication_AsTable(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces("text/csv")
    @Path("/AppDetail/DeviceType/Table/csv")
    Response get_DeviceType_ForApplication_AsTable_CSV(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/AppDetail/EventsByGCORegion")
    Table get_Events_ForApplication_ByGCORegion(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/AppDetail/EventsByGCORegion/csv")
    Response get_Events_ForApplication_ByGCORegion_CSV(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;


    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/AppDetail/DeviceModel")
    Chart get_DeviceModel_ForApplication(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/AppDetail/DeviceModel/Table")
    Table get_DeviceModel_ForApplication_AsTable(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces("text/csv")
    @Path("/AppDetail/DeviceModel/Table/csv")
    Response get_DeviceModel_ForApplication_AsTable_CSV(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/AppDetail/ActiveUsers/ByVersion")
    Chart get_ActiveUsers_ByApplicationVersion_ForApplication(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/AppDetail/ActiveUsers/ByVersion/Table")
    Table get_ActiveUsers_ByApplicationVersion_ForApplication_asTable(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces("text/csv")
    @Path("/AppDetail/ActiveUsers/ByVersion/Table/csv")
    Response get_ActiveUsers_ByApplicationVersion_ForApplication_asTable_CSV(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    /***
     * New APIs
     *
     * @throws UMException
     ****/

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/AppDetail/ActiveUsers/ByRegion")
    Chart get_ActiveUsers_ByRegion_ForApplication(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/AppDetail/ActiveUsers/ByRegion/Table")
    Table get_ActiveUsers_ByRegion_ForApplication_asTable(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces("text/csv")
    @Path("/AppDetail/ActiveUsers/ByRegion/Table/csv")
    Response get_ActiveUsers_ByRegion_ForApplication_asTable_CSV(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/Overview/Location/Table")
    Table get_LocationInfo_asTable(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    @POST
    @Produces("text/csv")
    @Path("/Overview/Location/Table/csv")
    Response get_LocationInfo_asTable_CSV(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            /* HTTP Body */ String param_appfilter)
            throws SQLException, UMException;

    // Global
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/Global/OSVersion/{platform}")
    Chart get_OS_Version(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            @PathParam("platform") ApplicationPlattform.PlatformType platform,
            /* HTTP Body */ String param_appfilter) throws Exception;

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/Global/OSVersion/{platform}/Table")
    Table get_OS_Version_AsTable(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            @PathParam("platform") ApplicationPlattform.PlatformType platform,
            /* HTTP Body */ String param_appfilter) throws Exception;

    @POST
    @Produces("text/csv")
    @Path("/Global/OSVersion/{platform}/Table/csv")
    Response get_OS_Version_AsTable_CSV(
            @QueryParam("start") long param_start,
            @QueryParam("end") long param_end,
            @QueryParam("interval") TimeInterval param_interval,
            @PathParam("platform") ApplicationPlattform.PlatformType platform,
            /* HTTP Body */ String param_appfilter)
            throws Exception;

    @GET
    @Produces("text/csv")
    @Path("/CSVExport")
    Response downloadPreGeneratedCSV(@QueryParam("uuid") String uuid);


}