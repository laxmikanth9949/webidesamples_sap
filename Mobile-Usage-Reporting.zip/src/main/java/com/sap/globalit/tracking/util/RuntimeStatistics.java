package com.sap.globalit.tracking.util;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Created by D053397 on 04.11.2016.
 */
public class RuntimeStatistics {

    public AtomicLong acquiredEntityManagers = new AtomicLong(0);
    public AtomicLong releasedEntityManagers = new AtomicLong(0);

}
