package com.sap.globalit.tracking.util;

import com.sap.it.mobile.hcp.service.email.HCPEmail;
import com.sap.it.mobile.hcp.service.email.HCPEmailBuilder;
import com.sap.it.mobile.hcp.service.email.HCPEmailException;
import com.sap.it.mobile.hcp.service.email.HCPEmailProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.mail.MessagingException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

public class MailHelper {

    private static Logger logger = LoggerFactory.getLogger(MailHelper.class);

    @Inject
    HCPEmailProvider mailProvider;

    @Inject
    LandscapeHelper landscapeHelper;

    public void sendMails(List<HCPEmail> emails) throws HCPEmailException {
        if (!landscapeHelper.isProductiveLandscape()) {
            logger.warn("Skipping email -> not productive landscape");
            return;
        }

        for (HCPEmail email : emails) {
            try {
                mailProvider.send(email);
            } catch (HCPEmailException e) {
                logger.warn("Failed to send mail to {}", email.getTo(), e);
            }
        }
    }

    public HCPEmail generateMail(String user, String subject, String body) throws MessagingException, IOException, URISyntaxException {
        // Text Email
        return new HCPEmailBuilder()
                .from("noreply+it-internal-usage-reporting@sap.corp", "SAP IT Mobile Usage Reporting")
                .to(user + "@exchange.sap.corp")
                .subject(subject)
                .text(body)
                .create();
    }

}
