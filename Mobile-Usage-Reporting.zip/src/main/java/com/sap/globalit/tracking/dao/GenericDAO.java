package com.sap.globalit.tracking.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

/**
 * Generic DAO
 */
public abstract class GenericDAO<TYPE, KEY> {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Inject
    protected EntityManager em;

    public Optional<TYPE> getByKey(KEY key) {
        return Optional.ofNullable(em.find(getEntityClass(), key));
    }

    public abstract Class<? extends TYPE> getEntityClass();

    @SuppressWarnings("unchecked")
    public List<TYPE> getAll() {
        return em.createQuery(
                "SELECT x FROM " + getEntityClass().getSimpleName()
                        + " x").getResultList();
    }
}
