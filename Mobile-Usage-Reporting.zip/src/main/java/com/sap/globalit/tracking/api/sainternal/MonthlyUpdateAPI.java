package com.sap.globalit.tracking.api.sainternal;

import com.sap.globalit.tracking.scheduling.MonthlyUpdateJob;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.quartz.JobBuilder;
import org.quartz.Scheduler;
import org.quartz.TriggerBuilder;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

/**
 * Created by D053397 on 28.08.2015.
 */

@Path("/sa-internal/monthlyUpdate")
@Api(value = "Monthly Update API", description = "Monthly Update Service")
public class MonthlyUpdateAPI {

    @Inject
    Scheduler scheduler;

    //@POST
    //@Path("/send")
    //@ApiOperation(value = "Send Monthly Update to User")
    //public void processSomeUserAgents(@QueryParam("user") String userId) throws Exception {
    //    monthlyUpdateJob.setForSingleUser(userId);
    //    monthlyUpdateJob.sendMonthlyUpdateMail();
    //}

    @POST
    @Path("/sendToAll")
    @ApiOperation(value = "Send Monthly Update to All")
    public void sentToAll() throws Exception {
        scheduler.scheduleJob(
                JobBuilder.newJob(MonthlyUpdateJob.class).build(),
                TriggerBuilder.newTrigger().startNow().build()
        );
    }

}