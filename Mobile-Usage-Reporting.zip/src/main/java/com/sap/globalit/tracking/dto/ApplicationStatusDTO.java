package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;

/**
 * Created by D053397 on 10.08.2016.
 */
public class ApplicationStatusDTO extends ApplicationDTO {

    public enum Status {ACTIVE, PENDING}

    @Expose
    public Status status;

    public ApplicationStatusDTO(String id, String displayName, Status status) {
        super(id, displayName);
        this.status = status;
    }
}