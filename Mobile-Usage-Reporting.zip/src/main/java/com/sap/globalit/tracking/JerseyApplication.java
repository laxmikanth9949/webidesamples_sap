package com.sap.globalit.tracking;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.jmx.JmxReporter;
import com.sap.cloud.security.oauth2.OAuthAuthorization;
import com.sap.globalit.tracking.api.ApplicationUsageAPI;
import com.sap.globalit.tracking.api.RealtimeSocketManager;
import com.sap.globalit.tracking.api.StatusAPI;
import com.sap.globalit.tracking.api.internal.*;
import com.sap.globalit.tracking.api.internal.v2.ReportAPIHanaImpl;
import com.sap.globalit.tracking.api.internal.v2.SQLDAO;
import com.sap.globalit.tracking.api.internal.v2.TemporaryCSVStore;
import com.sap.globalit.tracking.api.internal.v2.report.ReportBuilder;
import com.sap.globalit.tracking.api.reporting.MasterAPI;
import com.sap.globalit.tracking.api.reporting.NewsletterAPI;
import com.sap.globalit.tracking.api.reporting.SettingsAPI;
import com.sap.globalit.tracking.api.sainternal.*;
import com.sap.globalit.tracking.authorization.AuthorizationDAO;
import com.sap.globalit.tracking.authorization.AuthorizationManager;
import com.sap.globalit.tracking.dao.*;
import com.sap.globalit.tracking.injection.SchedulerFactory;
import com.sap.globalit.tracking.injection.*;
import com.sap.globalit.tracking.model.ViewCreation;
import com.sap.globalit.tracking.scheduling.MonthlyUpdateJob;
import com.sap.globalit.tracking.util.DBSequence;
import com.sap.globalit.tracking.util.LandscapeHelper;
import com.sap.globalit.tracking.util.MailHelper;
import com.sap.globalit.tracking.util.WebHostRestrictionManager;
import com.sap.it.mobile.hcp.jaxrs.feature.ScopesAllowedDynamicFeature;
import com.sap.it.mobile.hcp.jaxrs.provider.SupportExceptionMapper;
import com.sap.it.mobile.hcp.jersey.injection.HCPMailerFactory;
import com.sap.it.mobile.hcp.jersey.injection.UserProviderFactory;
import com.sap.it.mobile.hcp.service.email.HCPEmailProvider;
import com.sap.security.um.user.UserProvider;
import io.swagger.annotations.Info;
import io.swagger.annotations.SwaggerDefinition;
import io.swagger.jaxrs.config.BeanConfig;
import io.swagger.jaxrs.listing.ApiListingResource;
import io.swagger.jaxrs.listing.SwaggerSerializers;
import org.glassfish.jersey.internal.inject.AbstractBinder;
import org.glassfish.jersey.internal.inject.InjectionManager;
import org.glassfish.jersey.process.internal.RequestScoped;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.spi.Container;
import org.glassfish.jersey.server.spi.ContainerLifecycleListener;
import org.quartz.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Singleton;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import javax.ws.rs.ApplicationPath;
import java.sql.Connection;
import java.util.TimeZone;

/**
 * Created by D053397 on 12.10.2016.
 */
@SwaggerDefinition(
        info = @Info(
                description = "Mobile Usage Reporting API",
                version = "1.0",
                title = "API For Mobile Usage Reporting"
        ),
        consumes = {"application/json"},
        produces = {"application/json"},
        schemes = {SwaggerDefinition.Scheme.HTTPS},
        basePath = "/api"
)
@ApplicationPath("api")
public class JerseyApplication extends ResourceConfig {

    private static final Logger LOG = LoggerFactory.getLogger(JerseyApplication.class);

    public static InjectionManager serviceLocator;

    public JerseyApplication() {

        LOG.info("Creating JerseyApplication");

        // don´t generate WADL response for OPTIONS requests
        property("jersey.config.server.wadl.disableWadl", "true");

        // --- Register Services ---
        register(StatusAPI.class);
        register(ReportAPIHanaImpl.class);
        register(HeartbeatAPI.class);
        register(InternalStatusAPI.class);
        register(RequestAuthorizationAPI.class);
        register(ApplicationUsageAPI.class);
        register(RelaybotAPI.class);

        // Reporting UI
        register(MasterAPI.class);
        register(NewsletterAPI.class);
        register(SettingsAPI.class);

        // Internal APIS
        register(ApplicationAPI.class);
        register(ApplicationPlatformAPI.class);
        register(ApproveAuthorizationAPI.class);
        register(InternalSettingsAPI.class);
        register(MonthlyUpdateAPI.class);
        register(ShowroomAPI.class);
        register(StatisticsAPI.class);
        register(SaInternalStatusAPI.class);
        register(DocumentationAPI.class);
        register(EventAPI.class);

        MetricRegistry registry = new MetricRegistry();
        register(new InjectionBinder(registry));

        // Support
        register(SupportExceptionMapper.class);

        register(GsonJsonProvider.class);

        register(ViewCreation.class);

        register(ScopesAllowedDynamicFeature.class);

        // Metrics
        final JmxReporter reporter = JmxReporter.forRegistry(registry).build();
        reporter.start();

        register(new ContainerLifecycleListener() {
            @Override
            public void onStartup(Container container) {
                serviceLocator = container.getApplicationHandler().getInjectionManager();
                LOG.info("Service Locator Set");

                try {
                    Scheduler scheduler = serviceLocator.getInstance(Scheduler.class);
                    scheduler.setJobFactory((bundle, scheduler1) -> {
                        Class<? extends Job> jobClass = bundle.getJobDetail().getJobClass();
                        Job jobInstance = serviceLocator.createAndInitialize(jobClass);
                        LOG.info("Initialized {}", jobInstance);
                        return jobInstance;
                    });

                    // schedule monthly update @ first day of month at 8:00 UTC
                    scheduler.scheduleJob(
                            JobBuilder.newJob(MonthlyUpdateJob.class).build(),
                            TriggerBuilder.newTrigger().withSchedule(CronScheduleBuilder.cronSchedule("0 0 8 1 * ?").inTimeZone(TimeZone.getTimeZone("UTC"))).build()
                    );

                    scheduler.start();

                } catch (SchedulerException e) {
                    LOG.error("", e);
                }

            }

            @Override
            public void onReload(Container container) {

            }

            @Override
            public void onShutdown(Container container) {
                try {
                    InjectionManager serviceLocator = container.getApplicationHandler().getInjectionManager();

                    RealtimeSocketManager manager = serviceLocator.getInstance(RealtimeSocketManager.class);
                    manager.shutdown();

                    Scheduler scheduler = serviceLocator.getInstance(Scheduler.class);
                    scheduler.shutdown(true);
                } catch (SchedulerException e) {
                    LOG.error("Failed to shutdown", e);
                }
            }
        });

        // Swagger
        register(SwaggerSerializers.class);
        register(ApiListingResource.class);

        BeanConfig beanConfig = new BeanConfig();
        beanConfig.setResourcePackage(getClass().getPackage().getName());
        beanConfig.setPrettyPrint(false);
        beanConfig.setScan(true);
        beanConfig.setBasePath("/api");

    }

    static class InjectionBinder extends AbstractBinder {

        private final MetricRegistry registry;

        InjectionBinder(MetricRegistry registry) {
            this.registry = registry;
        }

        @Override
        protected void configure() {

            bind(InitialContext.class).to(Context.class).in(Singleton.class);
            bindFactory(DatasourceFactory.class).to(DataSource.class).in(Singleton.class);
            bindFactory(ConnectionFactory.class).to(Connection.class);

            OAuthAuthorization auth = OAuthAuthorization.getOAuthAuthorizationService();
            if (auth != null)
                bind(auth).to(OAuthAuthorization.class);

            bind(ApplicationPlattformDAO.class).to(ApplicationPlattformDAO.class);
            bind(ApplicationDAO.class).to(ApplicationDAO.class);
            bind(MonthlyUpdateOptOutDAO.class).to(MonthlyUpdateOptOutDAO.class);
            bind(SettingsDAO.class).to(SettingsDAO.class);
            bind(AuthorizationDAO.class).to(AuthorizationDAO.class);
            bind(WebHostRestrictionManager.class).to(WebHostRestrictionManager.class);
            bind(AuthorizationManager.class).to(AuthorizationManager.class);
            bind(SQLDAO.class).to(SQLDAO.class);
            bind(UsageDAO.class).to(UsageDAO.class);

            bind(RealtimeSocketManager.class).to(RealtimeSocketManager.class).in(Singleton.class);
            bind(MailHelper.class).to(MailHelper.class);
            bind(ReportBuilder.class).to(ReportBuilder.class);
            bind(LandscapeHelper.class).to(LandscapeHelper.class);

            bindFactory(HCPMailerFactory.class).to(HCPEmailProvider.class).in(Singleton.class);
            bindFactory(UserProviderFactory.class).to(UserProvider.class).in(Singleton.class);

            bindFactory(SchedulerFactory.class).to(Scheduler.class).in(Singleton.class);

            bindFactory(EMFFactory.class).to(EntityManagerFactory.class);
            bindFactory(EMFactory.class).to(EntityManager.class).proxy(true).proxyForSameScope(false).in(RequestScoped.class);

            bind(TemporaryCSVStore.class).to(TemporaryCSVStore.class).in(Singleton.class);

            bind(new DBSequence("USAGE_SEQUENCE")).to(DBSequence.class).named("USAGE_SEQUENCE");
            bind(new DBSequence("EVENT_SEQUENCE")).to(DBSequence.class).named("EVENT_SEQUENCE");
            bind(new DBSequence("USERINFO_SEQUENCE")).to(DBSequence.class).named("USERINFO_SEQUENCE");

            bind(registry).to(MetricRegistry.class);
        }
    }
}
