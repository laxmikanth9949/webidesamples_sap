package com.sap.globalit.tracking.util;

import java.util.Base64;

public class ChartUtil {


    public static String cleanTimeEntryKey(String name) {
        return name.replace("/", "-"); // not really required, but for backward compatibility
    }

    public static String cleanStringForReferenceInJS(String name) {
        return Base64.getEncoder().encodeToString(name.getBytes());
        /*
                name.replaceAll("/", "-")
                .replaceAll(":", "-")
                .replaceAll("\"", "-")
                .replaceAll("'", "-");
                */
    }
}
