package com.sap.globalit.tracking.api.internal;

import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.*;
import javax.ws.rs.core.*;

@Path("/internal/status")
@Api(value = "Status API", description = "Status Service")
public class InternalStatusAPI {

    private static Logger logger = LoggerFactory
            .getLogger(InternalStatusAPI.class);

    public InternalStatusAPI() {
    }

    @HeaderParam("Origin")
    String origin;

    @HeaderParam("Access-Control-Request-Headers")
    String requestedHeader;

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public Response status() throws Exception {
        return Response.ok("Internal: Tracking framework up and running!").header("Access-Control-Allow-Origin", "*").build();
    }

    @OPTIONS
    public Response statusCORS(@Context HttpHeaders headers, @Context UriInfo uriInfo) {
        logger.debug("Handling OPTIONS for {} / {}", uriInfo.getAbsolutePath(), headers);
        return createCORS(headers);
    }


    private Response createCORS(HttpHeaders headers) {
        // request
        // OPTIONS /resources/post-here/ HTTP/1.1
        // Host: bar.other
        // User-Agent: Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.5; en-US; rv:1.9.1b3pre) Gecko/20081130 Minefield/3.1b3pre
        // Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
        // Accept-Language: en-us,en;q=0.5
        // Accept-Encoding: gzip,deflate
        // Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7
        // Connection: keep-alive
        // Origin: http://foo.example
        // Access-Control-Request-Method: POST
        // Access-Control-Request-Headers: X-PINGOTHER
        Response.ResponseBuilder responseBuilder = Response.ok();

        // add allowOrigin Access-Control-Allow-Origin: http://foo.example
        responseBuilder.header("Access-Control-Allow-Origin", "*");

        // Access-Control-Allow-Methods: POST, GET, OPTIONS
        for (String method : headers.getRequestHeader("Access-Control-Request-Method")) {
            logger.debug("Adding Method {}", method);
            responseBuilder.header("Access-Control-Allow-Methods", method);
        }

        // Access-Control-Allow-Headers: X-PINGOTHER
        for (String header : headers.getRequestHeader("Access-Control-Request-Headers")) {
            logger.debug("Adding Header {}", header);
            responseBuilder.header("Access-Control-Allow-Headers", header);
        }

        // "Access-Control-Max-Age" -> remember for 1 minute
        responseBuilder.header("Access-Control-Max-Age", 60000);

        return responseBuilder.build();
    }

}