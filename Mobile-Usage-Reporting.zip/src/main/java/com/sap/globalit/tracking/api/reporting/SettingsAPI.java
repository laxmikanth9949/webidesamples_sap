package com.sap.globalit.tracking.api.reporting;

import com.sap.globalit.tracking.dao.SettingsDAO;
import com.sap.globalit.tracking.dto.Mapper;
import com.sap.globalit.tracking.dto.UserReportSettingDTO;
import com.sap.globalit.tracking.model.UserReportSetting;
import com.sap.security.um.user.PersistenceException;
import com.sap.security.um.user.UserProvider;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.time.Instant;

/**
 * This API is tailored to the Reporting UI
 * <p>
 * PROD: https://fiorilaunchpad.sap.com/sites#MU-Reporting
 * DEV: https://mobileusage-sapitcloudd.dispatcher.hana.ondemand.com
 */
@Path("reporting/settings")
@Api(value = "Reporting UI - Settings")
public class SettingsAPI {

    private static Logger logger = LoggerFactory.getLogger(SettingsAPI.class);

    @Inject
    UserProvider userProvider;

    @Inject
    EntityManager entityManager;

    @Inject
    SettingsDAO settingsDAO;

    public SettingsAPI() {
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public UserReportSettingDTO get() throws PersistenceException {
        String userId = userProvider.getCurrentUser().getName();

        logger.info("Gettings settings for {}", userId);

        assert userId != null && !userId.isEmpty();

        UserReportSetting reportSetting = settingsDAO.getSettings(userId);

        return Mapper.userReportSetting(reportSetting);
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response update(UserReportSettingDTO newSettings) throws PersistenceException {
        try {

            entityManager.getTransaction().begin();

            String userId = userProvider.getCurrentUser().getName();

            logger.info("Updating settings for {}", userId);
            logger.info("Received settings: {}", newSettings);

            if (isEmptyOrNull(userId) || isEmptyOrNull(newSettings.reportId) || isEmptyOrNull(newSettings.viewId)) {
                return Response.serverError()
                        .entity("User, reportId or viewId is null")
                        .build();
            }

            UserReportSetting reportSetting = entityManager.createQuery("SELECT s FROM UserReportSetting s WHERE s.userId = :user", UserReportSetting.class)
                    .setParameter("user", userId)
                    .getSingleResult();

            // update values
            reportSetting.setUserId(userId);
            reportSetting.setApplications(newSettings.applications);
            reportSetting.setReportId(newSettings.reportId);
            reportSetting.setViewId(newSettings.viewId);
            reportSetting.setTimeFrom(newSettings.timeFrom);
            reportSetting.setTimeTo(newSettings.timeTo);
            reportSetting.setTimeInterval(newSettings.timeInterval);

            // handle time
            if (Instant.now().toEpochMilli() <= newSettings.timeTo) {
                logger.info("Converting Setting to relative");

                // convert to relative
                reportSetting.setTimeDuration(newSettings.timeTo - newSettings.timeFrom);
                reportSetting.setTimeFrom(-1);
                reportSetting.setTimeTo(-1);

            }

            entityManager.getTransaction().commit();

            return Response.ok().build();
        } catch (Exception e) {
            logger.error("Exception updating the settings", e);
            return Response.serverError().build();
        }
    }

    public static boolean isEmptyOrNull(String value) {
        return value == null || value.isEmpty();
    }

}