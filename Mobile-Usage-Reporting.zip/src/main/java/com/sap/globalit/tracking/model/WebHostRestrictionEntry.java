package com.sap.globalit.tracking.model;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Application Usage for Web Applications can be restricted to some hosts using
 * whitelisting or blacklisting
 *
 * @author D053397
 */
@Entity
@IdClass(WebHostRestrictionEntry.Id.class)
public class WebHostRestrictionEntry {
    /**
     * corresponds to window.location.host of the browser e.g.
     * "veui5infra.dhcp.wdf.sap.corp:8080" or "www.google.de"
     */
    @javax.persistence.Id
    private String host;

    @ManyToOne
    @javax.persistence.Id
    private Application application;

    public enum Type {
        BLACKLIST, WHITELIST
    }

    @Enumerated(EnumType.STRING)
    private Type restrictionType;

    public WebHostRestrictionEntry() {

    }

    public WebHostRestrictionEntry(String host, Application application,
                                   Type restrictionType) {
        super();
        this.host = host;
        this.application = application;
        this.restrictionType = restrictionType;
    }

    public static class Id implements Serializable {

        private String application;
        private String host;

        public Id() {
        }

        public Id(String application, String host) {
            this.application = application;
            this.host = host;
        }

    }

}
