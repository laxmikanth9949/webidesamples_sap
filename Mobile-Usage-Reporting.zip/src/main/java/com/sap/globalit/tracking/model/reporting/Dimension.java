package com.sap.globalit.tracking.model.reporting;

public class Dimension extends DataRow {

	public Dimension(String name) {
		super("Dimension", name);
	}

}
