package com.sap.globalit.tracking.api.sainternal;

import com.sap.globalit.tracking.dao.ApplicationPlattformDAO;
import com.sap.globalit.tracking.dto.ApplicationPlatformDTO;
import com.sap.globalit.tracking.dto.Mapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.List;
import java.util.stream.Collectors;

@Path("/sa-internal/platform")
@Api(value = "Platform Admin", description = "Platform Admin Service")
public class ApplicationPlatformAPI {

    private static Logger logger = LoggerFactory.getLogger(ApplicationPlatformAPI.class);

    @Inject
    ApplicationPlattformDAO platformDAO;

    public ApplicationPlatformAPI() {
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value = "Get all")
    public List<ApplicationPlatformDTO> getAll() {
        List<ApplicationPlatformDTO> all = platformDAO.getAll()
                .stream()
                .map(Mapper::platform)
                .collect(Collectors.toList());
        return all;
    }

}