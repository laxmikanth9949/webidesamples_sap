package com.sap.globalit.tracking.util;

import com.sap.globalit.tracking.model.reporting.Chart;
import com.sap.globalit.tracking.model.reporting.DataRow;
import com.sap.globalit.tracking.model.reporting.Table;

import java.util.ArrayList;
import java.util.List;

public class CSVWriter {

    private static final String separator = ";";

    public static CSVDocument generateCSV(Table table) {
        return new CSVDocument(createCSV_Updated(table));
    }

    private static List<String> createCSV_Updated(Table table) {
        List<String> result = new ArrayList<>();

        List<DataRow> rows = table.getColumns();

        // create header row
        String firstRow = "";
        for (DataRow row : rows) {
            firstRow += row.getName() + separator;
        }
        result.add(firstRow);

        // create rows for entries
        List<Chart.ChartData> tableData = table.getTableData();
        for (Chart.ChartData tableRows : tableData) {

            String csvRow = "";
            for (DataRow col : rows) {
                String key = col.getKey();
                Object entry = tableRows.get(key);
                csvRow += entry + separator;
            }

            result.add(csvRow);
        }

        return result;
    }

    private CSVWriter() {
    }

    public static class CSVDocument {

        private static final String NEW_LINE = "\r\n";
        List<String> rows;

        CSVDocument(List<String> rows) {
            this.rows = rows;
        }

        public String getContent() {
            String response = "sep=" + separator + NEW_LINE;
            for (String s : rows) {
                response += s + NEW_LINE;
            }
            return response;
        }

        public String getRow(int i) {
            return rows.get(i);
        }

    }

}
