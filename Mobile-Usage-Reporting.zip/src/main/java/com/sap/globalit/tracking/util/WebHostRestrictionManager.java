package com.sap.globalit.tracking.util;

import com.sap.globalit.tracking.model.WebHostRestrictionEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.regex.Pattern;

public class WebHostRestrictionManager {

    private static Pattern localhostPattern = Pattern.compile("(localhost):([0-9]+)");

    private static Logger logger = LoggerFactory.getLogger(WebHostRestrictionManager.class);

    @Inject
    EntityManager em;

    public boolean isAllowed(String appId, String host) {

        if (localhostPattern.matcher(host).matches()) {
            logger.debug("{} | Ignoring local development ({})", appId, host);
            return false;
        }

        // if (any) whitelist is available -> all others are blacklisted
        long whitelistEntries = em
                .createQuery(
                        "SELECT count(e) FROM WebHostRestrictionEntry e WHERE e.application.id = :id AND e.restrictionType = :type",
                        Long.class).setParameter("id", appId)
                .setParameter("type", WebHostRestrictionEntry.Type.WHITELIST)
                .getSingleResult();

        if (whitelistEntries > 0) {
            // check if host is whitelisted

            long count = em
                    .createQuery(
                            "SELECT count(e) FROM WebHostRestrictionEntry e WHERE e.application.id = :id AND e.restrictionType = :type AND e.host = :host",
                            Long.class)
                    .setParameter("id", appId)
                    .setParameter("type",
                            WebHostRestrictionEntry.Type.WHITELIST)
                    .setParameter("host", host).getSingleResult();

            if (count >= 1) {
                logger.debug("{} | Host {} is explicitly whitelisted => allow",
                        appId, host);
                return true;
            } else {
                logger.debug(
                        "{} | Host {} is not explicitly whitelisted => deny",
                        appId, host);
                return false;
            }
        } else {
            // if no whiltelist is available -> check for blacklisted entry
            long blacklisted = em
                    .createQuery(
                            "SELECT count(e) FROM WebHostRestrictionEntry e WHERE e.application.id = :id AND e.restrictionType = :type AND e.host = :host",
                            Long.class)
                    .setParameter("id", appId)
                    .setParameter("type",
                            WebHostRestrictionEntry.Type.BLACKLIST)
                    .setParameter("host", host).getSingleResult();

            if (blacklisted == 0) {
                logger.debug("{} | Host {} is not blacklisted => allow", appId,
                        host);
                return true;
            } else {
                logger.debug("{} | Host {} is explicitly blacklisted => deny",
                        appId, host);
                return false;
            }
        }

    }
}
