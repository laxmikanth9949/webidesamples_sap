package com.sap.globalit.tracking.util;

import com.sap.globalit.tracking.api.ApplicationUsageAPI;

import java.util.List;
import java.util.Locale;

public class BrowserCountryProvider {

    public static String get(String acceptHeader, String fallback) {

        List<Locale.LanguageRange> languageRanges = Locale.LanguageRange.parse(acceptHeader.replace("_", "-"));

        if (languageRanges.isEmpty())
            return ApplicationUsageAPI.normalizeCountryCode(fallback);

        return ApplicationUsageAPI.normalizeCountryCode(languageRanges.get(0).getRange());

    }

}
