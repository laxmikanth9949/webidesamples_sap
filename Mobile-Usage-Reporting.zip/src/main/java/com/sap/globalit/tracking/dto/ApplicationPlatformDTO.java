package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;
import com.sap.globalit.tracking.model.ApplicationPlattform;

/**
 * Created by D053397 on 10.08.2016.
 */
public class ApplicationPlatformDTO {

    @Expose
    ApplicationDTO application;

    @Expose
    ApplicationPlattform.PlatformType platform;

    public ApplicationPlatformDTO(ApplicationDTO application, ApplicationPlattform.PlatformType platform) {
        this.application = application;
        this.platform = platform;
    }
}
