package com.sap.globalit.tracking.scheduling;

import com.sap.globalit.tracking.api.internal.ReportAPI.TimeInterval;
import com.sap.globalit.tracking.api.internal.v2.report.ReportBuilder;
import com.sap.globalit.tracking.authorization.AuthorizationManager;
import com.sap.globalit.tracking.dao.ApplicationDAO;
import com.sap.globalit.tracking.dao.MonthlyUpdateOptOutDAO;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.model.reporting.Chart;
import com.sap.globalit.tracking.monthlyupdate.MonthlyUpdateReport;
import com.sap.globalit.tracking.monthlyupdate.MonthlyUpdateReport.MonthlyUpdateApplicationEntry;
import com.sap.globalit.tracking.monthlyupdate.MonthlyUpdateReport.MonthlyUpdateApplicationMeasure;
import com.sap.globalit.tracking.util.ChartUtil;
import com.sap.globalit.tracking.util.MailHelper;
import com.sap.it.mobile.hcp.service.email.HCPEmail;
import com.sap.it.mobile.hcp.service.email.HCPEmailException;
import com.sap.security.um.UMException;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.mail.MessagingException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.sql.SQLException;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public class MonthlyUpdateJob extends RequestScopedJob {

    private static Logger log = LoggerFactory.getLogger(MonthlyUpdateJob.class);

    @Inject
    public ReportBuilder chartBuilder;

    @Inject
    public MonthlyUpdateOptOutDAO subscriptionDAO;

    @Inject
    public ApplicationDAO appDAO;

    @Inject
    public AuthorizationManager authManager;

    @Inject
    public MailHelper mailHelper;

    private Set<String> recipients;

    @Override
    public void executeInRequestScope(JobExecutionContext var1) throws JobExecutionException {
        log.info("Monthly Update Job started");
        setForAllRegisteredUsers();
        sendMonthlyUpdateMail();
        log.info("Monthly Update Job finished");
    }

    private void setForAllRegisteredUsers() {
        // get all Users
        recipients = authManager.getUsersWithAtLeastOneAuthorization();
    }

    private void sendMonthlyUpdateMail() {

        try {

            log.trace("Generating Monthly Udpate");
            ZonedDateTime now = ZonedDateTime.now(ZoneId.of("UTC"));

            // today is 01.07. -> start: 01.05.
            ZonedDateTime start = now
                    .minus(2, ChronoUnit.MONTHS)
                    .with(TemporalAdjusters.firstDayOfMonth())
                    .with(LocalTime.MIN);
            log.trace("Start: " + start.toString());

            // today is 01.07. -> end: 31.06.
            ZonedDateTime end = now
                    .minusMonths(1)
                    .with(TemporalAdjusters.lastDayOfMonth())
                    .with(LocalTime.MAX);
            log.trace("End: " + end.toString());

            // compute charts
            Chart chartUsage = chartBuilder.getChart_Usage_ByApp(start, end, TimeInterval.MONTH, appDAO.getAllIds());
            Chart chartActiveDevices = chartBuilder.getChart_ActiveDevices_ByApp(start, end, TimeInterval.MONTH, appDAO.getAllIds());

            if (recipients == null) {
                throw new RuntimeException("Recipients not defined!");
            }

            List<HCPEmail> emails = recipients.stream()
                    .map(user -> processUser(end, chartUsage, chartActiveDevices, user))
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());

            mailHelper.sendMails(emails);
        } catch (HCPEmailException e) {
            log.error("Exception sending mails", e);
        } catch (SQLException e) {
            log.error("Error building charts", e);
        }
    }

    private HCPEmail processUser(ZonedDateTime end, Chart chartUsage, Chart chartActiveDevices, String user) {
        try {
            log.debug("Generating Report for " + user);

            List<Application> subscribedApps = subscriptionDAO.getSubscribedAppIdForUser(user)
                    .stream().sorted(Application.SORT_BY_NAME)
                    .collect(Collectors.toList());

            log.trace("Building report for apps " + subscribedApps);

            MonthlyUpdateReport report = new MonthlyUpdateReport(end.format(DateTimeFormatter.ofPattern("MMMM yyyy")));

            for (Application app : subscribedApps) {
                try {
                    MonthlyUpdateApplicationMeasure entry = getEntry(chartActiveDevices, app, "Devices");

                    MonthlyUpdateApplicationMeasure entryUsage = getEntry(chartUsage, app, "Usage");

                    MonthlyUpdateApplicationEntry applicationEntry = new MonthlyUpdateApplicationEntry(app.getName());
                    applicationEntry.addMeasure(entry);
                    applicationEntry.addMeasure(entryUsage);

                    report.addEntry(applicationEntry);
                } catch (Exception e) {
                    // TODO improve exception handling
                    log.trace("No data for {}", app);
                }
            }

            if (report.doesContainData()) {
                log.trace(report.generateMailBody());
                return mailHelper.generateMail(user, "Global IT Mobile Usage Reporting - Monthly Update", report.generateMailBody());
            } else {
                log.debug("Monthly Update for {} does not contain any data...", user);
                return null;
            }
        } catch (IOException | URISyntaxException | UMException | MessagingException e) {
            log.warn("Error generating mail for {} {}", user, e);
            return null;
        }
    }

    MonthlyUpdateApplicationMeasure getEntry(Chart chart,
                                             Application app, String measure) {

        long valueA = getValue(chart, app.getName(), 0);
        long valueB = getValue(chart, app.getName(), 1);

        return new MonthlyUpdateApplicationMeasure(measure, valueA, valueB);
    }

    long getValue(Chart chart, String app, int pos) {
        Long value = (Long) chart.getChartData().get(pos).get(ChartUtil.cleanStringForReferenceInJS(app));
        return value;
    }

}