package com.sap.globalit.tracking.model.reporting;

public class Measure extends DataRow {

    public Measure(String name) {
        super("Measure", name);
    }

}
