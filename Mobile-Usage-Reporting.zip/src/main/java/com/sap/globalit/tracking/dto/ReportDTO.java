package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;

import java.util.List;

/**
 * Created by D053397 on 16.08.2016.
 */
public class ReportDTO {

    @Expose
    public String id;

    @Expose
    public String title;

    @Expose
    public String icon;

    @Expose
    public int pos;

    @Expose
    public List<ReportViewDTO> views;

    @Expose
    public String hint;

    public ReportDTO(String id, String title, String icon, int pos, List<ReportViewDTO> views, String hint) {
        this.id = id;
        this.title = title;
        this.icon = icon;
        this.pos = pos;
        this.views = views;
        this.hint = hint;
    }
}
