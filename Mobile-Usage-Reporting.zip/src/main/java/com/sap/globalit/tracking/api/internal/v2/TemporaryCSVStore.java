package com.sap.globalit.tracking.api.internal.v2;

import java.util.HashMap;

public class TemporaryCSVStore extends HashMap<String, String> {

}
