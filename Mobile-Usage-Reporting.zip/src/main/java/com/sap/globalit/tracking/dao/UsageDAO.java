package com.sap.globalit.tracking.dao;

import com.google.common.base.Strings;
import com.sap.globalit.tracking.api.ApplicationUsageAPI;
import com.sap.globalit.tracking.model.Usage;
import com.sap.globalit.tracking.util.DBSequence;
import com.sap.globalit.tracking.util.Timer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Provider;
import javax.ws.rs.BadRequestException;
import java.sql.*;
import java.time.Instant;
import java.util.Objects;

/**
 * Created by D053397 on 19.04.2017.
 */
public class UsageDAO {

    private static final Logger logger = LoggerFactory.getLogger(UsageDAO.class);

    static final String USERINFO_STMT = "INSERT INTO USERINFORMATION(ID,USERID) VALUES (?,?)";
    static final String UPDATE_USERINFO = "UPDATE USAGE SET USER_INFORMATION_ID = ? WHERE USAGE_ID = ?";

    @Inject
    Provider<Connection> connectionProvider;

    @Inject
    @Named("USAGE_SEQUENCE")
    DBSequence usageSequence;

    @Inject
    @Named("EVENT_SEQUENCE")
    DBSequence eventSequence;

    @Inject
    @Named("USERINFO_SEQUENCE")
    DBSequence userinfoSequence;

    // for test
    public void setup(Provider<Connection> connectionProvider, DBSequence usageSequence, DBSequence eventSequence) {
        this.connectionProvider = connectionProvider;
        this.usageSequence = usageSequence;
        this.eventSequence = eventSequence;
    }

    public void persistToDatabase(Usage usage, Timer timer) throws SQLException {
        // TODO merge report and usage

        // persist using jdbc
        try (Connection conn = connectionProvider.get();
             PreparedStatement usageStmt = conn.prepareStatement(ApplicationUsageAPI.USAGE_STMT);
             PreparedStatement eventStmt = conn.prepareStatement(ApplicationUsageAPI.EVENT_STMT);
             PreparedStatement platformStmt = conn.prepareStatement(ApplicationUsageAPI.PLATFORM_STMT)) {

            platformStmt.setString(1, usage.applicationId);
            platformStmt.setString(2, usage.platformId.name());
            ResultSet platformRS = platformStmt.executeQuery();
            if (!platformRS.next()) {
                throw new BadRequestException("Application or Platform does not exist: " + usage.applicationId + " / " + usage.platformId);
            }
            timer.tag("Find Platform");

            conn.setAutoCommit(false);


            usage.usageId = usageSequence.next(conn);
            usage.insertedAt = Instant.now();

            usageStmt.setTimestamp(1, Timestamp.from(usage.insertedAt));
            usageStmt.setString(2, usage.referer);
            usageStmt.setString(3, usage.countryCode);
            usageStmt.setString(4, usage.deviceId);
            usageStmt.setString(5, String.valueOf(usage.deviceType));
            usageStmt.setString(6, usage.modelName);
            usageStmt.setString(7, usage.operatingSystem);
            usageStmt.setString(8, usage.rawUserAgent);
            usageStmt.setDouble(9, usage.screenSize);
            usageStmt.setTimestamp(10, Timestamp.from(usage.usageStart));
            usageStmt.setTimestamp(11, Timestamp.from(usage.usageEnd));
            usageStmt.setNull(12, Types.BIGINT); // no userinformation
            usageStmt.setString(13, usage.applicationId);
            usageStmt.setString(14, usage.versionId);
            usageStmt.setString(15, String.valueOf(usage.platformId));
            usageStmt.setLong(16, usage.usageId);
            usageStmt.setString(17, usage.origin);

            // TODO usage.browserLocationHost
            if (usageStmt.executeUpdate() != 1)
                throw new SQLException("Insert failed!");

            timer.tag("Persist via JDBC (Usage)");

            int eventCount = 0;

            // insert events
            for (Usage.Event eventReported : usage.events) {
                if (Objects.isNull(eventReported) || Strings.isNullOrEmpty(eventReported.name) || eventReported.name.contains("\\")) {
                    logger.warn("Application {} reported an null or empty or invalid event", usage.applicationId);
                    continue;
                }

                eventStmt.setLong(1, eventSequence.next(conn));
                eventStmt.setTimestamp(2, Timestamp.from(Instant.now()));
                eventStmt.setLong(3, usage.usageId);
                eventStmt.setString(4, eventReported.name);
                eventStmt.setTimestamp(5, Timestamp.from(eventReported.instant));
                eventStmt.addBatch();
                eventCount++;
            }
            if (eventCount > 0)
                eventStmt.executeBatch();

            // insert user Info
            if (usage.userInformation != null && ApplicationUsageAPI.isValidUserInfo(usage.userInformation.userId)) {

                long userInfoId = insertUserInfo(conn, usage.userInformation.userId);
                attachUserInfoToUsage(conn, usage.usageId, userInfoId); // TODO could be done before inserting the usage

            }

            timer.tag("Persist via JDBC (" + eventCount + " Events)");

            conn.commit();

            conn.setAutoCommit(true);
        }
    }

    private void attachUserInfoToUsage(Connection conn, long usageId, long userinfoId) throws SQLException {
        try (PreparedStatement usageUpdate = conn.prepareStatement(UPDATE_USERINFO)) {
            usageUpdate.setLong(1, userinfoId);
            usageUpdate.setLong(2, usageId);
            usageUpdate.executeUpdate();
        }
    }

    private long insertUserInfo(Connection conn, String userId) throws SQLException {
        try (PreparedStatement userinfoStmt = conn.prepareStatement(USERINFO_STMT)) {
            long userinfoId = userinfoSequence.next(conn);

            userinfoStmt.setLong(1, userinfoId);
            userinfoStmt.setString(2, userId);
            userinfoStmt.executeUpdate();

            return userinfoId;
        }
    }
}
