package com.sap.globalit.tracking.dto;

// {"version":{"plattform":{"id":"WEB","application":{"displayName":"Jumble"}}},"deviceInformation":{"countryCode":"DE"}}
public class WebsocketMessageDTO {

    public Version version;
    public DeviceInformation deviceInformation;

    public WebsocketMessageDTO(Version version, DeviceInformation deviceInformation) {
        this.version = version;
        this.deviceInformation = deviceInformation;
    }

    public static class Version {
        // this is not a typo, just an "alternative version" :p
        public Platform plattform;

        public Version(Platform plattform) {
            this.plattform = plattform;
        }
    }

    public static class Platform {
        public String id;
        public Application application;

        public Platform(String id, Application application) {
            this.id = id;
            this.application = application;
        }
    }

    public static class Application {
        public String id;
        public String displayName;

        public Application(String displayName, String id) {
            this.displayName = displayName;
            this.id = id;
        }
    }

    public static class DeviceInformation {
        public String countryCode;

        public DeviceInformation(String countryCode) {
            this.countryCode = countryCode;
        }
    }
}
