package com.sap.globalit.tracking;

import com.sap.globalit.tracking.filter.*;
import net.sf.uadetector.service.UADetectorServiceFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.DispatcherType;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.util.EnumSet;

/**
 * Created by D053397 on 13.10.2016.
 */
public class ServletConfigListener implements ServletContextListener {

    public static final Logger log = LoggerFactory.getLogger(ServletConfigListener.class);

    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {

        ServletContext context = servletContextEvent.getServletContext();

        // (0) Rewriting
        context.addFilter("REWRITE", RewriteFilter.class)
                .addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD), false, "/*");

        // (1) Check Access
        context.addFilter("ACCESS", AccessFilter.class)
                .addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD), false, "/*");

        // (2) Serve Static Files
        context.addFilter("STATIC", StaticFileFilter.class)
                .addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD), false, "/*");

        // (3) CORS
        context.addFilter("CORS", CORSFilter.class)
                .addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD), false, "/web-client/*", "/api/usage", "/api/usage/addEvent/*");

        // (4) WebClient URL Filter
        context.addFilter("URL", WebClientUrlFilter.class)
                .addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD), false, "/web-client/v3/*");
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {
        log.debug("Shutting down...");

        // destroy UAP
        UADetectorServiceFactory.getCachingAndUpdatingParser().shutdown();

        log.debug("Shutdown completed!");
    }
}
