package com.sap.globalit.tracking.dto;

/**
 * Created by D053397 on 04.11.2016.
 */
public class ShowroomEventEntryDTO {

    String moment;
    long count;

    public String getMoment() {
        return moment;
    }

    public ShowroomEventEntryDTO setMoment(String moment) {
        this.moment = moment;
        return this;
    }

    public long getCount() {
        return count;
    }

    public ShowroomEventEntryDTO setCount(long count) {
        this.count = count;
        return this;
    }
}
