package com.sap.globalit.tracking.api.internal;

import com.google.gson.annotations.Expose;
import com.sap.globalit.tracking.dto.ApplicationDTO;
import com.sap.globalit.tracking.dto.Mapper;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.model.authorization.SingleAppAuthorization;
import com.sap.globalit.tracking.util.MailHelper;
import com.sap.it.mobile.hcp.service.email.HCPEmail;
import com.sap.it.mobile.hcp.service.email.HCPEmailException;
import com.sap.security.um.user.PersistenceException;
import com.sap.security.um.user.UnsupportedUserAttributeException;
import com.sap.security.um.user.User;
import com.sap.security.um.user.UserProvider;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.persistence.EntityManager;
import javax.persistence.RollbackException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.*;
import java.util.stream.Collectors;

@Path("/internal/authorization")
@Api(value = "Authorization API", description = "Authorization Service")
public class RequestAuthorizationAPI {

    private static Logger logger = LoggerFactory.getLogger(RequestAuthorizationAPI.class);

    public RequestAuthorizationAPI() {
    }

    @Inject
    MailHelper mailHelper;

    @Inject
    HttpServletRequest request;

    @Inject
    EntityManager em;

    @Inject
    UserProvider userProvider;

    public static class AuthorizationRequest {
        @Expose
        String userId;
        @Expose
        String reason;
        @Expose
        String[] apps;
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("whoami")
    public Map<String, String> whoAmI() {
        HashMap<String, String> result = new HashMap<>();
        result.put("id", request.getRemoteUser());
        return result;
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("whatDoYouKnowAboutMe")
    public Map<String, String> whatDoYouKnowAboutMe() throws PersistenceException, UnsupportedUserAttributeException {
        HashMap<String, String> result = new HashMap<>();
        User user = userProvider.getCurrentUser();

        for (String s: user.listAttributes()) {
            result.put(s, user.getAttribute(s));
        }

        return result;
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("apps/{id}")
    public List<ApplicationDTO> appsWithoutAccessRequest(@PathParam("id") String id) {
        return em.createQuery("SELECT x FROM Application x LEFT JOIN SingleAppAuthorization a ON (x = a.app AND a.userId = :id) WHERE a is null", Application.class)
                .setParameter("id", id)
                .getResultList()
                .stream()
                .sorted(Application.SORT_BY_NAME)
                .map(Mapper::application)
                .collect(Collectors.toList());
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("request")
    public Response requestAccessOther(AuthorizationRequest authRequest) {
        try {

            em.getTransaction().begin();

            // validate input
            authRequest.userId = authRequest.userId.toUpperCase();

            for (String appId: authRequest.apps) {
                Application app = em.find(Application.class, appId);
                SingleAppAuthorization authorization = new SingleAppAuthorization(authRequest.userId, app, authRequest.reason);
                authorization.setStatus(SingleAppAuthorization.Status.PENDING);
                em.persist(authorization);
            }

            sendRequestNotification(authRequest.userId, Arrays.toString(authRequest.apps));

            em.getTransaction().commit();

            return Response.status(201).build();
        } catch (RollbackException e) {
            logger.error("Error while requesting access ", e);
            return Response.serverError()
                    .entity("Authorization already requested").build();
        } catch (IOException | URISyntaxException | MessagingException | HCPEmailException e) {
            logger.error("Error while requesting access ", e);
            return Response.serverError().build();
        }
    }

    private void sendRequestNotification(String user, String appId) throws HCPEmailException, MessagingException, IOException, URISyntaxException {
        String header = "Tracking Access Requested";

        String body = "Hi, \n\n"
                + "the user "
                + user
                + " requested access to reports of the application "
                + appId
                + "\n \n"
                + "https://mobileusage-sapitcloud.dispatcher.hana.ondemand.com/webapp/index.html#admin/user/" + user;

        HCPEmail email = mailHelper.generateMail("DL_5322C8C6DF15DB06CA003BD9", header, body);
        mailHelper.sendMails(Collections.singletonList(email));
    }

}