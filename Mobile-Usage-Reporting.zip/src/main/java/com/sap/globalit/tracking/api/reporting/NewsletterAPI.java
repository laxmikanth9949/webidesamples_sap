package com.sap.globalit.tracking.api.reporting;

import com.sap.globalit.tracking.authorization.AuthorizationManager;
import com.sap.globalit.tracking.dao.MonthlyUpdateOptOutDAO;
import com.sap.globalit.tracking.dto.SubscriptionStatus;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.model.monthlyupdate.MonthlyUpdateOptOut;
import com.sap.security.um.UMException;
import com.sap.security.um.user.PersistenceException;
import com.sap.security.um.user.User;
import com.sap.security.um.user.UserProvider;
import io.swagger.annotations.Api;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This API is tailored to the Reporting UI
 * <p>
 * PROD: https://fiorilaunchpad.sap.com/sites#MU-Reporting
 * DEV: https://mobileusage-sapitcloudd.dispatcher.hana.ondemand.com
 */
@Path("reporting/newsletter")
@Api(value = "Reporting UI - Newsletter")
public class NewsletterAPI {

    @Inject
    MonthlyUpdateOptOutDAO monthlyUpdateDAO;

    @Inject
    AuthorizationManager authDAO;

    @Inject
    UserProvider userProvider;

    @GET
    @Path("mySubscriptions")
    /**
     * returns the subscription status of the current user
     * includes all applications where the user has access to
     * contains of a key value pair <appid> : <true/false>
     */
    public List<SubscriptionStatus> getMySubscriptions() throws UMException {

        User user = userProvider.getCurrentUser();

        List<MonthlyUpdateOptOut> monthlyUpdate = monthlyUpdateDAO.getOptOutForUser(user.getName());

        List<Application> apps = authDAO.getAuthorizedAppsFor(user.getName());

        return apps.stream()
                .sorted(Application.SORT_BY_NAME)
                .map(app -> new SubscriptionStatus(app.getId(), app.getName(), !userDidOptOut(monthlyUpdate, app.getId())))
                .collect(Collectors.toList());
    }

    @POST
    @Path("updateSubscription")
    public Response changeSubscription(SubscriptionStatus newStatus) throws PersistenceException {
        User user = userProvider.getCurrentUser();

        if (newStatus.appId == null) {
            return Response.serverError().build();
        }

        if (newStatus.isSubscribed) {
            monthlyUpdateDAO.ensureSubscribed(newStatus.appId, user.getName());
        } else {
            monthlyUpdateDAO.ensureUnsubscribed(newStatus.appId, user.getName());
        }

        return Response.ok().build();
    }

    public static boolean userDidOptOut(List<MonthlyUpdateOptOut> optOuts,
                                        String appId) {
        for (MonthlyUpdateOptOut optOut : optOuts) {
            // app getApplication might be null -> application removed in the meanwhile
            if (optOut.getApplication() != null && optOut.getApplication().getId().equals(appId))
                return true;
        }
        return false;
    }

}
