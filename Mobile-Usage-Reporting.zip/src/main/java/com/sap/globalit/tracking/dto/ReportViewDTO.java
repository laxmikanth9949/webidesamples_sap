package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;

import java.util.List;

/**
 * Created by D053397 on 16.08.2016.
 */
public class ReportViewDTO {

    public enum Type {
        CHART, BAR, TABLE, LINK
    }

    public enum Mode {
        GLOBAL, MULTIPLE, GCO, REALTIME, SINGLE
    }

    @Expose
    public String id;

    @Expose
    public String icon;

    @Expose
    public Type type;

    @Expose
    public Mode mode;

    @Expose
    public String url;

    @Expose
    public String text;

    @Expose
    public List<String> filter;

    public ReportViewDTO(String id, String icon, Type type, Mode mode, String url) {
        this.id = id;
        this.icon = icon;
        this.type = type;
        this.mode = mode;
        this.url = url;
    }

    public ReportViewDTO(String id, String icon, Type type, Mode mode, String url, String text, List<String> filter) {
        this.id = id;
        this.icon = icon;
        this.type = type;
        this.mode = mode;
        this.url = url;
        this.text = text;
        this.filter = filter;
    }
}
