package com.sap.globalit.tracking.api.sainternal;

import io.swagger.annotations.Api;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import java.util.*;

@Path("/sa-internal/statistics")
@Api(value = "Statistics API", description = "Statistics Service")
public class StatisticsAPI {

    @GET
    @Path("threads")
    public List<Object> getThreads() {
        Map<Thread, StackTraceElement[]> t = Thread.getAllStackTraces();
        List<Object> json = new ArrayList<>();
        for (Map.Entry<Thread, StackTraceElement[]> threadEntry : t.entrySet()) {
            Map<String, Object> thread = new LinkedHashMap<>();
            thread.put("thread", threadEntry.getKey().toString());
            thread.put("stackTrace", Arrays.toString(threadEntry.getValue()));
            json.add(thread);
        }
        return json;
    }
}
