package com.sap.globalit.tracking.model.analysis;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.List;

/**
 * Created by D053397 on 15.01.2015.
 */
@Entity
public class ReportView {

    @Id
    @GeneratedValue
    long id;

    String reportingUser;

    @ElementCollection
    List<String> applications;

    String report;

    String reportView;

    long requestDate;

    long timeFrom;

    long timeTo;

    String timeInterval;

    public ReportView() {
    }

    public ReportView(String user, List<String> applications, String report, String reportView, long requestDate, long timeFrom, long timeTo, String timeInterval) {
        this.reportingUser = user;
        this.applications = applications;
        this.report = report;
        this.reportView = reportView;
        this.requestDate = requestDate;
        this.timeFrom = timeFrom;
        this.timeTo = timeTo;
        this.timeInterval = timeInterval;
    }

    @Override
    public String toString() {
        return "ReportView{" +
                "user='" + reportingUser + '\'' +
                ", applications=" + applications +
                ", report='" + report + '\'' +
                ", reportView='" + reportView + '\'' +
                ", requestDate=" + requestDate +
                ", timeFrom=" + timeFrom +
                ", timeTo=" + timeTo +
                ", timeInterval=" + timeInterval +
                '}';
    }
}
