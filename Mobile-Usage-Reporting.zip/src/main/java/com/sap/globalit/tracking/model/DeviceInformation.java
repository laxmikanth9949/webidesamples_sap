package com.sap.globalit.tracking.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

@Embeddable
public class DeviceInformation {

    public static final String FALLBACK_DEVICE_ID = "UNKNOWN";
    public static final double FALLBACK_SCREEN_SIZE = 0.0;
    public static final String FALLBACK_MODEL_NAME = "UNKNOWN MODEL";
    public static final String FALLBACK_COUNTRY_CODE = "";
    public static final String FALLBACK_OPERATING_SYSTEM = "";

    /**
     * Unique device id
     */
    @Column(length = 40)
    private String deviceId;

    /**
     * The physical screen size of the device in inch
     */
    private double screenSize;

    /**
     * The model name of the device, e.g. iPhone 4 or Samsung Galaxy SII
     */
    private String modelName;

    /**
     * contains the unprocessed user agent for web apps
     */
    private String raw_user_agent;

    /**
     * The current country of the device as ISO 3166-1
     */
    private String countryCode;

    /**
     * The version of the os
     */
    private String operatingSystem;

    /**
     * Mobile / Desktop
     */
    @Enumerated(EnumType.STRING)
    private DeviceType deviceType;

    protected DeviceInformation() {

    }

    public DeviceInformation(String deviceId, double screenSize,
                             String modelName, String countryCode, String operatingSystem) {
        this();
        this.deviceId = deviceId;
        this.screenSize = screenSize;
        this.modelName = modelName;
        this.countryCode = countryCode;
        this.operatingSystem = operatingSystem;
    }

    public void setRawUserAgent(String raw_user_agent) {
        this.raw_user_agent = raw_user_agent;
    }

    public String getRawUserAgent() {
        return raw_user_agent;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public double getScreenSize() {
        return screenSize;
    }

    public String getModelName() {
        return modelName;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public String getOperatingSystem() {
        return operatingSystem;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public void setScreenSize(double screenSize) {
        this.screenSize = screenSize;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public void setOperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    public void setDeviceType(DeviceType type) {
        this.deviceType = type;
    }

    public DeviceType getDeviceType() {
        return deviceType;
    }

    @Override
    public String toString() {
        return "DeviceInformation [deviceId=" + deviceId + ", screenSize="
                + screenSize + ", modelName=" + modelName + ", raw_user_agent="
                + raw_user_agent + ", countryCode=" + countryCode
                + ", operatingSystem=" + operatingSystem + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((countryCode == null) ? 0 : countryCode.hashCode());
        result = prime * result
                + ((deviceId == null) ? 0 : deviceId.hashCode());
        result = prime * result
                + ((modelName == null) ? 0 : modelName.hashCode());
        result = prime * result
                + ((operatingSystem == null) ? 0 : operatingSystem.hashCode());
        long temp;
        temp = Double.doubleToLongBits(screenSize);
        result = prime * result + (int) (temp ^ (temp >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        DeviceInformation other = (DeviceInformation) obj;
        if (countryCode == null) {
            if (other.countryCode != null)
                return false;
        } else if (!countryCode.equals(other.countryCode))
            return false;
        if (deviceId == null) {
            if (other.deviceId != null)
                return false;
        } else if (!deviceId.equals(other.deviceId))
            return false;
        if (modelName == null) {
            if (other.modelName != null)
                return false;
        } else if (!modelName.equals(other.modelName))
            return false;
        if (operatingSystem == null) {
            if (other.operatingSystem != null)
                return false;
        } else if (!operatingSystem.equals(other.operatingSystem))
            return false;
        return Double.doubleToLongBits(screenSize) == Double
                .doubleToLongBits(other.screenSize);
    }

    /**
     * Fallback value for old versions of the tracking api
     *
     * @return
     */
    public static DeviceInformation getFallback() {
        return new DeviceInformation(FALLBACK_DEVICE_ID, FALLBACK_SCREEN_SIZE,
                FALLBACK_MODEL_NAME, FALLBACK_COUNTRY_CODE,
                FALLBACK_OPERATING_SYSTEM);
    }
}
