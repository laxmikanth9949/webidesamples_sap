package com.sap.globalit.tracking.util;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Timer {

    public static final String FORMAT = "-> %s: %d (+%d) \r\n";

    List<Map.Entry<String, Long>> list = new ArrayList<>();
    long time;

    public Timer() {
        this.time = System.currentTimeMillis();
    }

    public void tag(String name) {
        list.add(new AbstractMap.SimpleEntry<>(name, System.currentTimeMillis() - time));
    }

    public String getInfo() {
        if (list.isEmpty()) {
            return "no tags registered!";
        }

        StringBuilder sb = new StringBuilder("Start ");
        long prev = 0;
        for (Map.Entry<String, Long> entry : list) {
            sb.append(String.format(FORMAT, entry.getKey(), entry.getValue(), entry.getValue() - prev));
            prev = entry.getValue();
        }
        sb.append(" [ms]");
        return sb.toString();
    }
}