package com.sap.globalit.tracking.injection;

import org.glassfish.jersey.internal.inject.DisposableSupplier;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SchedulerFactory implements DisposableSupplier<Scheduler> {

    private static final Logger log = LoggerFactory.getLogger(SchedulerFactory.class);

    @Override
    public Scheduler get() {
        try {
            Scheduler scheduler = new StdSchedulerFactory().getScheduler();
            log.trace("Providing new Scheduler [{}]", scheduler);
            return scheduler;
        } catch (SchedulerException e) {
            log.error("Could not instantiate Scheduler", e);
            return null;
        }
    }

    @Override
    public void dispose(Scheduler scheduler) {
        log.trace("Disposing Scheduler [{}]", scheduler);
    }

}
