package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;
import com.sap.globalit.tracking.model.authorization.SingleAppAuthorization;

/**
 * Created by D053397 on 21.04.2016.
 */
public class AuthorizationDTO {
    @Expose
    public String type;
    @Expose
    public String appId;
    @Expose
    public long authId;
    @Expose
    public String userId;
    @Expose
    public String reason;
    @Expose
    public String approver;
    @Expose
    public SingleAppAuthorization.Status status;
    @Expose
    public long lastStatusModification;

    public AuthorizationDTO() {
    }

    public AuthorizationDTO(String type, String appId, long authId, String userId, String reason, String approver, SingleAppAuthorization.Status status, long lastStatusModification) {
        this.type = type;
        this.appId = appId;
        this.authId = authId;
        this.userId = userId;
        this.reason = reason;
        this.approver = approver;
        this.status = status;
        this.lastStatusModification = lastStatusModification;
    }
}
