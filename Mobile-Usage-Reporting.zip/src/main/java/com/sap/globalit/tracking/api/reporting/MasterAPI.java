package com.sap.globalit.tracking.api.reporting;

import com.sap.globalit.tracking.authorization.AuthorizationManager;
import com.sap.globalit.tracking.dao.ApplicationDAO;
import com.sap.globalit.tracking.dto.ApplicationDTO;
import com.sap.globalit.tracking.dto.Mapper;
import com.sap.globalit.tracking.dto.ReportDTO;
import com.sap.globalit.tracking.dto.ReportViewDTO;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.util.AppUtil;
import com.sap.security.um.user.PersistenceException;
import com.sap.security.um.user.UserProvider;
import io.swagger.annotations.Api;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This API is tailored to the Reporting UI
 * <p>
 * PROD: https://fiorilaunchpad.sap.com/sites#MU-Reporting
 * DEV: https://mobileusage-sapitcloudd.dispatcher.hana.ondemand.com
 */
@Path("reporting/master")
@Api(value = "Reporting UI - Master")
public class MasterAPI {

    private static final String LOCATION_HINT = "The location info is derived from the Locale setting of the device!";

    @Inject
    ApplicationDAO appDAO;

    @Inject
    AuthorizationManager authManager;

    @Inject
    UserProvider userProvider;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("apps")
    public List<ApplicationDTO> getAllWhichHaveUsage() throws PersistenceException {
        List<Application> appsWithUsage = appDAO.getAllWithRecentUsage();

        List<Application> authorizedApplications = authManager.getAuthorizedAppsFor(userProvider.getCurrentUser().getName());

        return AppUtil.filter(appsWithUsage, authorizedApplications)
                .stream()
                .sorted(Application.SORT_BY_NAME)
                .map(Mapper::application)
                .collect(Collectors.toList());
    }


    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("reports")
    public List<ReportDTO> getReports() throws PersistenceException {
        return Arrays.asList(
                new ReportDTO("iososversion", "iOS OS Version", "sap-icon://ipad", 1, Arrays.asList(
                        new ReportViewDTO("chart", "sap-icon://line-chart", ReportViewDTO.Type.CHART, ReportViewDTO.Mode.GLOBAL, "internal/report/v2/Global/OSVersion/IOS"),
                        new ReportViewDTO("table", "sap-icon://table-chart", ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GLOBAL, "internal/report/v2/Global/OSVersion/IOS/Table")
                ), null),
                new ReportDTO("androidosversion", "Android OS Version", "sap-icon://ipad", 1, Arrays.asList(
                        new ReportViewDTO("chart", "sap-icon://line-chart", ReportViewDTO.Type.CHART, ReportViewDTO.Mode.GLOBAL, "internal/report/v2/Global/OSVersion/ANDROID"),
                        new ReportViewDTO("table", "sap-icon://table-chart", ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GLOBAL, "internal/report/v2/Global/OSVersion/ANDROID/Table")
                ), null),
                new ReportDTO("devices", "Active Devices", "sap-icon://iphone", 2, Arrays.asList(
                        new ReportViewDTO("chart", "sap-icon://line-chart", ReportViewDTO.Type.CHART, ReportViewDTO.Mode.MULTIPLE, "internal/report/v2/ActiveDevices/ByApp"),
                        new ReportViewDTO("bar-chart", "sap-icon://horizontal-bar-chart", ReportViewDTO.Type.BAR, ReportViewDTO.Mode.MULTIPLE, "internal/report/v2/ActiveDevices/ByApp/Bar"),
                        new ReportViewDTO("table", "sap-icon://table-chart", ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.MULTIPLE, "internal/report/v2/ActiveDevices/ByApp/Table")
                ), null),
                new ReportDTO("usage", "Application Usage", "sap-icon://grid", 3, Arrays.asList(
                        new ReportViewDTO("chart", "sap-icon://line-chart", ReportViewDTO.Type.CHART, ReportViewDTO.Mode.MULTIPLE, "internal/report/v2/Usage/ByApp"),
                        new ReportViewDTO("bar-chart", "sap-icon://horizontal-bar-chart", ReportViewDTO.Type.BAR, ReportViewDTO.Mode.MULTIPLE, "internal/report/v2/Usage/ByApp/Bar"),
                        new ReportViewDTO("table", "sap-icon://table-chart", ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.MULTIPLE, "internal/report/v2/Usage/ByApp/Table")
                ), null),
                new ReportDTO("location", "Location", "sap-icon://map", 4, Arrays.asList(
                        new ReportViewDTO("table", "sap-icon://table-chart", ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.MULTIPLE, "internal/report/v2/Overview/Location/Table")
                ), LOCATION_HINT),
                new ReportDTO("events", "Events", "sap-icon://bookmark", 5, Arrays.asList(
                        new ReportViewDTO("chart", "sap-icon://line-chart", ReportViewDTO.Type.CHART, ReportViewDTO.Mode.SINGLE, "internal/report/v2/AppDetail/Events"),
                        new ReportViewDTO("table", "sap-icon://table-chart", ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.SINGLE, "internal/report/v2/AppDetail/Events/Table")
                ), null),
                new ReportDTO("device-type", "Device Type", "sap-icon://laptop", 6, Arrays.asList(
                        new ReportViewDTO("chart", "sap-icon://line-chart", ReportViewDTO.Type.CHART, ReportViewDTO.Mode.SINGLE, "internal/report/v2/AppDetail/DeviceType"),
                        new ReportViewDTO("table", "sap-icon://table-chart", ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.SINGLE, "internal/report/v2/AppDetail/DeviceType/Table")
                ), null),
                new ReportDTO("versions", "Version Distribution", "sap-icon://dimension", 7, Arrays.asList(
                        new ReportViewDTO("chart", "sap-icon://line-chart", ReportViewDTO.Type.CHART, ReportViewDTO.Mode.SINGLE, "internal/report/v2/AppDetail/ActiveUsers/ByVersion"),
                        new ReportViewDTO("table", "sap-icon://table-chart", ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.SINGLE, "internal/report/v2/AppDetail/ActiveUsers/ByVersion/Table")
                ), null),
                new ReportDTO("regions", "Region Distribution", "sap-icon://choropleth-chart", 8, Arrays.asList(
                        new ReportViewDTO("chart", "sap-icon://line-chart", ReportViewDTO.Type.CHART, ReportViewDTO.Mode.SINGLE, "internal/report/v2/AppDetail/ActiveUsers/ByRegion"),
                        new ReportViewDTO("table", "sap-icon://table-chart", ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.SINGLE, "internal/report/v2/AppDetail/ActiveUsers/ByRegion/Table")
                ), LOCATION_HINT),
                new ReportDTO("devicemodel", "Device Model Usage", "sap-icon://ipad", 9, Arrays.asList(
                        new ReportViewDTO("chart", "sap-icon://line-chart", ReportViewDTO.Type.CHART, ReportViewDTO.Mode.SINGLE, "internal/report/v2/AppDetail/DeviceModel"),
                        new ReportViewDTO("table", "sap-icon://table-chart", ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.SINGLE, "internal/report/v2/AppDetail/DeviceModel/Table")
                ), null),
                new ReportDTO("gco-active-devices-regional", "Active Devices - Regional", "sap-icon://iphone", 10, Arrays.asList(
                        new ReportViewDTO("all", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/ActiveDevices/ByRegionGCO/Table", "All", getFilterMajor("App")),
                        new ReportViewDTO("na", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/ActiveDevices/ByRegionGCO/Table", "NA", getFilterNA("App")),
                        new ReportViewDTO("la", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/ActiveDevices/ByRegionGCO/Table", "LA", getFilterLA("App")),
                        new ReportViewDTO("apj", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/ActiveDevices/ByRegionGCO/Table", "APJ", getFilterAPJ("App")),
                        new ReportViewDTO("mee", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/ActiveDevices/ByRegionGCO/Table", "MEE", getFilterMEE("App")),
                        new ReportViewDTO("emea", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/ActiveDevices/ByRegionGCO/Table", "EMEA", getFilterEMEA("App")),
                        new ReportViewDTO("gc", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/ActiveDevices/ByRegionGCO/Table", "GC", getFilterGC("App"))
                ), LOCATION_HINT),
                new ReportDTO("gco-usage-regional", "Usage - Regional", "sap-icon://grid", 11, Arrays.asList(
                        new ReportViewDTO("all", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/Usage/ByRegionGCO/Table", "All", getFilterMajor("App")),
                        new ReportViewDTO("na", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/Usage/ByRegionGCO/Table", "NA", getFilterNA("App")),
                        new ReportViewDTO("la", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/Usage/ByRegionGCO/Table", "LA", getFilterLA("App")),
                        new ReportViewDTO("apj", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/Usage/ByRegionGCO/Table", "APJ", getFilterAPJ("App")),
                        new ReportViewDTO("mee", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/Usage/ByRegionGCO/Table", "MEE", getFilterMEE("App")),
                        new ReportViewDTO("emea", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/Usage/ByRegionGCO/Table", "EMEA", getFilterEMEA("App")),
                        new ReportViewDTO("gc", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/Usage/ByRegionGCO/Table", "GC", getFilterGC("App"))
                ), LOCATION_HINT),
                new ReportDTO("gco-events-regional", "Events - Regional", "sap-icon://bookmark", 12, Arrays.asList(
                        new ReportViewDTO("all", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/AppDetail/EventsByGCORegion", "All", getFilterMajor("Event")),
                        new ReportViewDTO("na", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/AppDetail/EventsByGCORegion", "NA", getFilterNA("Event")),
                        new ReportViewDTO("la", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/AppDetail/EventsByGCORegion", "LA", getFilterLA("Event")),
                        new ReportViewDTO("apj", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/AppDetail/EventsByGCORegion", "APJ", getFilterAPJ("Event")),
                        new ReportViewDTO("mee", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/AppDetail/EventsByGCORegion", "MEE", getFilterMEE("Event")),
                        new ReportViewDTO("emea", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/AppDetail/EventsByGCORegion", "EMEA", getFilterEMEA("Event")),
                        new ReportViewDTO("gc", null, ReportViewDTO.Type.TABLE, ReportViewDTO.Mode.GCO, "internal/report/v2/AppDetail/EventsByGCORegion", "GC", getFilterGC("Event"))
                ), LOCATION_HINT),
                new ReportDTO("realtime-map", "Realtime - Map", "sap-icon://choropleth-chart", 13, Arrays.asList(
                        new ReportViewDTO("map", null, ReportViewDTO.Type.LINK, ReportViewDTO.Mode.REALTIME, "http://trackingshallwe.hana.ondemand.com/realtime/map")
                ), null),
                new ReportDTO("realtime-bubbles", "Realtime - Bubbles", "sap-icon://bubble-chart", 14, Arrays.asList(
                        new ReportViewDTO("bubbles", null, ReportViewDTO.Type.LINK, ReportViewDTO.Mode.REALTIME, "http://trackingshallwe.hana.ondemand.com/realtime/bubbles")
                ), null)
        );
    }

    private static List<String> getFilterMajor(String firstElement) {
        return Arrays.asList(firstElement, "All", "APJ", "LA", "NA", "EMEA", "MEE", "GC");
    }

    private static List<String> getFilterAPJ(String firstElement) {
        return Arrays.asList(firstElement, "APJ", "ANZ", "Japan", "India", "SEA", "Korea");
    }

    private static List<String> getFilterGC(String firstElement) {
        return Arrays.asList(firstElement, "GC", "Greater China", "Taiwan");
    }

    private static List<String> getFilterLA(String firstElement) {
        return Arrays.asList(firstElement, "LA", "SSSA North", "SSSA South", "Brazil", "Mexico", "Costa Rica");
    }

    private static List<String> getFilterNA(String firstElement) {
        return Arrays.asList(firstElement, "NA", "Canada", "US");
    }

    private static List<String> getFilterEMEA(String firstElement) {
        return Arrays.asList(firstElement, "EMEA", "France+Belux", "Africa", "South Europe", "UKI+Netherlands", "MENA+KSA", "Nordic");
    }

    private static List<String> getFilterMEE(String firstElement) {
        return Arrays.asList(firstElement, "MEE", "Germany", "CIS", "Switzerland", "CEE", "Austria");
    }

}