package com.sap.globalit.tracking.authorization;

import com.sap.globalit.tracking.model.authorization.SingleAppAuthorization;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AuthorizationDAO {

    @Inject
    EntityManager em;

    public List<SingleAppAuthorization> getAuthorizationsForUser(String userId) {
        return em.createQuery("SELECT a FROM SingleAppAuthorization a WHERE a.userId = :userId AND a.status = :status", SingleAppAuthorization.class)
                .setParameter("userId", userId)
                .setParameter("status", SingleAppAuthorization.Status.APPROVED)
                .getResultList();
    }

    public Set<String> getUsersWithAtLeastOneAuthorization() {
        return new HashSet<>(em
                .createQuery("SELECT distinct a.userId FROM SingleAppAuthorization a WHERE a.status = :status", String.class)
                .setParameter("status", SingleAppAuthorization.Status.APPROVED)
                .getResultList());
    }
}