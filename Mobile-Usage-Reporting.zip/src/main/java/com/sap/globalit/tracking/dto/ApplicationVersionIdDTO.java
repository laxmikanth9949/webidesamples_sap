package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;

public class ApplicationVersionIdDTO {

    @Expose
    public String versionId;

    @Expose
    public ApplicationPlattformIdDTO plattform;

    public ApplicationVersionIdDTO(String versionId, ApplicationPlattformIdDTO plattform) {
        this.versionId = versionId;
        this.plattform = plattform;
    }

    @Override
    public String toString() {
        return "Version{" +
                versionId + '\'' +
                ", plattform=" + plattform +
                '}';
    }
}
