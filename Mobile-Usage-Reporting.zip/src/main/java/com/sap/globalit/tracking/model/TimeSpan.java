package com.sap.globalit.tracking.model;

import java.io.Serializable;
import java.text.DateFormat;
import java.util.Date;

import javax.persistence.Embeddable;

import com.google.gson.annotations.Expose;

@Embeddable
public class TimeSpan implements Serializable {

	public static final DateFormat formatter = DateFormat.getDateTimeInstance(
			DateFormat.SHORT, DateFormat.SHORT);

	private static final long serialVersionUID = 1L;

	@Expose
	private long spanStart;

	@Expose
	private long spanEnd;

	public TimeSpan() {
	}

	public TimeSpan(long start, long end) {
		this();
		this.spanStart = start;
		this.spanEnd = end;
	}

	public long getSpanStart() {
		return spanStart;
	}

	public long getSpanEnd() {
		return spanEnd;
	}

	public boolean isConsistent() {
		return spanEnd >= spanStart;
	}

	public long getDifference() {
		return spanEnd - spanStart;
	}

	@Override
	public String toString() {
		return "[" + formatter.format(new Date(spanStart)) + " - "
				+ formatter.format(new Date(spanEnd)) + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (spanEnd ^ (spanEnd >>> 32));
		result = prime * result + (int) (spanStart ^ (spanStart >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TimeSpan other = (TimeSpan) obj;
		if (spanEnd != other.spanEnd)
			return false;
        return spanStart == other.spanStart;
    }

}