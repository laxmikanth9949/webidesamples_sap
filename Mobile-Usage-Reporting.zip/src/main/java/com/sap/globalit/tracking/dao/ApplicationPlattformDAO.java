package com.sap.globalit.tracking.dao;

import com.sap.globalit.tracking.model.ApplicationPlattform;
import com.sap.globalit.tracking.model.ApplicationPlattformId;

public class ApplicationPlattformDAO extends GenericDAO<ApplicationPlattform, ApplicationPlattformId> {

    @Override
    public Class<? extends ApplicationPlattform> getEntityClass() {
        return ApplicationPlattform.class;
    }

}