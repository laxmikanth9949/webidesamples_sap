package com.sap.globalit.tracking.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class StaticFileFilter implements Filter {

    static Map<String, String> MAPPING = new HashMap<>();

    static {
        MAPPING.put("/swagger-ui", "/swagger-ui/index.html");

        MAPPING.put("/realtime", "/realtimeComp2.html");
        MAPPING.put("/realtime/map", "/realtimeMap.html");
        MAPPING.put("/realtime/bubbles", "/realtime.html");


        MAPPING.put("/realtime/oauth", "/realtimeComp2.html");
        MAPPING.put("/realtime/map/oauth", "/realtimeMap.html");
        MAPPING.put("/realtime/bubbles/oauth", "/realtime.html");

        MAPPING.put("/documentation/gco-migration", "/documentation/integration.html");
        MAPPING.put("/documentation/integration", "/documentation/integration.html");
    }

    static Logger log = LoggerFactory.getLogger(StaticFileFilter.class);

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        log.info("{} initialized", this.getClass().getName());
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;

        String url = httpRequest.getRequestURI();
        log.debug("Processing {}", httpRequest.getRequestURI());

        String forward = MAPPING.get(url);
        if (forward != null) {
            log.debug("Dispatching Request to {} to file {}", url, forward);
            request.getRequestDispatcher(forward).include(request, response);
            return;
        }

        chain.doFilter(request, response);

    }

    @Override
    public void destroy() {
    }
}
