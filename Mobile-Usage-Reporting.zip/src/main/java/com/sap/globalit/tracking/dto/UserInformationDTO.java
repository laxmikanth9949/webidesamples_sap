package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;

/**
 * Created by D053397 on 04.07.2017.
 */
public class UserInformationDTO {
    @Expose
    public String id;

    @Override
    public String toString() {
        return "UserInformationDTO{" +
                "id='" + id + '\'' +
                '}';
    }
}
