package com.sap.globalit.tracking.dto;

import com.sap.globalit.tracking.model.*;
import com.sap.globalit.tracking.model.authorization.SingleAppAuthorization;

import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Created by D053397 on 10.08.2016.
 */
public class Mapper {

    public static List<AuthorizationDTO> authorization(List<SingleAppAuthorization> authList) {
        return authList.stream()
                .map(i -> new AuthorizationDTO("SINGLE", i.getApp().getId(), i.getAuthId(), i.getUserId(), i.getReason(), i.getApprover(), i.getStatus(), i.getLastStatusModification()))
                .collect(Collectors.toList());
    }

    public static UserReportSettingDTO userReportSetting(UserReportSetting s) {
        return new UserReportSettingDTO(s.getUserId(), s.getApplications(), s.getReportId(), s.getViewId(), s.getTimeFrom(), s.getTimeTo(), s.getTimeInterval());
    }

    public static ApplicationDTO application(Application a) {
        return new ApplicationDTO(a.getId(), a.getName());
    }

    public static ApplicationPlatformDTO platform(ApplicationPlattform platform) {
        return new ApplicationPlatformDTO(application(platform.getApplication()), platform.getId());
    }

    public static Usage usage(ApplicationUsageReport report) {
        Usage usage = new Usage();
        usage.applicationId = report.version.plattform.application;
        usage.platformId = report.version.plattform.id;
        usage.versionId = report.version.versionId;

        usage.usageStart = Instant.ofEpochMilli(report.timeSpan.spanStart);
        usage.usageEnd = Instant.ofEpochMilli(report.timeSpan.spanEnd);

        // deviceInformation is not submitted by every client
        if (report.deviceInformation == null)
            report.deviceInformation = DeviceInformationDTO.getFallback();

        usage.deviceId = report.deviceInformation.deviceId;
        usage.screenSize = report.deviceInformation.screenSize;
        usage.modelName = report.deviceInformation.modelName;
        usage.countryCode = report.deviceInformation.countryCode;
        usage.operatingSystem = report.deviceInformation.operatingSystem;

        usage.browserLocationHost = report.webUsageHost;

        usage.events = events(report.events);

        if (report.userInformation != null)
            usage.userInformation = new UserInformation(report.userInformation.id);

        return usage;
    }

    private static List<Usage.Event> events(List<ApplicationUsageReport.EventReportDTO> events) {
        return events.stream()
                .filter(Objects::nonNull)
                .map(i -> {
                    Usage.Event e = new Usage.Event();
                    e.name = i.getEventId();
                    e.instant = Instant.ofEpochMilli(i.dateTime);
                    return e;
                }).collect(Collectors.toList());
    }

    public static WebsocketMessageDTO websocketMessage(Usage report, String appName) {
        return new WebsocketMessageDTO(new WebsocketMessageDTO.Version(new WebsocketMessageDTO.Platform(report.platformId.toString(), new WebsocketMessageDTO.Application(appName, report.applicationId))), new WebsocketMessageDTO.DeviceInformation(report.countryCode));
    }
}
