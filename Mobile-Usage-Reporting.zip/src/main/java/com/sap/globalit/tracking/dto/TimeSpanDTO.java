package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;

import java.util.Date;

import static com.sap.globalit.tracking.model.TimeSpan.formatter;

public class TimeSpanDTO {

    @Expose
    public long spanStart;

    @Expose
    public long spanEnd;

    public TimeSpanDTO(long spanStart, long spanEnd) {
        this.spanStart = spanStart;
        this.spanEnd = spanEnd;
    }

    @Override
    public String toString() {
        return "[" + formatter.format(new Date(spanStart)) + " - "
                + formatter.format(new Date(spanEnd)) + "]";
    }
}