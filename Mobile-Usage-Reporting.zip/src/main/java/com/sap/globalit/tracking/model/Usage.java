package com.sap.globalit.tracking.model;

import java.time.Instant;
import java.util.List;

/**
 * Created by D053397 on 08.03.2017.
 */
public class Usage {
    public long usageId;
    public Instant insertedAt;
    public String countryCode;
    public String deviceId;
    public DeviceType deviceType;
    public String modelName;
    public String operatingSystem;
    public String rawUserAgent;
    public double screenSize;
    public Instant usageStart;
    public Instant usageEnd;
    public UserInformation userInformation;
    public String applicationId;
    public String versionId;
    public ApplicationPlattform.PlatformType platformId;
    public String referer;
    public String origin;
    public String browserLocationHost;
    public List<Event> events;

    public static class Event {
        public long eventId;
        public Instant instant;
        public String name;

        public Event setInstant(Instant instant) {
            this.instant = instant;
            return this;
        }

        public Event setName(String name) {
            this.name = name;
            return this;
        }
    }


}
