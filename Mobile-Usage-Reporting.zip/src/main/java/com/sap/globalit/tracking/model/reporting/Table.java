package com.sap.globalit.tracking.model.reporting;

import com.google.gson.annotations.Expose;
import com.sap.globalit.tracking.model.reporting.Chart.ChartData;

import java.util.ArrayList;
import java.util.List;

public class Table {

    @Expose
    List<ChartData> tableData;

    @Expose
    private List<DataRow> columns;

    public Table() {
        columns = new ArrayList<>();
    }

    public Table(List<ChartData> chartData, List<DataRow> columns) {
        this();
        this.tableData = chartData;
        this.columns = columns;
    }

    public DataRow getOrCreateColumnForName(String name) {
        for (DataRow row : columns) {
            if (row.getName().equals(name))
                return row;
        }
        DataRow row = new Measure(name);
        columns.add(row);
        return row;
    }

    public DataRow getColumn(int i) {
        return columns.get(i);
    }

    public List<DataRow> getColumns() {
        return columns;
    }

    public List<ChartData> getTableData() {
        return tableData;
    }

    @Override
    public String toString() {
        return "Table [" + tableData + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((columns == null) ? 0 : columns.hashCode());
        result = prime * result + ((tableData == null) ? 0 : tableData.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Table other = (Table) obj;
        if (columns == null) {
            if (other.columns != null)
                return false;
        } else if (!columns.equals(other.columns))
            return false;
        if (tableData == null) {
            if (other.tableData != null)
                return false;
        } else if (!tableData.equals(other.tableData))
            return false;
        return true;
    }

    public void setTableData(List<ChartData> tableData) {
        this.tableData = tableData;
    }
}
