package com.sap.globalit.tracking.api.sainternal;

import com.sap.globalit.tracking.authorization.AuthorizationManager;
import com.sap.globalit.tracking.dto.ApplicationDTO;
import com.sap.globalit.tracking.dto.AuthorizationDTO;
import com.sap.globalit.tracking.dto.AuthorizationDecisionDTO;
import com.sap.globalit.tracking.dto.Mapper;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.model.authorization.SingleAppAuthorization;
import com.sap.security.um.user.PersistenceException;
import com.sap.security.um.user.UserProvider;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.stream.Collectors;

@Path("/sa-internal/authorization")
@Api(value = "Internal Authorization API")
public class ApproveAuthorizationAPI {

    private static Logger logger = LoggerFactory.getLogger(ApproveAuthorizationAPI.class);

    @Inject
    AuthorizationManager authManager;

    @Inject
    UserProvider userProvider;

    @Inject
    EntityManager em;

    public ApproveAuthorizationAPI() {
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("decide")
    public Response processAuthorization(AuthorizationDecisionDTO authRequest) throws PersistenceException {

        em.getTransaction().begin();

        SingleAppAuthorization auth = em.find(SingleAppAuthorization.class, authRequest.authId);
        auth.setApprover(userProvider.getCurrentUser().getName());
        auth.setStatus(authRequest.status);

        em.getTransaction().commit();

        return Response.status(201).build();
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("getAll")
    public List<AuthorizationDTO> getAllAuthorizations() {
        List<SingleAppAuthorization> auths = em.createQuery("SELECT x FROM SingleAppAuthorization x", SingleAppAuthorization.class)
                .getResultList();

        return Mapper.authorization(auths);
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("check/{id}")
    @ApiOperation(value = "List Applications for User")
    public List<ApplicationDTO> checkForUser(@PathParam("id") String id) throws PersistenceException {
        List<Application> authorized = authManager.getAuthorizedAppsFor(id);

        return authorized.stream().map(Mapper::application).collect(Collectors.toList());
    }

}