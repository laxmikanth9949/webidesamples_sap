package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;

/**
 * Created by D053397 on 10.08.2016.
 */
public class ApplicationDTO {

    @Expose
    public String id;

    @Expose
    public String displayName;

    @Expose
    public String name;

    public ApplicationDTO(String id, String displayName) {
        this.id = id;
        this.displayName = displayName;
        this.name = displayName;
    }
}