package com.sap.globalit.tracking.api.internal.v2.report;

import com.sap.globalit.tracking.model.reporting.Chart;
import com.sap.globalit.tracking.model.reporting.DataRow;
import com.sap.globalit.tracking.model.reporting.Table;

import java.sql.ResultSet;
import java.sql.SQLException;

import static com.sap.globalit.tracking.util.ChartUtil.cleanStringForReferenceInJS;

/**
 * Created by D053397 on 26.07.2016.
 */
public class TableUtil {
    public static void enrichTableWithMeasureCol(Table table, ResultSet resultSet, String dimensionName) throws SQLException {

        while (resultSet.next()) {
            String dimension = resultSet.getString("DIMENSION");

            // skip empty entries
            if (dimension == null || dimension.isEmpty())
                continue;

            String measureName = resultSet.getString("MEASURE_COL");
            String measureKey = cleanStringForReferenceInJS(measureName);
            Long measure = resultSet.getLong("MEASURE");

            String dimensionKey = cleanStringForReferenceInJS(dimensionName);

            table.getOrCreateColumnForName(measureName);

            // get data entry
            for (Chart.ChartData row : table.getTableData()) {
                Object app = row.get(dimensionKey);
                if (app.equals(dimension)) {
                    row.put(measureKey, measure);
                    break;
                }
            }

        }

    }

    public static void ensureValueForAllMeasures(Table table) {
        for (DataRow col : table.getColumns()) {
            if (col.getType().equals("Measure")) {
                for (Chart.ChartData data : table.getTableData()) {
                    if (data.get(col.getKey()) == null)
                        data.put(col.getKey(), 0L);
                }
            }
        }

    }
}
