package com.sap.globalit.tracking.api.internal.v2.report;

import com.sap.globalit.tracking.api.internal.ReportAPI.TimeInterval;
import com.sap.globalit.tracking.api.internal.v2.SQLDAO;
import com.sap.globalit.tracking.model.ApplicationPlattform;
import com.sap.globalit.tracking.model.reporting.Chart;
import com.sap.globalit.tracking.model.reporting.Table;

import javax.inject.Inject;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static com.sap.globalit.tracking.api.internal.v2.report.TimeHelper.getTimeHelper;

public class ReportBuilder {

    @Inject
    SQLDAO dao;

    public Chart getChart_Usage_ByApp(ZonedDateTime start, ZonedDateTime end, TimeInterval interval, List<String> apps) throws SQLException {
        return dao.getUsage_byApp(toMillis(start), toMillis(end), apps, interval, r -> ResultSetUtil.toChart(r, getTimeHelper(interval), start, end));
    }

    public Table getTable_Usage_ByApp(ZonedDateTime start, ZonedDateTime end, TimeInterval interval, List<String> apps) throws SQLException {
        return dao.getUsage_byApp(toMillis(start), toMillis(end), apps, interval, r -> ResultSetUtil.toTable(r, getTimeHelper(interval), start, end, "App"));
    }

    public Chart getChart_ActiveDevices_ByApp(ZonedDateTime start, ZonedDateTime end, TimeInterval interval, List<String> apps) throws SQLException {
        return dao.getActiveDevices_byApp(toMillis(start), toMillis(end), apps, interval, r -> ResultSetUtil.toChart(r, getTimeHelper(interval), start, end));
    }

    public Table getTable_ActiveDevices_ByApp(ZonedDateTime start, ZonedDateTime end, TimeInterval interval, List<String> apps) throws SQLException {
        return dao.getActiveDevices_byApp(toMillis(start), toMillis(end), apps, interval, r -> ResultSetUtil.toTable(r, getTimeHelper(interval), start, end, "App"));
    }

    public Chart getChart_OsVersion_ByApp(ZonedDateTime start, ZonedDateTime end,
                                          TimeInterval interval, List<String> apps, ApplicationPlattform.PlatformType platformType) throws SQLException {
        return dao.getOsVersion(toMillis(start), toMillis(end), apps, platformType, interval, r -> ResultSetUtil.toChart(r, getTimeHelper(interval), start, end));
    }

    public Table getTable_OsVersion_ByApp(ZonedDateTime start, ZonedDateTime end,
                                          TimeInterval interval, List<String> apps, ApplicationPlattform.PlatformType platformType) throws SQLException {

        return dao.getOsVersion(toMillis(start), toMillis(end), apps, platformType, interval, r -> ResultSetUtil.toTable(r, getTimeHelper(interval), start, end, "App"));

    }

    public Chart getChart_VersionDistribution_ByActiveUsers(ZonedDateTime start, ZonedDateTime end, TimeInterval interval, String appId) throws SQLException {

        return dao.getVersionDistribution_ByActiveUsers(toMillis(start), toMillis(end), appId, interval, r -> ResultSetUtil.toChart(r, getTimeHelper(interval), start, end));

    }

    public Table getTable_VersionDistribution_ByActiveUsers(ZonedDateTime start, ZonedDateTime end, TimeInterval interval, String appId) throws SQLException {

        return dao.getVersionDistribution_ByActiveUsers(toMillis(start), toMillis(end), appId, interval, r -> ResultSetUtil.toTable(r, getTimeHelper(interval), start, end, "App Version"));

    }

    public Chart getChart_Usage_ByApp_noTime(ZonedDateTime start, ZonedDateTime end, List<String> authorizedApplications) throws SQLException {
        return dao.getUsage_byApp_noTime(toMillis(start), toMillis(end), authorizedApplications, r -> ResultSetUtil.toSingleValueChart(r, Collections.singletonList("DIMENSION"), Collections.singletonList("Dimension"), Collections.singletonList("MEASURE"), Collections.singletonList("Measure")));
    }

    public Chart getChart_ActiveDevices_ByApp_noTime(ZonedDateTime start, ZonedDateTime end, List<String> authorizedApplications) throws SQLException {
        return dao.getActiveDevices_byApp_noTime(toMillis(start), toMillis(end), authorizedApplications, r -> ResultSetUtil.toSingleValueChart(r, Collections.singletonList("DIMENSION"), Collections.singletonList("Dimension"), Collections.singletonList("MEASURE"), Collections.singletonList("Measure")));
    }

    public Table getTable_LocationInfo(ZonedDateTime start, ZonedDateTime end, List<String> apps) throws SQLException {

        return dao.getLocationInfo(toMillis(start), toMillis(end), apps, r -> ResultSetUtil.toSingleValueTable(r, Arrays.asList("APPLICATION_NAME", "REGION", "DEVICE_COUNTRY"), Arrays.asList("App", "Region", "Country"), Arrays.asList("USAGE", "ACTIVE_DEVICES"), Arrays.asList("Usages", "Active Devices")));

    }

    public Chart getChart_Events_ForApplication(ZonedDateTime start, ZonedDateTime end, TimeInterval interval, String appId) throws SQLException {

        return dao.getEvents_forApplication(toMillis(start), toMillis(end), appId, interval, r -> ResultSetUtil.toChart(r, getTimeHelper(interval), start, end));

    }


    public Table getTable_Events_ForApplication(ZonedDateTime start, ZonedDateTime end, TimeInterval interval, String appId) throws SQLException {

        return dao.getEvents_forApplication(toMillis(start), toMillis(end), appId, interval, r -> ResultSetUtil.toTable(r, getTimeHelper(interval), start, end, "Event"));

    }

    public Chart getChart_DeviceModel_ByUsage(ZonedDateTime start, ZonedDateTime end, TimeInterval interval, String appId) throws SQLException {

        return dao.getDeviceModel_ByUsage_ForApplication(toMillis(start), toMillis(end), appId, interval, r -> ResultSetUtil.toChart(r, getTimeHelper(interval), start, end));

    }

    public Table getTable_DeviceModel_ByUsage(ZonedDateTime start, ZonedDateTime end, TimeInterval interval, String appId) throws SQLException {

        return dao.getDeviceModel_ByUsage_ForApplication(toMillis(start), toMillis(end), appId, interval, r -> ResultSetUtil.toTable(r, getTimeHelper(interval), start, end, "Device Model"));

    }

    public Chart getChart_RegionDistribution_ByActiveDevices(ZonedDateTime start, ZonedDateTime end, TimeInterval interval, String appId) throws SQLException {

        return dao.getRegionDistribution_ByActiveDevices_ForApplication(toMillis(start), toMillis(end), appId, interval, r -> ResultSetUtil.toChart(r, getTimeHelper(interval), start, end));

    }

    public Table getTable_RegionDistribution_ByActiveDevices(ZonedDateTime start, ZonedDateTime end, TimeInterval interval, String appId) throws SQLException {

        return dao.getRegionDistribution_ByActiveDevices_ForApplication(toMillis(start), toMillis(end), appId, interval, r -> ResultSetUtil.toTable(r, getTimeHelper(interval), start, end, "Region"));

    }

    public Table getTable_Usage_ByGCORegion(ZonedDateTime start, ZonedDateTime end, List<String> apps) throws SQLException {

        Table table = dao.getUsage_byGCORegion_Field(toMillis(start), toMillis(end), apps, r -> ResultSetUtil.toTable_MeasureFromColumn(r, "App"));
        dao.getUsage_byGCORegion_Region(toMillis(start), toMillis(end), apps, r -> {
            TableUtil.enrichTableWithMeasureCol(table, r, "App");
            return null; // ignored
        });
        dao.getUsage_byGCORegion_All(toMillis(start), toMillis(end), apps, r -> {
            TableUtil.enrichTableWithMeasureCol(table, r, "App");
            return null; // ignored
        });

        TableUtil.ensureValueForAllMeasures(table);

        return table;

    }

    public Table getTable_ActiveDevices_ByGCORegion(ZonedDateTime start, ZonedDateTime end, List<String> apps) throws SQLException {

        Table table = dao.getActiveDevices_byGCORegion_Field(toMillis(start), toMillis(end), apps, r -> ResultSetUtil.toTable_MeasureFromColumn(r, "App"));
        dao.getActiveDevices_byGCORegion_Region(toMillis(start), toMillis(end), apps, r -> {
            TableUtil.enrichTableWithMeasureCol(table, r, "App");
            return null; // ignored
        });
        dao.getActiveDevices_byGCORegion_All(toMillis(start), toMillis(end), apps, r -> {
            TableUtil.enrichTableWithMeasureCol(table, r, "App");
            return null; // ignored
        });

        TableUtil.ensureValueForAllMeasures(table);

        return table;

    }

    public Table getTable_Events_ByGCORegion(ZonedDateTime start, ZonedDateTime end, List<String> apps) throws SQLException {

        Table table = dao.getEvents_byGCORegion_Field(toMillis(start), toMillis(end), apps, r -> ResultSetUtil.toTable_MeasureFromColumn(r, "Event"));
        dao.getEvents_byGCORegion_Region(toMillis(start), toMillis(end), apps, r -> {
            TableUtil.enrichTableWithMeasureCol(table, r, "Event");
            return null; // ignored
        });
        dao.getEvents_byGCORegion_All(toMillis(start), toMillis(end), apps, r -> {
            TableUtil.enrichTableWithMeasureCol(table, r, "Event");
            return null; // ignored
        });

        TableUtil.ensureValueForAllMeasures(table);

        return table;

    }

    private static long toMillis(ZonedDateTime dateTime) throws SQLException {
        return dateTime.toInstant().toEpochMilli();
    }

    public Chart getChart_DeviceType_ForApplication(ZonedDateTime start, ZonedDateTime end, TimeInterval interval, String appId) throws SQLException {

        return dao.getDeviceType_forApplication(toMillis(start), toMillis(end), appId, interval, r -> ResultSetUtil.toChart(r, getTimeHelper(interval), start, end));

    }

    public Table getTable_DeviceType_ForApplication(ZonedDateTime start, ZonedDateTime end, TimeInterval interval, String appId) throws SQLException {

        return dao.getDeviceType_forApplication(toMillis(start), toMillis(end), appId, interval, r -> ResultSetUtil.toTable(r, getTimeHelper(interval), start, end, "Type"));

    }

}