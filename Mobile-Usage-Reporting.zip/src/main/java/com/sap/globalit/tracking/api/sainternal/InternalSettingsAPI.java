package com.sap.globalit.tracking.api.sainternal;

import com.sap.globalit.tracking.dao.SettingsDAO;
import com.sap.globalit.tracking.dto.Mapper;
import com.sap.globalit.tracking.dto.UserReportSettingDTO;
import com.sap.globalit.tracking.model.UserReportSetting;
import com.sap.security.um.user.PersistenceException;
import io.swagger.annotations.Api;

import javax.inject.Inject;
import javax.ws.rs.*;

/**
 * Created by D053397 on 17.09.2015.
 */

@Path("/sa-internal/settings")
@Api(value = "Internal Settings API")
public class InternalSettingsAPI {

    @Inject
    SettingsDAO settingsDAO;

    @GET
    @Path("{user}")
    public UserReportSettingDTO getSettings(@PathParam("user") String user) throws PersistenceException {
        UserReportSetting settings = settingsDAO.getSettings(user);
        return Mapper.userReportSetting(settings);
    }

    @DELETE
    @Path("{user}")
    public void reset(@PathParam("user") String user) {
        if (user == null || user.isEmpty())
            throw new BadRequestException();

        settingsDAO.delete(user);
    }

}
