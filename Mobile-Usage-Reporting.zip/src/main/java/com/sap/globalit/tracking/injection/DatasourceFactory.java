package com.sap.globalit.tracking.injection;

import org.glassfish.jersey.internal.inject.DisposableSupplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class DatasourceFactory implements DisposableSupplier<DataSource> {

    private static final Logger log = LoggerFactory.getLogger(DatasourceFactory.class);
    private static final String ENV_JDBC_DEFAULT = "java:comp/env/jdbc/DefaultDB";

    @Inject
    Context context;

    // this is not used -> per-lookup injection
    @Override
    public void dispose(DataSource connection) {

    }

    @Override
    public DataSource get() {
        try {
            return (DataSource) context.lookup(ENV_JDBC_DEFAULT);
        } catch (NamingException e) {
            log.error("Error acquiring DataSource", e);
            throw new RuntimeException(e);
        }
    }
}
