package com.sap.globalit.tracking.dao;

import com.sap.globalit.tracking.authorization.AuthorizationManager;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.model.monthlyupdate.MonthlyUpdateOptOut;
import com.sap.security.um.UMException;

import javax.inject.Inject;
import javax.persistence.RollbackException;
import java.util.List;
import java.util.stream.Collectors;

public class MonthlyUpdateOptOutDAO extends GenericDAO<MonthlyUpdateOptOut, Object> {

    @Inject
    AuthorizationManager authDAO;

    @Override
    public Class<? extends MonthlyUpdateOptOut> getEntityClass() {
        return MonthlyUpdateOptOut.class;
    }

    public List<MonthlyUpdateOptOut> getOptOutForUser(String userId) {
        return this.em
                .createQuery(
                        "SELECT o FROM MonthlyUpdateOptOut o WHERE o.userId = :user",
                        MonthlyUpdateOptOut.class).setParameter("user", userId)
                .getResultList();
    }

    public List<Application> getSubscribedAppIdForUser(String currentUser) throws UMException {
        List<MonthlyUpdateOptOut> monthlyUpdate = this.getOptOutForUser(currentUser);

        List<Application> apps = authDAO.getAuthorizedAppsFor(currentUser);

        List<Application> result = apps.stream()
                .filter(i -> !userDidOptOut(monthlyUpdate, i.getId()))
                .collect(Collectors.toList());

        return result;
    }

    public void ensureSubscribed(String appId, String currentUser) {
        em.getTransaction().begin();
        em.createQuery("DELETE FROM MonthlyUpdateOptOut o WHERE o.userId = :user AND o.application.id = :appId")
                .setParameter("user", currentUser).setParameter("appId", appId)
                .executeUpdate();
        em.getTransaction().commit();
    }

    public void ensureUnsubscribed(String appId, String currentUser) {
        try {
            em.getTransaction().begin();
            Application application = em.find(Application.class, appId);
            em.persist(new MonthlyUpdateOptOut(currentUser, application));
            em.getTransaction().commit();
        } catch (RollbackException ignored) {
        }
    }

    public static boolean userDidOptOut(List<MonthlyUpdateOptOut> optOuts,
                                        String appId) {
        for (MonthlyUpdateOptOut optOut : optOuts) {
            // app getApplication might be null -> application removed in the meanwhile
            if (optOut.getApplication() != null && optOut.getApplication().getId().equals(appId))
                return true;
        }
        return false;
    }
}