package com.sap.globalit.tracking.model.reporting;

import com.google.gson.annotations.Expose;
import com.sap.globalit.tracking.util.ChartUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Chart {

    @Expose
    List<ChartData> chartData;

    @Expose
    private List<Dimension> dimensions;

    @Expose
    /**
     * during equals comparison, the order of the measures is ignored!
     */
    private List<Measure> measures;

    public Chart() {
        super();
        dimensions = new ArrayList<>();
        measures = new ArrayList<>();
    }

    public List<Dimension> getDimensions() {
        return dimensions;
    }

    public List<Measure> getMeasures() {
        return measures;
    }

    public Measure getMeasure(String name) {
        for (Measure m : measures)
            if (m.getName().equals(name))
                return m;

        Measure m = new Measure(name);
        measures.add(m);
        return m;
    }

    public void setMeasures(List<Measure> measures) {
        this.measures = measures;
    }

    public static class ChartData extends HashMap<String, Object> {

        public Object get(String key) {
            return super.get(key);
        }

        public ChartData with(String key, Object value) {
            this.put(ChartUtil.cleanStringForReferenceInJS(key), value);
            return this;
        }

    }

    @Override
    public String toString() {
        return "Chart [" + chartData + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((chartData == null) ? 0 : chartData.hashCode());
        result = prime * result + ((dimensions == null) ? 0 : dimensions.hashCode());
        result = prime * result + ((measures == null) ? 0 : measures.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Chart other = (Chart) obj;
        if (chartData == null) {
            if (other.chartData != null)
                return false;
        } else if (!chartData.equals(other.chartData))
            return false;
        if (dimensions == null) {
            if (other.dimensions != null)
                return false;
        } else if (!dimensions.equals(other.dimensions))
            return false;
        if (measures == null) {
            if (other.measures != null)
                return false;
        } else if (!measures.containsAll(other.measures))
            return false;
        else if (!other.measures.containsAll(measures))
            return false;
        return true;
    }

    public List<ChartData> getChartData() {
        return chartData;
    }


    public void setChartData(List<ChartData> chartData) {
        this.chartData = chartData;
    }
}
