package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;

/**
 * Created by D053397 on 12.09.2016.
 */
public class SubscriptionStatus {
    @Expose
    public String appId;
    @Expose
    public String appName;
    @Expose
    public boolean isSubscribed;

    public SubscriptionStatus(String appId, String appName,
                              boolean isSubscribed) {
        super();
        this.appId = appId;
        this.appName = appName;
        this.isSubscribed = isSubscribed;
    }

}
