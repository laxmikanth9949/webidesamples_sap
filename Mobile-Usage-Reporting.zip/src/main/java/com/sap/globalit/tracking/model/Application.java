package com.sap.globalit.tracking.model;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * One Application, e.g. EasyConnect or ShoppingCart
 *
 * @author D053397
 */
@Entity
public class Application {

    public static Comparator<Application> SORT_BY_NAME = (o1, o2) -> o1.getName().compareToIgnoreCase(o2.getName());

    @Id
    String id;

    String name;

    /**
     * name of the app on the UI
     */
    @Transient
    String displayName;

    @OneToMany(mappedBy = "application", fetch = FetchType.LAZY)
    private List<ApplicationPlattform> plattforms;

    protected Application() {
        plattforms = new ArrayList<>();
    }

    public Application(String id) {
        this();
        this.id = id;
        this.name = id;
    }

    public Application(String id, String name) {
        this();
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    @PostLoad
    void postLoad() {
        this.displayName = this.name;
    }

    public List<ApplicationPlattform> getPlattforms() {
        return plattforms;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Application other = (Application) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "Application [" + id + "]";
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }
}