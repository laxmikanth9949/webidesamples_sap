package com.sap.globalit.tracking.filter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by D053397 on 27.04.2016.
 */
public class CORSFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) servletRequest;
        HttpServletResponse resp = (HttpServletResponse) servletResponse;

        applyCORS(req::getHeader, resp::setHeader);

        filterChain.doFilter(servletRequest, servletResponse);
    }

    @Override
    public void destroy() {

    }

    static void applyCORS(HeaderSupplier headerSupplier, HeaderApplier headerApplier) {
        // add allowOrigin Access-Control-Allow-Origin: http://foo.example
        headerApplier.setHeader("Access-Control-Allow-Origin", "*");

        // Access-Control-Allow-Methods: POST, GET, OPTIONS
        String requestMethod = headerSupplier.getHeader("Access-Control-Request-Method");
        if (requestMethod != null) {
            headerApplier.setHeader("Access-Control-Allow-Methods", requestMethod);
        }

        // Access-Control-Allow-Headers: X-PINGOTHER
        String allowHeaders = headerSupplier.getHeader("Access-Control-Request-Headers");
        if (allowHeaders != null) {
            headerApplier.setHeader("Access-Control-Allow-Headers", allowHeaders);
        }

        // "Access-Control-Max-Age" -> remember for 1 minute
        headerApplier.setHeader("Access-Control-Max-Age", "60000");
    }

    @FunctionalInterface
    public interface HeaderSupplier {
        String getHeader(String headerName);
    }

    @FunctionalInterface
    public interface HeaderApplier {
        void setHeader(String header, String value);
    }
}
