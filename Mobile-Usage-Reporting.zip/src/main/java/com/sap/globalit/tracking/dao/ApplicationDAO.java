package com.sap.globalit.tracking.dao;

import com.sap.globalit.tracking.model.Application;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.sql.Timestamp;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

public class ApplicationDAO extends GenericDAO<Application, String> {

    @Inject
    EntityManager em;

    @Override
    public Class<? extends Application> getEntityClass() {
        return Application.class;
    }

    public List<String> getAllIds() {
        return this.em.createQuery("SELECT a.id FROM Application a", String.class)
                .getResultList();
    }

    public List<Application> getAllWithRecentUsage() {

        Timestamp from = Timestamp.from(ZonedDateTime.now().minus(2, ChronoUnit.MONTHS).toInstant());

        @SuppressWarnings("unchecked") List<Application> resultList = this.em.createNativeQuery("select distinct a.id, a.name from usage as u join application as a on (u.application_id = a.id) where usage_start > ?", Application.class)
                .setParameter(1, from)
                .getResultList();

        return resultList.stream()
                .sorted(Application.SORT_BY_NAME)
                .collect(Collectors.toList());
    }
}
