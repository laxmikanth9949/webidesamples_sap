package com.sap.globalit.tracking.api;

import com.codahale.metrics.Gauge;
import com.codahale.metrics.MetricRegistry;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.google.gson.Gson;
import com.sap.globalit.tracking.dto.Mapper;
import com.sap.globalit.tracking.dto.WebsocketMessageDTO;
import com.sap.globalit.tracking.model.Usage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.websocket.CloseReason;
import javax.websocket.Session;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

/**
 * Created by D053397 on 13.10.2016.
 */
public class RealtimeSocketManager {
    private static Logger logger = LoggerFactory.getLogger(RealtimeSocketManager.class);

    private static final String LAST_PING = "LAST_PING";
    private static final Set<String> REALTIME_BLACKLIST = new HashSet<>(Arrays.asList("MailScout", "GCOSalesCentral (Win8)", "PeopleProfileAccess", "MDR0: MCC Dashboards Overview", "MDR11: System Down Monitor", "MDR12: CIM Service Request Dashboard", "MDR1: Production Down Monitor", "MDR2: Activities", "MDR3: Top&Cross Issues", "MDR4: Schedules Service List", "MDR5: Scheduled Service", "MDR6: QGates", "MDR7: Case Cards", "MDR8: Case Map", "MDR9: Incident Dashboard", "GlobalIT_LibInfrastructureUtilities", "C4C (HTML5)", "C4C (HTML5/TEST)", "C4C (WINDOWS)", "C4C (WINDOWS/TEST)", "GlobalIT_LibKeychainUtilities"));

    private final Gson gson = new Gson();

    private final List<Session> openSessions = new CopyOnWriteArrayList<>();
    private final BlockingQueue<String> queue = new ArrayBlockingQueue<>(15);

    private final ExecutorService exec = Executors.newSingleThreadExecutor(
            new ThreadFactoryBuilder()
                    .setNameFormat("broadcaster-thread-%d").build()
    );

    @Inject
    public RealtimeSocketManager(MetricRegistry registry) {
        startBroadcaster();
        registry.register(MetricRegistry.name(RealtimeSocketManager.class, "sessions", "count"), (Gauge<Integer>) openSessions::size);
        registry.register(MetricRegistry.name(RealtimeSocketManager.class, "queue", "size"), (Gauge<Integer>) queue::size);
    }

    private void startBroadcaster() {
        exec.submit(new Broadcaster());
    }

    void broadcastUsage(Usage report, String appName) {
        // filter some apps
        String appId = report.applicationId;

        if (REALTIME_BLACKLIST.contains(appId))
            return;

        WebsocketMessageDTO websocketMessage = Mapper.websocketMessage(report, appName);
        String json = gson.toJson(websocketMessage);

        // having web-workers ready is more important than broadcasting the usage
        queue.offer(json);
    }

    void onNewSession(Session session) {
        openSessions.add(session);
        session.getUserProperties().put(LAST_PING, Instant.now());
    }

    void onPing(Session session) {
        session.getUserProperties().put(LAST_PING, Instant.now());
    }

    void onSessionTerminated(Session session) {
        openSessions.remove(session);
    }

    private class Broadcaster implements Runnable {

        @Override
        public void run() {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    String jsonObject = queue.take();

                    ListIterator<Session> iterator = openSessions.listIterator();
                    while (iterator.hasNext()) {
                        Session session = iterator.next();

                        if (isSessionAlive(session))
                            session.getAsyncRemote().sendText(jsonObject)
                                    .get(1, TimeUnit.SECONDS);
                        else
                            session.close(new CloseReason(CloseReason.CloseCodes.GOING_AWAY, "Closing session -> no ping received!"));
                    }

                } catch (RuntimeException | ExecutionException | TimeoutException | InterruptedException ex) {
                    logger.error("Broadcaster exception", ex);
                } catch (Throwable e) {
                    logger.error("WTF", e);
                }
            }

        }


        private boolean isSessionAlive(Session session) {
            return session.isOpen() && ((Instant) session.getUserProperties().get(LAST_PING)).plusSeconds(60).isAfter(Instant.now());
        }
    }

    public void shutdown() {
        logger.debug("Shutting down...");
        exec.shutdownNow();
    }


}
