package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;
import com.sap.globalit.tracking.api.internal.ReportAPI;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;

/**
 * Created by D053397 on 10.08.2016.
 */
public class UserReportSettingDTO {

    private static final ZoneId UTC = ZoneId.of("UTC");

    @Expose
    public String userId;

    @Expose
    public List<String> applications;

    @Expose
    public String reportId;

    @Expose
    public String viewId;

    @Expose
    public long timeFrom;

    @Expose
    public long timeTo;

    @Expose
    public ReportAPI.TimeInterval timeInterval;

    @Expose
    public ZonedDateTime timeFromDate;

    @Expose
    public ZonedDateTime timeToDate;

    public UserReportSettingDTO(String userId, List<String> applications, String reportId, String viewId, long timeFrom, long timeTo, ReportAPI.TimeInterval timeInterval) {
        this.userId = userId;
        this.applications = applications;
        this.reportId = reportId;
        this.viewId = viewId;
        this.timeFrom = timeFrom;
        this.timeTo = timeTo;
        this.timeInterval = timeInterval;

        // set timeFromDate and timeToDate
        timeFromDate = ZonedDateTime.ofInstant(Instant.ofEpochMilli(timeFrom), UTC);
        timeToDate = ZonedDateTime.ofInstant(Instant.ofEpochMilli(timeTo), UTC);
    }
}