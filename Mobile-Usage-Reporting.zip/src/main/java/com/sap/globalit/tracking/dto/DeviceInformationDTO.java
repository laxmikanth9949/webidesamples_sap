package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;

import static com.sap.globalit.tracking.model.DeviceInformation.*;

public class DeviceInformationDTO {

    @Expose
    public String deviceId;

    @Expose
    public double screenSize;

    @Expose
    public String modelName;

    @Expose
    public String countryCode;

    @Expose
    public String operatingSystem;

    public DeviceInformationDTO(String deviceId, double screenSize, String modelName, String countryCode, String operatingSystem) {
        this.deviceId = deviceId;
        this.screenSize = screenSize;
        this.modelName = modelName;
        this.countryCode = countryCode;
        this.operatingSystem = operatingSystem;
    }

    public static DeviceInformationDTO getFallback() {
        return new DeviceInformationDTO(FALLBACK_DEVICE_ID, FALLBACK_SCREEN_SIZE,
                FALLBACK_MODEL_NAME, FALLBACK_COUNTRY_CODE,
                FALLBACK_OPERATING_SYSTEM);
    }

    @Override
    public String toString() {
        return "DeviceInformationDTO{" +
                "deviceId='" + deviceId + '\'' +
                ", screenSize=" + screenSize +
                ", modelName='" + modelName + '\'' +
                ", countryCode='" + countryCode + '\'' +
                ", operatingSystem='" + operatingSystem + '\'' +
                '}';
    }
}
