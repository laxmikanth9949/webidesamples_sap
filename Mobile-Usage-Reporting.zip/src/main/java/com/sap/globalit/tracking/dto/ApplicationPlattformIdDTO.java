package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;
import com.sap.globalit.tracking.model.ApplicationPlattform.PlatformType;

public class ApplicationPlattformIdDTO {

    @Expose
    public PlatformType id;

    @Expose
    public String application;

    public ApplicationPlattformIdDTO(PlatformType id, String application) {
        this.id = id;
        this.application = application;
    }

    @Override
    public String toString() {
        return "{" +
                " " + id +
                " | " + application + '\'' +
                '}';
    }
}
