package com.sap.globalit.tracking.util;

import com.sap.globalit.tracking.model.Application;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by D053397 on 07.04.2017.
 */
public class AppUtil {
    /**
     * returns only applications, which are in both lists
     *
     * @param input
     * @param filter
     * @return
     */
    public static List<Application> filter(List<Application> input, List<Application> filter) {
        return input.stream().filter(a -> filter.contains(a)).collect(Collectors.toList());
    }
}
