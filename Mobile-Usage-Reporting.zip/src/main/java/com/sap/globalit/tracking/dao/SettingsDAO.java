package com.sap.globalit.tracking.dao;

import com.sap.globalit.tracking.api.internal.ReportAPI;
import com.sap.globalit.tracking.authorization.AuthorizationManager;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.model.UserReportSetting;
import com.sap.security.um.user.PersistenceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.time.temporal.IsoFields;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by D053397 on 17.09.2015.
 */
public class SettingsDAO {

    private static final ZoneId UTC = ZoneId.of("UTC");

    private static Logger logger = LoggerFactory.getLogger(SettingsDAO.class);

    @Inject
    EntityManager entityManager;

    @Inject
    AuthorizationManager authManager;

    public void delete(String userId) {
        entityManager.getTransaction().begin();

        List<UserReportSetting> settings = entityManager.createQuery("SELECT s FROM UserReportSetting s WHERE s.userId = :user", UserReportSetting.class)
                .setParameter("user", userId).getResultList();
        settings.forEach(i -> entityManager.remove(i));

        entityManager.getTransaction().commit();
    }

    public UserReportSetting getSettings(String userId) throws PersistenceException {
        UserReportSetting reportSetting = null;


        List<UserReportSetting> settingList = entityManager.createQuery("SELECT s FROM UserReportSetting s WHERE s.userId = :user", UserReportSetting.class)
                .setParameter("user", userId).getResultList();

        if (settingList.size() != 1) {
            // generate initial settings

            List<String> authorizedIds = authManager.getAuthorizedAppsFor(userId)
                    .stream()
                    .map(Application::getId)
                    .collect(Collectors.toList());

            entityManager.getTransaction().begin();

            reportSetting = new UserReportSetting(authorizedIds, "devices", "chart", -1, -1, ZonedDateTime.now().toInstant().toEpochMilli() - ZonedDateTime.now().minus(6, ChronoUnit.MONTHS).toInstant().toEpochMilli(), ReportAPI.TimeInterval.MONTH, userId);
            entityManager.persist(reportSetting);

            entityManager.getTransaction().commit();
        } else {
            reportSetting = settingList.get(0);
        }

        entityManager.detach(reportSetting);

        if (reportSetting.getTimeFrom() == -1 && reportSetting.getTimeTo() == -1) {
            logger.info("Converting Setting from relative");

            ZonedDateTime to = null;

            switch (reportSetting.getTimeInterval()) {
                case DAY:
                    to = ZonedDateTime.of(LocalDate.now(), LocalTime.MAX, UTC);
                    break;
                case WEEK:
                    to = ZonedDateTime.now(UTC).with(DayOfWeek.SUNDAY).with(LocalTime.MAX);
                    break;
                case MONTH:
                    to = ZonedDateTime.now(UTC).with(TemporalAdjusters.lastDayOfMonth()).with(LocalTime.MAX);
                    break;
                case QUARTER:
                    int quarter = ZonedDateTime.now(UTC).get(IsoFields.QUARTER_OF_YEAR);
                    int targetMonth = quarter * 3;
                    // snap to last day of last month of the quarter
                    to = ZonedDateTime.now(UTC).with(Month.of(targetMonth)).with(TemporalAdjusters.lastDayOfMonth()).with(LocalTime.MAX);
                    break;
                case YEAR:
                    to = ZonedDateTime.now(UTC).with(TemporalAdjusters.lastDayOfYear()).with(LocalTime.MAX);
                    break;
                default:
                    throw new RuntimeException("Unexpected Interval" + reportSetting.getTimeInterval());
            }

            reportSetting.setTimeTo(to.toInstant().toEpochMilli());
            reportSetting.setTimeFrom(to.minus(reportSetting.getTimeDuration(), ChronoUnit.MILLIS).toInstant().toEpochMilli());
        }

        return reportSetting;
    }

}