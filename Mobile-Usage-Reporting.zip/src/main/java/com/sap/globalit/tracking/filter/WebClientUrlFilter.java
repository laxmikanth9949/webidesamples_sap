package com.sap.globalit.tracking.filter;

import com.sap.globalit.tracking.util.LandscapeHelper;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class WebClientUrlFilter implements Filter {

    private static Logger log = LoggerFactory.getLogger(WebClientUrlFilter.class);
    private LandscapeHelper.Landscape landscape;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        landscape = new LandscapeHelper().get();
        log.info("{} initialized with landscape {}", this.getClass().getName(), landscape);
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {

        if (landscape != LandscapeHelper.Landscape.PROD) {
            log.debug("Wrapping response -> replacing url");
            WebClientUrlResponseWrapper wrapper = new WebClientUrlResponseWrapper((HttpServletResponse) response, landscape);
            chain.doFilter(request, wrapper);
            wrapper.replaceUrlAndWrite();
        } else {
            chain.doFilter(request, response);
        }
    }

    @Override
    public void destroy() {
    }

    class WebClientUrlResponseWrapper extends HttpServletResponseWrapper {

        private final LandscapeHelper.Landscape landscape;
        private ByteArrayOutputStream bos = new ByteArrayOutputStream();
        private ServletOutputStream os = new ServletOutputStream() {
            @Override
            public boolean isReady() {
                return true;
            }

            @Override
            public void setWriteListener(WriteListener writeListener) {

            }

            @Override
            public void write(byte[] b) throws IOException {
                bos.write(b);
            }

            @Override
            public void write(byte[] b, int off, int len) throws IOException {
                bos.write(b, off, len);
            }

            @Override
            public void write(int b) throws IOException {
                bos.write(b);
            }
        };

        WebClientUrlResponseWrapper(HttpServletResponse response, LandscapeHelper.Landscape landscape)
                throws IOException {
            super(response);
            this.landscape = landscape;
        }

        @Override
        public ServletOutputStream getOutputStream() throws IOException {
            return os;
        }

        void replaceUrlAndWrite() throws IOException {
            os.flush();

            byte[] response = bos.toString("UTF-8").replace(LandscapeHelper.Landscape.PROD.getUrl(), landscape.getUrl()).getBytes("UTF-8");
            getResponse().setContentLength(response.length);

            IOUtils.write(response, getResponse().getOutputStream());
        }
    }
}