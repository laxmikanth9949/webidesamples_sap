package com.sap.globalit.tracking.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class UserInformation {

    @Id
    @GeneratedValue
    public long id;

    public String userId;

    private String orgUnit;

    private String costCenter;

    private String boardArea;

    public UserInformation() {
    }

    public UserInformation(String userId) {
        this.userId = userId;
    }
}