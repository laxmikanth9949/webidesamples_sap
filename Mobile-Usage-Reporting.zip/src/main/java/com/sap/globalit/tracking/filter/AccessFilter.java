package com.sap.globalit.tracking.filter;

import com.sap.cloud.security.oauth2.OAuthAuthorization;
import com.sap.cloud.security.oauth2.OAuthSystemException;
import com.sap.security.auth.login.LoginContextFactory;
import com.sap.security.um.service.UserManagementAccessor;
import com.sap.security.um.user.PersistenceException;
import com.sap.security.um.user.User;
import com.sap.security.um.user.UserProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.security.auth.login.LoginException;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

public class AccessFilter implements Filter {

    private Logger log = LoggerFactory.getLogger(AccessFilter.class);

    private static Set<String> PUBLIC_URLS = new HashSet<>(Arrays.asList(
            /* Web Client */
            "/web-client/",

            /* Public APIs */
            "/api/status",
            "/api/usage",
            "/examples/plain",
            "/examples/component",

            /* oAuth based Realtime */
            "/realtime/oauth",
            "/realtime/map/oauth",
            "/realtime/bubbles/oauth",

            /* Realtime Resources */
            "/css/",
            "/js/",
            "/img/",
            "/favicon.ico"
    ));

    private static Set<String> SUPER_ADMIN = new HashSet<>(Arrays.asList(
            "/api/sa-internal/"
    ));

    private static Set<String> USER = new HashSet<>(Arrays.asList(
            "/realtime",
            "/websocket/",

            "/api/reporting/",
            "/api/internal/",

            "/swagger-ui/",
            "/api/swagger.json",

            "/documentation"
    ));

    private static Set<String> OAUTH = new HashSet<>(Arrays.asList(
            "/api/internal/heartbeat/",
            "/api/internal/status", // -> realtime dashboard ping
            "/api/internal/showroom",
            "/api/internal/relaybot",
            "/api/internal/authorization/whatDoYouKnowAboutMe",
            "/api/internal/events/report"
    ));
    private UserProvider userProvider;
    private Pattern internalUserPattern;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        try {
            userProvider = UserManagementAccessor.getUserProvider();
            internalUserPattern = Pattern.compile("^[dci][0-9]+$", Pattern.CASE_INSENSITIVE);
        } catch (PersistenceException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        try {

            HttpServletRequest httpRequest = (HttpServletRequest) request;
            HttpServletResponse httpResponse = (HttpServletResponse) response;
            String requestedURI = httpRequest.getRequestURI();

            log.trace("Processing {}", requestedURI);

            // check if URL is public
            if (startsWithEntryIn(requestedURI, PUBLIC_URLS)) {
                chain.doFilter(request, response);
                return;
            }

            // check if oAuth is provided for whitelisted urls
            String authHeader = httpRequest.getHeader("Authorization");
            if (authHeader != null && authHeader.startsWith("Bearer") && startsWithEntryIn(requestedURI, OAUTH)) {// && OAuthAuthorization.getOAuthAuthorizationService().isAuthorized(httpRequest)) {
                // request authenticated access
                try {
                    LoginContextFactory.createLoginContext("OAUTH").login();

                    User user = userProvider.getCurrentUser();

                    log.info("OAuth passed: {}", user);
                    chain.doFilter(request, response);
                    return;

                } catch (Exception e) {
                    log.error("Login Error ", e);
                }
            }

            // check if special TOKEN access for websocket
            if (requestedURI.startsWith("/websocket/realtime") && httpRequest.getParameter("token") != null) {
                try {
                    log.debug("Websocket handling");
                    OAuthAuthorization authAuthorization = OAuthAuthorization.getOAuthAuthorizationService();
                    HttpServletRequestWrapper wrappedRequest = new OauthTokenHttpServletRequest(httpRequest, httpRequest.getParameter("token"));
                    if (authAuthorization.isAuthorized(wrappedRequest)) {
                        log.info("Websocket passed");
                        chain.doFilter(request, response);
                        return;
                    }
                } catch (OAuthSystemException e) {
                    e.printStackTrace();
                }
            }

            // request authenticated access
            User user = userProvider.getCurrentUser();

            if ("/websocket/realtime".equalsIgnoreCase(requestedURI) && user == null) {
                ((HttpServletResponse) response).sendError(401); // SAML does not work for websockets...
                return;
            }

            if (user == null) {
                try {
                    LoginContextFactory.createLoginContext("FORM").login();
                    user = userProvider.getCurrentUser();
                    log.debug("Logged in user is {}", user.getName());
                } catch (LoginException e) {
                    log.warn("Exception during login: {} for {}", e.getMessage(), requestedURI);
                    if (!httpResponse.isCommitted()) {
                        log.info("Sending Error 403");
                        ((HttpServletResponse) response).sendError(403);
                    }
                    return;
                }
            }

            // whitelist user URLS
            if (internalUserPattern.matcher(user.getName()).matches() && startsWithEntryIn(requestedURI, USER)) {
                log.debug("Proceed to user area");
                chain.doFilter(request, response);
                return;
            }

            // whitelist superadmin URLS
            if (user.hasRole("superadmin") && startsWithEntryIn(requestedURI, SUPER_ADMIN)) {
                log.debug("Proceed to admin area");
                chain.doFilter(request, response);
                return;
            }

            // fail otherwise
            log.warn("User {} with roles {} requested access to {}", user.getName(), user.getRoles(), requestedURI);
            log.debug("Sending Error 404");
            if (!response.isCommitted()) // investigate, ID Service Redirection?
                httpResponse.sendError(404);
            else {
                httpResponse.setStatus(404);
            }
            return;
        } catch (PersistenceException e) {
            log.warn("Persistence Exception", e);
            log.debug("Sending Error 500");
            ((HttpServletResponse) response).sendError(500, e.getMessage());
            return;
        }
    }

    private boolean startsWithEntryIn(String requestedURI, Set<String> rules) {
        return rules.stream().anyMatch(requestedURI::startsWith);
    }

    @Override
    public void destroy() {
    }

    private static class OauthTokenHttpServletRequest extends HttpServletRequestWrapper {
        private String token;

        OauthTokenHttpServletRequest(HttpServletRequest request, String token) {
            super(request);
            this.token = token;
        }

        @Override
        public String getHeader(String name) {
            if (name.equalsIgnoreCase("Authorization")) {
                return "Bearer " + token;
            }
            return super.getHeader(name);
        }

    }
}