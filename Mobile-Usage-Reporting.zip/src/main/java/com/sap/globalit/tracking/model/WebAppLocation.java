package com.sap.globalit.tracking.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * Created by D053397 on 24.07.2015.
 */
@Entity
public class WebAppLocation {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    private long id;

    private String app;

    private String url;

    public WebAppLocation() {
    }

    public WebAppLocation(String app, String url) {
        this.app = app;
        this.url = url;
    }
}
