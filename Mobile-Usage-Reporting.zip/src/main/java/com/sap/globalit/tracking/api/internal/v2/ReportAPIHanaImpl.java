package com.sap.globalit.tracking.api.internal.v2;

import com.google.common.base.Strings;
import com.sap.globalit.tracking.api.internal.ReportAPI;
import com.sap.globalit.tracking.api.internal.v2.report.ReportBuilder;
import com.sap.globalit.tracking.authorization.AuthorizationManager;
import com.sap.globalit.tracking.dao.ApplicationDAO;
import com.sap.globalit.tracking.model.ApplicationPlattform;
import com.sap.globalit.tracking.model.analysis.ReportView;
import com.sap.globalit.tracking.model.reporting.Chart;
import com.sap.globalit.tracking.model.reporting.Table;
import com.sap.globalit.tracking.util.CSVWriter;
import com.sap.security.um.UMException;
import com.sap.security.um.user.PersistenceException;
import com.sap.security.um.user.UserProvider;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.sql.SQLException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Path("/internal/report/v2")
@Api(value = "Report API", description = "Report Service")
public class ReportAPIHanaImpl implements ReportAPI {

    private static final Logger log = LoggerFactory.getLogger(ReportAPIHanaImpl.class);

    private static ZoneId UTC = ZoneId.of("UTC");

    @Inject
    ApplicationDAO appDAO;

    @Inject
    ReportBuilder reportBuilder;

    @Inject
    AuthorizationManager authManager;

    @Inject
    TemporaryCSVStore tempCSVStore;

    @Inject
    EntityManager em;

    @Inject
    UserProvider userProvider;


    /**
     * Contains all authorized applications
     */
    private List<String> authorizedApplications;

    private ZonedDateTime start;
    private ZonedDateTime end;
    private TimeInterval interval;

    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // ----------------------------------------------- USAGE REPORT
    // ----------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------

    @Override
    public Chart get_Usage_ByApp(long param_start, long param_end,
                                 TimeInterval param_interval,
                                 String param_appfilter) throws Exception {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Application Usage", "LineChart", param_interval.toString());

        return reportBuilder.getChart_Usage_ByApp(
                start, end,
                interval, authorizedApplications);
    }

    @Override
    public Table get_Usage_ByApp_AsTable(long param_start, long param_end,
                                         TimeInterval param_interval,
                                         String param_appfilter) throws Exception {

        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Application Usage", "Table", param_interval.toString());

        return reportBuilder.getTable_Usage_ByApp(
                start, end,
                interval, authorizedApplications);
    }

    @Override
    public Response get_Usage_ByApp_AsTable_CSV(long param_start,
                                                long param_end, TimeInterval param_interval,
                                                String param_appfilter) throws Exception {

        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Application Usage", "Table/CSV", param_interval.toString());

        Table table = reportBuilder.getTable_Usage_ByApp(
                start, end,
                interval, authorizedApplications);
        return generateCSVResponse(table);
    }

    @Override
    public Chart get_Usage_ByApp_Bar(long param_start, long param_end,
                                     String param_appfilter) throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, null);

        storeReportViewForAnalysis("Application Usage", "Bar", null);

        return reportBuilder.getChart_Usage_ByApp_noTime(start, end, authorizedApplications);
    }

    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // ------------------------------------------- ACTIVE DEVICES REPORT
    // -----------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------

    @Override
    public Chart get_ActiveUser_ByApp(long param_start, long param_end,
                                      TimeInterval param_interval,
                                      String param_appfilter) throws Exception {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Active Devices", "LineChart", param_interval.toString());

        return reportBuilder.getChart_ActiveDevices_ByApp(
                start, end,
                interval, authorizedApplications);

    }

    @Override
    public Table get_ActiveUser_ByApp_AsTable(long param_start, long param_end,
                                              TimeInterval param_interval,
                                              String param_appfilter) throws Exception {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Active Devices", "Table", param_interval.toString());

        return reportBuilder.getTable_ActiveDevices_ByApp(
                start, end,
                interval, authorizedApplications);
    }

    @Override
    public Response get_ActiveUser_ByApp_AsTable_CSV(long param_start,
                                                     long param_end, TimeInterval param_interval,
                                                     String param_appfilter)
            throws Exception {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Active Devices", "Table/CSV", param_interval.toString());

        Table table = reportBuilder.getTable_ActiveDevices_ByApp(
                start, end,
                interval, authorizedApplications);

        return generateCSVResponse(table);
    }

    @Override
    public Chart get_ActiveUser_ByApp_Bar(long param_start, long param_end,
                                          String param_appfilter) throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, null);

        storeReportViewForAnalysis("Active Devices", "Top10", null);

        return reportBuilder.getChart_ActiveDevices_ByApp_noTime(start, end, authorizedApplications);
    }

    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // ------------------------------------------- EVENTS
    // --------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------

    @Override
    public Chart get_Events_ForApplication(long param_start, long param_end,
                                           TimeInterval param_interval,
                                           String param_appfilter) throws SQLException, UMException {
        applyParameters(param_start, param_end, param_appfilter, param_interval);

        storeReportViewForAnalysis("Events", "LineChart", param_interval.toString());

        String appId = authorizedApplications.get(0);

        return reportBuilder.getChart_Events_ForApplication(
                start, end,
                interval, appId);
    }

    @Override
    public Table get_Events_ForApplication_AsTable(long param_start,
                                                   long param_end, TimeInterval param_interval,
                                                   String param_appfilter) throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Events", "Table", param_interval.toString());

        String appId = authorizedApplications.get(0);

        return reportBuilder.getTable_Events_ForApplication(
                start, end,
                interval, appId);
    }

    @Override
    public Response get_Events_ForApplication_AsTable_CSV(long param_start,
                                                          long param_end, TimeInterval param_interval,
                                                          String param_appfilter)
            throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Events", "Table/CSV", param_interval.toString());

        String appId = authorizedApplications.get(0);

        Table table = reportBuilder.getTable_Events_ForApplication(
                start, end,
                interval, appId);

        return generateCSVResponse(table);
    }

    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // ------------------------------------------- Device Type
    // --------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------

    @Override
    public Chart get_DeviceType_ForApplication(long param_start, long param_end, TimeInterval param_interval, String param_appfilter) throws SQLException, UMException {
        applyParameters(param_start, param_end, param_appfilter, param_interval);

        storeReportViewForAnalysis("DeviceType", "LineChart", param_interval.toString());

        String appId = authorizedApplications.get(0);

        return reportBuilder.getChart_DeviceType_ForApplication(
                start, end,
                interval, appId);
    }

    @Override
    public Table get_DeviceType_ForApplication_AsTable(long param_start, long param_end, TimeInterval param_interval, String param_appfilter) throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("DeviceType", "Table", param_interval.toString());

        String appId = authorizedApplications.get(0);

        return reportBuilder.getTable_DeviceType_ForApplication(
                start, end,
                interval, appId);
    }

    @Override
    public Response get_DeviceType_ForApplication_AsTable_CSV(long param_start, long param_end, TimeInterval param_interval, String param_appfilter) throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("DeviceType", "Table/CSV", param_interval.toString());

        String appId = authorizedApplications.get(0);

        Table table = reportBuilder.getTable_DeviceType_ForApplication(
                start, end,
                interval, appId);

        return generateCSVResponse(table);
    }

    private Response generateCSVResponse(Table table) {
        String csv = CSVWriter.generateCSV(table).getContent();
        return storeCSVForDownload(csv);
    }

    @Override
    public Table get_Events_ForApplication_ByGCORegion(long param_start, long param_end, TimeInterval param_interval, String param_appfilter) throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, null);

        storeReportViewForAnalysis("Events - Regional (GCO)", "Table", "n/a");

        return reportBuilder.getTable_Events_ByGCORegion(
                start, end,
                authorizedApplications);
    }

    @Override
    public Response get_Events_ForApplication_ByGCORegion_CSV(long param_start, long param_end, TimeInterval param_interval, String param_appfilter) throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, null);

        storeReportViewForAnalysis("Events - Regional (GCO)", "Table", "n/a");

        Table table = reportBuilder.getTable_Events_ByGCORegion(
                start, end,
                authorizedApplications);

        return generateCSVResponse(table);
    }

    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // ------------------------------------------- Version Distribution
    // ------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------

    @Override
    public Chart get_ActiveUsers_ByApplicationVersion_ForApplication(
            long param_start, long param_end,
            TimeInterval param_interval, String param_appfilter)
            throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Version Distribution", "LineChart", param_interval.toString());

        String appId = authorizedApplications.get(0);

        return reportBuilder.getChart_VersionDistribution_ByActiveUsers(
                start, end,
                interval, appId);
    }

    @Override
    public Table get_ActiveUsers_ByApplicationVersion_ForApplication_asTable(
            long param_start, long param_end,
            TimeInterval param_interval, String param_appfilter)
            throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Version Distribution", "Table", param_interval.toString());

        String appId = authorizedApplications.get(0);

        return reportBuilder.getTable_VersionDistribution_ByActiveUsers(
                start, end,
                interval, appId);
    }

    @Override
    public Response get_ActiveUsers_ByApplicationVersion_ForApplication_asTable_CSV(
            long param_start, long param_end,
            TimeInterval param_interval, String param_appfilter)
            throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Version Distribution", "Table/CSV", param_interval.toString());

        String appId = authorizedApplications.get(0);

        Table table = reportBuilder.getTable_VersionDistribution_ByActiveUsers(
                start, end,
                interval, appId);

        return generateCSVResponse(table);
    }

    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // ------------------------------------------- Device Model Usage
    // --------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------

    @Override
    public Chart get_DeviceModel_ForApplication(long param_start,
                                                long param_end, TimeInterval param_interval,
                                                String param_appfilter) throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Device Model Usage", "LineChart", param_interval.toString());

        String appId = authorizedApplications.get(0);

        return reportBuilder.getChart_DeviceModel_ByUsage(
                start, end,
                interval, appId);
    }

    @Override
    public Table get_DeviceModel_ForApplication_AsTable(long param_start,
                                                        long param_end, TimeInterval param_interval,
                                                        String param_appfilter) throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Device Model Usage", "Table", param_interval.toString());

        String appId = authorizedApplications.get(0);

        return reportBuilder.getTable_DeviceModel_ByUsage(
                start, end,
                interval, appId);
    }

    @Override
    public Response get_DeviceModel_ForApplication_AsTable_CSV(long param_start,
                                                               long param_end, TimeInterval param_interval,
                                                               String param_appfilter)
            throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Device Model Usage", "Table/CSV", param_interval.toString());

        String appId = authorizedApplications.get(0);

        Table table = reportBuilder.getTable_DeviceModel_ByUsage(
                start, end,
                interval, appId);

        return generateCSVResponse(table);
    }

    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // ------------------------------------------- Region
    // --------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------

    @Override
    public Chart get_ActiveUsers_ByRegion_ForApplication(long param_start,
                                                         long param_end, TimeInterval param_interval,
                                                         String param_appfilter) throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Region Distribution", "LineChart", param_interval.toString());

        String appId = authorizedApplications.get(0);

        return reportBuilder.getChart_RegionDistribution_ByActiveDevices(
                start, end,
                interval, appId);
    }

    @Override
    public Table get_ActiveUsers_ByRegion_ForApplication_asTable(
            long param_start, long param_end,
            TimeInterval param_interval, String param_appfilter)
            throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Region Distribution", "Table", param_interval.toString());

        String appId = authorizedApplications.get(0);

        return reportBuilder.getTable_RegionDistribution_ByActiveDevices(
                start, end,
                interval, appId);
    }

    @Override
    public Response get_ActiveUsers_ByRegion_ForApplication_asTable_CSV(
            long param_start, long param_end,
            TimeInterval param_interval, String param_appfilter)
            throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Region Distribution", "Table/CSV", param_interval.toString());

        String appId = authorizedApplications.get(0);

        Table table = reportBuilder.getTable_RegionDistribution_ByActiveDevices(
                start, end,
                interval, appId);

        return generateCSVResponse(table);
    }

    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // ------------------------------------------- Location Info
    // --------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------

    @Override
    public Table get_LocationInfo_asTable(long param_start, long param_end,
                                          TimeInterval param_interval,
                                          String param_appfilter) throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Location", "Table", param_interval.toString());

        return reportBuilder.getTable_LocationInfo(
                start, end,
                authorizedApplications);
    }

    @Override
    public Response get_LocationInfo_asTable_CSV(long param_start,
                                                 long param_end, TimeInterval param_interval,
                                                 String param_appfilter) throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, param_interval);

        storeReportViewForAnalysis("Location", "Table/CSV", param_interval.toString());

        Table table = reportBuilder.getTable_LocationInfo(
                start, end,
                authorizedApplications);

        return generateCSVResponse(table);
    }

    @Override
    public Chart get_OS_Version(long param_start, long param_end, TimeInterval param_interval, ApplicationPlattform.PlatformType platform, String param_appfilter) throws Exception {
        applyParameters(param_start, param_end, param_appfilter, param_interval);

        storeReportViewForAnalysis(platform + "OS Version", "LineChart", param_interval.toString());

        return reportBuilder.getChart_OsVersion_ByApp(
                start, end,
                interval, authorizedApplications, platform);
    }

    @Override
    public Table get_OS_Version_AsTable(long param_start, long param_end, TimeInterval param_interval, ApplicationPlattform.PlatformType platform, String param_appfilter) throws Exception {
        applyParameters(param_start, param_end, param_appfilter, param_interval);

        storeReportViewForAnalysis(platform + "OS Version", "Table", param_interval.toString());

        return reportBuilder.getTable_OsVersion_ByApp(
                start, end,
                interval, authorizedApplications, platform);
    }

    @Override
    public Response get_OS_Version_AsTable_CSV(long param_start, long param_end, TimeInterval param_interval, ApplicationPlattform.PlatformType platform, String param_appfilter) throws Exception {
        applyParameters(param_start, param_end, param_appfilter, param_interval);

        storeReportViewForAnalysis(platform + "OS Version", "Table/CSV", param_interval.toString());

        Table table = reportBuilder.getTable_OsVersion_ByApp(
                start, end,
                interval, authorizedApplications, platform);

        return generateCSVResponse(table);
    }

    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // --------------------------------------------------- GCO
    // --------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------

    @Override
    public Table get_Usage_ByRegionGCO_AsTable(long param_start,
                                               long param_end, String param_appfilter)
            throws SQLException, UMException {
        applyParameters(param_start, param_end, param_appfilter, null);

        storeReportViewForAnalysis("Usage - Regional (GCO)", "Table", "n/a");

        return reportBuilder.getTable_Usage_ByGCORegion(
                start, end,
                authorizedApplications);
    }

    @Override
    public Response get_Usage_ByRegionGCO_AsTable_csv(long param_start,
                                                      long param_end, String param_appfilter)
            throws SQLException, UMException {
        applyParameters(param_start, param_end, param_appfilter, null);

        storeReportViewForAnalysis("Usage - Regional (GCO)", "Table/CSV", "n/a");

        Table table = reportBuilder.getTable_Usage_ByGCORegion(
                start, end,
                authorizedApplications);

        return generateCSVResponse(table);
    }

    @Override
    public Table get_ActiveDevices_ByRegionGCO_AsTable(long param_start,
                                                       long param_end, String param_appfilter)
            throws SQLException, UMException {
        applyParameters(param_start, param_end,
                param_appfilter, null);

        storeReportViewForAnalysis("Active Devices - Regional (GCO)", "Table", "n/a");

        return reportBuilder.getTable_ActiveDevices_ByGCORegion(
                start, end,
                authorizedApplications);
    }

    @Override
    public Response get_ActiveDevices_ByRegionGCO_AsTable_CSV(long param_start,
                                                              long param_end, String param_appfilter)
            throws SQLException, UMException {

        applyParameters(param_start, param_end,
                param_appfilter, null);

        storeReportViewForAnalysis("Active Devices - Regional (GCO)", "Table/CSV", "n/a");

        Table table = reportBuilder.getTable_ActiveDevices_ByGCORegion(
                start, end,
                authorizedApplications);

        return generateCSVResponse(table);
    }

    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // --------------------------------------------------- MISC
    // --------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------------------------------------

    private void applyParameters(long start, long end, String appFilterString, TimeInterval interval) throws UMException {

        // resolve apps (authorized & requested)
        List<String> requestedApplications = Strings.isNullOrEmpty(appFilterString) ? appDAO.getAllIds() : Arrays.asList(appFilterString.split("\\|"));
        List<String> authorizedApps = authManager.getAuthorizedAppsFor(userProvider.getCurrentUser().getName()).stream().map(i -> i.getId()).collect(Collectors.toList());
        requestedApplications.retainAll(authorizedApps);

        this.authorizedApplications = requestedApplications;

        this.interval = interval;

        this.start = ZonedDateTime.ofInstant(Instant.ofEpochMilli(start), UTC);
        this.end = ZonedDateTime.ofInstant(Instant.ofEpochMilli(end), UTC);
    }

    private void storeReportViewForAnalysis(String report, String view, String timeInterval) throws PersistenceException {
        em.getTransaction().begin();
        ReportView reportView = new ReportView(userProvider.getCurrentUser().getName(), this.authorizedApplications, report, view, Instant.now().toEpochMilli(), start.toInstant().toEpochMilli(), end.toInstant().toEpochMilli(), timeInterval);
        em.persist(reportView);
        em.getTransaction().commit();
    }

    private Response storeCSVForDownload(String content) {
        String uuid = UUID.randomUUID().toString();
        tempCSVStore.put(uuid, content);
        return Response.ok(uuid, MediaType.APPLICATION_JSON).build();
    }

    @Override
    public Response downloadPreGeneratedCSV(String uuid) {
        String csv = tempCSVStore.remove(uuid);
        if (csv == null)
            return Response.serverError().build();
        return Response
                .ok(csv, "text/csv")
                .header("Content-Disposition",
                        "attachment;filename=globalit-tracking-export.csv")
                .build();
    }

}