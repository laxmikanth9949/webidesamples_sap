package com.sap.globalit.tracking.api.sainternal;

import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/sa-internal/status")
@Api(value = "SA Internal Status", description = "SA Internal Status Service")
public class SaInternalStatusAPI {

    private static Logger logger = LoggerFactory.getLogger(SaInternalStatusAPI.class);

    public SaInternalStatusAPI() {
    }

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public Response status() throws Exception {
        return Response.ok("Sa-Internal: Tracking framework up and running!")
                .header("Access-Control-Allow-Origin", "*")
                .build();
    }

}