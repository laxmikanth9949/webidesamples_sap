package com.sap.globalit.tracking.api.internal;

import com.google.gson.annotations.Expose;
import com.sap.globalit.tracking.api.internal.v2.SQLDAO;
import com.sap.globalit.tracking.dao.ApplicationDAO;
import com.sap.globalit.tracking.dto.ApplicationDTO;
import com.sap.globalit.tracking.model.Application;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by D053397 on 29.04.2016.
 */
@Path("/internal/heartbeat")
@Api(value = "Heartbeat API", description = "Services for the Heartbeat Project")
public class HeartbeatAPI {

    private static final Logger log = LoggerFactory.getLogger(HeartbeatAPI.class);

    @Inject
    ApplicationDAO applicationDAO;

    @Inject
    SQLDAO sqldao;

    @GET
    @Path("application")
    @ApiOperation(value = "List existing applications")
    public List<ApplicationDTO> allApplications() {
        log.info("Get Applications");

        return applicationDAO.getAllWithRecentUsage()
                .stream()
                .map(a -> new ApplicationDTO(a.getId(), a.getName()))
                .collect(Collectors.toList());
    }

    @GET
    @Path("application/{appId}/usage")
    @ApiOperation(value = "Get usage for an application")
    public ApplicationMeasure appMeasurement(@PathParam("appId") String appId) throws SQLException {
        log.info("Get Applications");

        long from = ZonedDateTime.now().minusHours(1).toEpochSecond() * 1000;
        long to = ZonedDateTime.now().toEpochSecond() * 1000;

        Application application = applicationDAO.getByKey(appId)
                .orElseThrow(() -> new NotFoundException("App " + appId + " not found"));

        return sqldao.getUsage_byApp(from, to, Collections.singletonList(appId), ReportAPI.TimeInterval.DAY, r -> {
            long count = r.next() ? r.getLong("MEASURE") : 0;
            return new ApplicationMeasure(application.getId(), application.getName(), count);
        });
    }

    public static class ApplicationMeasure extends ApplicationDTO {
        @Expose
        public long value;

        public ApplicationMeasure(String id, String name, long value) {
            super(id, name);
            this.value = value;
        }
    }

}
