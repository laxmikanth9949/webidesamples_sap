package com.sap.globalit.tracking.util;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.sap.globalit.tracking.model.DeviceType;
import net.sf.uadetector.ReadableUserAgent;
import net.sf.uadetector.UserAgent;
import net.sf.uadetector.UserAgentStringParser;
import net.sf.uadetector.UserAgentType;
import net.sf.uadetector.service.UADetectorServiceFactory;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class UserAgentUtil {

    private static final UserAgentStringParser parser = UADetectorServiceFactory.getResourceModuleParser();

    private static final LoadingCache<String, ReadableUserAgent> cache = CacheBuilder.newBuilder()
            .maximumSize(500)
            .expireAfterWrite(2, TimeUnit.HOURS)
            .build(new CacheLoader<String, ReadableUserAgent>() {
                @Override
                public ReadableUserAgent load(String s) throws Exception {
                    return parser.parse(s);
                }
            });

    public static DeviceType getDeviceType(String rawUserAgent) throws ExecutionException {
        ReadableUserAgent result = cache.get(rawUserAgent);

        if (result.getType() == UserAgentType.MOBILE_BROWSER) {
            return DeviceType.MOBILE;
        }

        return DeviceType.DESKTOP;
    }

    public static String getModelName(String rawUserAgent) {
        try {
            ReadableUserAgent result = cache.get(rawUserAgent);

            if (result.equals(UserAgent.EMPTY)) {
                // not able to resolve it -> keep raw string
                return rawUserAgent;
            }

            return result.getName() + " " + result.getVersionNumber().getMajor();
        } catch (ExecutionException e){
            throw new RuntimeException(e);
        }
    }

}
