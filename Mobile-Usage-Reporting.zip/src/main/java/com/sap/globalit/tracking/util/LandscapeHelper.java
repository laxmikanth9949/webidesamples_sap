package com.sap.globalit.tracking.util;

import java.util.Arrays;
import java.util.Objects;

public class LandscapeHelper {

    public enum Landscape {

        PROD("https://sapprod.apimanagement.hana.ondemand.com:443/it-mobile-usage-reporting/api", "shallwe", "tracking"),

        TEST("https://saptst.apimanagement.hana.ondemand.com/it-mobile-usage-reporting/api", "sapitcloudt", "tracking"),

        DEV("https://q83gvu4dlz-prod.stakeholder.apim.hana.ondemand.com/q83gvu4dlz/it-mobile-usage-reporting/api", "br339jmc4c", "tracking");

        String url;
        String account;
        String application;

        Landscape(String url, String account, String application) {
            this.url = url;
            this.account = account;
            this.application = application;
        }

        public String getUrl() {
            return url;
        }
    }

    public Landscape get() {
        String account = System.getenv("HC_ACCOUNT");
        String application = System.getenv("HC_APPLICATION");

        return Arrays.stream(Landscape.values())
                .filter(i -> Objects.equals(i.account, account) && Objects.equals(i.application, application))
                .findFirst()
                .orElse(Landscape.DEV);
    }

    public boolean isProductiveLandscape() {
        return get() == Landscape.PROD;
    }
}
