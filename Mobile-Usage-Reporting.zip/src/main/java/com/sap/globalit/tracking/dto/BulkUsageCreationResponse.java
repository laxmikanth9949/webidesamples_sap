package com.sap.globalit.tracking.dto;

import java.util.List;

/**
 * Created by D053397 on 02.01.2017.
 */
public class BulkUsageCreationResponse {

    public final List<UsageCreationResponse> entries;
    public final long successful;
    public final long error;

    public BulkUsageCreationResponse(List<UsageCreationResponse> entries) {
        this.entries = entries;
        this.successful = entries.stream().filter(i -> i.error == null).count();
        this.error = entries.stream().filter(i -> i.usageId == null).count();
    }
}
