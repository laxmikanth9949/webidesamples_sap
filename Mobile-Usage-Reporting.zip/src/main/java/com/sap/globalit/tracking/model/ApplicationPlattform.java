package com.sap.globalit.tracking.model;

import javax.persistence.*;

/**
 * Plattform of the Application, e.g. EasyConnect for Android and EasyConnect
 * for iOS Does not distinguish between Tablets and Phones!
 *
 * @author D053397
 */
@Entity
@IdClass(ApplicationPlattformId.class)
public class ApplicationPlattform {

    public enum PlatformType {
        ANDROID, IOS, WEB, WINDOWS, MAC
    }

    @Id
    @Enumerated(EnumType.STRING)
    private PlatformType id;

    @Id
    @ManyToOne
    private Application application;

    protected ApplicationPlattform() {

    }

    public ApplicationPlattform(PlatformType id, Application application) {
        this();
        this.id = id;
        this.application = application;
        this.application.getPlattforms().add(this);
    }

    public PlatformType getId() {
        return id;
    }

    public Application getApplication() {
        return application;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
                + ((application == null) ? 0 : application.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ApplicationPlattform other = (ApplicationPlattform) obj;
        if (application == null) {
            if (other.application != null)
                return false;
        } else if (!application.equals(other.application))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "ApplicationPlattform [" + id + " | " + application + "]";
    }

    public String getName() {
        return application.getName() + " | " + id;
    }

    public ApplicationPlattformId getPersistenceId() {
        return new ApplicationPlattformId(id, application.getId());
    }

}