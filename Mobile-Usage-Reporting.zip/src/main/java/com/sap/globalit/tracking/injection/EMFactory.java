package com.sap.globalit.tracking.injection;

import javax.persistence.EntityManager;


public class EMFactory extends com.sap.it.mobile.hcp.jersey.injection.EMFactory {

    @Override
    public void dispose(EntityManager entityManager) {
        // if transaction is still active -> assume exception -> rollback
        if (entityManager.getTransaction().isActive())
            entityManager.getTransaction().rollback();

        super.dispose(entityManager);
    }
}
