package com.sap.globalit.tracking.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by D053397 on 20.02.2017.
 */
public class DBSequence {

    protected String name;

    public DBSequence(String name) {
        this.name = name;
    }

    public long next(Connection connection) throws SQLException {
        try (PreparedStatement stmt = connection.prepareStatement(String.format("SELECT \"%s\".nextval FROM DUMMY", name));
             ResultSet rs = stmt.executeQuery()) {
            rs.next();
            return rs.getLong(1);
        }
    }
}