package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;
import com.sap.globalit.tracking.model.authorization.SingleAppAuthorization;

public class AuthorizationDecisionDTO {

    @Expose
    public long authId;

    @Expose
    public SingleAppAuthorization.Status status;

}