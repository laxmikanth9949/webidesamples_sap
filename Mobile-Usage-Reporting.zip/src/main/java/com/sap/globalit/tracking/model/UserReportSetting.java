package com.sap.globalit.tracking.model;

import com.sap.globalit.tracking.api.internal.ReportAPI;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * Created by D053397 on 13.03.2015.
 */
@Entity
@Table(name = "REPORTSETTING_USER", uniqueConstraints = {@UniqueConstraint(columnNames = {"userId"})})
public class UserReportSetting extends ReportSetting {

    @NotNull
    String userId;

    protected UserReportSetting() {
    }

    public UserReportSetting(List<String> applications, String reportId, String viewId, long timeFrom, long timeTo, long timeDuration, ReportAPI.TimeInterval timeInterval, String userId) {
        super(applications, reportId, viewId, timeFrom, timeTo, timeDuration, timeInterval);
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
