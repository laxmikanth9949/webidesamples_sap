package com.sap.globalit.tracking.model;

/**
 * Created by D053397 on 07.09.2016.
 */
public enum DeviceType {
    MOBILE, DESKTOP
}
