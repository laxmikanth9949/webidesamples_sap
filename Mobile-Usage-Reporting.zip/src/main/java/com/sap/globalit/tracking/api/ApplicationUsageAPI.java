package com.sap.globalit.tracking.api;

import com.codahale.metrics.Meter;
import com.codahale.metrics.MetricRegistry;
import com.google.common.base.Strings;
import com.sap.globalit.tracking.dao.UsageDAO;
import com.sap.globalit.tracking.dto.ApplicationUsageReport;
import com.sap.globalit.tracking.dto.BulkUsageCreationResponse;
import com.sap.globalit.tracking.dto.Mapper;
import com.sap.globalit.tracking.dto.UsageCreationResponse;
import com.sap.globalit.tracking.model.ApplicationPlattform.PlatformType;
import com.sap.globalit.tracking.model.DeviceInformation;
import com.sap.globalit.tracking.model.DeviceType;
import com.sap.globalit.tracking.model.Usage;
import com.sap.globalit.tracking.util.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Nullable;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Provider;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import java.sql.*;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Path("/usage")
@Api(value = "Usage API", description = "Usage API")
public class ApplicationUsageAPI {

    private static final Logger logger = LoggerFactory.getLogger(ApplicationUsageAPI.class);

    private static final Pattern PATTERN_CC_BROWSER = Pattern.compile("[a-zA-z]{2}\\-([a-zA-z]{2})");

    private static final Map<String, String> deviceModelConversion = ConfigurationUtil.loadFromJSONFile("device-model-conv.json");

    private static final long SEC_1 = 1000 * 1;

    public static final String USAGE_CHECK_STMT = "SELECT USAGE_ID, APPLICATION_ID FROM USAGE WHERE USAGE_ID = ?";
    public static final String EVENT_STMT = "INSERT INTO USAGE_EVENT (EVENT_ID, INSERTED_AT, USAGE_ID, EVENT_NAME, EVENT_DATE) VALUES (?,?,?,?,?)";
    public static final String USAGE_STMT = "INSERT INTO USAGE (INSERTED_AT,REFERER,COUNTRY_CODE,DEVICE_ID,DEVICE_TYPE,MODEL_NAME,OPERATING_SYSTEM,RAW_USER_AGENT,SCREEN_SIZE,USAGE_START,USAGE_END,USER_INFORMATION_ID,APPLICATION_ID,VERSION_ID,PLATFORM_ID,USAGE_ID,ORIGIN) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    public static final String PLATFORM_STMT = "SELECT a.id, a.name, p.id FROM APPLICATION a JOIN APPLICATIONPLATTFORM p ON (a.ID = p.APPLICATION_ID) WHERE a.ID = ? AND p.id = ?";


    @Inject
    RealtimeSocketManager realtimeManager;

    @Inject
    WebHostRestrictionManager webHostRestrictionManager;

    @Inject
    Provider<Connection> connectionProvider;

    @Inject
    @Named("EVENT_SEQUENCE")
    DBSequence eventSequence;

    @Inject
    UsageDAO usageDAO;

    @Inject
    MetricRegistry registry;

    private Meter slowUsageMeter;
    private Meter missingVersionInfoMeter;

    public ApplicationUsageAPI() {
    }

    @PostConstruct
    public void init() {
        slowUsageMeter = registry.meter("slow-usage-report");
        missingVersionInfoMeter = registry.meter("missing-version-info");
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Response createNew(ApplicationUsageReport report, @HeaderParam("Accept-Language") String acceptLanguageHeader, @HeaderParam("Referer") String referer, @DefaultValue("true") @QueryParam("Realtime") Boolean broadcastUsage, @HeaderParam("Origin") String origin) {

        if (report == null) {
            logger.info("Usage rejected: no information provided | {}", report);
            throw new BadRequestException("No information provided");
        }

        logger.debug("Incoming report | {}", report);

        // map external DTO to internal model
        Usage usage = Mapper.usage(report);

        Timer timer = new Timer();
        long start = System.currentTimeMillis();

        if (didNotProvideVersionInformation(usage)) {
            logger.info("Usage rejected: version information missing | {}", report);
            missingVersionInfoMeter.mark();
            throw new BadRequestException("Version Information missing");
        }
        timer.tag("Missing Version Information Check");

        // ignore snapshots
        if (isSnapshotVersion(usage.versionId)) {
            logger.info("Usage rejected: non-productive app usage | {}", report);
            throw new BadRequestException("Non productive app usages are ignored (-SNAPSHOT)");
        }
        timer.tag("Snapshot Check");

        // trim device id
        usage.deviceId = trimDeviceId(usage.deviceId, report);

        timer.tag("Trim Device Id");

        // resolve device model if not already resolved by client lib
        // e.g. iPhone7,2 -> iPhone 6
        String resolvedModelName = deviceModelConversion.get(usage.modelName);
        if (resolvedModelName != null)
            usage.modelName = resolvedModelName;

        timer.tag("Resolve Model Name");

        // set country code using accept header if available
        if (acceptLanguageHeader != null && !acceptLanguageHeader.isEmpty()) {
            updateCountryCodeFromAcceptHeader(usage, acceptLanguageHeader);
        }

        timer.tag("Update Country Code");

        if (!isConsistentTimespan(usage)) {
            logger.info("Usage rejected: inconsistent timespan | {}", report);
            throw new BadRequestException("Inconsistent timespan");
        }
        timer.tag("Check TimeSpan");

        // check if host is blacklisted/whitelisted
        if (isBlacklisted(usage)) {
            logger.info("Usage rejected: {} | {}", "Host " + report.webUsageHost + " is restricted", report);

            return Response.ok("Host " + report.webUsageHost + " is restricted", "text/plain").build();
        }
        timer.tag("Check Blacklist");

        normalizeDeviceInformation(usage);
        timer.tag("Normalize Device Info");

        // parse model name
        if (usage.platformId == PlatformType.WEB && (Strings.isNullOrEmpty(usage.rawUserAgent))) {
            usage.rawUserAgent = usage.modelName;
            usage.modelName = UserAgentUtil.getModelName(usage.rawUserAgent);
        }
        timer.tag("Parse Model Name");

        // parse device type
        try {
            switch (usage.platformId) {
                case ANDROID:
                case IOS:
                    usage.deviceType = DeviceType.MOBILE;
                    break;
                case WEB:
                    usage.deviceType = UserAgentUtil.getDeviceType(usage.rawUserAgent);
                    break;
                case WINDOWS:
                case MAC:
                    usage.deviceType = DeviceType.DESKTOP;
                    break;
            }
        } catch (Exception e) {
            logger.warn("Could not parse Device Type", e);
        }
        timer.tag("Parse Device Type");

        // set referer for web apps
        if (!Strings.isNullOrEmpty(origin)) {
            usage.origin = origin;
        }
        if (!Strings.isNullOrEmpty(referer)) {
            usage.referer = referer;
        }

        try {
            usageDAO.persistToDatabase(usage, timer);

            logger.info("Report created | {}", usage);

            if (broadcastUsage) {
                try (Connection conn = connectionProvider.get();
                     PreparedStatement platformStmt = conn.prepareStatement(PLATFORM_STMT)) {

                    timer.tag("Broadcast (CO)");

                    platformStmt.setString(1, usage.applicationId);
                    platformStmt.setString(2, usage.platformId.name());

                    try (ResultSet platformRS = platformStmt.executeQuery()) {

                        if (!platformRS.next()) {
                            logger.warn("Usage rejected: platform does not exist | {}", report);
                            throw new BadRequestException("Application or Platform does not exist");
                        }

                        timer.tag("Broadcast (DB)");

                        String applicationName = platformRS.getString(2);
                        realtimeManager.broadcastUsage(usage, applicationName);

                        timer.tag("Broadcast (WS)");
                    }
                }
            }

            return generateResponse(usage.usageId);
        } catch (WebApplicationException e) {
            throw e; // pass through -> prevent wrapping to InternalServerErrorException
        } catch (RuntimeException | SQLException e) {
            logger.error("Usage failed: {} | {} | {}", e.getMessage(), report, origin);
            throw new InternalServerErrorException(e);
        } finally {
            String timerInfo = timer.getInfo();
            logger.debug("Timer: {}", timerInfo);

            long duration = System.currentTimeMillis() - start;
            if (duration > SEC_1) {
                logger.debug("Slow report | {} | {}", report, timerInfo + " s");
                slowUsageMeter.mark();
            }
        }
    }

    private boolean isConsistentTimespan(Usage usage) {
        return usage.usageEnd.isAfter(usage.usageStart) || Objects.equals(usage.usageStart, usage.usageEnd);
    }

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("bulk")
    @ApiOperation(value = "Buld Usage Creation")
    public Response createBulk(List<ApplicationUsageReport> reportList) {
        logger.info("Receiving Bulk Report {}", reportList);

        // TODO collect statistics
        List<UsageCreationResponse> responseList = reportList.stream()
                .map(i -> {
                    try {
                        return (UsageCreationResponse) createNew(i, null, null, false, null).getEntity();
                    } catch (RuntimeException e) {
                        return UsageCreationResponse.error(e.getMessage());
                    }
                })
                .collect(Collectors.toList());

        return Response.status(207)
                .entity(new BulkUsageCreationResponse(responseList))
                .build();
    }

    private boolean didNotProvideVersionInformation(Usage report) {
        return report == null || report.applicationId == null || report.platformId == null || report.versionId == null;
    }

    private void updateCountryCodeFromAcceptHeader(Usage report, String acceptLanguageHeader) {
        String includedLanguage = report.countryCode;

        String countryCode = BrowserCountryProvider.get(acceptLanguageHeader, includedLanguage);

        report.countryCode = countryCode;
    }

    private String trimDeviceId(@Nullable String deviceID, ApplicationUsageReport report) {

        if (deviceID == null) {
            logger.warn("Usage rejected: no device id | {}", report);
            throw new BadRequestException("No device id provided");
        }

        if (deviceID.length() == 40)
            return deviceID.substring(0, deviceID.length() - 3);
        return deviceID;
    }

    private boolean isSnapshotVersion(String versionId) {
        return versionId.endsWith("SNAPSHOT");
    }

    private Response generateResponse(long usageID) {
        UsageCreationResponse response = UsageCreationResponse.sucessfull(usageID);

        return Response.status(Status.CREATED)
                .header("Access-Control-Allow-Origin", "*")
                .entity(response)
                .build();
    }

    private boolean isBlacklisted(Usage report) {
        if (Objects.equals(report.platformId, PlatformType.WEB.toString()) && report.browserLocationHost != null) {
            if (!webHostRestrictionManager.isAllowed(
                    report.applicationId,
                    report.browserLocationHost)) {
                return true;
            }
        }
        return false;
    }

    @POST
    @Path("/addEvent/{usageId}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addEventToUsage(@PathParam("usageId") long usageId,
                                    ApplicationUsageReport.EventReportDTO event) {

        try (Connection conn = connectionProvider.get();
             PreparedStatement statement = conn.prepareStatement(USAGE_CHECK_STMT);
             PreparedStatement eventStmt = conn.prepareStatement(EVENT_STMT)) {

            if (event.getEventId().contains("\\"))
                throw new BadRequestException("\\ are not allowed");

            conn.setAutoCommit(false);

            statement.setLong(1, usageId);
            ResultSet result = statement.executeQuery();
            if (!result.next())
                throw new InternalServerErrorException("Can´t find usage with id " + usageId);

            String appIdOfUsage = result.getString("APPLICATION_ID");
            String appIdOfEvent = event.appId;

            if (!Objects.equals(appIdOfEvent, appIdOfUsage)) {
                if (!"Fiori-itdssf".equalsIgnoreCase(appIdOfEvent)) {
                    logger.error("{} does not match usage id {} -> {}", event, usageId, appIdOfUsage);
                    return Response.serverError().build();
                } else {
                    // this seems to be Hao´s wrapper -> it´s fine if events app id does not match usages app id // todo fix mapping (?) in Haos wrapper
                    logger.debug("Allowing {} for usage id {} -> {}", event, usageId, appIdOfUsage);
                }
            }

            eventStmt.setLong(1, eventSequence.next(conn));
            eventStmt.setTimestamp(2, Timestamp.from(Instant.now()));
            eventStmt.setLong(3, usageId);
            eventStmt.setString(4, event.getEventId().replace("\\", ""));
            eventStmt.setTimestamp(5, Timestamp.from(Instant.ofEpochMilli(event.dateTime)));
            eventStmt.executeUpdate();

            conn.commit();

            return Response.status(Status.CREATED)
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        } catch (Exception e) {
            throw new InternalServerErrorException(e);
        }
    }

    @POST
    @Path("/addUser/{usageId}")
    @Consumes(MediaType.TEXT_PLAIN)
    public Response addUserToUsage(@PathParam("usageId") long usageId,
                                   String userId, @Context HttpHeaders headers) {
        logger.info("Adding User {} to Usage {}", userId, usageId);

        if (!isValidUserInfo(userId))
            return Response.status(Status.BAD_REQUEST)
                    .header("Access-Control-Allow-Origin", "*")
                    .build();

        return Response.status(Status.CREATED)
                .header("Access-Control-Allow-Origin", "*")
                .build();
    }

    public static boolean isValidUserInfo(String userId) {
        boolean isValidUser = userId != null && !userId.isEmpty() && (userId.toUpperCase().startsWith("D") || userId.toUpperCase().startsWith("C") || userId.toUpperCase().startsWith("I") || userId.toUpperCase().startsWith("S"));
        if (!isValidUser)
            logger.debug("Not a valid user: {}", userId);

        return isValidUser;
    }

    private void normalizeDeviceInformation(Usage usage) {
        normalizeCountryCode(usage);
    }

    public static String normalizeCountryCode(String countryCode) {
        String cc = countryCode;

        if (cc == null) {
            cc = DeviceInformation.FALLBACK_COUNTRY_CODE;
            return cc;
        }

        // convert country to upper case
        if (cc.length() == 2) {
            return cc.toUpperCase();
        }

        // convert en-US (input from some browsers) to US
        Matcher browser = PATTERN_CC_BROWSER.matcher(cc);
        if (browser.matches()) {
            return browser.group(1).toUpperCase();
        }

        return cc;
    }

    private void normalizeCountryCode(Usage devInfo) {
        String cc = normalizeCountryCode(devInfo.countryCode);
        devInfo.countryCode = cc;
    }
}