package com.sap.globalit.tracking.api.internal.v2.report;

import com.sap.globalit.tracking.api.internal.ReportAPI;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.IsoFields;
import java.time.temporal.TemporalAdjusters;
import java.util.Locale;

/**
 * Created by D053397 on 20.07.2016.
 */
public interface TimeHelper {
    String getDimensionKey();

    String getTimeEntryKey(ResultSet resultSet) throws SQLException;

    String getTimeEntryKey(ZonedDateTime instant);

    ZonedDateTime increment(ZonedDateTime current);

    ZonedDateTime snapToEnd(ZonedDateTime instant);

    ZonedDateTime snapToStart(ZonedDateTime instant);

    static TimeHelper getTimeHelper(ReportAPI.TimeInterval interval) {
        switch (interval) {
            case HOUR:
                return new TimeHelper.HourTimeHelper();
            case DAY:
                return new TimeHelper.DayTimeHelper();
            case WEEK:
                return new TimeHelper.WeekTimeHelper();
            case MONTH:
                return new TimeHelper.MonthTimeHelper();
            case QUARTER:
                return new TimeHelper.QuarterTimeHelper();
            case YEAR:
                return new TimeHelper.YearTimeHelper();
        }
        throw new RuntimeException();
    }

    class DayTimeHelper implements TimeHelper {

        private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd")
                .withLocale(Locale.ENGLISH)
                .withZone(ZoneId.of("UTC"));

        @Override
        public String getDimensionKey() {
            return "DAY";
        }

        @Override
        public String getTimeEntryKey(ResultSet resultSet) throws SQLException {
            // 2015/12/16
            String dayColumn = resultSet.getString("DAY");
            return dayColumn;
        }

        @Override
        public String getTimeEntryKey(ZonedDateTime instant) {
            return formatter.format(instant);
        }

        @Override
        public ZonedDateTime increment(ZonedDateTime current) {
            return current.plus(1, ChronoUnit.DAYS);
        }

        @Override
        public ZonedDateTime snapToEnd(ZonedDateTime instant) {
            return instant;
        }

        @Override
        public ZonedDateTime snapToStart(ZonedDateTime instant) {
            return instant;
        }
    }

    class WeekTimeHelper implements TimeHelper {

        @Override
        public String getDimensionKey() {
            return "WEEK";
        }

        @Override
        public String getTimeEntryKey(ResultSet resultSet) throws SQLException {
            // 2015/12/16
            String dayColumn = resultSet.getString("ISOWEEK");
            return dayColumn;
        }

        @Override
        public String getTimeEntryKey(ZonedDateTime instant) {
            return instant.get(IsoFields.WEEK_BASED_YEAR) + "-W" + String.format("%02d", instant.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR));
        }

        @Override
        public ZonedDateTime increment(ZonedDateTime current) {
            return current.plus(1, ChronoUnit.WEEKS);
        }

        @Override
        public ZonedDateTime snapToEnd(ZonedDateTime instant) {
            return instant.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY));
        }

        @Override
        public ZonedDateTime snapToStart(ZonedDateTime instant) {
            return instant.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        }
    }

    class MonthTimeHelper implements TimeHelper {

        private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/yyyy")
                .withLocale(Locale.ENGLISH)
                .withZone(ZoneId.of("UTC"));

        @Override
        public String getDimensionKey() {
            return "MONTH";
        }

        @Override
        public String getTimeEntryKey(ResultSet resultSet) throws SQLException {
            int year = resultSet.getInt("YEAR");
            int month = resultSet.getInt("MONTH");

            return String.format("%02d/%04d", month, year);
        }

        @Override
        public String getTimeEntryKey(ZonedDateTime instant) {
            return formatter.format(instant);
        }

        @Override
        public ZonedDateTime increment(ZonedDateTime current) {
            return current.plus(1, ChronoUnit.MONTHS);
        }

        @Override
        public ZonedDateTime snapToEnd(ZonedDateTime instant) {
            return instant.with(TemporalAdjusters.lastDayOfMonth());
        }

        @Override
        public ZonedDateTime snapToStart(ZonedDateTime instant) {
            return instant.with(TemporalAdjusters.firstDayOfMonth());
        }
    }

    class QuarterTimeHelper implements TimeHelper {

        // 2016-W28
        private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("'Q'Q'/'yyyy")
                .withLocale(Locale.ENGLISH)
                .withZone(ZoneId.of("UTC"));

        @Override
        public String getDimensionKey() {
            return "QUARTER";
        }

        @Override
        public String getTimeEntryKey(ResultSet resultSet) throws SQLException {
            // 2015/12/16
            int quarter = resultSet.getInt("Q");
            int year = resultSet.getInt("YEAR");
            return String.format("Q%d/%d", quarter, year);
        }

        @Override
        public String getTimeEntryKey(ZonedDateTime instant) {
            return formatter.format(instant);
        }

        @Override
        public ZonedDateTime increment(ZonedDateTime current) {
            return current.plus(3, ChronoUnit.MONTHS);
        }

        @Override
        public ZonedDateTime snapToEnd(ZonedDateTime instant) {
            return instant.withMonth(instant.getMonth().firstMonthOfQuarter().getValue()).plusMonths(2).with(TemporalAdjusters.lastDayOfMonth());
        }

        @Override
        public ZonedDateTime snapToStart(ZonedDateTime instant) {
            return instant.withMonth(instant.getMonth().firstMonthOfQuarter().getValue()).with(TemporalAdjusters.firstDayOfMonth());
        }
    }

    class YearTimeHelper implements TimeHelper {

        // 2016-W28
        private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy")
                .withLocale(Locale.ENGLISH)
                .withZone(ZoneId.of("UTC"));

        @Override
        public String getDimensionKey() {
            return "YEAR";
        }

        @Override
        public String getTimeEntryKey(ResultSet resultSet) throws SQLException {
            int year = resultSet.getInt("YEAR");
            return String.valueOf(year);
        }

        @Override
        public String getTimeEntryKey(ZonedDateTime instant) {
            return formatter.format(instant);
        }

        @Override
        public ZonedDateTime increment(ZonedDateTime current) {
            return current.plus(1, ChronoUnit.YEARS);
        }

        @Override
        public ZonedDateTime snapToEnd(ZonedDateTime instant) {
            return instant.with(TemporalAdjusters.lastDayOfYear());
        }

        @Override
        public ZonedDateTime snapToStart(ZonedDateTime instant) {
            return instant.with(TemporalAdjusters.firstDayOfYear());
        }
    }

    class HourTimeHelper implements TimeHelper {
        private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:'00'")
                .withLocale(Locale.ENGLISH)
                .withZone(ZoneId.of("UTC"));

        @Override
        public String getDimensionKey() {
            return "HOUR";
        }

        @Override
        public String getTimeEntryKey(ResultSet resultSet) throws SQLException {
            // 2015/12/16
            String dayColumn = resultSet.getString("DAY");
            int hourColumn = resultSet.getInt("HOUR");
            return dayColumn + " " + String.format("%02d", hourColumn) + ":00";
        }

        @Override
        public String getTimeEntryKey(ZonedDateTime instant) {
            return formatter.format(instant);
        }

        @Override
        public ZonedDateTime increment(ZonedDateTime current) {
            return current.plus(1, ChronoUnit.HOURS);
        }

        @Override
        public ZonedDateTime snapToEnd(ZonedDateTime instant) {
            return instant;
        }

        @Override
        public ZonedDateTime snapToStart(ZonedDateTime instant) {
            return instant;
        }
    }
}