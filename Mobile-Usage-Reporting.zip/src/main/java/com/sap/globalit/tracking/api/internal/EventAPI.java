package com.sap.globalit.tracking.api.internal;


import com.sap.globalit.tracking.api.internal.v2.SQLDAO;
import com.sap.globalit.tracking.api.internal.v2.report.TimeHelper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

@Path("/internal/events")
@Api(value = "Events API", description = "")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class EventAPI {

    private static final Logger log = LoggerFactory.getLogger(EventAPI.class);

    public static class EventReportRequest {
        @ApiParam(example = "2016-01-01")
        public String start;

        @ApiParam(example = "2016-01-01")
        public String end;

        @ApiParam(example = "DAY")
        public ReportAPI.TimeInterval interval;

        public List<EventId> events;

        public EventReportRequest setStart(String start) {
            this.start = start;
            return this;
        }

        public EventReportRequest setEnd(String end) {
            this.end = end;
            return this;
        }

        public EventReportRequest setInterval(ReportAPI.TimeInterval interval) {
            this.interval = interval;
            return this;
        }

        public EventReportRequest setEvents(List<EventId> events) {
            this.events = events;
            return this;
        }
    }

    public static class EventId {
        public String app;
        public String event;

        public EventId setApp(String app) {
            this.app = app;
            return this;
        }

        public EventId setEvent(String event) {
            this.event = event;
            return this;
        }

    }

    public static class EventValue {
        public String app;
        public String event;
        public long count;

        public EventValue setApp(String app) {
            this.app = app;
            return this;
        }

        public EventValue setEvent(String event) {
            this.event = event;
            return this;
        }

        public EventValue setCount(long count) {
            this.count = count;
            return this;
        }
    }

    public static class EventReportEntry {
        public String moment;
        public List<EventValue> events;

        public EventReportEntry setMoment(String moment) {
            this.moment = moment;
            return this;
        }

        public EventReportEntry setEvents(List<EventValue> events) {
            this.events = events;
            return this;
        }
    }

    @Inject
    SQLDAO sqldao;

    @POST
    @Path("report")
    public List<EventReportEntry> statistics(EventReportRequest reportRequest) throws SQLException {

        log.info("Get Statistics / Events");

        ZoneId utc = ZoneId.of("UTC");

        ZonedDateTime dateFrom = ZonedDateTime.of(LocalDate.parse(reportRequest.start), LocalTime.MIN, utc);
        ZonedDateTime dateTo = ZonedDateTime.of(LocalDate.parse(reportRequest.end), LocalTime.MAX, utc);

        TimeHelper timeHelper = TimeHelper.getTimeHelper(reportRequest.interval);

        LinkedHashMap<String, EventReportEntry> data = new LinkedHashMap<>();

        // generate all required time entries
        ZonedDateTime current = timeHelper.snapToStart(dateFrom);
        ZonedDateTime dateToAdjusted = timeHelper.snapToEnd(dateTo);
        while (current.isBefore(dateToAdjusted)) {
            String key = timeHelper.getTimeEntryKey(current);

            log.trace("Added {}", key);

            data.put(key, new EventReportEntry().setMoment(key).setEvents(new ArrayList<>()));

            current = timeHelper.increment(current);
        }

        log.debug("Values: {}", data.keySet());

        sqldao.getEvents_generic(dateFrom.toInstant().toEpochMilli(), dateTo.toInstant().toEpochMilli(), reportRequest.events, reportRequest.interval, r -> {
            // fill values - usage
            while (r.next()) {
                String event = r.getString("DIMENSION");
                String appId = r.getString("APPLICATION_ID");

                // skip empty entries
                if (event == null || event.isEmpty())
                    continue;

                Long measure = r.getLong("MEASURE");

                String key = timeHelper.getTimeEntryKey(r);
                data.get(key).events.add(
                        new EventValue()
                                .setCount(measure)
                                .setEvent(event)
                                .setApp(appId)
                );
            }
            return null;
        });

        return new ArrayList<>(data.values());
    }
}
