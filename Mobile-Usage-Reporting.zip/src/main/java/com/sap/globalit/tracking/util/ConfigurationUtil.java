package com.sap.globalit.tracking.util;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class ConfigurationUtil {

    public static Map<String, String> loadFromJSONFile(String name) {
        return new Gson().fromJson(new InputStreamReader(
                        ConfigurationUtil.class.getResourceAsStream("/" + name)),
                new TypeToken<HashMap<String, String>>() {
                }.getType());
    }

}
