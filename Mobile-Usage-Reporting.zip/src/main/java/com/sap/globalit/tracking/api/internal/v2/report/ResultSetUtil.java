package com.sap.globalit.tracking.api.internal.v2.report;

import com.sap.globalit.tracking.model.reporting.Chart;
import com.sap.globalit.tracking.model.reporting.Dimension;
import com.sap.globalit.tracking.model.reporting.Measure;
import com.sap.globalit.tracking.model.reporting.Table;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.sap.globalit.tracking.util.ChartUtil.cleanStringForReferenceInJS;

/**
 * Created by D053397 on 20.07.2016.
 */
public class ResultSetUtil {

    private static final Logger log = LoggerFactory.getLogger(ResultSetUtil.class);

    public static Table toTable(ResultSet resultSet, TimeHelper monthTimeHelper, ZonedDateTime start, ZonedDateTime end, String dimensionName /* Usually App, could also be Event / Version / ... */) throws SQLException {
        Table table = new Table();

        // EasyConnect ==>  01/2016->10
        //                  02/2016->5
        LinkedHashMap<String, Chart.ChartData> data = new LinkedHashMap<>();

        List<String> timeEntries = new ArrayList<>();

        // generate all required time entries
        ZonedDateTime current = start;
        while (current.isBefore(end)) {
            String key = monthTimeHelper.getTimeEntryKey(current);

            log.trace("Added {}", key);

            timeEntries.add(key);

            current = monthTimeHelper.increment(current);
        }

        // create columns
        table.getColumns().add(new Dimension(dimensionName));
        // add time entries
        for (String s : timeEntries) {
            table.getColumns().add(new Measure(s));
        }

        log.debug("{}", timeEntries);

        while (resultSet.next()) {
            String dimension = resultSet.getString("DIMENSION");

            // skip empty entries
            if (dimension == null || dimension.isEmpty())
                continue;

            Long measure = resultSet.getLong("MEASURE");

            String key = cleanStringForReferenceInJS(monthTimeHelper.getTimeEntryKey(resultSet));

            Chart.ChartData timeEntry = getOrCreateKeyForTable(data, timeEntries, dimension, dimensionName);

            timeEntry.put(key, measure);
        }

        log.debug("{}", data);


        table.setTableData(new ArrayList<>(data.values()));

        return table;
    }

    /**
     * result set has a dimension "e.g. the app"
     * result set contains MEASURE_COL = measure
     * result set contains MEASURE = value for the measure
     * <p>
     * MEASURE_COL should be transformed into individual measure
     *
     * @param resultSet
     * @return
     */
    public static Table toTable_MeasureFromColumn(ResultSet resultSet, String dimensionName /* usually App/Event/Version/... */) throws SQLException {
        Table table = new Table();

        table.getColumns().add(new Dimension(dimensionName));

        String dimensionKey = cleanStringForReferenceInJS(dimensionName);

        LinkedHashMap<String, Chart.ChartData> data = new LinkedHashMap<>();

        Set<String> measures = new LinkedHashSet<>();

        while (resultSet.next()) {
            String dimension = resultSet.getString("DIMENSION");

            // skip empty entries
            if (dimension == null || dimension.isEmpty())
                continue;

            String measureName = resultSet.getString("MEASURE_COL");
            String measureKey = cleanStringForReferenceInJS(measureName);

            measures.add(measureName);

            Long measure = resultSet.getLong("MEASURE");

            Chart.ChartData dimensionEntry = getOrCreateDimensionEntry(data, dimension, dimensionKey);

            dimensionEntry.put(measureKey, measure);
        }

        for (String measure : measures) {
            table.getColumns().add(new Measure(measure));
        }

        table.setTableData(new ArrayList<>(data.values()));

        return table;
    }

    private static Chart.ChartData getOrCreateDimensionEntry(LinkedHashMap<String, Chart.ChartData> data, String dimensionValue, String dimensionKey) {
        Chart.ChartData entry = data.get(dimensionValue);
        if (entry == null) {
            entry = new Chart.ChartData();

            entry.put(dimensionKey, dimensionValue);

            data.put(dimensionValue, entry);
        }
        return entry;
    }

    private static Chart.ChartData getOrCreateKeyForTable(LinkedHashMap<String, Chart.ChartData> data, List<String> timeEntries, String dimension, String dimensionName) {
        Chart.ChartData entry = data.get(dimension);
        if (entry == null) {
            entry = new Chart.ChartData();

            entry.put(cleanStringForReferenceInJS(dimensionName), dimension);

            // add time entries
            for (String s : timeEntries) {
                entry.put(cleanStringForReferenceInJS(s), 0L);
            }

            data.put(dimension, entry);
        }
        return entry;
    }

    public static Chart toChart(ResultSet resultSet, TimeHelper timeHelper, ZonedDateTime start, ZonedDateTime end) throws SQLException {

        Chart chart = new Chart();
        chart.getDimensions().add(new Dimension(timeHelper.getDimensionKey()));

        // 01/2016 ==>  EasyConnect->10
        //              App->5
        LinkedHashMap<String, Chart.ChartData> data = new LinkedHashMap<>();

        // generate all required time entries
        ZonedDateTime current = start;
        while (current.isBefore(end)) {
            String key = timeHelper.getTimeEntryKey(current);

            log.trace("Added {}", key);

            Chart.ChartData timeEntry = new Chart.ChartData();
            timeEntry.put(cleanStringForReferenceInJS(timeHelper.getDimensionKey()), key);
            data.put(key, timeEntry);

            current = timeHelper.increment(current);
        }

        log.debug("{}", data);

        Set<String> measures = new HashSet<>();

        while (resultSet.next()) {
            String dimension = resultSet.getString("DIMENSION");

            // skip empty entries
            if (dimension == null || dimension.isEmpty())
                continue;

            measures.add(dimension);

            Long measure = resultSet.getLong("MEASURE");

            String key = timeHelper.getTimeEntryKey(resultSet);
            Chart.ChartData timeEntry = data.get(key); // has to exist -> generated previously

            if (timeEntry == null)
                throw new RuntimeException("No time entry for key: " + key);

            timeEntry.put(cleanStringForReferenceInJS(dimension), measure);
        }

        // fill entries for all apps/measures
        for (String measure : measures) {
            for (Chart.ChartData chartData : data.values()) {
                String key = cleanStringForReferenceInJS(measure);
                if (!chartData.containsKey(key)) {
                    chartData.put(key, 0L);
                }
            }
        }

        chart.setChartData(new ArrayList<>(data.values()));

        List<Measure> measureList = measures.stream().map(i -> new Measure(i)).collect(Collectors.toList());
        chart.setMeasures(measureList);


        return chart;
    }

    public static Chart toSingleValueChart(ResultSet resultSet, List<String> dimensions, List<String> dimensionNames, List<String> measures, List<String> measureNames) throws SQLException {
        Chart chart = new Chart();

        for (int i = 0; i < dimensions.size(); i++) {
            chart.getDimensions().add(new Dimension(dimensionNames.get(i)));
        }

        for (int i = 0; i < measures.size(); i++) {
            chart.getMeasures().add(new Measure(measureNames.get(i)));
        }

        chart.setChartData(new ArrayList<>());

        while (resultSet.next()) {

            Chart.ChartData chartDataEntry = new Chart.ChartData();

            for (int i = 0; i < dimensions.size(); i++) {
                chartDataEntry.put(cleanStringForReferenceInJS(dimensionNames.get(i)), resultSet.getString(dimensions.get(i)));
            }


            for (int i = 0; i < measures.size(); i++) {
                chartDataEntry.put(cleanStringForReferenceInJS(measureNames.get(i)), resultSet.getLong(measures.get(i)));
            }

            chart.getChartData().add(chartDataEntry);
        }

        return chart;
    }

    public static Table toSingleValueTable(ResultSet resultSet, List<String> dimensions, List<String> dimensionNames, List<String> measures, List<String> measureNames) throws SQLException {
        Table table = new Table();

        for (int i = 0; i < dimensions.size(); i++) {
            table.getColumns().add(new Dimension(dimensionNames.get(i)));
        }

        for (int i = 0; i < measures.size(); i++) {
            table.getColumns().add(new Measure(measureNames.get(i)));
        }

        table.setTableData(new ArrayList<>());

        while (resultSet.next()) {

            Chart.ChartData chartDataEntry = new Chart.ChartData();

            for (int i = 0; i < dimensions.size(); i++) {
                chartDataEntry.put(cleanStringForReferenceInJS(dimensionNames.get(i)), resultSet.getString(dimensions.get(i)));
            }


            for (int i = 0; i < measures.size(); i++) {
                chartDataEntry.put(cleanStringForReferenceInJS(measureNames.get(i)), resultSet.getLong(measures.get(i)));
            }

            table.getTableData().add(chartDataEntry);
        }

        return table;
    }

}
