package com.sap.globalit.tracking.api.internal;

import com.sap.globalit.tracking.api.internal.v2.SQLDAO;
import com.sap.globalit.tracking.api.internal.v2.report.TimeHelper;
import com.sap.globalit.tracking.dao.ApplicationDAO;
import com.sap.globalit.tracking.dto.ShowroomEntryDTO;
import com.sap.globalit.tracking.model.Application;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * Created by D053397 on 29.04.2016.
 */
@Path("/internal/showroom")
@Api(value = "Showroom API", description = "Services for the Showroom Project")
public class ShowroomAPI {

    private static final Logger log = LoggerFactory.getLogger(ShowroomAPI.class);

    @Inject
    ApplicationDAO applicationDAO;

    @Inject
    SQLDAO sqldao;

    @GET
    @Path("statistics/{appId}")
    @ApiOperation(value = "Get usage for an application")
    public List<ShowroomEntryDTO> getStatistics(@ApiParam(example = "EasyConnect") @PathParam("appId") String appId,
                                                @ApiParam(example = "2016-01-01") @QueryParam("start") String from,
                                                @ApiParam(example = "2016-01-07") @QueryParam("end") String to,
                                                @ApiParam(example = "DAY") @QueryParam("interval") ReportAPI.TimeInterval interval) throws SQLException {

        log.info("Get Showroom Statistics");

        ZoneId utc = ZoneId.of("UTC");

        ZonedDateTime dateFrom = ZonedDateTime.of(LocalDate.parse(from), LocalTime.MIN, utc);
        ZonedDateTime dateTo = ZonedDateTime.of(LocalDate.parse(to), LocalTime.MAX, utc);

        Application application = applicationDAO.getByKey(appId)
                .orElseThrow(() -> new NotFoundException("App " + appId + " not found"));

        TimeHelper timeHelper = TimeHelper.getTimeHelper(interval);

        LinkedHashMap<String, ShowroomEntryDTO> data = new LinkedHashMap<>();

        // generate all required time entries
        ZonedDateTime current = dateFrom;
        while (current.isBefore(dateTo)) {
            String key = timeHelper.getTimeEntryKey(current);

            log.trace("Added {}", key);

            ShowroomEntryDTO entry = new ShowroomEntryDTO(key, 0L, 0L);
            data.put(key, entry);

            current = timeHelper.increment(current);
        }

        log.debug("Values: {}", data.keySet());

        sqldao.getUsage_byApp(dateFrom.toInstant().toEpochMilli(), dateTo.toInstant().toEpochMilli(), Collections.singletonList(application.getId()), interval, r -> {
            // fill values - usage
            while (r.next()) {
                String dimension = r.getString("DIMENSION");

                // skip empty entries
                if (dimension == null || dimension.isEmpty())
                    continue;

                Long measure = r.getLong("MEASURE");

                String key = timeHelper.getTimeEntryKey(r);
                ShowroomEntryDTO timeEntry = data.get(key); // has to exist -> generated previously

                timeEntry.setUsages(measure);
            }
            return null; // ignore
        });

        // fill values - devices
        sqldao.getActiveDevices_byApp(dateFrom.toInstant().toEpochMilli(), dateTo.toInstant().toEpochMilli(), Collections.singletonList(application.getId()), interval, r -> {
            while (r.next()) {
                String dimension = r.getString("DIMENSION");

                // skip empty entries
                if (dimension == null || dimension.isEmpty())
                    continue;

                Long measure = r.getLong("MEASURE");

                String key = timeHelper.getTimeEntryKey(r);
                ShowroomEntryDTO timeEntry = data.get(key); // has to exist -> generated previously
                timeEntry.setActiveDevices(measure);
            }

            return null; // ignore
        });

        return new ArrayList<>(data.values());
    }

}