package com.sap.globalit.tracking.model;

import com.google.gson.annotations.Expose;
import com.sap.globalit.tracking.model.ApplicationPlattform.PlatformType;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.io.Serializable;

public class ApplicationPlattformId implements Serializable {

    @Enumerated(EnumType.STRING)
    @Expose
    PlatformType id;

    @Expose
    String application;

    public ApplicationPlattformId(PlatformType id, String application) {
        super();
        this.id = id;
        this.application = application;
    }

    public PlatformType getId() {
        return id;
    }

    public String getApplication() {
        return application;
    }

    @Override
    public String toString() {
        return "ApplicationPlattformId [id=" + id + ", application=" + application + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((application == null) ? 0 : application.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ApplicationPlattformId other = (ApplicationPlattformId) obj;
        if (application == null) {
            if (other.application != null)
                return false;
        } else if (!application.equals(other.application))
            return false;
        return id == other.id;
    }

}
