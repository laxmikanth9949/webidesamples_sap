package com.sap.globalit.tracking.scheduling;

import org.glassfish.jersey.process.internal.RequestScope;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.concurrent.Callable;

/**
 * Created by D053397 on 26.10.2016.
 */
public abstract class RequestScopedJob implements Job {

    static Logger log = LoggerFactory.getLogger(RequestScopedJob.class);

    @Inject
    RequestScope requestScope;

    @Override
    public void execute(JobExecutionContext jobExecutionContext) {
        log.info("Entry: execute");

        try {
            requestScope.runInScope((Callable<Object>) () -> {
                executeInRequestScope(jobExecutionContext);
                return null;
            });
        } catch (Exception e) {
            log.warn("Job failed!", e);
        }
    }

    public abstract void executeInRequestScope(JobExecutionContext var1) throws JobExecutionException;

}
