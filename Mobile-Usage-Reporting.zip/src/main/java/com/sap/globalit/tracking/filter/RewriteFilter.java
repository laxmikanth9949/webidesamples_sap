package com.sap.globalit.tracking.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class RewriteFilter implements Filter {

    static Map<String, String> PERMANENT_REDIRECT = new HashMap<>();

    static {
        // legacy redirection for old "realtime" urls
        PERMANENT_REDIRECT.put("/realtime.html", "/realtime/bubbles");
        PERMANENT_REDIRECT.put("/realtimeComp.html", "/realtime");
        PERMANENT_REDIRECT.put("/realtimeMap.html", "/realtime/map");

        // redirect old reporting ui
        PERMANENT_REDIRECT.put("/", "https://fiorilaunchpad.sap.com/sites?origin=fromLegacyUI#MU-Reporting");
        PERMANENT_REDIRECT.put("/reporting", "https://fiorilaunchpad.sap.com/sites?origin=fromLegacyUI#MU-Reporting");
        PERMANENT_REDIRECT.put("/reporting/", "https://fiorilaunchpad.sap.com/sites?origin=fromLegacyUI#MU-Reporting");
        PERMANENT_REDIRECT.put("/tracking/internal", "https://fiorilaunchpad.sap.com/sites?origin=fromLegacyUI#MU-Reporting");
        PERMANENT_REDIRECT.put("/tracking/internal/", "https://fiorilaunchpad.sap.com/sites?origin=fromLegacyUI#MU-Reporting");
        PERMANENT_REDIRECT.put("/request", "https://fiorilaunchpad.sap.com/sites#MU-Reporting&/request");
        PERMANENT_REDIRECT.put("/request-access", "https://fiorilaunchpad.sap.com/sites#MU-Reporting&/request");

        // redirect faq to github
        PERMANENT_REDIRECT.put("/documentation/faq", "https://github.wdf.sap.corp/it-mobile/Mobile-Usage-Reporting/tree/master/documentation/faq");

        // redirect legacy clients
        PERMANENT_REDIRECT.put("/tracking/web-client/web-tracking.js", "/web-client/web-tracking.js");
        PERMANENT_REDIRECT.put("/tracking/web-client/jquery.js", "/web-client/jquery.js");
        PERMANENT_REDIRECT.put("/tracking/web-client/MobileUsageReporting.js", "/web-client/MobileUsageReporting.js");
        PERMANENT_REDIRECT.put("/tracking/web-client/crypto-sha1.js", "/web-client/crypto-sha1.js");
    }

    static Logger log = LoggerFactory.getLogger(RewriteFilter.class);

    FilterConfig filterConfig;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        log.info("{} initialized", this.getClass().getName());
        this.filterConfig = filterConfig;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        String url = httpRequest.getRequestURI();
        log.info("Processing {}", httpRequest.getRequestURI());

        String target = PERMANENT_REDIRECT.get(url);
        if (target != null) {
            log.info("Redirecting to {}", target);
            // httpResponse.sendRedirect(target);
            httpResponse.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY);
            httpResponse.setHeader("Location", target);
            return;
        }

        if (url.startsWith("/tracking/")) {
            url = url.replaceFirst("/tracking", "");
            log.info("Forwarding internally to {}", url);
            filterConfig.getServletContext().getRequestDispatcher(url).forward(request, response);
            return;
        }

        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
    }
}
