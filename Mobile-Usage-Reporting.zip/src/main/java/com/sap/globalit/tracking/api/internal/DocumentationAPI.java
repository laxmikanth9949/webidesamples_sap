package com.sap.globalit.tracking.api.internal;

import com.sap.globalit.tracking.dao.ApplicationDAO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by D053397 on 29.04.2016.
 */
@Path("/internal/documentation")
@Api(value = "Documentation API")
public class DocumentationAPI {

    private static final Logger log = LoggerFactory.getLogger(DocumentationAPI.class);

    @Inject
    ApplicationDAO applicationDAO;

    @GET
    @Path("apps")
    @ApiOperation(value = "Get usage for an application")
    @Produces("text/plain")
    public String getApps() throws SQLException {
        List<String> appList = applicationDAO.getAll().stream()
                .map(a -> a.getName() + ": " + a.getId())
                .collect(Collectors.toList());
        appList.add(0, "--------------------");
        appList.add(0, "Name -> Reporting Id");

        return appList.stream().collect(Collectors.joining("\r\n"));
    }
}