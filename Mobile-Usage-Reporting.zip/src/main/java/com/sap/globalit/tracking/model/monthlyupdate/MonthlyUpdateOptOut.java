package com.sap.globalit.tracking.model.monthlyupdate;

import com.sap.globalit.tracking.model.Application;

import javax.persistence.Entity;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;
import java.io.Serializable;

/**
 * User does not want to recieve a monthly update for the specified app
 *
 * @author D053397
 */

@Entity
@IdClass(MonthlyUpdateOptOut.Id.class)
public class MonthlyUpdateOptOut {

    @javax.persistence.Id
    private String userId;

    @ManyToOne
    @javax.persistence.Id
    private Application application;

    public MonthlyUpdateOptOut() {
        super();
    }

    public MonthlyUpdateOptOut(String userId, Application application) {
        this();
        this.userId = userId;
        this.application = application;
    }

    public Application getApplication() {
        return application;
    }

    public void setApplication(Application application) {
        this.application = application;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public static class Id implements Serializable {

        private String application;
        private String userId;

        public Id() {
        }

        public Id(String application, String userId) {
            this.application = application;
            this.userId = userId;
        }

    }
}