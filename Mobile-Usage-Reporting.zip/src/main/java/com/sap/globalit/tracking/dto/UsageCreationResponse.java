package com.sap.globalit.tracking.dto;

/**
 * Created by D053397 on 02.01.2017.
 */
public class UsageCreationResponse {
    public final Long usageId;
    public final String error;

    public static UsageCreationResponse sucessfull(long usageId) {
        return new UsageCreationResponse(usageId, null);
    }

    public static UsageCreationResponse error(String error) {
        return new UsageCreationResponse(null, error);
    }

    private UsageCreationResponse(Long usageId, String error) {
        this.usageId = usageId;
        this.error = error;
    }
}
