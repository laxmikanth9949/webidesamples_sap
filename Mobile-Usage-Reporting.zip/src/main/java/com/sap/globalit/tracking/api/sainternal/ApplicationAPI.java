package com.sap.globalit.tracking.api.sainternal;

import com.google.gson.annotations.Expose;
import com.sap.globalit.tracking.api.internal.v2.SQLDAO;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.model.ApplicationPlattform;
import com.sap.globalit.tracking.model.ApplicationPlattformId;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Path("/sa-internal/application")
@Api(value = "App Admin", description = "App Admin Service")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ApplicationAPI {

    private static Logger logger = LoggerFactory.getLogger(ApplicationAPI.class);

    @Inject
    EntityManager em;

    @Inject
    SQLDAO sqldao;

    @POST
    @Path("{appId}/name")
    @ApiOperation(value = "Rename Application")
    public void rename(@ApiParam String newName, @PathParam("appId") String appId) {

        // TODO create test

        em.getTransaction().begin();

        // check if application exists
        Application application = em.find(Application.class, appId);
        if (application == null) throw new NotFoundException("App " + appId + " does not exist");

        application.setName(newName);

        em.getTransaction().commit();
    }

    @POST
    @ApiOperation(value = "Create new")
    public void createNew(@ApiParam ApplicationCreationDTO creationDTO) {

        // TODO create test

        em.getTransaction().begin();

        // check if application exists
        Application application = em.find(Application.class, creationDTO.appId);
        if (application == null) {
            logger.info("Creating Application {}", creationDTO.appId);
            application = new Application(creationDTO.appId, creationDTO.name);
            em.persist(application);
        }

        // check if platform exsits
        ApplicationPlattform plattform = em.find(ApplicationPlattform.class, new ApplicationPlattformId(creationDTO.platform, creationDTO.appId));
        if (plattform == null) {
            logger.info("Creating Platform {}", creationDTO.appId);
            plattform = new ApplicationPlattform(creationDTO.platform, application);
            em.persist(plattform);
        }

        em.getTransaction().commit();
    }

    @GET
    @Path("usage-count")
    public List<ApplicationUsageCount> usageCount() throws SQLException {

        List<ApplicationUsageCount> result = new ArrayList<>();

        sqldao.getUsageCount_byApp(r -> {
                    while (r.next()) {
                        String name = r.getString("APPLICATION_NAME");
                        String appId = r.getString("APPLICATION_ID");
                        Long measure = r.getLong("MEASURE");

                        ApplicationUsageCount entry = new ApplicationUsageCount();
                        entry.appId = appId;
                        entry.appName = name;
                        entry.count = measure;
                        result.add(entry);
                    }
                    return null;
                }
        );
        return result;
    }

    @GET
    @Path("distinct-user-count")
    public List<ApplicationUsageCount> distinctUserCount() throws SQLException {

        List<ApplicationUsageCount> result = new ArrayList<>();

        sqldao.getDistinctUserCount_byApp(r -> {
                    while (r.next()) {
                        String name = r.getString("APPLICATION_NAME");
                        String appId = r.getString("APPLICATION_ID");
                        Long measure = r.getLong("MEASURE");

                        ApplicationUsageCount entry = new ApplicationUsageCount();
                        entry.appId = appId;
                        entry.appName = name;
                        entry.count = measure;
                        result.add(entry);
                    }
                    return null;
                }
        );
        return result;
    }

    public static class ApplicationCreationDTO {
        @Expose
        public String appId;

        @Expose
        public String name;

        @Expose
        public ApplicationPlattform.PlatformType platform;
    }

    public static class ApplicationUsageCount {
        @Expose
        public String appId;

        @Expose
        public String appName;

        @Expose
        public long count;
    }

}