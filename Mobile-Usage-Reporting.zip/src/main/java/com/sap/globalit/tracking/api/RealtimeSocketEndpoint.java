package com.sap.globalit.tracking.api;

import com.sap.globalit.tracking.JerseyApplication;
import com.sap.security.um.user.PersistenceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;

@ServerEndpoint(value = "/websocket/realtime")
public class RealtimeSocketEndpoint {

    private static Logger logger = LoggerFactory.getLogger(RealtimeSocketEndpoint.class);

    private RealtimeSocketManager manager;

    public RealtimeSocketEndpoint() {
        logger.debug("Initializing Realtime Endpoint");
        manager = JerseyApplication.serviceLocator.getInstance(RealtimeSocketManager.class);
    }

    @OnOpen
    public void onOpen(Session session) throws IOException,
            PersistenceException {
        logger.debug("New session id: {} | user: {}", session.getId(), getUserFromSession(session));
        manager.onNewSession(session);
    }

    @OnMessage
    public void onMessage(String message, Session session) {
        logger.debug("onMessage: {} | user: {}", session.getId(), getUserFromSession(session));

        manager.onPing(session);
    }

    @OnError
    public void onError(Session session, Throwable t) {
        logger.debug("onError, sessionId=" + session.getId(), t);

        manager.onSessionTerminated(session);
    }

    @OnClose
    public void onClose(Session session) {
        logger.debug("Session closed id: {} | user: {}", session.getId(), getUserFromSession(session));
        manager.onSessionTerminated(session);
    }


    private static String getUserFromSession(Session s) {
        if (s.getUserPrincipal() == null) {
            return "Anonymous";
        }
        return s.getUserPrincipal().getName();
    }

}
