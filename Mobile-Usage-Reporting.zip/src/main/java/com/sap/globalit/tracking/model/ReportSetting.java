package com.sap.globalit.tracking.model;

import com.sap.globalit.tracking.api.internal.ReportAPI;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * Created by D053397 on 13.03.2015.
 */
@MappedSuperclass
public abstract class ReportSetting {

    @Id
    @GeneratedValue
    long id;

    @ElementCollection
    List<String> applications;

    @NotNull
    @Size(min = 1)
    String reportId;

    @NotNull
    @Size(min = 1)
    String viewId;

    long timeFrom;

    long timeTo;

    long timeDuration;

    @Enumerated(EnumType.STRING)
    ReportAPI.TimeInterval timeInterval;

    protected ReportSetting() {

    }

    public ReportSetting(List<String> applications, String reportId, String viewId, long timeFrom, long timeTo, long timeDuration, ReportAPI.TimeInterval timeInterval) {
        this.applications = applications;
        this.reportId = reportId;
        this.viewId = viewId;
        this.timeFrom = timeFrom;
        this.timeTo = timeTo;
        this.timeDuration = timeDuration;
        this.timeInterval = timeInterval;
    }

    public long getId() {
        return id;
    }

    public List<String> getApplications() {
        return applications;
    }

    public String getReportId() {
        return reportId;
    }

    public String getViewId() {
        return viewId;
    }

    public long getTimeFrom() {
        return timeFrom;
    }

    public long getTimeTo() {
        return timeTo;
    }

    public long getTimeDuration() {
        return timeDuration;
    }

    public ReportAPI.TimeInterval getTimeInterval() {
        return timeInterval;
    }

    public void setApplications(List<String> applications) {
        this.applications = applications;
    }

    public void setReportId(String reportId) {
        this.reportId = reportId;
    }

    public void setViewId(String viewId) {
        this.viewId = viewId;
    }

    public void setTimeFrom(long timeFrom) {
        this.timeFrom = timeFrom;
    }

    public void setTimeTo(long timeTo) {
        this.timeTo = timeTo;
    }

    public void setTimeDuration(long timeDuration) {
        this.timeDuration = timeDuration;
    }

    public void setTimeInterval(ReportAPI.TimeInterval timeInterval) {
        this.timeInterval = timeInterval;
    }
}
