package com.sap.globalit.tracking.api.internal;

import com.sap.globalit.tracking.dao.ApplicationDAO;
import com.sap.globalit.tracking.dto.ApplicationDTO;
import com.sap.globalit.tracking.dto.Mapper;
import com.sap.globalit.tracking.dto.ShowroomEntryDTO;
import com.sap.globalit.tracking.model.Application;
import com.sap.it.mobile.hcp.jaxrs.annotation.ScopesAllowed;
import com.sap.security.um.user.PersistenceException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by D053397 on 29.04.2016.
 */
@Path("/internal/relaybot")
@Api(value = "Relaybot API", description = "Services for the Relay Bot")
@Produces(MediaType.APPLICATION_JSON)
public class RelaybotAPI {

    private static final Logger log = LoggerFactory.getLogger(RelaybotAPI.class);

    @Inject
    ShowroomAPI showroomAPI;

    @Inject
    ApplicationDAO appDAO;

    @GET
    @Path("statistics/{appId}")
    @ApiOperation(value = "Get usage for an application")
    @ScopesAllowed("relay-bot")
    public List<ShowroomEntryDTO> getStatistics(@ApiParam(example = "EasyConnect") @PathParam("appId") String appId,
                                                @ApiParam(example = "2016-01-01") @QueryParam("start") String from,
                                                @ApiParam(example = "2016-01-07") @QueryParam("end") String to,
                                                @ApiParam(example = "DAY") @QueryParam("interval") ReportAPI.TimeInterval interval) throws SQLException {
        return showroomAPI.getStatistics(appId, from, to, interval);
    }

    @GET
    @Path("apps")
    @ApiOperation(value = "Get all applications with recent usage")
    @ScopesAllowed("relay-bot")
    public List<ApplicationDTO> getAllWhichHaveUsage() throws PersistenceException {
        return appDAO.getAllWithRecentUsage()
                .stream()
                .sorted(Application.SORT_BY_NAME)
                .map(Mapper::application)
                .collect(Collectors.toList());
    }
}