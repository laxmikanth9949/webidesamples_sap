package com.sap.globalit.tracking.injection;

import org.glassfish.jersey.internal.inject.DisposableSupplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;


public class ConnectionFactory implements DisposableSupplier<Connection> {

    private static final Logger log = LoggerFactory.getLogger(ConnectionFactory.class);

    @Inject
    DataSource ds;

    @Override
    public Connection get() {
        try {
            Connection connection = ds.getConnection();
            log.info("Creating Connection {}", connection.hashCode());

            return connection;
        } catch (SQLException e) {
            log.error("Error acquiring connection ", e);
            throw new RuntimeException(e);
        }
    }

    // this is not used -> per-lookup injection
    @Override
    public void dispose(Connection connection) {
        throw new RuntimeException("Not used");
    }

}
