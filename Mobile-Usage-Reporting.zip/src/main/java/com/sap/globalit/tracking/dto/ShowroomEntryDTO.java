package com.sap.globalit.tracking.dto;

/**
 * Created by D053397 on 04.11.2016.
 */
public class ShowroomEntryDTO {

    long activeDevices;
    long usages;
    String moment;

    public ShowroomEntryDTO(String moment, long activeDevices, long usages) {
        this.activeDevices = activeDevices;
        this.usages = usages;
        this.moment = moment;
    }

    public long getActiveDevices() {
        return activeDevices;
    }

    public long getUsages() {
        return usages;
    }

    public String getMoment() {
        return moment;
    }

    public void setActiveDevices(long activeDevices) {
        this.activeDevices = activeDevices;
    }

    public void setUsages(long usages) {
        this.usages = usages;
    }
}
