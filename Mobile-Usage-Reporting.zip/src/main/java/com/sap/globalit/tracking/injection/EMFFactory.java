package com.sap.globalit.tracking.injection;

import org.eclipse.persistence.config.PersistenceUnitProperties;
import org.glassfish.jersey.internal.inject.DisposableSupplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;


public class EMFFactory implements DisposableSupplier<EntityManagerFactory> {

    private static final Logger log = LoggerFactory.getLogger(EMFFactory.class);

    public static final String PERSISTENCE_UNIT = "default";

    @Override
    public EntityManagerFactory get() {
        EntityManagerFactory entityManagerFactory = getEntityManager(PERSISTENCE_UNIT);
        log.trace("Providing new EntityManagerFactory [{}]", entityManagerFactory);
        return entityManagerFactory;
    }

    @Override
    public void dispose(EntityManagerFactory entityManagerFactory) {
        log.trace("Disposing EntityManagerFactory [{}]", entityManagerFactory);
        entityManagerFactory.close();
    }

    public static EntityManagerFactory getEntityManager(String persistenceUnit) {
        String contextPath = "java:comp/env/jdbc/DefaultDB";
        try {

            log.debug("Bind EntityManagerFactory from contextPath '{}'", contextPath);

            InitialContext ctx = new InitialContext();
            DataSource ds = (DataSource) ctx.lookup(contextPath);

            /*
            DataSource dataSource =
                    ProxyDataSourceBuilder
                            .create(ds)
                            .logQueryBySlf4j()
                            .countQuery()
                            .logSlowQueryBySlf4j(1, TimeUnit.SECONDS)  // also by sl4j, jul, system out
                            .build();
                            */

            Map<Object, Object> properties = new HashMap<>();
            properties.put(PersistenceUnitProperties.NON_JTA_DATASOURCE, ds);
            properties.put(PersistenceUnitProperties.WEAVING_INTERNAL, "false");

            return Persistence.createEntityManagerFactory(persistenceUnit, properties);
        } catch (NamingException | RuntimeException e) {
            log.error("Could not lookup EntityManagerFactory at '{}'", contextPath, e);
            return null;
        }
    }
}
