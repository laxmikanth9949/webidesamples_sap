package com.sap.globalit.tracking.api.internal.v2;

import com.sap.ea.eacp.remotequeryclient.sql.builder.OrderBy;
import com.sap.ea.eacp.remotequeryclient.sql.builder.RemoteQueryBuilder;
import com.sap.ea.eacp.remotequeryclient.sql.builder.SelectBuilder;
import com.sap.ea.eacp.remotequeryclient.sql.builder.WhereBuilder;
import com.sap.ea.eacp.remotequeryclient.sql.builder.modifier.Column;
import com.sap.ea.eacp.remotequeryclient.sql.builder.modifier.ColumnBuilder;
import com.sap.ea.eacp.remotequeryclient.sql.builder.modifier.ComplexColumn;
import com.sap.globalit.tracking.api.internal.EventAPI;
import com.sap.globalit.tracking.api.internal.ReportAPI.TimeInterval;
import com.sap.globalit.tracking.model.ApplicationPlattform;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Provider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.sap.ea.eacp.remotequeryclient.sql.builder.modifier.ColumnBuilder.of;
import static com.sap.ea.eacp.remotequeryclient.sql.builder.modifier.ColumnBuilder.ofCountAll;

public class SQLDAO {

    private final static Logger log = LoggerFactory.getLogger(SQLDAO.class);

    private static final Column USAGE_START = of("SPANSTART").build();
    private static final Column EVENT_INSTANT = of("EVENT_TIME").build();

    @Inject
    Provider<Connection> connectionProvider;

    public <T> T getOsVersion(long param_start, long param_end, List<String> authorizedApplications, ApplicationPlattform.PlatformType platform, TimeInterval param_interval, ResultMapper<T> mappingFunction) throws SQLException {
        Report report = Report.OS_VERSION;

        SelectBuilder selectBuilder = RemoteQueryBuilder.select("VIEW_APPLICATION_USAGE")
                .columns(report.dimension(), report.measure())
                .whereNotNull("DEVICE_OS_VERSION")
                .whereEquals("DEVICE_OS", platform.name())
                .groupByNonAggregates()
                .orderBy(report.dimension());

        applyAppSelection(selectBuilder, authorizedApplications);

        applyTimeSelection(selectBuilder, param_start, param_end, TimeIntervalDB.valueOf(param_interval.name()), USAGE_START);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getUsage_byApp(long param_start, long param_end, List<String> apps, TimeInterval interval, ResultMapper<T> mappingFunction) throws SQLException {
        Report report = Report.USAGE;

        SelectBuilder selectBuilder = RemoteQueryBuilder.select("VIEW_APPLICATION_USAGE")
                .columns(report.dimension(), report.measure())
                .groupByNonAggregates()
                .orderBy(report.dimension());

        applyAppSelection(selectBuilder, apps);

        applyTimeSelection(selectBuilder, param_start, param_end, TimeIntervalDB.valueOf(interval.name()), USAGE_START);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getUsage_byApp_noTime(long param_start, long param_end, List<String> apps, ResultMapper<T> mappingFunction) throws SQLException {
        Report report = Report.USAGE;

        SelectBuilder selectBuilder = RemoteQueryBuilder.select("VIEW_APPLICATION_USAGE")
                .columns(report.dimension(), report.measure())
                .groupByNonAggregates()
                .orderBy(report.measure());

        applyTimeSelection(selectBuilder, param_start, param_end, TimeIntervalDB.ALL, USAGE_START);

        applyAppSelection(selectBuilder, apps);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getActiveDevices_byApp(long param_start, long param_end, List<String> apps, TimeInterval interval, ResultMapper<T> mappingFunction) throws SQLException {
        Report report = Report.ACTIVE_DEVICES;

        SelectBuilder selectBuilder = RemoteQueryBuilder.select("VIEW_APPLICATION_USAGE")
                .columns(report.dimension(), report.measure())
                .groupByNonAggregates()
                .orderBy(report.dimension());

        applyAppSelection(selectBuilder, apps);

        applyTimeSelection(selectBuilder, param_start, param_end, TimeIntervalDB.valueOf(interval.name()), USAGE_START);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getEvents_generic(long start, long end, List<EventAPI.EventId> events, TimeInterval interval, ResultMapper<T> mappingFunction) throws SQLException {
        Report report = Report.EVENTS;

        SelectBuilder selectBuilder = RemoteQueryBuilder.select("VIEW_APPLICATION_EVENTS")
                .columns(report.dimension(), report.measure(), ColumnBuilder.of("APPLICATION_ID").build())
                .groupByNonAggregates()
                .orderBy(report.dimension());

        List<WhereBuilder> eventFilterCondition = events.stream()
                .map(i -> new WhereBuilder()
                        .whereEquals("APPLICATION_ID", i.app)
                        .whereEquals("EVENT_ID", i.event))
                .collect(Collectors.toList());

        selectBuilder.and(new WhereBuilder().or(eventFilterCondition.toArray(new WhereBuilder[]{})));

        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.valueOf(interval.name()), EVENT_INSTANT);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getEvents_forApplication(long start, long end, String appId, TimeInterval interval, ResultMapper<T> mappingFunction) throws SQLException {
        Report report = Report.EVENTS;

        SelectBuilder selectBuilder = RemoteQueryBuilder.select("VIEW_APPLICATION_EVENTS")
                .columns(report.dimension(), report.measure())
                .groupByNonAggregates()
                .orderBy(report.dimension());

        applyAppSelection(selectBuilder, Collections.singletonList(appId));

        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.valueOf(interval.name()), EVENT_INSTANT);

        return execute(selectBuilder, mappingFunction);
    }

    private void applyTimeSelection(SelectBuilder selectBuilder, long param_start, long param_end, TimeIntervalDB timeInterval, Column timeColumn) {
        selectBuilder.columns(timeInterval.columns())
                .whereGreaterThan(timeColumn, param_start)
                .whereLowerThan(timeColumn, param_end)
                .orderBy(timeInterval.orderBy());
    }

    public <T> T getVersionDistribution_ByActiveUsers(long start, long end, String appId, TimeInterval interval, ResultMapper<T> mappingFunction) throws SQLException {
        Report report = Report.VERSION_DISTRIBUTION_BY_USERS;

        SelectBuilder selectBuilder = RemoteQueryBuilder.select("VIEW_APPLICATION_USAGE")
                .columns(report.dimension(), report.measure())
                .groupByNonAggregates()
                .orderBy(report.dimension());

        applyAppSelection(selectBuilder, Collections.singletonList(appId));

        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.valueOf(interval.name()), USAGE_START);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getActiveDevices_byApp_noTime(long param_start, long param_end, List<String> apps, ResultMapper<T> mappingFunction) throws SQLException {

        Report report = Report.ACTIVE_DEVICES;

        SelectBuilder selectBuilder = RemoteQueryBuilder.select("VIEW_APPLICATION_USAGE")
                .columns(report.dimension(), report.measure())
                .groupByNonAggregates()
                .orderBy(report.measure());

        applyTimeSelection(selectBuilder, param_start, param_end, TimeIntervalDB.ALL, USAGE_START);

        applyAppSelection(selectBuilder, apps);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getLocationInfo(long start, long end, List<String> apps, ResultMapper<T> mappingFunction) throws SQLException {

        SelectBuilder selectBuilder = RemoteQueryBuilder.select("VIEW_APPLICATION_USAGE_AND_REGION")
                .columns(
                        of("APPLICATION_NAME").build(),
                        of("COMMON_REGION").buildAs("REGION"),
                        of("DEVICE_COUNTRY").build(),
                        of("USAGE_ID").count().buildAs("USAGE"),
                        of("DEVICE_ID").distinct().count().buildAs("ACTIVE_DEVICES"))
                .groupByNonAggregates()
                .orderBy("APPLICATION_NAME")
                .orderBy("COMMON_REGION")
                .orderBy("DEVICE_COUNTRY");

        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.ALL, USAGE_START);
        applyAppSelection(selectBuilder, apps);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getDeviceModel_ByUsage_ForApplication(long start, long end, String appId, TimeInterval interval, ResultMapper<T> mappingFunction) throws SQLException {

        Report report = Report.DEVICE_MODEL_BY_USAGE;

        SelectBuilder selectBuilder = RemoteQueryBuilder.select("VIEW_APPLICATION_USAGE")
                .columns(report.dimension(), report.measure())
                .groupByNonAggregates()
                .orderBy(report.dimension());

        applyAppSelection(selectBuilder, Collections.singletonList(appId));

        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.valueOf(interval.name()), USAGE_START);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getRegionDistribution_ByActiveDevices_ForApplication(long start, long end, String appId, TimeInterval interval, ResultMapper<T> mappingFunction) throws SQLException {
        Report report = Report.REGION_BY_ACTIVE_DEVICES;

        SelectBuilder selectBuilder = RemoteQueryBuilder.select("VIEW_APPLICATION_USAGE_AND_REGION")
                .columns(report.dimension(), report.measure())
                .groupByNonAggregates()
                .orderBy(report.dimension());

        applyAppSelection(selectBuilder, Collections.singletonList(appId));

        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.valueOf(interval.name()), USAGE_START);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getUsage_byGCORegion_Field(long start, long end, List<String> apps, ResultMapper<T> mappingFunction) throws SQLException {
        Column dimension = ColumnBuilder.of("APPLICATION_NAME").buildAs("DIMENSION");
        Column measureColumn = ColumnBuilder.of("GCO_FIELD").buildAs("MEASURE_COL");
        Column measure = ColumnBuilder.of("USAGE_ID").count().buildAs("MEASURE");

        SelectBuilder selectBuilder = gcoRegionQuery("VIEW_APPLICATION_USAGE_AND_REGION", dimension, measureColumn, measure, apps);
        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.ALL, USAGE_START);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getUsage_byGCORegion_Region(long start, long end, List<String> apps, ResultMapper<T> mappingFunction) throws SQLException {
        Column dimension = ColumnBuilder.of("APPLICATION_NAME").buildAs("DIMENSION");
        Column measureColumn = ColumnBuilder.of("GCO_REGION").buildAs("MEASURE_COL");
        Column measure = ColumnBuilder.of("USAGE_ID").count().buildAs("MEASURE");

        SelectBuilder selectBuilder = gcoRegionQuery("VIEW_APPLICATION_USAGE_AND_REGION", dimension, measureColumn, measure, apps);
        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.ALL, USAGE_START);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getUsage_byGCORegion_All(long start, long end, List<String> apps, ResultMapper<T> mappingFunction) throws SQLException {
        Column dimension = ColumnBuilder.of("APPLICATION_NAME").buildAs("DIMENSION");
        Column measureColumn = ColumnBuilder.of(new ComplexColumn("'All'", false)).buildAs("MEASURE_COL");
        Column measure = ColumnBuilder.of("USAGE_ID").count().buildAs("MEASURE");

        SelectBuilder selectBuilder = gcoRegionQuery("VIEW_APPLICATION_USAGE_AND_REGION", dimension, measureColumn, measure, apps);
        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.ALL, USAGE_START);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getActiveDevices_byGCORegion_Field(long start, long end, List<String> apps, ResultMapper<T> mappingFunction) throws SQLException {

        Column dimension = ColumnBuilder.of("APPLICATION_NAME").buildAs("DIMENSION");
        Column measureColumn = ColumnBuilder.of("GCO_FIELD").buildAs("MEASURE_COL");
        Column measure = ColumnBuilder.of("DEVICE_ID").distinct().count().buildAs("MEASURE");

        SelectBuilder selectBuilder = gcoRegionQuery("VIEW_APPLICATION_USAGE_AND_REGION", dimension, measureColumn, measure, apps);
        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.ALL, USAGE_START);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getActiveDevices_byGCORegion_Region(long start, long end, List<String> apps, ResultMapper<T> mappingFunction) throws SQLException {

        Column dimension = ColumnBuilder.of("APPLICATION_NAME").buildAs("DIMENSION");
        Column measureColumn = ColumnBuilder.of("GCO_REGION").buildAs("MEASURE_COL");
        Column measure = ColumnBuilder.of("DEVICE_ID").distinct().count().buildAs("MEASURE");

        SelectBuilder selectBuilder = gcoRegionQuery("VIEW_APPLICATION_USAGE_AND_REGION", dimension, measureColumn, measure, apps);
        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.ALL, USAGE_START);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getActiveDevices_byGCORegion_All(long start, long end, List<String> apps, ResultMapper<T> mappingFunction) throws SQLException {

        Column dimension = ColumnBuilder.of("APPLICATION_NAME").buildAs("DIMENSION");
        Column measureColumn = ColumnBuilder.of(new ComplexColumn("'All'", false)).buildAs("MEASURE_COL");
        Column measure = ColumnBuilder.of("DEVICE_ID").distinct().count().buildAs("MEASURE");

        SelectBuilder selectBuilder = gcoRegionQuery("VIEW_APPLICATION_USAGE_AND_REGION", dimension, measureColumn, measure, apps);
        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.ALL, USAGE_START);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getEvents_byGCORegion_Field(long start, long end, List<String> apps, ResultMapper<T> mappingFunction) throws SQLException {

        Column dimension = ColumnBuilder.of("EVENT_ID").buildAs("DIMENSION");
        Column measureColumn = ColumnBuilder.of("GCO_FIELD").buildAs("MEASURE_COL");
        Column measure = ColumnBuilder.ofCountAll().buildAs("MEASURE");

        SelectBuilder selectBuilder = gcoRegionQuery("VIEW_APPLICATION_EVENTS_AND_REGION", dimension, measureColumn, measure, apps);
        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.ALL, EVENT_INSTANT);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getEvents_byGCORegion_Region(long start, long end, List<String> apps, ResultMapper<T> mappingFunction) throws SQLException {
        Column dimension = ColumnBuilder.of("EVENT_ID").buildAs("DIMENSION");
        Column measureColumn = ColumnBuilder.of("GCO_REGION").buildAs("MEASURE_COL");
        Column measure = ColumnBuilder.ofCountAll().buildAs("MEASURE");

        SelectBuilder selectBuilder = gcoRegionQuery("VIEW_APPLICATION_EVENTS_AND_REGION", dimension, measureColumn, measure, apps);
        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.ALL, EVENT_INSTANT);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getEvents_byGCORegion_All(long start, long end, List<String> apps, ResultMapper<T> mappingFunction) throws SQLException {
        Column dimension = ColumnBuilder.of("EVENT_ID").buildAs("DIMENSION");
        Column measureColumn = ColumnBuilder.of(new ComplexColumn("'All'", false)).buildAs("MEASURE_COL");
        Column measure = ColumnBuilder.ofCountAll().buildAs("MEASURE");

        SelectBuilder selectBuilder = gcoRegionQuery("VIEW_APPLICATION_EVENTS_AND_REGION", dimension, measureColumn, measure, apps);
        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.ALL, EVENT_INSTANT);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getDeviceType_forApplication(long start, long end, String appId, TimeInterval interval, ResultMapper<T> mappingFunction) throws SQLException {
        Report report = Report.DEVICE_TYPE_BY_APP;

        SelectBuilder selectBuilder = RemoteQueryBuilder.select("VIEW_APPLICATION_USAGE")
                .columns(report.dimension(), report.measure())
                .groupByNonAggregates()
                .orderBy(report.dimension());

        applyAppSelection(selectBuilder, Collections.singletonList(appId));

        applyTimeSelection(selectBuilder, start, end, TimeIntervalDB.valueOf(interval.name()), USAGE_START);

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getUsageCount_byApp(ResultMapper<T> mappingFunction) throws SQLException {
        SelectBuilder selectBuilder = RemoteQueryBuilder.select("VIEW_APPLICATION_USAGE")
                .columns(
                        of("APPLICATION_NAME").build(), of("APPLICATION_ID").build(), of("USAGE_ID").count().buildAs("MEASURE")
                )
                .groupByNonAggregates()
                .orderBy(of("APPLICATION_NAME").build());

        return execute(selectBuilder, mappingFunction);
    }

    public <T> T getDistinctUserCount_byApp(ResultMapper<T> mappingFunction) throws SQLException {
        SelectBuilder selectBuilder = RemoteQueryBuilder.select("VIEW_APPLICATION_USAGE_USER")
                .columns(
                        of("APPLICATION_NAME").build(), of("APPLICATION_ID").build(), of("USERID").distinct().count().buildAs("MEASURE")
                )
                .groupByNonAggregates()
                .orderBy(of("APPLICATION_NAME").build());

        return execute(selectBuilder, mappingFunction);
    }

    private SelectBuilder gcoRegionQuery(String tableName, Column dimension, Column measureColumn, Column measure, List<String> apps) {
        SelectBuilder selectBuilder = RemoteQueryBuilder.select(tableName)
                .columns(dimension, measureColumn, measure)
                .whereNotEquals("GCO_FIELD", "UNKNOWN")
                .groupByNonAggregates();

        applyAppSelection(selectBuilder, apps);
        return selectBuilder;
    }

    private <T> T execute(SelectBuilder selectBuilder, ResultMapper<T> mappingFunction) throws SQLException {
        String sql = selectBuilder.buildSql();
        List<Object> parameters = selectBuilder.buildParameters();
        log.debug("SQL: {}", sql);
        log.debug("Parameter: {}", parameters);

        try (Connection conn = connectionProvider.get()) {
            PreparedStatement preparedStatement = conn.prepareStatement(sql);

            // add parameters
            int i = 1;
            for (Object parameter : parameters) {
                preparedStatement.setObject(i, parameter);
                i++;
            }

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return mappingFunction.map(resultSet);
            }
        }
    }

    private void applyAppSelection(SelectBuilder selectBuilder, List<String> apps) {
        Column APP_ID = of("APPLICATION_ID").build();
        // limit app selection
        if (apps.isEmpty()) {
            selectBuilder.whereIn(APP_ID, RemoteQueryBuilder.select("APPLICATION").columns(of("ID").build()));
        } else {
            selectBuilder.whereIn(APP_ID, apps);
        }
    }

    enum TimeIntervalDB {
        HOUR(Arrays.asList("DAY", "HOUR")),
        DAY(Arrays.asList("DAY")),
        WEEK(Arrays.asList("YEAR", "ISOWEEK")),
        MONTH(Arrays.asList("YEAR", "MONTH")),
        QUARTER(Arrays.asList("YEAR", "Q")),
        YEAR(Arrays.asList("YEAR")),
        ALL(Collections.emptyList());

        private List<String> columns;

        TimeIntervalDB(List<String> columns) {
            this.columns = columns;
        }

        public List<Column> columns() {
            return columns.stream().map(i -> of(i).build()).collect(Collectors.toList());
        }

        public List<OrderBy> orderBy() {
            return columns.stream().map(i -> new OrderBy(i, OrderBy.Order.ASC)).collect(Collectors.toList());
        }
    }

    enum Report {
        ACTIVE_DEVICES(
                of("APPLICATION_NAME").buildAs("DIMENSION"),
                of("DEVICE_ID").distinct().count().buildAs("MEASURE")),

        USAGE(
                of("APPLICATION_NAME").buildAs("DIMENSION"),
                of("USAGE_ID").count().buildAs("MEASURE")),

        EVENTS(
                of("EVENT_ID").buildAs("DIMENSION"),
                ofCountAll().buildAs("MEASURE")),

        VERSION_DISTRIBUTION_BY_USERS(
                of(new ComplexColumn(" \"DEVICE_OS\" || ' | ' || \"APPLICATION_VERSION\"", false)).buildAs("DIMENSION"),
                of("DEVICE_ID").distinct().count().buildAs("MEASURE")),

        DEVICE_MODEL_BY_USAGE(
                of("DEVICE_MODELNAME").buildAs("DIMENSION"),
                of("USAGE_ID").count().buildAs("MEASURE")),

        REGION_BY_ACTIVE_DEVICES(
                of("GCO_REGION").buildAs("DIMENSION"),
                of("DEVICE_ID").distinct().count().buildAs("MEASURE")),

        OS_VERSION(
                of("DEVICE_OS_VERSION").buildAs("DIMENSION"),
                of("USAGE_ID").count().buildAs("MEASURE")),

        DEVICE_TYPE_BY_APP(
                of("DEVICETYPE").buildAs("DIMENSION"),
                of("DEVICETYPE").count().buildAs("MEASURE"));

        private Column dimension;
        private Column measure;

        Report(Column dimension, Column measure) {
            this.dimension = dimension;
            this.measure = measure;
        }

        public Column dimension() {
            return dimension;
        }

        public Column measure() {
            return measure;
        }
    }

    @FunctionalInterface
    public interface ResultMapper<T> {
        T map(ResultSet t) throws SQLException;
    }

    public SQLDAO setConnectionProvider(Provider<Connection> connectionProvider) {
        this.connectionProvider = connectionProvider;
        return this;
    }
}