package com.sap.globalit.tracking.dto;

import com.google.gson.annotations.Expose;
import com.sap.globalit.tracking.model.TimeSpan;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Used by the API as an import parameter
 *
 * @author D053397
 */

public class ApplicationUsageReport {

    @Expose
    public ApplicationVersionIdDTO version;

    @Expose
    public TimeSpanDTO timeSpan;

    @Expose
    public List<EventReportDTO> events = new ArrayList<>();

    @Expose
    public DeviceInformationDTO deviceInformation;

    @Expose
    public UserInformationDTO userInformation;

    /**
     * Only used for web reports contains the window.location.host attribute for
     * black/whitelisting
     */
    @Expose
    public String webUsageHost;


    public ApplicationUsageReport(ApplicationVersionIdDTO version,
                                  TimeSpanDTO timeSpan) {
        this.version = version;
        this.timeSpan = timeSpan;
    }

    @Override
    public String toString() {
        return "ApplicationUsageReport{" +
                "version=" + version +
                ", timeSpan=" + timeSpan +
                ", events=" + events +
                ", deviceInformation=" + deviceInformation +
                ", userInformation=" + userInformation +
                ", webUsageHost='" + webUsageHost + '\'' +
                '}';
    }

    public static class EventReportDTO {

        /**
         * unfortunatelly, existing clients are sending as part of the usage an event as {eventId:".."}
         * the /api/usage/addEvent API however sends {id:".."}
         */

        @Expose
        private String eventId;

        @Expose
        private String id;

        @Expose
        public long dateTime;

        @Expose
        @Nullable /* only send by WEB */
        public String appId;

        private EventReportDTO() {

        }

        public EventReportDTO(String eventId, long dateTime) {
            this();
            this.eventId = eventId;
            this.dateTime = dateTime;
        }

        public EventReportDTO(String eventId, long dateTime, String appId) {
            this.eventId = eventId;
            this.dateTime = dateTime;
            this.appId = appId;
        }

        public String getEventId() {
            if (eventId != null)
                return eventId;
            return id;
        }

        @Override
        public String toString() {
            return "Event [" + getEventId() + " | " + appId + " | " + TimeSpan.formatter.format(new Date(dateTime)) + "]";
        }

    }

}