package com.sap.globalit.tracking.monthlyupdate;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

public class MonthlyUpdateReport {

    String month;

    List<MonthlyUpdateApplicationEntry> entries;

    public MonthlyUpdateReport(String month) {
        super();
        this.month = month;
        this.entries = new ArrayList<>();
    }

    public void addEntry(MonthlyUpdateApplicationEntry entry) {
        entries.add(entry);
    }

    public boolean doesContainData() {
        return !entries.isEmpty();
    }

    public String generateMailBody() {

        StringBuilder result = new StringBuilder();

        result.append("Dear user,");
        result.append("\n");
        result.append("\n");
        result.append("Here are the usage statistics for " + month + ":");
        result.append("\n");
        result.append("\n");

        for (MonthlyUpdateApplicationEntry app : entries) {
            app.printToStringBuilder(result);
            result.append("\n");
        }
        result.append("\n");

        result.append("You can find the full reports here: https://fiorilaunchpad.sap.com/sites#MU-Reporting");
        result.append("\n\n");

        result.append("You're receiving this because you subscribed for one or more apps in the Global IT Mobile Usage Reporting.");// To
        // edit
        // you
        // subscriptions,
        // please
        // follow
        // this
        // link:
        // ...");
        result.append("\n\n");
        result.append("Best regards,");
        result.append("\n");
        result.append("Platform CoE");

        return result.toString();
    }

    public static class MonthlyUpdateApplicationEntry {
        String appId;
        List<MonthlyUpdateApplicationMeasure> measures;

        public MonthlyUpdateApplicationEntry(String appId) {
            super();
            this.appId = appId;
            measures = new ArrayList<>();
        }

        public void printToStringBuilder(StringBuilder result) {
            result.append(appId);
            result.append("\n");
            result.append("------------------------------------");
            result.append("\n");
            for (MonthlyUpdateApplicationMeasure m : measures) {
                result.append(m.print());
                result.append("\n");
            }
        }

        public void addMeasure(MonthlyUpdateApplicationMeasure m) {
            measures.add(m);
        }

        public String getAppId() {
            return appId;
        }

    }

    public static class MonthlyUpdateApplicationMeasure {

        private static final DecimalFormat formatter = new DecimalFormat(
                "+ #.0;- #");

        private String measure;
        private long valuePrevious;
        private long valueCurrent;

        public MonthlyUpdateApplicationMeasure(String measure,
                                               long valuePrevious, long valueCurrent) {
            super();
            this.measure = measure;
            this.valuePrevious = valuePrevious;
            this.valueCurrent = valueCurrent;
        }

        NumberFormat format = DecimalFormat.getNumberInstance();

        public double getDifference() {
            return (((valueCurrent / (double) valuePrevious) - 1) * 100);
        }

        public String getDifferenceInPercentage() {
            double value = getDifference();
            return formatter.format(value);
        }

        public String print() {
            return String.format("%-8s : %8s %%   (%s -> %s)", measure,
                    getDifferenceInPercentage(), format.format(valuePrevious),
                    format.format(valueCurrent));
        }
    }

}
