package com.sap.globalit.tracking.model;

import org.apache.commons.io.IOUtils;
import org.glassfish.jersey.server.spi.Container;
import org.glassfish.jersey.server.spi.ContainerLifecycleListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.inject.Provider;
import javax.persistence.EntityManagerFactory;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.function.Function;
import java.util.stream.Stream;

/**
 * Created by D053397 on 12.04.2017.
 */
public class ViewCreation implements ContainerLifecycleListener {

    private static final Logger log = LoggerFactory.getLogger(ViewCreation.class);

    private static final Function<String, Stream<? extends String>> SPLIT_STATEMENTS = i -> Arrays.stream(i.split(";")).filter(j -> !j.startsWith("--"));

    @Inject
    Provider<Connection> connectionProvider;

    @Inject
    EntityManagerFactory emf;

    private Function<String, String> readFileToString() {
        return i -> {
            try {
                return IOUtils.toString(new InputStreamReader(getClass().getResourceAsStream(i)));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        };
    }

    @Override
    public void onStartup(Container container) {

        // force generation of tables
        emf.createEntityManager().close();

        try (Connection conn = connectionProvider.get()) {
            // allow failures (e.g. view does not exist yet)
            Stream.of("/views/REPLACE_VIEWS_DROP.sql")
                    .map(readFileToString())
                    .flatMap(SPLIT_STATEMENTS)
                    .forEachOrdered(s -> {
                        try {
                            executeStatement(conn, s);
                        } catch (Exception e) {
                            log.debug("Error during initialization", e);
                        }
                    });

            // don´t allow failures
            Stream.of("/views/CREATE_VIEW_ONE_TIME.sql", "/views/REPLACE_VIEWS_CREATE.sql")
                    .map(readFileToString())
                    .flatMap(SPLIT_STATEMENTS)
                    .forEachOrdered(s -> executeStatement(conn, s));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void executeStatement(Connection conn, String s) {
        log.debug("Executing {}", s);
        try (PreparedStatement preparedStatement = conn.prepareStatement(s)) {
            preparedStatement.execute();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onReload(Container container) {

    }

    @Override
    public void onShutdown(Container container) {

    }
}
