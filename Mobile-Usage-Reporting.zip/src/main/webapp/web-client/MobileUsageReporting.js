jQuery.sap.declare("sap.git.usage.MobileUsageReporting");

// usage reporting client for component-based ui5 applications
sap.git.usage.MobileUsageReporting = {

    component: null,
    reporting: null,
    isDebugMode: false,

    reportingInitialized: null,

    startReporting: function (uiComponent) {
        this.component = uiComponent;

        this.reportingInitialized = new Promise(function (resolve, reject) {

            // Only load tracking script if not loaded, yet
            if (typeof(GlobalITTracking) === "undefined") {
                // Adding the script tag to the head
                var head = document.getElementsByTagName("head")[0];
                var reportingScript = document.createElement("script");
                reportingScript.type = "text/javascript";
                head.appendChild(reportingScript);
                reportingScript.src = "https://trackingshallwe.hana.ondemand.com/web-client/web-tracking.js";
                reportingScript.id = "GITTrackingClient";
                reportingScript.onload = function () {
                    this._callback();
                    resolve();
                }.bind(this);
            } else {
                this._callback();
                resolve();
            }
        }.bind(this));

        this.reportingInitialized.catch(function (e) {
            jQuery.sap.log.warning("[sap.git.usage.MobileUsageReporting]", "Could not initialize Usage Reporting..." + e);
        });
    },

    postEvent: function (sEvent) {
        this.reportingInitialized.then(function () {
            jQuery.sap.log.debug("[sap.git.usage.MobileUsageReporting]", sEvent);
            if (this.isDebugMode) {
                jQuery.sap.log.debug("[sap.git.usage.MobileUsageReporting]", "Usage reporting disabled for this host.");
                return;
            }

            if (this.reporting) {
                this.reporting.postEvent(sEvent);
            } else {
                jQuery.sap.log.warning("[sap.git.usage.MobileUsageReporting]", "Usage reporting not initialized. Call startReporting(uiComponent) first.");
            }
        }.bind(this), function (e) {
            jQuery.sap.log.warning("[sap.git.usage.MobileUsageReporting]", "Could not post Event" + e);
        }.bind(this));
    },

    postUser: function (sUser) {
        this.reportingInitialized.then(function () {
            this.reporting.postUser(sUser);
        }.bind(this), function (e) {
            jQuery.sap.log.warning("[sap.git.usage.MobileUsageReporting]", "Could not post User" + e);
        }.bind(this));
    },

    // Callback to start reporting
    _callback: function () {
        var id = this.component.getMetadata().getConfig().reportingId;
        var version = this.component.getMetadata().getVersion();
        var hosts = this.component.getMetadata().getConfig().reportingHosts;

        // Add (FLP) when launched from fiorilaunchpad
        if (window.location.host.indexOf("fiorilaunchpad") >= 0) {
            version = version + " (FLP)";
        }

        jQuery.sap.log.debug("[sap.git.usage.MobileUsageReporting]", "Reporting usage  for " + id + "[" + version + "]");

        // Only report on production system
        if (!hosts || jQuery.inArray(window.location.host, hosts) >= 0) {
            this.reporting = new GlobalITTracking(id, version);
        } else {
            jQuery.sap.log.debug("[sap.git.usage.MobileUsageReporting]", "Usage reporting disabled for this host. Starting debug mode.");
            this.isDebugMode = true;
        }
    },

    // ------------------
    // ------ V2 --------
    // ------------------
    setup: function (component) {
        jQuery.sap.log.info("[sap.git.usage.MobileUsageReporting]", "Setup Mobile Usage Reporting");

        var id = component.getMetadata().getConfig().reportingId;
        var version = this._getVersion(component);
        var deviceId = this._getDeviceId();
        var hosts = component.getMetadata().getConfig().reportingHosts;

        jQuery.sap.log.info("[sap.git.usage.MobileUsageReporting]", "App Id: " + id);
        jQuery.sap.log.info("[sap.git.usage.MobileUsageReporting]", "App Version: " + version);

        // setup "usageId" deferred
        var uIdDeferred = $.Deferred();

        // store usageid and appid in the component
        component["sap.git.usage.UsageIdDeferred"] = uIdDeferred;
        component["sap.git.usage.AppId"] = id;

        // check if host is enabled
        if (hosts && jQuery.inArray(window.location.host, hosts) === -1) {
            jQuery.sap.log.debug("[sap.git.usage.MobileUsageReporting]", "Usage reporting disabled for this host.");
            return;
        }

        this._applyFLPWorkaround();

        // send usage to backend
        var usageURL = "https://sapprod.apimanagement.hana.ondemand.com:443/it-mobile-usage-reporting/api/usage";
        var usageData = this._createUsageBody(id, version, deviceId);
        $.ajax({
            url: usageURL,
            method: "POST",
            contentType: "application/json",
            data: JSON.stringify(usageData)
        }).done(function (data) {
            var usageId = data.usageId;
            jQuery.sap.log.info("[sap.git.usage.MobileUsageReporting]", "Usage Reported");
            jQuery.sap.log.info("[sap.git.usage.MobileUsageReporting]", "Usage Id: " + usageId);

            uIdDeferred.resolve(usageId);
        });
    },

    addEvent: function (component, eventId) {
        jQuery.sap.log.info("[sap.git.usage.MobileUsageReporting]", "Add Event");

        component["sap.git.usage.UsageIdDeferred"].then(function (usageId) {
            var appId = component["sap.git.usage.AppId"];
            var eventURL = "https://sapprod.apimanagement.hana.ondemand.com:443/it-mobile-usage-reporting/api/usage/addEvent/" + usageId;
            var eventDate = new Date().getTime();
            var eventData = {
                id: eventId,
                dateTime: eventDate,
                appId: appId
            };

            // send event to backend
            $.ajax({
                url: eventURL,
                method: "POST",
                contentType: "application/json",
                data: JSON.stringify(eventData)
            }).done(function () {
                jQuery.sap.log.info("[sap.git.usage.MobileUsageReporting]", "Event added");
            });
        });
    },

    setUser: function (component, userId) {
        // not available anymore
    },

    _createUsageBody: function (appId, versionId, deviceId) {

        var usageStart = new Date().getTime();
        var usageEnd = usageStart + 1000;  // default duration for web apps

        var usage = {
            version: {
                versionId: versionId,
                plattform: {
                    id: 'WEB',
                    application: appId
                }
            },
            timeSpan: {
                spanStart: usageStart,
                spanEnd: usageEnd
            },
            events: [],
            deviceInformation: {
                deviceId: deviceId,
                screenSize: 1,
                modelName: navigator.userAgent,
                countryCode: navigator.language,
                operatingSystem: navigator.oscpu
            }
        };
        return usage;
    },

    _getDeviceId: function () {
        if (!navigator.cookieEnabled) {
            return "FALLBACK_USER_COOKIES_DISABLED";
        }

        // @formatter:off
        // helper for accessing cookies
        // https://developer.mozilla.org/en-US/docs/Web/API/Document/cookie/Simple_document.cookie_framework
        var docCookies={getItem:function(a){return a?decodeURIComponent(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*"+encodeURIComponent(a).replace(/[\-\.\+\*]/g,"\\$&")+"\\s*\\=\\s*([^;]*).*$)|^.*$"),"$1"))||null:null},setItem:function(a,b,c,d,e,f){if(!a||/^(?:expires|max\-age|path|domain|secure)$/i.test(a))return!1;var g="";if(c)switch(c.constructor){case Number:g=c===1/0?"; expires=Fri, 31 Dec 9999 23:59:59 GMT":"; max-age="+c;break;case String:g="; expires="+c;break;case Date:g="; expires="+c.toUTCString()}return document.cookie=encodeURIComponent(a)+"="+encodeURIComponent(b)+g+(e?"; domain="+e:"")+(d?"; path="+d:"")+(f?"; secure":""),!0},removeItem:function(a,b,c){return!!this.hasItem(a)&&(document.cookie=encodeURIComponent(a)+"=; expires=Thu, 01 Jan 1970 00:00:00 GMT"+(c?"; domain="+c:"")+(b?"; path="+b:""),!0)},hasItem:function(a){return!!a&&new RegExp("(?:^|;\\s*)"+encodeURIComponent(a).replace(/[\-\.\+\*]/g,"\\$&")+"\\s*\\=").test(document.cookie)},keys:function(){for(var a=document.cookie.replace(/((?:^|\s*;)[^\=]+)(?=;|$)|^\s*|\s*(?:\=[^;]*)?(?:\1|$)/g,"").split(/\s*(?:\=[^;]*)?;\s*/),b=a.length,c=0;c<b;c++)a[c]=decodeURIComponent(a[c]);return a}};
        // @formatter:on

        if (docCookies.hasItem("tracking_uuid")) {
            return docCookies.getItem("tracking_uuid");
        } else {

            // @formatter:off
            /*
             CryptoJS v3.1.2
             code.google.com/p/crypto-js
             (c) 2009-2013 by Jeff Mott. All rights reserved.
             code.google.com/p/crypto-js/wiki/License
             */
            var CryptoJS=CryptoJS||function(a,b){var c={},d=c.lib={},e=function(){},f=d.Base={extend:function(a){e.prototype=this;var b=new e;return a&&b.mixIn(a),b.hasOwnProperty("init")||(b.init=function(){b.$super.init.apply(this,arguments)}),b.init.prototype=b,b.$super=this,b},create:function(){var a=this.extend();return a.init.apply(a,arguments),a},init:function(){},mixIn:function(a){for(var b in a)a.hasOwnProperty(b)&&(this[b]=a[b]);a.hasOwnProperty("toString")&&(this.toString=a.toString)},clone:function(){return this.init.prototype.extend(this)}},g=d.WordArray=f.extend({init:function(a,c){a=this.words=a||[],this.sigBytes=c!=b?c:4*a.length},toString:function(a){return(a||i).stringify(this)},concat:function(a){var b=this.words,c=a.words,d=this.sigBytes;if(a=a.sigBytes,this.clamp(),d%4)for(var e=0;e<a;e++)b[d+e>>>2]|=(c[e>>>2]>>>24-8*(e%4)&255)<<24-8*((d+e)%4);else if(65535<c.length)for(e=0;e<a;e+=4)b[d+e>>>2]=c[e>>>2];else b.push.apply(b,c);return this.sigBytes+=a,this},clamp:function(){var b=this.words,c=this.sigBytes;b[c>>>2]&=4294967295<<32-8*(c%4),b.length=a.ceil(c/4)},clone:function(){var a=f.clone.call(this);return a.words=this.words.slice(0),a},random:function(b){for(var c=[],d=0;d<b;d+=4)c.push(4294967296*a.random()|0);return new g.init(c,b)}}),h=c.enc={},i=h.Hex={stringify:function(a){var b=a.words;a=a.sigBytes;for(var c=[],d=0;d<a;d++){var e=b[d>>>2]>>>24-8*(d%4)&255;c.push((e>>>4).toString(16)),c.push((15&e).toString(16))}return c.join("")},parse:function(a){for(var b=a.length,c=[],d=0;d<b;d+=2)c[d>>>3]|=parseInt(a.substr(d,2),16)<<24-4*(d%8);return new g.init(c,b/2)}},j=h.Latin1={stringify:function(a){var b=a.words;a=a.sigBytes;for(var c=[],d=0;d<a;d++)c.push(String.fromCharCode(b[d>>>2]>>>24-8*(d%4)&255));return c.join("")},parse:function(a){for(var b=a.length,c=[],d=0;d<b;d++)c[d>>>2]|=(255&a.charCodeAt(d))<<24-8*(d%4);return new g.init(c,b)}},k=h.Utf8={stringify:function(a){try{return decodeURIComponent(escape(j.stringify(a)))}catch(a){throw Error("Malformed UTF-8 data")}},parse:function(a){return j.parse(unescape(encodeURIComponent(a)))}},l=d.BufferedBlockAlgorithm=f.extend({reset:function(){this._data=new g.init,this._nDataBytes=0},_append:function(a){"string"==typeof a&&(a=k.parse(a)),this._data.concat(a),this._nDataBytes+=a.sigBytes},_process:function(b){var c=this._data,d=c.words,e=c.sigBytes,f=this.blockSize,h=e/(4*f),h=b?a.ceil(h):a.max((0|h)-this._minBufferSize,0);if(b=h*f,e=a.min(4*b,e),b){for(var i=0;i<b;i+=f)this._doProcessBlock(d,i);i=d.splice(0,b),c.sigBytes-=e}return new g.init(i,e)},clone:function(){var a=f.clone.call(this);return a._data=this._data.clone(),a},_minBufferSize:0});d.Hasher=l.extend({cfg:f.extend(),init:function(a){this.cfg=this.cfg.extend(a),this.reset()},reset:function(){l.reset.call(this),this._doReset()},update:function(a){return this._append(a),this._process(),this},finalize:function(a){return a&&this._append(a),this._doFinalize()},blockSize:16,_createHelper:function(a){return function(b,c){return new a.init(c).finalize(b)}},_createHmacHelper:function(a){return function(b,c){return new m.HMAC.init(a,c).finalize(b)}}});var m=c.algo={};return c}(Math);!function(){var a=CryptoJS,b=a.lib,c=b.WordArray,d=b.Hasher,e=[],b=a.algo.SHA1=d.extend({_doReset:function(){this._hash=new c.init([1732584193,4023233417,2562383102,271733878,3285377520])},_doProcessBlock:function(a,b){for(var c=this._hash.words,d=c[0],f=c[1],g=c[2],h=c[3],i=c[4],j=0;80>j;j++){if(16>j)e[j]=0|a[b+j];else{var k=e[j-3]^e[j-8]^e[j-14]^e[j-16];e[j]=k<<1|k>>>31}k=(d<<5|d>>>27)+i+e[j],k=20>j?k+((f&g|~f&h)+1518500249):40>j?k+((f^g^h)+1859775393):60>j?k+((f&g|f&h|g&h)-1894007588):k+((f^g^h)-899497514),i=h,h=g,g=f<<30|f>>>2,f=d,d=k}c[0]=c[0]+d|0,c[1]=c[1]+f|0,c[2]=c[2]+g|0,c[3]=c[3]+h|0,c[4]=c[4]+i|0},_doFinalize:function(){var a=this._data,b=a.words,c=8*this._nDataBytes,d=8*a.sigBytes;return b[d>>>5]|=128<<24-d%32,b[(d+64>>>9<<4)+14]=Math.floor(c/4294967296),b[(d+64>>>9<<4)+15]=c,a.sigBytes=4*b.length,this._process(),this._hash},clone:function(){var a=d.clone.call(this);return a._hash=this._hash.clone(),a}});a.SHA1=d._createHelper(b),a.HmacSHA1=d._createHmacHelper(b)}();
            // @formatter:on

            // generate uuid
            var hash = CryptoJS.SHA1(CryptoJS.lib.WordArray.random(16));
            docCookies.setItem("tracking_uuid", hash, Infinity);
            return hash.toString();
        }
    },

    _getVersion: function (component) {
        var version = component.getMetadata().getVersion();
        // Add (FLP) when launched from fiorilaunchpad
        if (window.location.host.indexOf("fiorilaunchpad") >= 0) {
            version = version + " (FLP)";
        }
        return version;
    },

    _applyFLPWorkaround: function () {
        // temporary workaround for flp
        // prevent InterceptService from modifying our requests
        try {
            if (typeof sap !== 'undefined' && typeof sap.ushell !== 'undefined' && typeof sap.ushell.Container !== 'undefined') {
                sap.ushell.Container.getService('InterceptService')._routes.push('https://sapprod.apimanagement.hana.ondemand.com:443/it-mobile-usage-reporting/api/usage');
            }
        } catch (e) {
        }
    }
}