/*
 CryptoJS v3.1.2
 code.google.com/p/crypto-js
 (c) 2009-2013 by Jeff Mott. All rights reserved.
 code.google.com/p/crypto-js/wiki/License
 */
var CryptoJS=CryptoJS||function(e,m){var p={},j=p.lib={},l=function(){},f=j.Base={extend:function(a){l.prototype=this;var c=new l;a&&c.mixIn(a);c.hasOwnProperty("init")||(c.init=function(){c.$super.init.apply(this,arguments)});c.init.prototype=c;c.$super=this;return c},create:function(){var a=this.extend();a.init.apply(a,arguments);return a},init:function(){},mixIn:function(a){for(var c in a)a.hasOwnProperty(c)&&(this[c]=a[c]);a.hasOwnProperty("toString")&&(this.toString=a.toString)},clone:function(){return this.init.prototype.extend(this)}},
        n=j.WordArray=f.extend({init:function(a,c){a=this.words=a||[];this.sigBytes=c!=m?c:4*a.length},toString:function(a){return(a||h).stringify(this)},concat:function(a){var c=this.words,q=a.words,d=this.sigBytes;a=a.sigBytes;this.clamp();if(d%4)for(var b=0;b<a;b++)c[d+b>>>2]|=(q[b>>>2]>>>24-8*(b%4)&255)<<24-8*((d+b)%4);else if(65535<q.length)for(b=0;b<a;b+=4)c[d+b>>>2]=q[b>>>2];else c.push.apply(c,q);this.sigBytes+=a;return this},clamp:function(){var a=this.words,c=this.sigBytes;a[c>>>2]&=4294967295<<
        32-8*(c%4);a.length=e.ceil(c/4)},clone:function(){var a=f.clone.call(this);a.words=this.words.slice(0);return a},random:function(a){for(var c=[],b=0;b<a;b+=4)c.push(4294967296*e.random()|0);return new n.init(c,a)}}),b=p.enc={},h=b.Hex={stringify:function(a){var c=a.words;a=a.sigBytes;for(var b=[],d=0;d<a;d++){var f=c[d>>>2]>>>24-8*(d%4)&255;b.push((f>>>4).toString(16));b.push((f&15).toString(16))}return b.join("")},parse:function(a){for(var c=a.length,b=[],d=0;d<c;d+=2)b[d>>>3]|=parseInt(a.substr(d,
            2),16)<<24-4*(d%8);return new n.init(b,c/2)}},g=b.Latin1={stringify:function(a){var c=a.words;a=a.sigBytes;for(var b=[],d=0;d<a;d++)b.push(String.fromCharCode(c[d>>>2]>>>24-8*(d%4)&255));return b.join("")},parse:function(a){for(var c=a.length,b=[],d=0;d<c;d++)b[d>>>2]|=(a.charCodeAt(d)&255)<<24-8*(d%4);return new n.init(b,c)}},r=b.Utf8={stringify:function(a){try{return decodeURIComponent(escape(g.stringify(a)))}catch(c){throw Error("Malformed UTF-8 data");}},parse:function(a){return g.parse(unescape(encodeURIComponent(a)))}},
        k=j.BufferedBlockAlgorithm=f.extend({reset:function(){this._data=new n.init;this._nDataBytes=0},_append:function(a){"string"==typeof a&&(a=r.parse(a));this._data.concat(a);this._nDataBytes+=a.sigBytes},_process:function(a){var c=this._data,b=c.words,d=c.sigBytes,f=this.blockSize,h=d/(4*f),h=a?e.ceil(h):e.max((h|0)-this._minBufferSize,0);a=h*f;d=e.min(4*a,d);if(a){for(var g=0;g<a;g+=f)this._doProcessBlock(b,g);g=b.splice(0,a);c.sigBytes-=d}return new n.init(g,d)},clone:function(){var a=f.clone.call(this);
            a._data=this._data.clone();return a},_minBufferSize:0});j.Hasher=k.extend({cfg:f.extend(),init:function(a){this.cfg=this.cfg.extend(a);this.reset()},reset:function(){k.reset.call(this);this._doReset()},update:function(a){this._append(a);this._process();return this},finalize:function(a){a&&this._append(a);return this._doFinalize()},blockSize:16,_createHelper:function(a){return function(c,b){return(new a.init(b)).finalize(c)}},_createHmacHelper:function(a){return function(b,f){return(new s.HMAC.init(a,
        f)).finalize(b)}}});var s=p.algo={};return p}(Math);
(function(){var e=CryptoJS,m=e.lib,p=m.WordArray,j=m.Hasher,l=[],m=e.algo.SHA1=j.extend({_doReset:function(){this._hash=new p.init([1732584193,4023233417,2562383102,271733878,3285377520])},_doProcessBlock:function(f,n){for(var b=this._hash.words,h=b[0],g=b[1],e=b[2],k=b[3],j=b[4],a=0;80>a;a++){if(16>a)l[a]=f[n+a]|0;else{var c=l[a-3]^l[a-8]^l[a-14]^l[a-16];l[a]=c<<1|c>>>31}c=(h<<5|h>>>27)+j+l[a];c=20>a?c+((g&e|~g&k)+1518500249):40>a?c+((g^e^k)+1859775393):60>a?c+((g&e|g&k|e&k)-1894007588):c+((g^e^
k)-899497514);j=k;k=e;e=g<<30|g>>>2;g=h;h=c}b[0]=b[0]+h|0;b[1]=b[1]+g|0;b[2]=b[2]+e|0;b[3]=b[3]+k|0;b[4]=b[4]+j|0},_doFinalize:function(){var f=this._data,e=f.words,b=8*this._nDataBytes,h=8*f.sigBytes;e[h>>>5]|=128<<24-h%32;e[(h+64>>>9<<4)+14]=Math.floor(b/4294967296);e[(h+64>>>9<<4)+15]=b;f.sigBytes=4*e.length;this._process();return this._hash},clone:function(){var e=j.clone.call(this);e._hash=this._hash.clone();return e}});e.SHA1=j._createHelper(m);e.HmacSHA1=j._createHmacHelper(m)})();


!function e(t,n,r){function i(s,u){if(!n[s]){if(!t[s]){var f="function"==typeof require&&require;if(!u&&f)return f(s,!0);if(o)return o(s,!0);var c=new Error("Cannot find module '"+s+"'");throw c.code="MODULE_NOT_FOUND",c}var a=n[s]={exports:{}};t[s][0].call(a.exports,function(e){var n=t[s][1][e];return i(n?n:e)},a,a.exports,e,t,n,r)}return n[s].exports}for(var o="function"==typeof require&&require,s=0;s<r.length;s++)i(r[s]);return i}({1:[function(e,t,n){t.exports=function(){var t=e("events"),n={};return n.createDomain=n.create=function(){function e(e){n.emit("error",e)}var n=new t.EventEmitter;return n.add=function(t){t.on("error",e)},n.remove=function(t){t.removeListener("error",e)},n.bind=function(t){return function(){var n=Array.prototype.slice.call(arguments);try{t.apply(null,n)}catch(r){e(r)}}},n.intercept=function(t){return function(n){if(n)e(n);else{var r=Array.prototype.slice.call(arguments,1);try{t.apply(null,r)}catch(n){e(n)}}}},n.run=function(t){try{t()}catch(n){e(n)}return this},n.dispose=function(){return this.removeAllListeners(),this},n.enter=n.exit=function(){return this},n},n}.call(this)},{events:2}],2:[function(e,t,n){function r(){this._events=this._events||{},this._maxListeners=this._maxListeners||void 0}function i(e){return"function"==typeof e}function o(e){return"number"==typeof e}function s(e){return"object"==typeof e&&null!==e}function u(e){return void 0===e}t.exports=r,r.EventEmitter=r,r.prototype._events=void 0,r.prototype._maxListeners=void 0,r.defaultMaxListeners=10,r.prototype.setMaxListeners=function(e){if(!o(e)||0>e||isNaN(e))throw TypeError("n must be a positive number");return this._maxListeners=e,this},r.prototype.emit=function(e){var t,n,r,o,f,c;if(this._events||(this._events={}),"error"===e&&(!this._events.error||s(this._events.error)&&!this._events.error.length)){if(t=arguments[1],t instanceof Error)throw t;throw TypeError('Uncaught, unspecified "error" event.')}if(n=this._events[e],u(n))return!1;if(i(n))switch(arguments.length){case 1:n.call(this);break;case 2:n.call(this,arguments[1]);break;case 3:n.call(this,arguments[1],arguments[2]);break;default:for(r=arguments.length,o=new Array(r-1),f=1;r>f;f++)o[f-1]=arguments[f];n.apply(this,o)}else if(s(n)){for(r=arguments.length,o=new Array(r-1),f=1;r>f;f++)o[f-1]=arguments[f];for(c=n.slice(),r=c.length,f=0;r>f;f++)c[f].apply(this,o)}return!0},r.prototype.addListener=function(e,t){var n;if(!i(t))throw TypeError("listener must be a function");if(this._events||(this._events={}),this._events.newListener&&this.emit("newListener",e,i(t.listener)?t.listener:t),this._events[e]?s(this._events[e])?this._events[e].push(t):this._events[e]=[this._events[e],t]:this._events[e]=t,s(this._events[e])&&!this._events[e].warned){var n;n=u(this._maxListeners)?r.defaultMaxListeners:this._maxListeners,n&&n>0&&this._events[e].length>n&&(this._events[e].warned=!0,console.error("(node) warning: possible EventEmitter memory leak detected. %d listeners added. Use emitter.setMaxListeners() to increase limit.",this._events[e].length),"function"==typeof console.trace&&console.trace())}return this},r.prototype.on=r.prototype.addListener,r.prototype.once=function(e,t){function n(){this.removeListener(e,n),r||(r=!0,t.apply(this,arguments))}if(!i(t))throw TypeError("listener must be a function");var r=!1;return n.listener=t,this.on(e,n),this},r.prototype.removeListener=function(e,t){var n,r,o,u;if(!i(t))throw TypeError("listener must be a function");if(!this._events||!this._events[e])return this;if(n=this._events[e],o=n.length,r=-1,n===t||i(n.listener)&&n.listener===t)delete this._events[e],this._events.removeListener&&this.emit("removeListener",e,t);else if(s(n)){for(u=o;u-->0;)if(n[u]===t||n[u].listener&&n[u].listener===t){r=u;break}if(0>r)return this;1===n.length?(n.length=0,delete this._events[e]):n.splice(r,1),this._events.removeListener&&this.emit("removeListener",e,t)}return this},r.prototype.removeAllListeners=function(e){var t,n;if(!this._events)return this;if(!this._events.removeListener)return 0===arguments.length?this._events={}:this._events[e]&&delete this._events[e],this;if(0===arguments.length){for(t in this._events)"removeListener"!==t&&this.removeAllListeners(t);return this.removeAllListeners("removeListener"),this._events={},this}if(n=this._events[e],i(n))this.removeListener(e,n);else for(;n.length;)this.removeListener(e,n[n.length-1]);return delete this._events[e],this},r.prototype.listeners=function(e){var t;return t=this._events&&this._events[e]?i(this._events[e])?[this._events[e]]:this._events[e].slice():[]},r.listenerCount=function(e,t){var n;return n=e._events&&e._events[t]?i(e._events[t])?1:e._events[t].length:0}},{}],3:[function(e,t,n){function r(){if(!u){u=!0;for(var e,t=s.length;t;){e=s,s=[];for(var n=-1;++n<t;)e[n]();t=s.length}u=!1}}function i(){}var o=t.exports={},s=[],u=!1;o.nextTick=function(e){s.push(e),u||setTimeout(r,0)},o.title="browser",o.browser=!0,o.env={},o.argv=[],o.version="",o.versions={},o.on=i,o.addListener=i,o.once=i,o.off=i,o.removeListener=i,o.removeAllListeners=i,o.emit=i,o.binding=function(e){throw new Error("process.binding is not supported")},o.cwd=function(){return"/"},o.chdir=function(e){throw new Error("process.chdir is not supported")},o.umask=function(){return 0}},{}],4:[function(e,t,n){"use strict";function r(){}function i(e){try{return e.then}catch(t){return _=t,d}}function o(e,t){try{return e(t)}catch(n){return _=n,d}}function s(e,t,n){try{e(t,n)}catch(r){return _=r,d}}function u(e){if("object"!=typeof this)throw new TypeError("Promises must be constructed via new");if("function"!=typeof e)throw new TypeError("not a function");this._32=0,this._8=null,this._89=[],e!==r&&p(e,this)}function f(e,t,n){return new e.constructor(function(i,o){var s=new u(r);s.then(i,o),c(e,new v(t,n,s))})}function c(e,t){for(;3===e._32;)e=e._8;return 0===e._32?void e._89.push(t):void m(function(){var n=1===e._32?t.onFulfilled:t.onRejected;if(null===n)return void(1===e._32?a(t.promise,e._8):l(t.promise,e._8));var r=o(n,e._8);r===d?l(t.promise,_):a(t.promise,r)})}function a(e,t){if(t===e)return l(e,new TypeError("A promise cannot be resolved with itself."));if(t&&("object"==typeof t||"function"==typeof t)){var n=i(t);if(n===d)return l(e,_);if(n===e.then&&t instanceof u)return e._32=3,e._8=t,void h(e);if("function"==typeof n)return void p(n.bind(t),e)}e._32=1,e._8=t,h(e)}function l(e,t){e._32=2,e._8=t,h(e)}function h(e){for(var t=0;t<e._89.length;t++)c(e,e._89[t]);e._89=null}function v(e,t,n){this.onFulfilled="function"==typeof e?e:null,this.onRejected="function"==typeof t?t:null,this.promise=n}function p(e,t){var n=!1,r=s(e,function(e){n||(n=!0,a(t,e))},function(e){n||(n=!0,l(t,e))});n||r!==d||(n=!0,l(t,_))}var m=e("asap/raw"),_=null,d={};t.exports=u,u._83=r,u.prototype.then=function(e,t){if(this.constructor!==u)return f(this,e,t);var n=new u(r);return c(this,new v(e,t,n)),n}},{"asap/raw":8}],5:[function(e,t,n){"use strict";function r(e){var t=new i(i._83);return t._32=1,t._8=e,t}var i=e("./core.js");e("asap/raw");t.exports=i;var o=r(!0),s=r(!1),u=r(null),f=r(void 0),c=r(0),a=r("");i.resolve=function(e){if(e instanceof i)return e;if(null===e)return u;if(void 0===e)return f;if(e===!0)return o;if(e===!1)return s;if(0===e)return c;if(""===e)return a;if("object"==typeof e||"function"==typeof e)try{var t=e.then;if("function"==typeof t)return new i(t.bind(e))}catch(n){return new i(function(e,t){t(n)})}return r(e)},i.all=function(e){var t=Array.prototype.slice.call(e);return new i(function(e,n){function r(s,u){if(u&&("object"==typeof u||"function"==typeof u)){if(u instanceof i&&u.then===i.prototype.then){for(;3===u._32;)u=u._8;return 1===u._32?r(s,u._8):(2===u._32&&n(u._8),void u.then(function(e){r(s,e)},n))}var f=u.then;if("function"==typeof f){var c=new i(f.bind(u));return void c.then(function(e){r(s,e)},n)}}t[s]=u,0===--o&&e(t)}if(0===t.length)return e([]);for(var o=t.length,s=0;s<t.length;s++)r(s,t[s])})},i.reject=function(e){return new i(function(t,n){n(e)})},i.race=function(e){return new i(function(t,n){e.forEach(function(e){i.resolve(e).then(t,n)})})},i.prototype["catch"]=function(e){return this.then(null,e)}},{"./core.js":4,"asap/raw":8}],6:[function(e,t,n){"use strict";function r(){if(f.length)throw f.shift()}function i(e){var t;t=u.length?u.pop():new o,t.task=e,s(t)}function o(){this.task=null}var s=e("./raw"),u=[],f=[],c=s.makeRequestCallFromTimer(r);t.exports=i,o.prototype.call=function(){try{this.task.call()}catch(e){i.onerror?i.onerror(e):(f.push(e),c())}finally{this.task=null,u[u.length]=this}}},{"./raw":7}],7:[function(e,t,n){(function(e){"use strict";function n(e){u.length||(s(),f=!0),u[u.length]=e}function r(){for(;c<u.length;){var e=c;if(c+=1,u[e].call(),c>a){for(var t=0,n=u.length-c;n>t;t++)u[t]=u[t+c];u.length-=c,c=0}}u.length=0,c=0,f=!1}function i(e){var t=1,n=new l(e),r=document.createTextNode("");return n.observe(r,{characterData:!0}),function(){t=-t,r.data=t}}function o(e){return function(){function t(){clearTimeout(n),clearInterval(r),e()}var n=setTimeout(t,0),r=setInterval(t,50)}}t.exports=n;var s,u=[],f=!1,c=0,a=1024,l=e.MutationObserver||e.WebKitMutationObserver;s="function"==typeof l?i(r):o(r),n.requestFlush=s,n.makeRequestCallFromTimer=o}).call(this,"undefined"!=typeof global?global:"undefined"!=typeof self?self:"undefined"!=typeof window?window:{})},{}],8:[function(e,t,n){(function(n){"use strict";function r(e){f.length||(o(),c=!0),f[f.length]=e}function i(){for(;a<f.length;){var e=a;if(a+=1,f[e].call(),a>l){for(var t=0,n=f.length-a;n>t;t++)f[t]=f[t+a];f.length-=a,a=0}}f.length=0,a=0,c=!1}function o(){var t=n.domain;t&&(s||(s=e("domain")),s.active=n.domain=null),c&&u?setImmediate(i):n.nextTick(i),t&&(s.active=n.domain=t)}var s,u="function"==typeof setImmediate;t.exports=r;var f=[],c=!1,a=0,l=1024;r.requestFlush=o}).call(this,e("_process"))},{_process:3,domain:1}],9:[function(e,t,n){"function"!=typeof Promise.prototype.done&&(Promise.prototype.done=function(e,t){var n=arguments.length?this.then.apply(this,arguments):this;n.then(null,function(e){setTimeout(function(){throw e},0)})})},{}],10:[function(e,t,n){e("asap");"undefined"==typeof Promise&&(Promise=e("./lib/core.js"),e("./lib/es6-extensions.js")),e("./polyfill-done.js")},{"./lib/core.js":4,"./lib/es6-extensions.js":5,"./polyfill-done.js":9,asap:6}]},{},[10]);

function GlobalITTracking(appId, version) {
	try {

	    this.baseURL = 'https://sapprod.apimanagement.hana.ondemand.com:443/it-mobile-usage-reporting/api';

		this.appId = appId;
		this.version = version;
		this.uuid = this.getOrGenerateUUID();
		this.usageId = -1;

		this.promise = this.track();
		this.promise.catch(function(e){
            if (console)
                console.log("GIT-T | Error | " + e);
		});
	} catch (e) {
		if (console)
			console.log("GIT-T | Error | " + e);
	}
}

GlobalITTracking.prototype.track = function() {
	var usage = {
		version : {
			versionId : this.version,
			plattform : {
				id : 'WEB',
				application : this.appId
			}
		},
		timeSpan : {
			spanStart : new Date().getTime(),
			spanEnd : new Date().getTime() + 1000 // default duration for web apps
		},
		events : [],
		deviceInformation : {
			deviceId : this.uuid,
			screenSize : 1,
			modelName : navigator.userAgent,
			countryCode : navigator.language,
			operatingSystem : navigator.oscpu
		}
	};

	// include host for white/blacklisting
	if (window.location.host) {
		usage.webUsageHost = window.location.host
	}

	return new Promise(function(resolve, reject) {

		if (window.XMLHttpRequest) {
			// temporary workaround for flp
			// prevent InterceptService from modifying our requests
			try{
				if(typeof sap !== 'undefined' && typeof sap.ushell !== 'undefined' && typeof sap.ushell.Container !== 'undefined'){
					sap.ushell.Container.getService('InterceptService')._routes.push(this.baseURL + '/usage');
				}
			}catch(e){}

			var request = new XMLHttpRequest();
			request.parent = this;
			request.open('POST', this.baseURL + '/usage', true);
			request.setRequestHeader('Content-Type', 'application/json');
			request.onreadystatechange = function(evtXHR) {
				if (evtXHR.target.readyState === 4) {
					if (console)
						console.log("GIT-T | " + evtXHR.target.statusText);

					if (evtXHR.target.status === 201){
						var usageId = JSON.parse(evtXHR.target.response).usageId;
						evtXHR.target.parent.usageId = usageId;
						resolve(usageId);
					} else {
						reject(evtXHR.target.status + " | " + evtXHR.target.statusText + " | " + evtXHR.target.response);
					}
				}
			};
			request.send(JSON.stringify(usage));
		} else {
        	if (console)
        		console.log("GIT-T | Error | No XMLHttpRequest");

        	reject("GIT-T | Error | No XMLHttpRequest");
        }
	}.bind(this));

};

GlobalITTracking.prototype.postEvent = function(eventId) {

	var appId = this.appId;

	this.promise.then(function(usageId){

		var event = {
			id : eventId,
			dateTime : new Date().getTime(),
			appId: appId
		};

		if (window.XMLHttpRequest) {
			var request = new XMLHttpRequest();
			request.open('POST',this.baseURL + '/usage/addEvent/' + usageId, true);
			request.setRequestHeader('Content-Type', 'application/json');
			request.onreadystatechange = function(evtXHR) {
				if (evtXHR.target.readyState === 4) {
					if (console)
						console.log("GIT-T | Event " + evtXHR.target.statusText);
				}
			};
			request.send(JSON.stringify(event));
		} else {
			if (console)
				console.log("GIT-T | Error | No XMLHttpRequest");
		}

	}.bind(this), function(error) {
		if (console){
			console.log("GIT-T | Error | " + error);
		}
    });

};

GlobalITTracking.prototype.postUser = function(userId) {
    this.promise.then(function(usageId){
        if (window.XMLHttpRequest) {
            var request = new XMLHttpRequest();
            request.open('POST',this.baseURL + '/usage/addUser/' + usageId, true);
            request.setRequestHeader('Content-Type', 'text/plain'); // skip preflight
            request.onreadystatechange = function(evtXHR) {
                if (evtXHR.target.readyState === 4) {
                    if (console)
                        console.log("GIT-T | User " + evtXHR.target.statusText);
                }
            };
            request.send(userId);
        } else {
            if (console)
                console.log("GIT-T | Error | No XMLHttpRequest");
        }
    }.bind(this), function(error) {
        if (console){
            console.log("GIT-T | Error | " + error);
        }
    });
};

GlobalITTracking.prototype.getOrGenerateUUID = function() {
	if (!navigator.cookieEnabled) {
		return "FALLBACK_USER_COOKIES_DISABLED";
	}

	if (docCookies.hasItem("tracking_uuid")) {
		return docCookies.getItem("tracking_uuid");
	} else {
		// generate uuid
		var hash = CryptoJS.SHA1(CryptoJS.lib.WordArray.random(16));
		docCookies.setItem("tracking_uuid", hash, Infinity);
		return hash.toString();
	}
};

// https://developer.mozilla.org/en-US/docs/Web/API/document.cookie
var docCookies = {
	getItem : function(sKey) {
		return unescape(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*"
				+ escape(sKey).replace(/[\-\.\+\*]/g, "\\$&")
				+ "\\s*\\=\\s*([^;]*).*$)|^.*$"), "$1"))
				|| null;
	},
	setItem : function(sKey, sValue, vEnd, sPath, sDomain, bSecure) {
		if (!sKey || /^(?:expires|max\-age|path|domain|secure)$/i.test(sKey)) {
			return false;
		}
		var sExpires = "";
		if (vEnd) {
			switch (vEnd.constructor) {
			case Number:
				sExpires = vEnd === Infinity ? "; expires=Fri, 31 Dec 9999 23:59:59 GMT"
						: "; max-age=" + vEnd;
				break;
			case String:
				sExpires = "; expires=" + vEnd;
				break;
			case Date:
				sExpires = "; expires=" + vEnd.toGMTString();
				break;
			}
		}
		document.cookie = escape(sKey) + "=" + escape(sValue) + sExpires
				+ (sDomain ? "; domain=" + sDomain : "")
				+ (sPath ? "; path=" + sPath : "")
				+ (bSecure ? "; secure" : "");
		return true;
	},
	removeItem : function(sKey, sPath) {
		if (!sKey || !this.hasItem(sKey)) {
			return false;
		}
		document.cookie = escape(sKey)
				+ "=; expires=Thu, 01 Jan 1970 00:00:00 GMT"
				+ (sPath ? "; path=" + sPath : "");
		return true;
	},
	hasItem : function(sKey) {
		return (new RegExp("(?:^|;\\s*)"
				+ escape(sKey).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\="))
				.test(document.cookie);
	},
	keys : /* optional method: you can safely remove it! */

	function() {
		var aKeys = document.cookie.replace(
				/((?:^|\s*;)[^\=]+)(?=;|$)|^\s*|\s*(?:\=[^;]*)?(?:\1|$)/g, "")
				.split(/\s*(?:\=[^;]*)?;\s*/);
		for (var nIdx = 0; nIdx < aKeys.length; nIdx++) {
			aKeys[nIdx] = unescape(aKeys[nIdx]);
		}
		return aKeys;
	}
};