sap.ui.define([
    "sap/ui/core/UIComponent"
], function (UIComponent) {
    "use strict";

    return UIComponent.extend("UsageReportingExample.Component", {

        metadata: {
            manifest: "json"
        },

        /**
         * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
         * @public
         * @override
         */
        init: function () {
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);

            jQuery.sap.log.setLevel(jQuery.sap.log.Level.INFO);

            // @formatter:off
			/* Mobile Usage Reporting */
			/* Version v3 */
			sap.git=sap.git||{},sap.git.usage=sap.git.usage||{},sap.git.usage.Reporting={_lp:null,_load:function(a){this._lp=this._lp||sap.ui.getCore().loadLibrary("sap.git.usage",{url:"/web-client/v3",async:!0}),this._lp.then(function(){a(sap.git.usage.MobileUsageReporting)},this._loadFailed)},_loadFailed:function(a){jQuery.sap.log.warning("[sap.git.usage.MobileUsageReporting]","Loading failed: "+a)},setup:function(a){this._load(function(b){b.setup(a)})},addEvent:function(a,b){this._load(function(c){c.addEvent(a,b)})},setUser:function(a,b){this._load(function(c){c.setUser(a,b)})}};
			// @formatter:on

            sap.git.usage.Reporting.setup(this);
            sap.git.usage.Reporting.addEvent(this, "test");

            jQuery.sap.log.warning("[App]", "After Reporting");
        }
    });

});