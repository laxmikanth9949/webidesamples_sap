function ModelLocator() {
}

ModelLocator.shouldUseDebug = function () {
    return ModelLocator.getParameterByName("MOCK") === "TRUE";
};

ModelLocator.getMonthlyUpdateSubscriptionModel = function () {
    return new sap.ui.model.json.JSONModel(
        Backend.api("reporting/newsletter/mySubscriptions")
    );
};

ModelLocator.getWhoAmI = function () {
    if (!ModelLocator.shouldUseDebug())
        return new sap.ui.model.json.JSONModel(
            Backend.api("internal/authorization/whoami")
        );
    return new sap.ui.model.json.JSONModel({
        id: "D000001"
    });
};

ModelLocator.getAppSuggestionModel = function () {
    if (!ModelLocator.shouldUseDebug())
        return new sap.ui.model.json.JSONModel(
            Backend.api("internal/application/unfiltered")
        );
    return new sap.ui.model.json.JSONModel([{
        "id": "Customer 360",
        "displayName": "360 Customer View"
    }, {
        "id": "AGSMCCMobileApp",
        "displayName": "AGSMCCMobileApp"
    }]);

};

ModelLocator.getAuthorizationStatusList = function () {
    if (!ModelLocator.shouldUseDebug())
        return new sap.ui.model.json.JSONModel(
            Backend.api("sa-internal/authorization/getAll")
        );

    return new sap.ui.model.json.JSONModel([{
        type: "SINGLE",
        appId: "EasyConnect",
        authId: 1,
        userId: "D053397",
        reason: "I am the app owner!",
        approver: "D055218",
        status: "APPROVED",
        lastStatusModification: 1349333576093
    }, {
        type: "SINGLE",
        appId: "EasyConnect",
        authId: 2,
        userId: "D053397",
        reason: "I am the app owner!",
        approver: "D055218",
        status: "APPROVED",
        lastStatusModification: 1349333576093
    }, {
        type: "SINGLE",
        appId: "Wire",
        authId: 3,
        userId: "I804190",
        reason: "Just give me access!",
        approver: "D055218",
        status: "PENDING",
        lastStatusModification: 1349333576093
    }, {
        type: "SINGLE",
        appId: "EasyConnect",
        authId: 4,
        userId: "D056065",
        reason: "Yeah!",
        approver: "D055218",
        status: "REJECTED",
        lastStatusModification: 1349333576093
    }]);
};

ModelLocator.getParameterByName = function (name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), results = regex
        .exec(location.search);
    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g,
        " "));
};
