var gAudio = new Audio('/resources/ping.mp3');
var gAudioOn = false;
var gShowAppName = true;

$(document)
    .ready(
    function () {

        // Initialize WorldMap

        $('#world-map').css("width", window.innerWidth);
        $('#world-map').css("height", window.innerHeight);

        $('#world-map').vectorMap({
            backgroundColor: '#000000',
            regionStyle: {
                initial: {
                    fill: '#909090',
                    "fill-opacity": 1,
                    stroke: 'none',
                    "stroke-width": 0,
                    "stroke-opacity": 1
                },
                hover: {
                    "fill-opacity": 0.8
                },
                selected: {
                    fill: '#f0ab00'
                },
                selectedHover: {}
            }
        });

        var mapObject = $('#world-map').vectorMap('get',
            'mapObject');

        // Add WorldMap Customizations

        // Audio button
        $('.jvectormap-container')
            .append(
            "<div id='worldmap-audio'><img alt='Speaker' src='/img/audio_off.png' /></div>");
        $('#worldmap-audio')
            .click(
            function () {
                if (gAudioOn) {
                    gAudioOn = false;
                    $(this)
                        .html(
                        "<img alt='Speaker' src='/img/audio_off.png' />");
                } else {
                    gAudioOn = true;
                    $(this)
                        .html(
                        "<img alt='Speaker' src='/img/audio_on.png' />");
                }
            });

        // Deactivated displaying the app name by GET parameter
        if (getParameterByName("showAppName") === 'false') {
            gShowAppName = false;
        }

        // Deactivated displaying the app name by invisible button
        $('.jvectormap-container').append(
            "<div id='worldmap-appname'>o</div>");
        $('#worldmap-appname').click(function () {
            if (gShowAppName)
                gShowAppName = false;
            else
                gShowAppName = true;
        });

        // Initialize WebSocket

        var socket = new RealtimeSocket(
            function (report) {

                if (typeof report.deviceInformation.countryCode === 'undefined') {
                    if (console)
                        console
                            .log("Skipping Usage in Map without Country Code...");
                }

                try {

                    // guess country for "EN"
                    var cc = report.deviceInformation.countryCode;
                    if (cc === "EN")
                        cc = "US";
                    if(cc === "SG") // display Singapore as Malaysia
                        cc = "MY";
                    if(cc === "DA") // Denmark
                        cc = "DK";
                    if(cc === "CA") // Czech
                        cc = "CZ";

                    selectRegion(mapObject,cc);
                    deselectRegion(mapObject, cc);
                } catch (e) {
                    if (console)
                        console.log("Could not highlight " + report.deviceInformation.countryCode + " on the map...");
                }


                if (gShowAppName) {
                    var id = createId();
                    $('#footer')
                        .append(
                        "<li id='"
                        + id
                        + "'>"
                        + report.version.plattform.application.displayName
                        + "</li>");
                    $('#' + id).animate({
                        opacity: 0.01
                    }, 9000, function () {
                        $('#' + id).remove();
                    });
                }

                if (gAudioOn)
                    gAudio.play();
            });
    });

function deselectRegion(mapObject, region) {
    setTimeout(function () {
        mapObject['regions'][region].element.setSelected(false);
    }, 2000);
}

function selectRegion(mapObject, region) {
    mapObject['regions'][region].element.setSelected(true);
}

function createId() {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < 12; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text;
}

function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), results = regex
        .exec(location.search);
    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g,
        " "));
}