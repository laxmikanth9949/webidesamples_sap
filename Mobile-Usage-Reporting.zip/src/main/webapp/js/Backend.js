function Backend() {
}

Backend.api = function (path) {
    Backend._ensureOrigin();
    return window.location.origin + "/api/" + path;
};

Backend.secureWebsocket = function (path) {
    Backend._ensureOrigin();
    var host = Backend.getParameterByName("overwriteHost") === null ? window.location.host : Backend.getParameterByName("overwriteHost");
    return 'wss://' + host + '/' + path;
};

Backend._ensureOrigin = function () {
    // IE BUG
    if (!window.location.origin) {
        window.location.origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port : '');
    }
};


Backend.getParameterByName = function (name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), results = regex
        .exec(location.search);
    return results == null ? null : decodeURIComponent(results[1].replace(/\+/g,
        " "));
};