function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&")
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function RealtimeSocket(onUsage) {
    this.usageCallback = onUsage;
    this.id = -1;

    // allow client side filtering
    var appFilter = getParameterByName("appFilter");
    if (appFilter)
        this.appFilter = appFilter.split(",");

    this.connect();
}

RealtimeSocket.prototype.shouldDisplay = function (appId) {
    if (this.appFilter)
        return this.appFilter.indexOf(appId) !== -1;
    return true;
};

RealtimeSocket.prototype.sendPing = function () {
    this.socket.send("Ping!");
};

// Log errors
RealtimeSocket.prototype.onerror = function (error) {
    if (console) {
        console.log('WebSocket Error ' + error);
        console.log(error);
    }

    clearInterval(this.pingInterval);

    $("#error").empty().append("Could not establish a connection. Lets try it again!");
};

// Log errors
RealtimeSocket.prototype.onopen = function () {
    if (console)
        console.log('WebSocket Opened ');

    $("#error").empty();
    clearInterval(this.id);

    this.pingInterval = setInterval($.proxy(this.sendPing, this), 10000);
};

RealtimeSocket.prototype.onclose = function (close) {
    if (console) {
        console.log('WebSocket Close');
        console.log(close);
        console.log("Code: " + close.code);
        console.log("Reason: " + close.reason);
    }

    clearInterval(this.pingInterval);

    if (close.code == 1000) {// close normal
        return;
    }

    this.id = setTimeout($.proxy(this.connect, this), 3000);

    if (console) {
        console.log("Scheduling reconnect... (1)");
    }

};

// Log messages from the server
RealtimeSocket.prototype.onmessage = function (e) {
    var report = JSON.parse(e.data);

    if (!this.shouldDisplay(report.version.plattform.application.id))
        return;

    this.usageCallback(report);
};

RealtimeSocket.prototype.connect = function () {
    if (console) {
        console.log('WebSocket connecting... ');
    }
    $("#error").empty().append("Connecting...");

    var queryParam = getParameterByName('token');

    // create a request to an authenticated endpoint to get a session (oauth)
    $.ajax({
        method: "GET",
        url: Backend.api('internal/status'),
        dataType: "text",
        beforeSend: function (xhr) {
            if (queryParam) {
                xhr.setRequestHeader("Authorization", "Bearer " + queryParam);
            }
        },
        success: function (data, text, jqXHR) {

            var url = Backend.secureWebsocket("websocket/realtime");
            if (queryParam) {
                url += "?token=" + queryParam;
            }

            if (jqXHR.getResponseHeader("com.sap.cloud.security.login") === "login-request") {
                if (console) {
                    console.log("Got ID Service response, this should not happen!");
                }
            }

            if (console) {
                console.log("Authentication performed!");
                console.log("About to connecto to WS");
            }

            this.socket = new WebSocket(url);
            this.socket.onopen = $.proxy(this.onopen, this);
            this.socket.onerror = $.proxy(this.onerror, this);
            this.socket.onclose = $.proxy(this.onclose, this);
            this.socket.onmessage = $.proxy(this.onmessage, this);
        }.bind(this),
        error: function (jqXHR, textStatus, errorThrown) {

            // display close error
            $("#error").empty().append("Error: Order 66");

            if (console) {
                console.log("Failed");
            }

            this.id = setTimeout($.proxy(this.connect, this), 3000);

            if (console) {
                console.log("Scheduling reconnect... (2)");
            }
        }.bind(this)
    });
};