GlobalITTracking_Heartbeat = {

    repeat: function () {

        function getParameterByName(name, url) {
            if (!url) url = window.location.href;
            url = url.toLowerCase(); // This is just to avoid case sensitiveness
            name = name.replace(/[\[\]]/g, "\\$&").toLowerCase();// This is just to avoid case sensitiveness for query parameter name
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        }

        var queryParam = getParameterByName('token');

        var request = $.ajax({
            type: "GET",
            url: Backend.api('internal/status'),
            beforeSend: function (xhr) {
                if (queryParam !== null) {
                    xhr.setRequestHeader("Authorization", "Bearer " + queryParam);
                }
            }
        });
        request.done(GlobalITTracking_Heartbeat.done);
        request.fail(GlobalITTracking_Heartbeat.fail);
    },

    done: function (data, textStatus, jqXHR) {
        if (GlobalITTracking_Heartbeat.isSAPIDChallenge(jqXHR)) {
            if (console) {
                console.log("SAP ID Login Request");
            }
            window.location.reload();
        } else {
            if (console) {
                console.log("--^_--");
            }
        }
    },

    isSAPIDChallenge: function (jqXHR) {
        return jqXHR.getResponseHeader("com.sap.cloud.security.login") === "login-request";
    },

    fail: function () {
        if (console)
            console.log("______");
    }

};

// keeps session alive -> for realtime visualization
$(document).ready(function () {
    setInterval(GlobalITTracking_Heartbeat.repeat, 10000);
});