var hasMap = document.getElementById("world-map") !== null;
var hasBubble = document.getElementById("bubble-container") !== null;
console.log(hasMap);

// Mobile World Map Initialization
if (hasMap) {
    $('#world-map').css("width", "100%");
    $('#world-map').css("height", "100%");

    $('#world-map').vectorMap({
        backgroundColor: '#000000',
        regionStyle: {
            initial: {
                fill: '#909090',
                "fill-opacity": 1,
                stroke: 'none',
                "stroke-width": 0,
                "stroke-opacity": 1
            },
            hover: {
                "fill-opacity": 0.8
            },
            selected: {
                fill: '#f0ab00'
            },
            selectedHover: {}
        }
    });
    var mapObject = $('#world-map').vectorMap('get', 'mapObject');
}

if (hasBubble) {
    var bubbleContainer = document.getElementById('bubble-container');
}


var gFooter = document.getElementById("world-map-footer");

var mapCallback = function (report) {

    function deselectRegion(mapObject, region) {
        setTimeout(function () {
            mapObject['regions'][region].element.setSelected(false);
        }, 2000);
    }

    function selectRegion(mapObject, region) {
        mapObject['regions'][region].element.setSelected(true);
    }

    if (typeof report.deviceInformation.countryCode === 'undefined') {
        if (console)
            console.log("Skipping Usage in Map without Country Code...");
    }

    try {

        // guess country for "EN"
        var cc = report.deviceInformation.countryCode;
        if (cc === "EN")
            cc = "US";
        if (cc === "SG") // display Singapore as Malaysia
            cc = "MY";
        if (cc === "DA") // Denmark
            cc = "DK";
        if (cc === "CA") // Czech
            cc = "CZ";

        selectRegion(mapObject, cc);
        deselectRegion(mapObject, cc);
    } catch (e) {
        if (console)
            console.log("Could not highlight " + report.deviceInformation.countryCode + " on the map...");
    }


    var li = document.createElement("li");
    li.className += "map-footer";
    li.appendChild(document.createTextNode(report.version.plattform.application.displayName));

    gFooter.appendChild(li);

    li.addEventListener("animationend", function () {
        gFooter.removeChild(this);
    }.bind(li), false);

};

// Bubbles Initialization
var bubblesCallback = function (report) {

    var app = report.version.plattform.application.displayName;
    var platform = report.version.plattform.id;

    var bubbleSize = (Math.floor(Math.random() * 200) + 100);

    var wrapper = document.createElement("div");
    wrapper.className += "bubbleOuter";
    wrapper.style.left = Math.floor(Math.random() * (document.body.clientWidth - bubbleSize)) + "px";

    var div = document.createElement("div");

    var span = document.createElement("span");
    span.appendChild(document.createTextNode(app));

    div.appendChild(span);

    div.className += "bubble";

    // bubble color
    div.className += " bubble" + platform;

    // bubble size
    div.style.width = bubbleSize + "px";
    div.style.height = bubbleSize + "px";
    div.style.borderRadius = Math.ceil(bubbleSize / 2) + "px";

    wrapper.style.bottom = -bubbleSize + "px";

    // font size
    var fontSize = 25;
    span.style.fontSize = fontSize + "px";

    wrapper.appendChild(div);

    wrapper.addEventListener("animationend", function () {
        bubbleContainer.removeChild(this);
    }.bind(wrapper), false);

    bubbleContainer.appendChild(wrapper);


    // dynamically resize font size
    var isTooBig = span.offsetWidth > bubbleSize || span.offsetHeight > bubbleSize;
    while (isTooBig) {
        fontSize -= 3;
        span.style.fontSize = fontSize + "px";
        isTooBig = span.offsetWidth > bubbleSize || span.offsetHeight > bubbleSize;
        if (fontSize == 1)
            isTooBig = false;
    }

};

// Socket Initialization
new RealtimeSocket(function (usage) {
    try {
        if (hasMap)
            mapCallback(usage);
    } catch (e) {
    }
    try {
        if (hasBubble)
            bubblesCallback(usage);
    } catch (e) {
    }
});