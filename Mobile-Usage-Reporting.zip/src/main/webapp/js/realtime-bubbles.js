function addBubble(app, platform) {

    // Randomise the bubble positions (0 - 100%)
    var position = Math.floor(Math.random() * 101) + "%";

    var riseDuration = (10 + Math.floor(Math.random() * 9)) + "s";
    var wobbleDuration = (Math.floor(2 + Math.random() * 4)) + "s";

    var sizeInt = (Math.floor(Math.random() * 200) + 100);
    var size = sizeInt + "px";

    /* Color */
    var bubbleColorCSS = "iosBubble";
    if (platform === "WEB") {
        bubbleColorCSS = "webBubble";
    } else if (platform === "ANDROID") {
        bubbleColorCSS = "androidBubble";
    } else if (platform === "WINDOWS"){
        bubbleColorCSS = "windowsBubble";
    }

    var bubble = $('<div></div>').addClass(bubbleColorCSS).css({
        /* Layout */
        position: "absolute",
        display: "table",

        /* Size */
        width: size,
        height: size,
        "-moz-border-radius": size,
        "-webkit-border-radius": size,
        "border-radius": size,

        /* Prevent boarder clipping on Safari */
        "-webkit-background-clip": "padding-box",
        "-moz-background-clip": "padding",
        "background-clip": "padding-box",

        /* Position */
        'left': position,

        /* Animation */
        "-webkit-animation": "bubblerise " + riseDuration + " ease-in,bubblewobble " + wobbleDuration + " infinite ease-in-out steps(5)",
        "-moz-animation": "bubblerise " + riseDuration + " ease-in,bubblewobble " + wobbleDuration + " infinite ease-in-out steps(5)",
        "animation": "bubblerise " + riseDuration + " ease-in,bubblewobble " + wobbleDuration + " infinite ease-in-out steps(5)"
    }).bind('oanimationend animationend webkitAnimationEnd', function () {
        $(this).remove();
    });

    var fontSize = 25;

    var bubbleTitle = $("<div>" + app + "</div>").css({
        display: "table-cell",
        "vertical-align": "middle",
        "text-align": "center",

        "font-family": "BentonSans, Helvetica, Arial, sans-serif",
        "font-size": fontSize + "px",
        padding: "15px"

    }).appendTo(bubble);

    bubble.appendTo('.bubbles');

    // dynamically resize font size
    var isTooBig = bubble.width() > sizeInt || bubble.height() > sizeInt;
    while (isTooBig) {
        fontSize--;
        bubbleTitle.css({"font-size": fontSize + "px"});
        isTooBig = bubble.width() > sizeInt || bubble.height() > sizeInt;
        if (fontSize == 1)
            isTooBig = false;
    }

}

$(document).ready(
    function () {
        var socket = new RealtimeSocket(function (report) {
            addBubble(report.version.plattform.application.displayName,
                report.version.plattform.id);
        });
    });