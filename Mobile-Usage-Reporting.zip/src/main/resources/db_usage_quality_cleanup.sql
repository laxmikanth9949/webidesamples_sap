-- Native iOS App: Country Code
--	Cleaned Values: '?', '150', '419', 'null'

UPDATE APPLICATIONUSAGE SET COUNTRYCODE = '' WHERE ID = 'IOS' AND COUNTRYCODE IN ('?','150','419','null');

-- Native iOS App: Model Name
--	Cleaned Values: 
--		iPad4,1 => iPad Air
--		iPad4,2 => iPad Air
--		iPad4,3 => TODO -> UNKNOWN
--		iPad4,4 => iPad Mini (Retina)
--		iPad4,5 => iPad Mini (Retina)
--		iPhone3,2 => iPhone 4
--
-- // TODO enhande iOS Lib

UPDATE APPLICATIONUSAGE SET MODELNAME = 'iPad Air' WHERE ID = 'IOS' AND MODELNAME IN ('iPad4,1','iPad4,2');
UPDATE APPLICATIONUSAGE SET MODELNAME = 'iPad Air 2' WHERE ID = 'IOS' AND MODELNAME IN ('iPad5,3','iPad5,4');

UPDATE APPLICATIONUSAGE SET MODELNAME = 'iPad Mini (Retina)' WHERE ID = 'IOS' AND MODELNAME IN ('iPad4,4','iPad4,5','iPad4,6');

UPDATE APPLICATIONUSAGE SET MODELNAME = 'iPad Mini 3' WHERE ID = 'IOS' AND MODELNAME IN ('iPad4,7','iPad4,8','iPad4,9');

UPDATE APPLICATIONUSAGE SET MODELNAME = 'iPhone 6' WHERE ID = 'IOS' AND MODELNAME IN ('iPhone7,2');
UPDATE APPLICATIONUSAGE SET MODELNAME = 'iPhone 6 Plus' WHERE ID = 'IOS' AND MODELNAME IN ('iPhone7,1');

UPDATE APPLICATIONUSAGE SET MODELNAME = 'iPhone 4' WHERE ID = 'IOS' AND MODELNAME IN ('iPhone3,2');


-- change country code values like en-US (length = 5 AND seperated by '-') to US
UPDATE APPLICATIONUSAGE SET COUNTRYCODE = UCASE(SUBSTRING(COUNTRYCODE,4,2)) WHERE SUBSTRING(COUNTRYCODE,3,1) = '-' AND LENGTH(COUNTRYCODE) = 5;

-- convert all (safe) country codes to upper case
UPDATE APPLICATIONUSAGE SET COUNTRYCODE = UCASE(COUNTRYCODE) WHERE LENGTH(COUNTRYCODE) = 2;

-- make sure monthlyupdateoptout is in sync with (deleted) applications
DELETE from MONTHLYUPDATEOPTOUT where not exists (SELECT * FROM APPLICATION WHERE ID = APPLICATION_ID)
delete FROM T_AUTHORIZATION_SINGLE WHERE not exists (SELECT * FROM APPLICATION WHERE ID = appid)
-- // TODO automatically assert this when an application is deleted