package com.sap.globalit.tracking.api;

import com.sap.globalit.tracking.StandaloneTest;
import org.junit.Test;

import javax.ws.rs.core.Response;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;


public class SwaggerTest extends StandaloneTest {

    @Test
    public void getSwaggerJSON() {
        setUserContext(USER);

        Response response = target().path("api/swagger.json").request().get();
        assertThat(response.getStatus(), is(200));

        String s = response.readEntity(String.class);
        assertThat(s, notNullValue());
    }

}