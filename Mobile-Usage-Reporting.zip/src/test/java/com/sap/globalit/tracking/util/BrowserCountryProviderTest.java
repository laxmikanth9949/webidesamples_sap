package com.sap.globalit.tracking.util;

import org.junit.Test;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class BrowserCountryProviderTest {


    @Test
    public void getLanguage() {
        String country = BrowserCountryProvider.get("de,en-US;q=0.9,en;q=0.8","x");
        assertThat(country).isEqualTo("DE");
    }

    @Test
    public void getLanguage2() {
        String country = BrowserCountryProvider.get("en-US,de;q=0.9,en;q=0.8","x");
        assertThat(country).isEqualTo("US");
    }

    @Test
    public void getLanguage3() {
        String country = BrowserCountryProvider.get("de,en_ph;q=0.9,en;q=0.8", "x");
        assertThat(country).isEqualTo("DE");
    }

}
