package com.sap.globalit.tracking.api.internal.v2.report;

import com.sap.globalit.tracking.api.internal.v2.ResultSetMocker;
import com.sap.globalit.tracking.model.reporting.Chart;
import com.sap.globalit.tracking.model.reporting.Dimension;
import com.sap.globalit.tracking.model.reporting.Measure;
import com.sap.globalit.tracking.model.reporting.Table;
import com.sap.globalit.tracking.util.ChartUtil;
import org.junit.Test;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasEntry;

/**
 * Created by D053397 on 26.07.2016.
 */
public class TableUtilTest {

    @Test
    public void shouldEnrichWithMeasureCol() throws SQLException {

        // prepare table
        Table table = new Table();
        table.getColumns().add(new Dimension("App"));
        table.getColumns().add(new Measure("Africa"));

        Chart.ChartData tableData = new Chart.ChartData();
        tableData.with("App", "EasyConnect");
        tableData.with("Africa", 500L);

        table.setTableData(Arrays.asList(tableData));

        // prepare result set
        List<Object[]> data = new ArrayList<>();
        data.add(new Object[]{"EasyConnect", "EMEA", 500L});

        ResultSet resultSet = ResultSetMocker.mock(data, new String[]{"DIMENSION", "MEASURE_COL", "MEASURE"});

        TableUtil.enrichTableWithMeasureCol(table, resultSet, "App");

        assertThat(table.getColumns().size(), is(3));
        assertThat(table.getColumn(0).getName(), is("App"));
        assertThat(table.getColumn(0).getType(), is("Dimension"));

        assertThat(table.getColumn(1).getName(), is("Africa"));
        assertThat(table.getColumn(1).getType(), is("Measure"));

        assertThat(table.getColumn(2).getName(), is("EMEA"));

        assertThat(table.getTableData().size(), is(1));

        assertThat(table.getTableData().get(0), hasEntry(ChartUtil.cleanStringForReferenceInJS("App"), "EasyConnect"));
        assertThat(table.getTableData().get(0), hasEntry(ChartUtil.cleanStringForReferenceInJS("Africa"), 500L));
        assertThat(table.getTableData().get(0), hasEntry(ChartUtil.cleanStringForReferenceInJS("EMEA"), 500L));
    }

}