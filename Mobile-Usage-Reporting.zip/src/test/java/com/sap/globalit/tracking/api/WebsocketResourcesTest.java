package com.sap.globalit.tracking.api;

import com.sap.globalit.tracking.StandaloneTest;

/**
 * Created by D053397 on 07.12.2016.
 */
public class WebsocketResourcesTest extends StandaloneTest {

    // TODO add websocket connection & authentication test
}