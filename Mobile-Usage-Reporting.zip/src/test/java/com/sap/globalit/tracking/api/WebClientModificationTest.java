package com.sap.globalit.tracking.api;

import com.sap.globalit.tracking.StandaloneTest;
import com.sap.globalit.tracking.util.LandscapeHelper;
import org.apache.catalina.LifecycleException;
import org.junit.Test;

import javax.servlet.ServletException;
import javax.ws.rs.core.Response;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.endsWith;

/**
 * Created by D053397 on 07.12.2016.
 */
public class WebClientModificationTest extends StandaloneTest {

    @Test
    public void shouldServeWebClient() throws ServletException, LifecycleException {
        Response response = target().path("web-client/v3/library.js")
                .request()
                .get();

        String entity = response.readEntity(String.class);

        assertThat(entity, containsString(LandscapeHelper.Landscape.DEV.getUrl()));
        assertThat(entity, endsWith("}, /* bExport= */ false);"));
    }

    @Test
    public void shouldServeWebClient_Preload() throws ServletException, LifecycleException {
        Response response = target().path("web-client/v3/library-preload.js")
                .request()
                .get();

        String entity = response.readEntity(String.class);

        assertThat(entity, containsString(LandscapeHelper.Landscape.DEV.getUrl()));
    }

}
