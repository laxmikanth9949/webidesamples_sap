package com.sap.globalit.tracking.api;

import com.sap.globalit.tracking.StandaloneTest;
import org.apache.catalina.LifecycleException;
import org.junit.Test;

import javax.servlet.ServletException;
import javax.ws.rs.core.Response;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * Created by D053397 on 07.12.2016.
 */
public class UserRestrictionTest extends StandaloneTest {

    @Test
    public void shouldRequireUser() throws ServletException, LifecycleException {

        setUserContext(USER);

        Response response = target().path("api/reporting/master/apps")
                .request()
                .get();

        assertThat(response.getStatus(), is(200));

        setUserContext(ANONYMOUS);

        Response responseUser = target().path("api/reporting/master/apps")
                .request()
                .get();

        assertThat(responseUser.getStatus(), is(403));
    }


    @Test
    public void shouldRequireUser_status() throws ServletException, LifecycleException {

        setUserContext(USER);

        Response response = target().path("api/internal/status")
                .request()
                .get();

        assertThat(response.getStatus(), is(200));

        setUserContext(ANONYMOUS);

        Response responseUser = target().path("api/internal/status")
                .request()
                .get();

        assertThat(responseUser.getStatus(), is(403));
    }
}