package com.sap.globalit.tracking.api.internal.v2;

import static org.junit.Assert.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class ResultSetMockerTest {

	private final List<Object[]> data = new ArrayList<Object[]>();

	@Test
	public void testMockColumns() throws SQLException {
		data.add(new Object[] { "Johannes", 24, "Karlsruhe" });
		data.add(new Object[] { "Jonas", 20, "Karlsruhe" });
		data.add(new Object[] { "Stefanie", 15, "Fellbach" });

		String[] columns = new String[] { "name", "age", "city" };
		ResultSet res = ResultSetMocker.mock(data, columns);

		while (res.next()) {
			assertEquals(res.getString(1), res.getString("name"));
			assertEquals(res.getInt(2), res.getInt("age"));
			assertEquals(res.getString(3), res.getString("city"));
		}

	}
}
