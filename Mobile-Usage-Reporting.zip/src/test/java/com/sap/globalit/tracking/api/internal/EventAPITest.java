package com.sap.globalit.tracking.api.internal;

import com.sap.globalit.tracking.StandaloneTest;
import com.sap.globalit.tracking.dao.UsageDAO;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.model.ApplicationPlattform;
import com.sap.globalit.tracking.model.DeviceType;
import com.sap.globalit.tracking.model.Usage;
import com.sap.globalit.tracking.util.Timer;
import org.junit.Test;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class EventAPITest extends StandaloneTest {

    @Test
    public void getStatistics_simple() throws SQLException {

        // prepare
        String APP_ID = "App";

        persistence.transactional(em -> {
            Application app = new Application(APP_ID);
            em.persist(app);
            ApplicationPlattform plattform = new ApplicationPlattform(ApplicationPlattform.PlatformType.WEB, app);
            em.persist(plattform);
        });

        // trigger view creation
        target().path("api/status")
                .request()
                .get();

        // create usage
        UsageDAO usageDAO = new UsageDAO();
        usageDAO.setup(() -> connectionFactory.get(), usage_sequence, event_sequence);

        // TODO factory/util to create usage
        Usage u = new Usage();
        u.applicationId = APP_ID;
        u.platformId = ApplicationPlattform.PlatformType.WEB;
        u.deviceType = DeviceType.MOBILE;
        u.usageStart = ZonedDateTime.of(2016, 1, 1, 15, 0, 0, 0, ZoneId.of("UTC")).toInstant();
        u.usageEnd = u.usageStart.plusSeconds(1);
        u.events = Arrays.asList(
                new Usage.Event()
                        .setName("event-a")
                        .setInstant(u.usageStart),
                new Usage.Event()
                        .setName("event-b")
                        .setInstant(u.usageStart)
        );
        u.deviceId = "Device 1";

        usageDAO.persistToDatabase(u, new Timer());

        // execute
        setUserContext(USER);

        // create events
        List<EventAPI.EventReportEntry> response = target().path("api/internal/events/report")
                .request()
                .post(Entity.json(
                        new EventAPI.EventReportRequest()
                                .setStart("2016-01-01")
                                .setEnd("2016-01-02")
                                .setInterval(ReportAPI.TimeInterval.MONTH)
                                .setEvents(Arrays.asList(
                                        new EventAPI.EventId()
                                                .setApp(APP_ID)
                                                .setEvent("event-a")
                                ))
                )).readEntity(new GenericType<List<EventAPI.EventReportEntry>>() {
                });

        assertThat(response.get(0).moment, equalTo("01/2016"));
        assertThat(response.get(0).events.get(0).count, equalTo(1L));
        assertThat(response.get(0).events.get(0).app, equalTo(APP_ID));
        assertThat(response.get(0).events.get(0).event, equalTo("event-a"));
    }

    @Test
    public void getStatistics_TimeBug() throws SQLException {

        // prepare
        String APP_ID = "App";

        persistence.transactional(em -> {
            Application app = new Application(APP_ID);
            em.persist(app);
            ApplicationPlattform plattform = new ApplicationPlattform(ApplicationPlattform.PlatformType.WEB, app);
            em.persist(plattform);
        });

        // trigger view creation
        target().path("api/status")
                .request()
                .get();

        // create usage
        UsageDAO usageDAO = new UsageDAO();
        usageDAO.setup(() -> connectionFactory.get(), usage_sequence, event_sequence);

        // TODO factory/util to create usage
        Usage u = new Usage();
        u.applicationId = APP_ID;
        u.platformId = ApplicationPlattform.PlatformType.WEB;
        u.deviceType = DeviceType.MOBILE;
        u.usageStart = ZonedDateTime.of(2018, 1, 1, 15, 0, 0, 0, ZoneId.of("UTC")).toInstant();
        u.usageEnd = u.usageStart.plusSeconds(1);
        u.events = Arrays.asList(
                new Usage.Event()
                        .setName("event-a")
                        .setInstant(u.usageStart),
                new Usage.Event()
                        .setName("event-b")
                        .setInstant(u.usageStart)
        );
        u.deviceId = "Device 1";

        usageDAO.persistToDatabase(u, new Timer());

        // execute
        setUserContext(USER);

        // create events
        List<EventAPI.EventReportEntry> response = target().path("api/internal/events/report")
                .request()
                .post(Entity.json(
                        new EventAPI.EventReportRequest()
                                .setStart("2016-09-21")
                                .setEnd("2018-03-05")
                                .setInterval(ReportAPI.TimeInterval.YEAR)
                                .setEvents(Arrays.asList(
                                        new EventAPI.EventId()
                                                .setApp(APP_ID)
                                                .setEvent("event-a")
                                ))
                )).readEntity(new GenericType<List<EventAPI.EventReportEntry>>() {
                });

        assertThat(response.get(2).moment, equalTo("2018"));
        assertThat(response.get(2).events.get(0).count, equalTo(1L));
        assertThat(response.get(2).events.get(0).app, equalTo(APP_ID));
        assertThat(response.get(2).events.get(0).event, equalTo("event-a"));
    }

}