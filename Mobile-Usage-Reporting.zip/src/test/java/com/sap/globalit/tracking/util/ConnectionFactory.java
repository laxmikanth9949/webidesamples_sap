package com.sap.globalit.tracking.util;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.function.Supplier;

public class ConnectionFactory implements Supplier<Connection> {

    private DataSource ds;

    public ConnectionFactory(DataSource ds) {
        this.ds = ds;
    }

    @Override
    public Connection get() {
        try {
            return ds.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
