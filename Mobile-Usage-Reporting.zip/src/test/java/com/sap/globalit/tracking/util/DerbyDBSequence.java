package com.sap.globalit.tracking.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by D053397 on 20.02.2017.
 */
public class DerbyDBSequence extends DBSequence {
    public DerbyDBSequence(String name) {
        super(name);
    }

    @Override
    public long next(Connection connection) throws SQLException {
        try (PreparedStatement stmt = connection.prepareStatement(String.format("SELECT NEXT VALUE FOR %s FROM SYSIBM.SYSDUMMY1", name));
             ResultSet rs = stmt.executeQuery()) {
            rs.next();
            return rs.getLong(1);
        }
    }
}