package com.sap.globalit.tracking.util;

import java.sql.Timestamp;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.IsoFields;
import java.util.Date;

/**
 * Created by D053397 on 12.04.2017.
 */
public class DerbyDBFunction {
    public static int week(Timestamp timestamp) {
        return ZonedDateTime.ofInstant(timestamp.toInstant(), ZoneId.of("UTC"))
                .get(IsoFields.WEEK_OF_WEEK_BASED_YEAR);
    }

    public static int isoweek(Timestamp timestamp) {
        return ZonedDateTime.ofInstant(timestamp.toInstant(), ZoneId.of("UTC"))
                .get(IsoFields.WEEK_OF_WEEK_BASED_YEAR);
    }

    public static String to_char(Timestamp timestamp, String format) {
        ZonedDateTime time = ZonedDateTime.ofInstant(timestamp.toInstant(), ZoneId.of("UTC"));
        switch (format) {
            case "Q":
                return String.valueOf(time.get(IsoFields.QUARTER_OF_YEAR));
            case "YYYY/MM/DD":
                return time.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
        }
        throw new RuntimeException("IMPLEMENT for " + format);
    }

    public static double seconds_between(String start, Timestamp ende) {
        long epochStart = new Date(0).toInstant().getEpochSecond();
        long epochEnd = ende.toInstant().getEpochSecond();
        return epochEnd - epochStart;
    }
}
