package com.sap.globalit.tracking;

import com.sap.cloud.security.oauth2.OAuthAuthorization;
import com.sap.cloud.security.oauth2.OAuthSystemException;
import com.sap.core.jpaas.security.auth.api.AuthenticationService;
import com.sap.globalit.tracking.api.RealtimeSocketEndpoint;
import com.sap.globalit.tracking.filter.StaticFileFilter;
import com.sap.globalit.tracking.util.*;
import com.sap.it.mobile.hcp.service.email.HCPEmailProvider;
import com.sap.it.mobile.hcp.service.email.mock.HCPEmailProviderMock;
import com.sap.it.mobile.hcp.service.user.mock.UserMock;
import com.sap.it.mobile.hcp.service.user.mock.UserProviderMock;
import com.sap.security.auth.login.LoginContextFactory;
import com.sap.security.um.service.UserManagementAccessor;
import com.sap.security.um.user.PersistenceException;
import com.sap.security.um.user.User;
import com.sap.security.um.user.UserProvider;
import org.apache.catalina.Context;
import org.apache.catalina.servlets.DefaultServlet;
import org.apache.catalina.startup.Tomcat;
import org.apache.tomcat.websocket.server.WsSci;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.JerseyClient;
import org.glassfish.jersey.client.JerseyClientBuilder;
import org.glassfish.jersey.client.JerseyWebTarget;
import org.glassfish.jersey.internal.inject.AbstractBinder;
import org.glassfish.jersey.logging.LoggingFeature;
import org.glassfish.jersey.servlet.ServletContainer;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.mockito.Mockito;
import org.quartz.Scheduler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.bridge.SLF4JBridgeHandler;

import javax.persistence.EntityManagerFactory;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Supplier;

import static org.junit.Assert.fail;

/**
 * Created by D053397 on 04.11.2016.
 */
public abstract class StandaloneTest {

    private static final String OAUTH_ID_ATTRIBUTE = "com.sap.security.oauth2.clientId";
    private static final String OAUTH_INVALID_TOKEN_ATTRIBUTE = "com.sap.security.oauth2.valid_token";

    public static Logger log = LoggerFactory.getLogger(StaticFileFilter.class);

    public static UserMock ADMIN = new UserMock.Builder().setName("D000001").assignRole("superadmin").create();
    public static UserMock USER = new UserMock.Builder().setName("D053397").assignRole("user").create();
    public static UserMock ANONYMOUS = null;

    public static UserMock OAUTH_RELAY = new UserMock.Builder()
            .setName("oauth-relay")
            .setAttribute(OAUTH_ID_ATTRIBUTE, "oauth-relay")
            .assignScope("relay-bot")
            .create();
    public static UserMock OAUTH_HEARTBEAT = new UserMock.Builder()
            .setName("oauth-heartbeat")
            .setAttribute(OAUTH_ID_ATTRIBUTE, "oauth-heartbeat")
            .assignScope("heartbeat-default")
            .create();
    public static UserMock OAUTH_REALTIME = new UserMock.Builder()
            .setName("oauth-realtime")
            .setAttribute(OAUTH_ID_ATTRIBUTE, "oauth-realtime")
            .assignScope("realtime-consumer")
            .create();
    public static UserMock OAUTH_INVALID_TOKEN = new UserMock.Builder()
            .setName("oauth-invalid-token")
            .setAttribute(OAUTH_INVALID_TOKEN_ATTRIBUTE, "X")
            .create();

    @Rule
    public PersistenceRule persistence = new PersistenceRule();

    protected UserProviderMock userProviderMock = new UserProviderMock();
    protected HCPEmailProviderMock hcpEmailProviderMock = new HCPEmailProviderMock();
    private MockedOAuthAuthorization oauthSetting;
    private JerseyClient client;
    private Tomcat tomcat;

    protected Scheduler schedulerMock = Mockito.mock(Scheduler.class);
    protected Supplier<Connection> connectionFactory;
    protected int port = 0;

    protected DerbyDBSequence usage_sequence;
    protected DerbyDBSequence event_sequence;
    protected DerbyDBSequence userinfo_sequence;
    protected ServletContainer servlet;
    protected LandscapeHelper landscapeHelper = Mockito.mock(LandscapeHelper.class);
    private AuthenticationService authMock;

    @BeforeClass
    public static void classSetUp() throws Exception {
        // unified logging via SLF4J
        SLF4JBridgeHandler.removeHandlersForRootLogger();
        SLF4JBridgeHandler.install();
    }

    public static class UserProviderAccessor {

        UserProvider userProvider;

        public UserProviderAccessor(UserProvider userProvider) {
            this.userProvider = userProvider;
        }

        public UserProvider getUserProvider() {
            return userProvider;
        }
    }

    @Before
    public void setUp() throws Exception {
        connectionFactory = new ConnectionFactory(persistence.getDataSource());

        usage_sequence = new DerbyDBSequence("USAGE_SEQUENCE");
        event_sequence = new DerbyDBSequence("EVENT_SEQUENCE");
        userinfo_sequence = new DerbyDBSequence("USERINFO_SEQUENCE");

        userProviderMock.addUser(ADMIN);
        userProviderMock.addUser(USER);
        userProviderMock.addUser(OAUTH_RELAY);
        userProviderMock.addUser(OAUTH_HEARTBEAT);
        userProviderMock.addUser(OAUTH_REALTIME);
        userProviderMock.addUser(OAUTH_INVALID_TOKEN);

        client = JerseyClientBuilder.createClient();
        client.property(ClientProperties.FOLLOW_REDIRECTS, Boolean.FALSE);
        client.register(GsonJsonProvider.class);
        client.register(new LoggingFeature(java.util.logging.Logger.getLogger("Test")));

        tomcat = new Tomcat();
        tomcat.setBaseDir("target/tomcat");
        tomcat.setPort(port);

        // inject oauth
        oauthSetting = new MockedOAuthAuthorization(userProviderMock);
        Field oauthField = OAuthAuthorization.class.getDeclaredField("service");
        oauthField.setAccessible(true);
        oauthField.set(null, oauthSetting);

        Field authService = LoginContextFactory.class.getDeclaredField("authService");
        authService.setAccessible(true);
        authMock = Mockito.mock(AuthenticationService.class);
        authService.set(null, authMock);

        // inject UserProvider
        UserProviderAccessor accessor = new UserProviderAccessor(userProviderMock);
        Field userProviderField =
                UserManagementAccessor.class.getDeclaredField("userProviderAccessor");
        userProviderField.setAccessible(true);
        userProviderField.set(null, accessor);

        Context rootCTX = tomcat.addContext("", new File("src/main/webapp").getAbsolutePath());

        servlet = new ServletContainer(new JerseyApplication().register(new LocalInjectionBinder()));
        Tomcat.addServlet(rootCTX, "Jersey", servlet)
                .addMapping("/api/*");

        Tomcat.addServlet(rootCTX, "Default", new DefaultServlet())
                .addMapping("/*");

        HashSet<Class<?>> classes = new HashSet<>();
        classes.add(RealtimeSocketEndpoint.class);

        rootCTX.addApplicationListener(ServletConfigListener.class.getName());
        rootCTX.addServletContainerInitializer(new WsSci(), classes);

        tomcat.start();
    }

    @After
    public void tearDown() throws Exception {
        tomcat.stop();
        tomcat.destroy();
    }

    protected void configureBinding(AbstractBinder binder) {
        binder.bind(persistence.getEmf()).to(EntityManagerFactory.class).ranked(1);
        binder.bind(userProviderMock).to(UserProvider.class).ranked(1);
        binder.bind(hcpEmailProviderMock).to(HCPEmailProvider.class).ranked(1);
        binder.bindFactory(connectionFactory).to(Connection.class).ranked(1);
        binder.bind(schedulerMock).to(Scheduler.class).ranked(1);

        binder.bind(landscapeHelper).to(LandscapeHelper.class).ranked(1);

        binder.bind(oauthSetting).to(OAuthAuthorization.class).ranked(1);

        binder.bind(usage_sequence).to(DBSequence.class).named("USAGE_SEQUENCE").ranked(1);
        binder.bind(event_sequence).to(DBSequence.class).named("EVENT_SEQUENCE").ranked(1);
        binder.bind(userinfo_sequence).to(DBSequence.class).named("USERINFO_SEQUENCE").ranked(1);
    }

    public class LocalInjectionBinder extends AbstractBinder {
        @Override
        protected void configure() {
            configureBinding(this);
        }
    }

    public JerseyWebTarget target() {
        return client.target("http://" + getHostnameAndPort());
    }

    public String getHostnameAndPort() {
        return "localhost:" + tomcat.getConnector().getLocalPort();
    }

    public void setUserContext(User user) {
        try {
            if (user == OAUTH_REALTIME || user == OAUTH_RELAY || user == OAUTH_HEARTBEAT) {
                Mockito.reset(authMock);
                Mockito.when(authMock.createLoginContext("OAUTH")).thenReturn(Mockito.mock(LoginContext.class));
            } else if (user == null) {
                Mockito.reset(authMock);
                LoginContext failMock = Mockito.mock(LoginContext.class);
                Mockito.doThrow(LoginException.class).when(failMock).login();
                Mockito.when(authMock.createLoginContext(Mockito.any())).thenReturn(failMock);
            } else {
                Mockito.reset(authMock);
            }

            userProviderMock.setCurrentUser((user == null) ? null : user.getName());
        } catch (LoginException e) {
            throw new RuntimeException(e);
        }
    }

    public static class MockedOAuthAuthorization extends OAuthAuthorization {

        private final UserProviderMock userProviderMock;

        MockedOAuthAuthorization(UserProviderMock userProviderMock) {
            this.userProviderMock = userProviderMock;
        }

        private UserMock getCurrentUser() {
            try {
                return (UserMock) userProviderMock.getCurrentUser();
            } catch (PersistenceException e) {
                throw new RuntimeException(e);
            }
        }

        @Override
        public boolean isAuthorized(HttpServletRequest httpServletRequest) throws OAuthSystemException {
            return !getCurrentUser().listAttributes().contains(OAUTH_INVALID_TOKEN_ATTRIBUTE);
        }

        @Override
        public boolean isAuthorized(HttpServletRequest httpServletRequest, String s) throws OAuthSystemException {
            return getCurrentUser().getScopes().contains(s);
        }

        @Override
        public boolean isAuthorized(String s) throws OAuthSystemException {
            return getCurrentUser().getScopes().contains(s);
        }

        @Override
        public boolean isAuthorized(HttpServletRequest httpServletRequest, Set<String> set) throws OAuthSystemException {
            throw new RuntimeException();
        }

        @Override
        public boolean isAuthorized(Set<String> set) throws OAuthSystemException {
            throw new RuntimeException();
        }
    }

    protected void withConnection(ConnectionConsumer consumer) {
        try (Connection conn = connectionFactory.get()) {
            consumer.accept(conn);
        } catch (SQLException e) {
            fail(e.getMessage());
        }
    }

    @FunctionalInterface
    public interface ConnectionConsumer {
        void accept(Connection t) throws SQLException;
    }
}