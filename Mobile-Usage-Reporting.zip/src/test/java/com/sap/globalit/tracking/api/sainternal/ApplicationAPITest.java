package com.sap.globalit.tracking.api.sainternal;

import com.sap.globalit.tracking.StandaloneTest;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.model.ApplicationPlattform;
import org.junit.Test;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Response;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class ApplicationAPITest extends StandaloneTest {

    @Test
    public void renameApplication() {

        // prepare
        persistence.transactional(em -> {
            Application app = new Application("app");
            ApplicationPlattform plattform = new ApplicationPlattform(ApplicationPlattform.PlatformType.WEB, app);
            em.persist(app);
            em.persist(plattform);
        });
        setUserContext(ADMIN);
        Response response = target().path("api/sa-internal/application/app/name").request().post(Entity.json("New Name"));

        assertThat(response.getStatus(), is(204));

    }
}