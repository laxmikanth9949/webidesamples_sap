package com.sap.globalit.tracking.api.internal;

import com.sap.globalit.tracking.StandaloneTest;
import com.sap.globalit.tracking.dto.ApplicationDTO;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.model.authorization.SingleAppAuthorization;
import org.junit.Test;

import javax.ws.rs.core.GenericType;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

/**
 * Created by D053397 on 17.05.2017.
 */
public class RequestAuthorizationAPITest extends StandaloneTest {

    @Test
    public void appsWithoutAccessRequest() throws Exception {

        // prepare
        String APP_ID = "App";
        String APP_ID_2 = "App2";

        persistence.transactional(em -> {
            Application app = new Application(APP_ID);
            em.persist(app);

            em.persist(new SingleAppAuthorization(USER.getName(), SingleAppAuthorization.Status.PENDING, app));

            em.persist(new Application(APP_ID_2));
        });

        setUserContext(USER);

        // trigger view creation
        List<ApplicationDTO> response = target().path("api/internal/authorization/apps/" + USER.getName())
                .request()
                .get(new GenericType<List<ApplicationDTO>>() {
                });

        assertThat(response.size(), equalTo(1));
    }

}