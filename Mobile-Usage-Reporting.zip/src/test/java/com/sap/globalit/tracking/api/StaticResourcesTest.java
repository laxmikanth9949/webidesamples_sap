package com.sap.globalit.tracking.api;

import com.sap.globalit.tracking.StandaloneTest;
import org.apache.catalina.LifecycleException;
import org.glassfish.jersey.client.JerseyInvocation;
import org.junit.Test;

import javax.security.auth.login.LoginException;
import javax.servlet.ServletException;
import javax.ws.rs.core.Response;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.isEmptyString;

/**
 * Created by D053397 on 07.12.2016.
 */
public class StaticResourcesTest extends StandaloneTest {

    @Test
    public void shouldServeWebClient() throws ServletException, LifecycleException {

        verify200AndNotEmptyBody(
                target().path("web-client/MobileUsageReporting.js")
                        .request()
                        .get()
        );

        verify200AndNotEmptyBody(
                target().path("web-client/jquery.js")
                        .request()
                        .get()
        );

        verify200AndNotEmptyBody(
                target().path("web-client/web-tracking.js")
                        .request()
                        .get()
        );

        verify200AndNotEmptyBody(
                target().path("web-client/crypto-sha1.js")
                        .request()
                        .get()
        );
    }

    @Test
    public void shouldServeWebClient_LegacyURL() throws ServletException, LifecycleException {

        verifyRedirectTo(
                target().path("tracking/web-client/MobileUsageReporting.js")
                        .request()
                        .get(), "/web-client/MobileUsageReporting.js"
        );

        verifyRedirectTo(
                target().path("tracking/web-client/jquery.js")
                        .request()
                        .get(), "/web-client/jquery.js"
        );

        verifyRedirectTo(
                target().path("tracking/web-client/web-tracking.js")
                        .request()
                        .get(), "/web-client/web-tracking.js"
        );

        verifyRedirectTo(
                target().path("tracking/web-client/crypto-sha1.js")
                        .request()
                        .get(), "/web-client/crypto-sha1.js"
        );
    }


    @Test
    public void shouldSendRedirectToReportingUI() throws ServletException, LifecycleException {
        verifyRedirectTo(
                target().path("reporting")
                        .request()
                        .get(), "https://fiorilaunchpad.sap.com/sites?origin=fromLegacyUI#MU-Reporting"
        );

        verifyRedirectTo(
                target().path("request")
                        .request()
                        .get(), "https://fiorilaunchpad.sap.com/sites#MU-Reporting&/request"
        );

        verifyRedirectTo(
                target().path("request-access")
                        .request()
                        .get(), "https://fiorilaunchpad.sap.com/sites#MU-Reporting&/request"
        );
    }


    @Test
    public void shouldServeRealtime() throws NoSuchFieldException, IllegalAccessException, LoginException {

        setUserContext(USER);


        verify200AndNotEmptyBody(
                target().path("realtime")
                        .request()
                        .get()
        );
        verify200AndNotEmptyBody(
                target().path("realtime/map")
                        .request()
                        .get()
        );
        verify200AndNotEmptyBody(
                target().path("realtime/bubbles")
                        .request()
                        .get()
        );


        // verify resources
        verify200AndNotEmptyBody(target().path("css/main.css").request().get());
        verify200AndNotEmptyBody(target().path("img/SAP_grad_R_min.png").request().get());

        verify200AndNotEmptyBody(target().path("img/SAP_grad_R_min.png").request().get());
        verify200AndNotEmptyBody(target().path("js/jquery-jvectormap-1.2.2.min.js").request().get());
        verify200AndNotEmptyBody(target().path("js/jquery-jvectormap-world-mill-en.js").request().get());
        verify200AndNotEmptyBody(target().path("js/Backend.js").request().get());
        verify200AndNotEmptyBody(target().path("js/RealtimeSocket-1.js").request().get());
        verify200AndNotEmptyBody(target().path("js/realtime-heartbeat.js").request().get());
        verify200AndNotEmptyBody(target().path("js/main.js").request().get());
    }

    @Test
    public void shouldRequireAuthForRealtime() throws NoSuchFieldException, IllegalAccessException, LoginException {

        setUserContext(ANONYMOUS);

        verifyNotAccessableWithoutAuthenticatedUser(
                target().path("realtime")
                        .request()
        );
        verifyNotAccessableWithoutAuthenticatedUser(
                target().path("realtime/map")
                        .request()
        );
        verifyNotAccessableWithoutAuthenticatedUser(
                target().path("realtime/bubbles")
                        .request()
        );
    }


    @Test
    public void shouldServeRealtimeStaticWithOauth() throws NoSuchFieldException, IllegalAccessException, LoginException {

        setUserContext(ANONYMOUS);

        verify200AndNotEmptyBody(
                target().path("realtime/oauth")
                        .request()
                        .get()
        );
        verify200AndNotEmptyBody(
                target().path("realtime/map/oauth")
                        .request()
                        .get()
        );
        verify200AndNotEmptyBody(
                target().path("realtime/bubbles/oauth")
                        .request()
                        .get()
        );
    }

    @Test
    public void shouldRedirectFromLegacyRealtime() throws NoSuchFieldException, IllegalAccessException, LoginException {

        //authSetting.setAuthenticated();

        verifyRedirectTo(target().path("realtime.html")
                        .request()
                        .get(),
                "/realtime/bubbles");

        verifyRedirectTo(target().path("realtimeComp.html")
                        .request()
                        .get(),
                "/realtime");

        verifyRedirectTo(target().path("realtimeMap.html")
                        .request()
                        .get(),
                "/realtime/map");
    }

    static void verifyRedirectTo(Response response, String redirectTarget) {
        assertThat(response.getStatus(), is(301));
        assertThat(response.getHeaderString("Location"), is(redirectTarget));
    }

    static void verify200AndNotEmptyBody(Response response) {
        assertThat(response.getStatus(), is(200));

        String body = response.readEntity(String.class);
        log.debug("Response body is {}", body);

        assertThat(body, not(isEmptyString()));
    }

    private void verifyNotAccessableWithoutAuthenticatedUser(JerseyInvocation.Builder request) {
        //authSetting.setUnauthenticated();
        assertThat(request.get().getStatus(), is(403));
    }

}
