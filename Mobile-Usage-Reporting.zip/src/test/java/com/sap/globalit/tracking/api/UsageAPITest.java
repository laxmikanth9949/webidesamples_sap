package com.sap.globalit.tracking.api;

import com.sap.globalit.tracking.StandaloneTest;
import com.sap.globalit.tracking.dto.*;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.model.ApplicationPlattform;
import com.sap.security.um.service.UserManagementAccessor;
import org.apache.catalina.LifecycleException;
import org.junit.Test;

import javax.servlet.ServletException;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * Created by D053397 on 07.12.2016.
 */
public class UsageAPITest extends StandaloneTest {

    @Test
    public void simpleMacTest() {
        persistence.transactional(em -> {
            ApplicationPlattform plattform = new ApplicationPlattform(ApplicationPlattform.PlatformType.MAC, new Application("App"));
            em.persist(plattform.getApplication());
            em.persist(plattform);
        });

        ApplicationUsageReport report = new ApplicationUsageReport(new ApplicationVersionIdDTO("1.0.0", new ApplicationPlattformIdDTO(ApplicationPlattform.PlatformType.MAC, "App")), new TimeSpanDTO(1, 2));

        Response response = target().path("api/usage")
                .request()
                .post(Entity.json(report));

        assertThat(response.getStatus(), is(201));
    }

    @Test
    public void simpleTest() {
        // setup application
        persistence.transactional(em -> {
            ApplicationPlattform plattform = new ApplicationPlattform(ApplicationPlattform.PlatformType.WEB, new Application("App"));
            em.persist(plattform.getApplication());
            em.persist(plattform);
        });

        // upload bulk

        ApplicationUsageReport report = new ApplicationUsageReport(new ApplicationVersionIdDTO("1.0.0", new ApplicationPlattformIdDTO(ApplicationPlattform.PlatformType.WEB, "App")), new TimeSpanDTO(1, 2));
        report.events.add(new ApplicationUsageReport.EventReportDTO("EVENT-1", 1));
        report.events.add(new ApplicationUsageReport.EventReportDTO("EVENT-2", 2));

        Response response = target().path("api/usage")
                .request()
                .post(Entity.json(report));

        assertThat(response.getStatus(), is(201));

        UsageCreationResponse usageCreationResponse = response.readEntity(UsageCreationResponse.class);
        assertThat(usageCreationResponse.usageId, is(1L));
        assertThat(usageCreationResponse.error, is(nullValue()));

        // add new event
        Response responseEvent = target().path("api/usage/addEvent/" + usageCreationResponse.usageId)
                .request()
                .post(Entity.json(new ApplicationUsageReport.EventReportDTO("EVENT-3", 3, "App")));

        assertThat(responseEvent.getStatus(), is(201));

        // associate user
        Response responseUser = target().path("api/usage/addUser/" + usageCreationResponse.usageId)
                .request()
                .post(Entity.text("D053397"));

        assertThat(responseUser.getStatus(), is(201));
    }

    @Test
    public void invalidJSON() throws ServletException, LifecycleException {
        setUserContext(USER);
        Response response = target().path("api/usage")
                .request()
                .post(Entity.entity("{'version':{'versionId':'$versionId','plattform':{'id':'$platformId','application':'$application'}},'timeSpan':{'spanStart':$startTime,'spanEnd':$endTime},'events':[$events],'deviceInformation':{'deviceId':'$deviceId','screenSize': $screenSize,'modelName':'$modelName','countryCode':'$countryCode','operatingSystem':'$operatingSystem'}}", MediaType.APPLICATION_JSON));

        assertThat(response.getStatus(), is(400));
    }

    @Test
    public void ignore_null_events_in_events_array() throws ServletException, LifecycleException {

        persistence.transactional(em -> {
            ApplicationPlattform plattform = new ApplicationPlattform(ApplicationPlattform.PlatformType.WEB, new Application("SSF P2P"));
            em.persist(plattform.getApplication());
            em.persist(plattform);
        });

        Response response = target().path("api/usage")
                .request()
                .post(Entity.entity("{'version':{ 'versionId':'1.0', 'plattform':{'id':'WEB','application':'SSF P2P'} }, 'events':[,{'eventId':'InboxSearch','dateTime':1483601688029},{'eventId':'InboxSearch','dateTime':1483601688754}], 'timeSpan':{ 'spanStart':1483601687550,'spanEnd':1483601689754}, 'deviceInformation':{'deviceId':'0C1501E481C65B0B2F183EFC95075A3C', 'modelName':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36', 'countryCode':'in'}}", MediaType.APPLICATION_JSON));

        assertThat(response.getStatus(), is(201));
    }

    // TODO add broadcasting test

    @Test
    public void bulkUpload() {

        // setup application
        persistence.transactional(em -> {
            ApplicationPlattform plattform = new ApplicationPlattform(ApplicationPlattform.PlatformType.WEB, new Application("App"));
            em.persist(plattform.getApplication());
            em.persist(plattform);
        });

        // upload bulk
        List<ApplicationUsageReport> reports = Arrays.asList(
                new ApplicationUsageReport(new ApplicationVersionIdDTO("1.0.0", new ApplicationPlattformIdDTO(ApplicationPlattform.PlatformType.WEB, "App")), new TimeSpanDTO(1, 2)),
                new ApplicationUsageReport(new ApplicationVersionIdDTO("1.0.0", new ApplicationPlattformIdDTO(ApplicationPlattform.PlatformType.WEB, "App")), new TimeSpanDTO(2, 3))
        );

        Response response = target().path("api/usage/bulk")
                .request()
                .post(Entity.json(reports));

        assertThat(response.getStatus(), is(207));


        withConnection((conn) -> {
            try (ResultSet rs = conn.prepareStatement("SELECT count(*) FROM USAGE").executeQuery()) {
                rs.next();
                long count = rs.getLong(1);
                assertThat(count, is(2L));
            }
        });

    }


    @Test
    public void bulkUpload_fail_subset() {

        // setup application
        persistence.transactional(em -> {
            ApplicationPlattform plattform = new ApplicationPlattform(ApplicationPlattform.PlatformType.WEB, new Application("App"));
            em.persist(plattform.getApplication());
            em.persist(plattform);
        });

        // upload bulk

        List<ApplicationUsageReport> reports = Arrays.asList(
                new ApplicationUsageReport(new ApplicationVersionIdDTO("1.0.0", new ApplicationPlattformIdDTO(ApplicationPlattform.PlatformType.WEB, "App")), new TimeSpanDTO(1, 2)),
                new ApplicationUsageReport(new ApplicationVersionIdDTO("1.0.0", new ApplicationPlattformIdDTO(ApplicationPlattform.PlatformType.WEB, "INVALID_APP")), new TimeSpanDTO(2, 3))
        );

        Response response = target().path("api/usage/bulk")
                .request()
                .post(Entity.json(reports));

        assertThat(response.getStatus(), is(207));

        BulkUsageCreationResponse bulkUsageCreationResponse = response.readEntity(BulkUsageCreationResponse.class);
        assertThat(bulkUsageCreationResponse.successful, is(1L));
        assertThat(bulkUsageCreationResponse.error, is(1L));

        withConnection((conn) -> {
            try (ResultSet rs = conn.prepareStatement("SELECT count(*) FROM USAGE").executeQuery()) {
                rs.next();
                long count = rs.getLong(1);
                assertThat(count, is(1L));
            }
        });
    }

    @Test
    public void testCORS() {

        setUserContext(ANONYMOUS);

        // otherwise e.g. Access-Control-Request-Method cannot be set
        System.setProperty("sun.net.http.allowRestrictedHeaders", "true");

        Response response = target().path("api/usage")
                .request()
                .header("Access-Control-Request-Headers", "content-type")
                .header("Access-Control-Request-Method", "POST")
                .options();

        assertThat(response.getStatus(), is(200));
        assertThat(response.getHeaderString("Access-Control-Allow-Headers"), is("content-type"));
        assertThat(response.getHeaderString("Access-Control-Allow-Methods"), is("POST"));
        assertThat(response.getHeaderString("Access-Control-Allow-Origin"), is("*"));

        // addEvent

        Response eventResponse = target().path("api/usage/addEvent/1")
                .request()
                .header("Access-Control-Request-Headers", "content-type")
                .header("Access-Control-Request-Method", "POST")
                .options();

        assertThat(eventResponse.getStatus(), is(200));
        assertThat(eventResponse.getHeaderString("Access-Control-Allow-Headers"), is("content-type"));
        assertThat(eventResponse.getHeaderString("Access-Control-Allow-Methods"), is("POST"));
        assertThat(eventResponse.getHeaderString("Access-Control-Allow-Origin"), is("*"));
    }

}