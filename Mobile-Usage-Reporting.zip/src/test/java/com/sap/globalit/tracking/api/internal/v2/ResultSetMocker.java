package com.sap.globalit.tracking.api.internal.v2;

import static org.mockito.Mockito.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

public class ResultSetMocker {

	public static class PositionHolder {
		int value = -1;
	}

	public static ResultSet mock(final List<Object[]> table, String[] columns) throws SQLException {
		ResultSet mockResult = org.mockito.Mockito.mock(ResultSet.class);
		final PositionHolder position = new PositionHolder();

		when(mockResult.next()).then(new Answer<Boolean>() {

			@Override
			public Boolean answer(InvocationOnMock invocation) throws Throwable {
				return ++position.value < table.size();
			}
		});

		when(mockResult.previous()).then(new Answer<Boolean>() {

			@Override
			public Boolean answer(InvocationOnMock invocation) throws Throwable {
				throw new RuntimeException("The operation is not allowed for result set type FORWARD_ONLY");
			}
		});

		when(mockResult.first()).then(new Answer<Boolean>() {

			@Override
			public Boolean answer(InvocationOnMock invocation) throws Throwable {
				throw new RuntimeException("The operation is not allowed for result set type FORWARD_ONLY");
			}
		});

		while (mockResult.next()) {
			Object[] row = table.get(position.value);

			for (int i = 1; i < row.length + 1; i++) {
				final Object object = row[i - 1];
				final int popo = i - 1;

				if (object instanceof String) {
					when(mockResult.getString(i)).then(answer(table, position, popo));
					when(mockResult.getString(columns[i - 1])).then(answer(table, position, popo));
				} else if (object instanceof Integer) {
					when(mockResult.getInt(i)).then(answer(table, position, popo));
					when(mockResult.getInt(columns[i - 1])).then(answer(table, position, popo));
				} else if (object instanceof Long) {
					when(mockResult.getLong(i)).then(answer(table, position, popo));
					when(mockResult.getLong(columns[i - 1])).then(answer(table, position, popo));
				} else {
					when(mockResult.getObject(i)).thenReturn(answer(table, position, popo));
					when(mockResult.getObject(columns[i - 1])).then(answer(table, position, popo));
				}

			}
		}
		position.value = -1;

		return mockResult;
	}

	private static <T> Answer<T> answer(final List<Object[]> table, final PositionHolder position, final int pos2) {
		return new Answer<T>() {
			@Override
			public T answer(InvocationOnMock invocation) throws Throwable {
				return (T) table.get(position.value)[pos2];
			}
		};
	}
}