package com.sap.globalit.tracking.util;

import org.apache.derby.jdbc.EmbeddedDataSource;
import org.eclipse.persistence.config.PersistenceUnitProperties;
import org.junit.rules.ExternalResource;
import org.junit.runner.Description;
import org.junit.runners.model.Statement;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

public class PersistenceRule extends ExternalResource {
    private String name;
    private EntityManagerFactory emf;
    private EmbeddedDataSource dataSource;

    public Statement apply(Statement base, Description description) {
        name = description.getDisplayName();

        dataSource = new org.apache.derby.jdbc.EmbeddedDataSource();
        dataSource.setCreateDatabase("create");
        dataSource.setDatabaseName("memory:" + name);

        return super.apply(base, description);
    }

    @Override
    protected void before() throws Throwable {
        super.before();

        Map<Object, Object> properties = new HashMap<>();
        properties.put(PersistenceUnitProperties.NON_JTA_DATASOURCE, dataSource);
        properties.put(PersistenceUnitProperties.WEAVING_INTERNAL, "false");
        properties.put("eclipselink.target-database", "DERBY");

        emf = Persistence.createEntityManagerFactory("default", properties);
    }

    @Override
    protected void after() {
        super.after();
        emf.close();
    }

    public EntityManagerFactory getEmf() {
        return emf;
    }

    public EntityManager createEm() {
        return getEmf().createEntityManager();
    }

    public void transactional(Consumer<EntityManager> consumer) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            consumer.accept(em);
            tx.commit();
        } catch (RuntimeException e) {
            if (tx != null && tx.isActive())
                tx.rollback();
            throw e;
        } finally {
            em.close();
        }
    }

    public DataSource getDataSource() {
        return dataSource;
    }
}