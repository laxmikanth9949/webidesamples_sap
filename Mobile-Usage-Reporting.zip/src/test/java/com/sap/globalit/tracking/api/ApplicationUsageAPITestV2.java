package com.sap.globalit.tracking.api;

import com.sap.globalit.tracking.StandaloneTest;
import com.sap.globalit.tracking.dto.*;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.model.ApplicationPlattform;
import org.junit.Test;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import java.sql.ResultSet;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.hasKey;
import static org.junit.Assert.assertThat;

/**
 * Created by D053397 on 02.11.2016.
 */
public class ApplicationUsageAPITestV2 extends StandaloneTest {

    @Test
    public void createUsage_simple() {

        // prepare
        persistence.transactional(em -> {
            Application app = new Application("App");
            ApplicationPlattform plattform = new ApplicationPlattform(ApplicationPlattform.PlatformType.WEB, app);
            em.persist(app);
            em.persist(plattform);
        });

        ApplicationUsageReport report = new ApplicationUsageReport(new ApplicationVersionIdDTO("1.0.0", new ApplicationPlattformIdDTO(ApplicationPlattform.PlatformType.WEB, "App")), new TimeSpanDTO(1, 2));

        // execute
        Response response = target().path("api/usage").request().post(Entity.json(report));

        // verify
        assertThat(response.getStatus(), is(201));

        Map<String, Long> responseEntity = response.readEntity(new GenericType<Map<String, Long>>() {
        });

        assertThat(responseEntity, hasKey("usageId"));
    }

    @Test
    public void createUsage_withUser() {

        // prepare
        persistence.transactional(em -> {
            Application app = new Application("App");
            ApplicationPlattform plattform = new ApplicationPlattform(ApplicationPlattform.PlatformType.WEB, app);
            em.persist(app);
            em.persist(plattform);
        });

        ApplicationUsageReport report = new ApplicationUsageReport(new ApplicationVersionIdDTO("1.0.0", new ApplicationPlattformIdDTO(ApplicationPlattform.PlatformType.WEB, "App")), new TimeSpanDTO(1, 2));
        report.userInformation = new UserInformationDTO();
        report.userInformation.id = "D053397";

        // execute
        Response response = target().path("api/usage").request().post(Entity.json(report));

        // verify
        assertThat(response.getStatus(), is(201));

        Map<String, Long> responseEntity = response.readEntity(new GenericType<Map<String, Long>>() {
        });

        assertThat(responseEntity, hasKey("usageId"));

        withConnection((c) -> {
            try (ResultSet rs = c.prepareStatement("SELECT count(*) FROM UserInformation").executeQuery()) {
                rs.next();
                long count = rs.getLong(1);
                assertThat(count, is(1L));
            }
        });

    }


    @Test
    public void createUsage_missingPlatform() {

        // prepare

        persistence.transactional(em -> {
            Application app = new Application("App");
            em.persist(app);
        });

        ApplicationUsageReport report = new ApplicationUsageReport(new ApplicationVersionIdDTO("1.0.0", new ApplicationPlattformIdDTO(ApplicationPlattform.PlatformType.WEB, "App")), new TimeSpanDTO(1, 2));

        // execute
        Response response = target().path("api/usage").request().post(Entity.json(report));

        // verify
        assertThat(response.getStatus(), is(400));
    }

}