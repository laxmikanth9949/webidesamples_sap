package com.sap.globalit.tracking.scheduling;

import com.sap.globalit.tracking.StandaloneTest;
import com.sap.globalit.tracking.dao.UsageDAO;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.model.ApplicationPlattform;
import com.sap.globalit.tracking.model.DeviceType;
import com.sap.globalit.tracking.model.Usage;
import com.sap.globalit.tracking.model.authorization.SingleAppAuthorization;
import com.sap.globalit.tracking.util.Timer;
import org.glassfish.jersey.internal.inject.InjectionManager;
import org.junit.Test;
import org.mockito.Mockito;
import org.quartz.JobExecutionException;

import java.sql.SQLException;
import java.time.ZonedDateTime;
import java.util.Collections;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

/**
 * Created by D053397 on 25.04.2017.
 */
public class MonthlyUpdateJobTest extends StandaloneTest {

    @Test
    public void simpleTest() throws JobExecutionException, SQLException {

        Mockito.when(landscapeHelper.isProductiveLandscape()).thenReturn(true);

        // prepare
        String APP_ID = "App";

        persistence.transactional(em -> {
            Application app = new Application(APP_ID);
            em.persist(app);
            ApplicationPlattform plattform = new ApplicationPlattform(ApplicationPlattform.PlatformType.WEB, app);
            em.persist(plattform);

            SingleAppAuthorization auth = new SingleAppAuthorization("D053397", app, "");
            auth.setStatus(SingleAppAuthorization.Status.APPROVED);
            em.persist(auth);
        });

        // trigger view creation
        target().path("api/status")
                .request()
                .get();

        // create usage
        UsageDAO usageDAO = new UsageDAO();
        usageDAO.setup(() -> connectionFactory.get(), usage_sequence, event_sequence);

        // TODO factory/util to create usage
        Usage u = new Usage();
        u.applicationId = APP_ID;
        u.platformId = ApplicationPlattform.PlatformType.WEB;
        u.deviceType = DeviceType.MOBILE;
        u.usageStart = ZonedDateTime.now().minusMonths(1).toInstant();
        u.usageEnd = u.usageStart.plusSeconds(1);
        u.events = Collections.emptyList();
        u.deviceId = "Device 1";

        usageDAO.persistToDatabase(u, new Timer());


        InjectionManager sl = servlet.getApplicationHandler().getInjectionManager();

        MonthlyUpdateJob service = sl.createAndInitialize(MonthlyUpdateJob.class);
        service.execute(null);

        // verify mail generated
        assertThat(hcpEmailProviderMock.getOutbox().size(), equalTo(1));

        hcpEmailProviderMock.getOutbox().forEach(i -> {
            System.out.println(i);
        });
    }

}