package com.sap.globalit.tracking;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

/**
 * Created by D053397 on 02.01.2017.
 */
public class RunStandalone extends StandaloneTest {

    @Override
    @Before
    public void setUp() throws Exception {
        port = 8080;
        super.setUp();
    }

    @Test
    @Ignore
    public void doIt() throws InterruptedException {
        setUserContext(USER);
        Thread.sleep(99999999999L);
    }
}
