



package com.sap.globalit.tracking.api;

import com.sap.globalit.tracking.StandaloneTest;
import org.apache.catalina.LifecycleException;
import org.junit.Test;

import javax.servlet.ServletException;
import javax.ws.rs.core.Response;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * Created by D053397 on 07.12.2016.
 */
public class OauthRestrictionTest extends StandaloneTest {

    @Test
    public void shouldRequireValidToken() throws ServletException, LifecycleException {
        setUserContext(OAUTH_HEARTBEAT);

        Response response = target().path("api/internal/heartbeat/application")
                .request()
                .header("Authorization", "Bearer VALID")
                .get();

        assertThat(response.getStatus(), is(200));
    }

    @Test
    public void shouldRejectInvalidToken() throws ServletException, LifecycleException {

        setUserContext(OAUTH_INVALID_TOKEN);

        Response response = target().path("api/internal/heartbeat/application")
                .request()
                .header("Authorization", "Bearer NON-SENSE")
                .get();

        assertThat(response.getStatus(), is(404));
    }

    // Realtime Dashboard oAuth
    @Test
    public void shouldRequireValidToken_status() throws ServletException, LifecycleException {

        setUserContext(OAUTH_HEARTBEAT);

        Response response = target().path("api/internal/status")
                .request()
                .header("Authorization", "Bearer VALID")
                .get();

        assertThat(response.getStatus(), is(200));
    }

}
