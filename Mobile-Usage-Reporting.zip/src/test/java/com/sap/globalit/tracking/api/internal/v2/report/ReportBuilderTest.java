package com.sap.globalit.tracking.api.internal.v2.report;

import com.sap.globalit.tracking.api.internal.v2.ResultSetMocker;
import com.sap.globalit.tracking.api.internal.v2.SQLDAO;
import com.sap.globalit.tracking.model.reporting.Table;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.stubbing.Answer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import java.util.Arrays;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;

public class ReportBuilderTest {

    @Test
    public void getTable_Events_ByGCORegion() throws SQLException {

        Connection mock = Mockito.mock(Connection.class);

        ReportBuilder reportBuilder = new ReportBuilder();
        reportBuilder.dao = new SQLDAO();
        reportBuilder.dao.setConnectionProvider(() -> mock);

        PreparedStatement statement = Mockito.mock(PreparedStatement.class);

        ResultSet res1 = ResultSetMocker.mock(Arrays.<Object[]>asList(new Object[]{"Event A", "MEE", 10L}), new String[]{"DIMENSION", "MEASURE_COL", "MEASURE"});
        ResultSet res2 = ResultSetMocker.mock(Arrays.<Object[]>asList(new Object[]{"Event A", "Germany", 5L}), new String[]{"DIMENSION", "MEASURE_COL", "MEASURE"});
        ResultSet res3 = ResultSetMocker.mock(Arrays.<Object[]>asList(new Object[]{"Event A", "All", 10L}), new String[]{"DIMENSION", "MEASURE_COL", "MEASURE"});
        Mockito.when(statement.executeQuery())
                .thenReturn(res1)
                .thenReturn(res2)
                .thenReturn(res3);

        Mockito.when(mock.prepareStatement(Mockito.anyString())).thenAnswer((Answer<PreparedStatement>) invocationOnMock -> {
            String sql = (String) invocationOnMock.getArguments()[0];
            //System.out.println(sql);
            return statement;
        });

        Table table = reportBuilder
                .getTable_Events_ByGCORegion(ZonedDateTime.now(), ZonedDateTime.now(), Arrays.asList("App A"));

        assertThat(table.getColumns(), hasSize(4));

    }
}