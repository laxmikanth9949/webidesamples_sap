package com.sap.globalit.tracking.util;

import com.sap.globalit.tracking.model.reporting.Chart;
import com.sap.globalit.tracking.model.reporting.Dimension;
import com.sap.globalit.tracking.model.reporting.Measure;
import com.sap.globalit.tracking.model.reporting.Table;
import org.junit.Test;

import java.util.Arrays;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

public class CSVWriterTest {

    @Test
    public void getCSV() {

        Table input = new Table();
        input.getColumns().add(new Dimension("App"));
        input.getColumns().add(new Measure("01.01.2010"));
        input.getColumns().add(new Measure("02.01.2010"));

        input.setTableData(Arrays.asList(
                new Chart.ChartData()
                        .with("App", "360 Customer View")
                        .with("01.01.2010", 1L)
                        .with("02.01.2010", 2L)
                ,
                new Chart.ChartData()
                        .with("App", "EasyConnect")
                        .with("01.01.2010", 10L)
                        .with("02.01.2010", 20L)
        ));

        CSVWriter.CSVDocument csvDocument = CSVWriter.generateCSV(input);
        assertThat(csvDocument.getRow(0), is("App;01.01.2010;02.01.2010;"));
        assertThat(csvDocument.getRow(1), is("360 Customer View;1;2;"));
        assertThat(csvDocument.getRow(2), is("EasyConnect;10;20;"));

        String content = csvDocument.getContent();

        assertThat(content.startsWith("sep=;"), is(true));
    }

}
