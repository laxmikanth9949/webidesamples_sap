package com.sap.globalit.tracking.api;

import com.sap.globalit.tracking.StandaloneTest;
import org.apache.catalina.LifecycleException;
import org.junit.Test;

import javax.servlet.ServletException;
import javax.ws.rs.core.Response;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * Created by D053397 on 07.12.2016.
 */
public class AdminRestrictionTest extends StandaloneTest {

    @Test
    public void shouldRequireAdmin() throws ServletException, LifecycleException {

        setUserContext(ADMIN);

        Response response = target().path("api/sa-internal/status")
                .request()
                .get();

        assertThat(response.getStatus(), is(200));

        setUserContext(USER);

        Response responseUser = target().path("api/sa-internal/status")
                .request()
                .get();
        assertThat(responseUser.getStatus(), is(404));
    }

}