package com.sap.globalit.tracking.api.internal;

import com.sap.globalit.tracking.StandaloneTest;
import com.sap.globalit.tracking.model.Application;
import org.junit.Test;

import javax.ws.rs.core.Response;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Created by D053397 on 04.11.2016.
 */
public class HeartbeatAPITest extends StandaloneTest {

    @Test
    public void getStatistics_simple() {

        // prepare
        String APP_ID = "App";

        persistence.transactional(em -> {
            Application app = new Application(APP_ID);
            em.persist(app);
        });

        // execute
        setUserContext(OAUTH_HEARTBEAT);

        Response response = target()
                .path("api/internal/heartbeat/application")
                .path(APP_ID)
                .path("usage")
                .request()
                .header("Authorization", "Bearer VALID")
                .get();

        // verify
        assertThat(response.getStatus(), is(200));


        HeartbeatAPI.ApplicationMeasure responseEntity = response.readEntity(HeartbeatAPI.ApplicationMeasure.class);


        assertThat(responseEntity.displayName, is("App"));
    }


}