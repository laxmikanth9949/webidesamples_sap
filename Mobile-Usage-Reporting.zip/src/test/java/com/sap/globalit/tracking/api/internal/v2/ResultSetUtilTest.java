package com.sap.globalit.tracking.api.internal.v2;

import com.sap.globalit.tracking.api.internal.v2.report.ResultSetUtil;
import com.sap.globalit.tracking.api.internal.v2.report.TimeHelper;
import com.sap.globalit.tracking.model.reporting.Chart;
import com.sap.globalit.tracking.model.reporting.Table;
import org.junit.Test;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.sap.globalit.tracking.api.internal.v2.report.ResultSetUtil.*;
import static com.sap.globalit.tracking.util.ChartUtil.cleanStringForReferenceInJS;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasEntry;

@SuppressWarnings("rawtypes")
public class ResultSetUtilTest {

    public static final ZoneId UTC = ZoneId.of("UTC");

    @Test
    public void test_Top10_Charts() throws SQLException {
        List<Object[]> data = new ArrayList<>();
        data.add(new Object[]{"EasyConnect", 500L});
        data.add(new Object[]{"Relay", 400L});

        ResultSet resultSet = ResultSetMocker.mock(data, new String[]{"DIMENSION", "MEASURE"});

        Chart chart = toSingleValueChart(resultSet, Arrays.asList("DIMENSION"), Arrays.asList("Dimension"), Arrays.asList("MEASURE"), Arrays.asList("Measure"));

        assertThat(chart.getDimensions().size(), is(1));
        assertThat(chart.getDimensions().get(0).getKey(), is(cleanStringForReferenceInJS("Dimension")));

        assertThat(chart.getMeasures().size(), is(1));
        assertThat(chart.getMeasures().get(0).getKey(), is(cleanStringForReferenceInJS("Measure")));

        assertThat(chart.getChartData().size(), is(2));

        assertThat(chart.getChartData().get(0), hasEntry(cleanStringForReferenceInJS("Dimension"), "EasyConnect"));
        assertThat(chart.getChartData().get(0), hasEntry(cleanStringForReferenceInJS("Measure"), 500L));

        assertThat(chart.getChartData().get(1), hasEntry(cleanStringForReferenceInJS("Dimension"), "Relay"));
        assertThat(chart.getChartData().get(1), hasEntry(cleanStringForReferenceInJS("Measure"), 400L));
    }

    @Test
    public void test_Location_Report() throws SQLException {
        List<Object[]> data = new ArrayList<>();
        data.add(new Object[]{"EasyConnect", "AMER", "AR", 500L, 50L});
        data.add(new Object[]{"EasyConnect", "AMER", "BR", 400L, 40L});

        ResultSet resultSet = ResultSetMocker.mock(data, new String[]{"APPLICATION_ID", "REGION", "DEVICE_COUNTRY", "USAGE", "ACTIVE_DEVICES"});

        // todo rename to "simple table"
        Table table = toSingleValueTable(resultSet, Arrays.asList("APPLICATION_ID", "REGION", "DEVICE_COUNTRY"), Arrays.asList("App", "Region", "Country"), Arrays.asList("USAGE", "ACTIVE_DEVICES"), Arrays.asList("Usages", "Active Devices"));

        assertThat(table.getColumns().size(), is(5));
        //assertThat(table.getDimensions().get(0).getKey(), is("Dimension")); // TODO

        //assertThat(table.getMeasures().size(), is(2));
        // TODO assertThat(table.getMeasures().get(0).getKey(), is("Region"));
        // TODO assertThat(table.getMeasures().get(1).getKey(), is("Country"));
        // TODO assertThat(table.getMeasures().get(2).getKey(), is("Usages"));
        // TODO assertThat(table.getMeasures().get(3).getKey(), is("Active Devices"));

        assertThat(table.getTableData().size(), is(2));

        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("App"), "EasyConnect"));
        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("Region"), "AMER"));
        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("Country"), "AR"));
        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("Usages"), 500L));
        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("Active Devices"), 50L));

        assertThat(table.getTableData().get(1), hasEntry(cleanStringForReferenceInJS("App"), "EasyConnect"));
        assertThat(table.getTableData().get(1), hasEntry(cleanStringForReferenceInJS("Region"), "AMER"));
        assertThat(table.getTableData().get(1), hasEntry(cleanStringForReferenceInJS("Country"), "BR"));
        assertThat(table.getTableData().get(1), hasEntry(cleanStringForReferenceInJS("Usages"), 400L));
        assertThat(table.getTableData().get(1), hasEntry(cleanStringForReferenceInJS("Active Devices"), 40L));
    }

    @Test
    public void testSingleApp_Month_TimeComplete_Table() throws SQLException {
        List<Object[]> data = new ArrayList<>();
        data.add(new Object[]{"EasyConnect", 500L, 2016, 1});
        data.add(new Object[]{"EasyConnect", 400L, 2016, 2});
        data.add(new Object[]{"EasyConnect", 300L, 2016, 3});

        ResultSet resultSet = ResultSetMocker.mock(data, new String[]{"DIMENSION", "MEASURE", "YEAR", "MONTH"});

        Table table = toTable(resultSet, new TimeHelper.MonthTimeHelper(), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1451606400000L), UTC), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1459468799999L), UTC), "App");

        assertThat(table.getColumns().size(), is(4));
        assertThat(table.getColumn(0).getName(), is("App"));
        assertThat(table.getColumn(0).getType(), is("Dimension"));

        assertThat(table.getColumn(1).getName(), is("01/2016"));
        assertThat(table.getColumn(1).getType(), is("Measure"));

        assertThat(table.getColumn(2).getName(), is("02/2016"));
        assertThat(table.getColumn(2).getType(), is("Measure"));

        assertThat(table.getColumn(3).getName(), is("03/2016"));
        assertThat(table.getColumn(3).getType(), is("Measure"));

        assertThat(table.getTableData().size(), is(1));

        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("App"), "EasyConnect"));
        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("01/2016"), 500L));
        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("02/2016"), 400L));
        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("03/2016"), 300L));
    }

    @Test
    public void testSingleApp_Month_TimeComplete_Table_MissingValue() throws SQLException {
        List<Object[]> data = new ArrayList<>();
        data.add(new Object[]{"EasyConnect", 500L, 2016, 1});
        data.add(new Object[]{"EasyConnect", 400L, 2016, 2});
        data.add(new Object[]{"EasyConnect", 300L, 2016, 3});

        ResultSet resultSet = ResultSetMocker.mock(data, new String[]{"DIMENSION", "MEASURE", "YEAR", "MONTH"});

        Table table = toTable(resultSet, new TimeHelper.MonthTimeHelper(), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1451606400000L), UTC), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1459468799999L), UTC), "App");

        assertThat(table.getColumns().size(), is(4));
        assertThat(table.getColumn(0).getName(), is("App"));
        assertThat(table.getColumn(0).getType(), is("Dimension"));

        assertThat(table.getColumn(1).getName(), is("01/2016"));
        assertThat(table.getColumn(1).getType(), is("Measure"));

        assertThat(table.getColumn(2).getName(), is("02/2016"));
        assertThat(table.getColumn(2).getType(), is("Measure"));

        assertThat(table.getColumn(3).getName(), is("03/2016"));
        assertThat(table.getColumn(3).getType(), is("Measure"));

        assertThat(table.getTableData().size(), is(1));

        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("App"), "EasyConnect"));
        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("01/2016"), 500L));
        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("02/2016"), 400L));
        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("03/2016"), 300L));
    }

    @Test
    public void testGCO_REGION_TABLES() throws SQLException {

        // extract columns from resultset

        List<Object[]> data = new ArrayList<>();
        data.add(new Object[]{"EasyConnect", "India", 500L});
        data.add(new Object[]{"EasyConnect", "Korea", 400L});
        data.add(new Object[]{"EasyConnect", "Africa", 300L});

        ResultSet resultSet = ResultSetMocker.mock(data, new String[]{"DIMENSION", "MEASURE_COL", "MEASURE"});

        Table table = ResultSetUtil.toTable_MeasureFromColumn(resultSet, "App");

        assertThat(table.getColumns().size(), is(4));
        assertThat(table.getColumn(0).getName(), is("App"));
        assertThat(table.getColumn(0).getType(), is("Dimension"));

        assertThat(table.getColumn(1).getName(), is("India"));
        assertThat(table.getColumn(1).getType(), is("Measure"));

        assertThat(table.getColumn(2).getName(), is("Korea"));
        assertThat(table.getColumn(2).getType(), is("Measure"));

        assertThat(table.getColumn(3).getName(), is("Africa"));
        assertThat(table.getColumn(3).getType(), is("Measure"));

        assertThat(table.getTableData().size(), is(1));

        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("App"), "EasyConnect"));
        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("India"), 500L));
        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("Korea"), 400L));
        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("Africa"), 300L));
    }

    @Test
    public void testSingleApp_Month_TimeComplete_Table_ignoreEmptyOrNullRows() throws SQLException {
        List<Object[]> data = new ArrayList<>();
        data.add(new Object[]{"EasyConnect", 500L, 2016, 1});
        data.add(new Object[]{"", 500L, 2016, 1});
        data.add(new Object[]{null, 500L, 2016, 1});

        ResultSet resultSet = ResultSetMocker.mock(data, new String[]{"DIMENSION", "MEASURE", "YEAR", "MONTH"});

        Table table = toTable(resultSet, new TimeHelper.MonthTimeHelper(), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1451606400000L), UTC), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1459468799999L), UTC), "App");

        assertThat(table.getColumns().size(), is(4));
        assertThat(table.getColumn(0).getName(), is("App"));
        assertThat(table.getColumn(0).getType(), is("Dimension"));

        assertThat(table.getColumn(1).getName(), is("01/2016"));
        assertThat(table.getColumn(1).getType(), is("Measure"));

        assertThat(table.getTableData().size(), is(1));

        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("App"), "EasyConnect"));
        assertThat(table.getTableData().get(0), hasEntry(cleanStringForReferenceInJS("01/2016"), 500L));
    }

    @Test
    public void testSingleApp_Month_TimeComplete() throws SQLException {
        List<Object[]> data = new ArrayList<>();
        data.add(new Object[]{"EasyConnect", 500L, 2016, 1});
        data.add(new Object[]{"EasyConnect", 400L, 2016, 2});
        data.add(new Object[]{"EasyConnect", 300L, 2016, 3});

        ResultSet resultSet = ResultSetMocker.mock(data, new String[]{"DIMENSION", "MEASURE", "YEAR", "MONTH"});

        Chart chart = toChart(resultSet, new TimeHelper.MonthTimeHelper(), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1451606400000L), UTC), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1459468799999L), UTC));

        System.out.println(chart);
        System.out.println(chart.getChartData());
        System.out.println(chart.getMeasures());
        System.out.println(chart.getDimensions());

        assertThat(chart.getDimensions().size(), is(1));
        assertThat(chart.getDimensions().get(0).getName(), is("MONTH"));

        assertThat(chart.getMeasures().size(), is(1));
        assertThat(chart.getMeasure("EasyConnect").getName(), is("EasyConnect"));

        assertThat(chart.getChartData().get(0), hasEntry(cleanStringForReferenceInJS("MONTH"), "01/2016"));
        assertThat(chart.getChartData().get(0), hasEntry(cleanStringForReferenceInJS("EasyConnect"), 500L));

        assertThat(chart.getChartData().get(1), hasEntry(cleanStringForReferenceInJS("MONTH"), "02/2016"));
        assertThat(chart.getChartData().get(1), hasEntry(cleanStringForReferenceInJS("EasyConnect"), 400L));

        assertThat(chart.getChartData().get(2), hasEntry(cleanStringForReferenceInJS("MONTH"), "03/2016"));
        assertThat(chart.getChartData().get(2), hasEntry(cleanStringForReferenceInJS("EasyConnect"), 300L));
    }

    @Test
    public void testSpecialCharacterInApp_Month_TimeComplete() throws SQLException {
        List<Object[]> data = new ArrayList<>();
        data.add(new Object[]{"E/asy:Connect", 500L, 2016, 1});
        data.add(new Object[]{"E/asy:Connect", 300L, 2016, 3});

        ResultSet resultSet = ResultSetMocker.mock(data, new String[]{"DIMENSION", "MEASURE", "YEAR", "MONTH"});

        Chart cart = toChart(resultSet, new TimeHelper.MonthTimeHelper(), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1451606400000L), UTC), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1459468799999L), UTC));

        assertThat(cart.getDimensions().size(), is(1));
        assertThat(cart.getDimensions().get(0).getName(), is("MONTH"));

        assertThat(cart.getMeasures().size(), is(1));
        assertThat(cart.getMeasure("EasyConnect").getName(), is("EasyConnect"));

        assertThat(cart.getChartData().get(0), hasEntry(cleanStringForReferenceInJS("MONTH"), "01/2016"));
        assertThat(cart.getChartData().get(0), hasEntry(cleanStringForReferenceInJS("E/asy:Connect"), 500L));

        assertThat(cart.getChartData().get(1), hasEntry(cleanStringForReferenceInJS("MONTH"), "02/2016"));
        assertThat(cart.getChartData().get(1), hasEntry(cleanStringForReferenceInJS("E/asy:Connect"), 0L));

        assertThat(cart.getChartData().get(2), hasEntry(cleanStringForReferenceInJS("MONTH"), "03/2016"));
        assertThat(cart.getChartData().get(2), hasEntry(cleanStringForReferenceInJS("E/asy:Connect"), 300L));
    }


    @Test
    public void testSingleApp_Month_TimeComplete_IgnoreEmptyOrNullRows() throws SQLException {
        List<Object[]> data = new ArrayList<>();
        data.add(new Object[]{"EasyConnect", 500L, 2016, 1});
        data.add(new Object[]{"", 500L, 2016, 1});
        data.add(new Object[]{null, 500L, 2016, 1});

        ResultSet resultSet = ResultSetMocker.mock(data, new String[]{"DIMENSION", "MEASURE", "YEAR", "MONTH"});

        Chart cart = toChart(resultSet, new TimeHelper.MonthTimeHelper(), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1451606400000L), UTC), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1459468799999L), UTC));

        assertThat(cart.getDimensions().size(), is(1));
        assertThat(cart.getDimensions().get(0).getName(), is("MONTH"));

        assertThat(cart.getMeasures().size(), is(1));
        assertThat(cart.getMeasure("EasyConnect").getName(), is("EasyConnect"));

        assertThat(cart.getChartData().size(), is(3));

        assertThat(cart.getChartData().get(0), hasEntry(cleanStringForReferenceInJS("MONTH"), "01/2016"));
        assertThat(cart.getChartData().get(0), hasEntry(cleanStringForReferenceInJS("EasyConnect"), 500L));
    }

    @Test
    public void testSingleApp_Day_TimeComplete() throws SQLException {

        List<Object[]> data = new ArrayList<>();
        data.add(new Object[]{"EasyConnect", 500L, "2015/12/15"});
        data.add(new Object[]{"EasyConnect", 400L, "2015/12/16"});
        data.add(new Object[]{"EasyConnect", 300L, "2015/12/17"});

        ResultSet resultSet = ResultSetMocker.mock(data, new String[]{"DIMENSION", "MEASURE", "DAY"});

        Chart cart = toChart(resultSet, new TimeHelper.DayTimeHelper(), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1450137600000L), UTC), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1450396799999L), UTC));

        assertThat(cart.getDimensions().size(), is(1));
        assertThat(cart.getDimensions().get(0).getName(), is("DAY"));

        assertThat(cart.getMeasures().size(), is(1));
        assertThat(cart.getMeasure("EasyConnect").getName(), is("EasyConnect"));

        assertThat(cart.getChartData().get(0), hasEntry(cleanStringForReferenceInJS("DAY"), "2015/12/15"));
        assertThat(cart.getChartData().get(0), hasEntry(cleanStringForReferenceInJS("EasyConnect"), 500L));

        assertThat(cart.getChartData().get(1), hasEntry(cleanStringForReferenceInJS("DAY"), "2015/12/16"));
        assertThat(cart.getChartData().get(1), hasEntry(cleanStringForReferenceInJS("EasyConnect"), 400L));

        assertThat(cart.getChartData().get(2), hasEntry(cleanStringForReferenceInJS("DAY"), "2015/12/17"));
        assertThat(cart.getChartData().get(2), hasEntry(cleanStringForReferenceInJS("EasyConnect"), 300L));
    }

    @Test
    public void testSingleApp_Day_TimeIncomplete() throws SQLException {

        List<Object[]> data = new ArrayList<>();
        data.add(new Object[]{"EasyConnect", 500L, "2015/12/15"});
        // no entry for 2015/12/16
        data.add(new Object[]{"EasyConnect", 300L, "2015/12/17"});

        ResultSet resultSet = ResultSetMocker.mock(data, new String[]{"DIMENSION", "MEASURE", "DAY"});

        Chart cart = toChart(resultSet, new TimeHelper.DayTimeHelper(), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1450137600000L), UTC), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1450396799999L), UTC));

        assertThat(cart.getDimensions().size(), is(1));
        assertThat(cart.getDimensions().get(0).getName(), is("DAY"));

        assertThat(cart.getMeasures().size(), is(1));
        assertThat(cart.getMeasure("EasyConnect").getName(), is("EasyConnect"));

        assertThat(cart.getChartData().get(0), hasEntry(cleanStringForReferenceInJS("DAY"), "2015/12/15"));
        assertThat(cart.getChartData().get(0), hasEntry(cleanStringForReferenceInJS("EasyConnect"), 500L));

        assertThat(cart.getChartData().get(1), hasEntry(cleanStringForReferenceInJS("DAY"), "2015/12/16"));
        assertThat(cart.getChartData().get(1), hasEntry(cleanStringForReferenceInJS("EasyConnect"), 0L));

        assertThat(cart.getChartData().get(2), hasEntry(cleanStringForReferenceInJS("DAY"), "2015/12/17"));
        assertThat(cart.getChartData().get(2), hasEntry(cleanStringForReferenceInJS("EasyConnect"), 300L));
    }

    @Test
    public void testSingleApp_Week_TimeIncomplete() throws SQLException {
        List<Object[]> data = new ArrayList<>();
        data.add(new Object[]{"EasyConnect", 100L, "2016-W28"});
        // no entry for 2015/12/16
        data.add(new Object[]{"EasyConnect", 150L, "2016-W30"});

        ResultSet resultSet = ResultSetMocker.mock(data, new String[]{"DIMENSION", "MEASURE", "ISOWEEK"});

        Chart cart = toChart(resultSet, new TimeHelper.WeekTimeHelper(), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1468195200000L), UTC), ZonedDateTime.ofInstant(Instant.ofEpochMilli(1470009599999L), UTC));

        assertThat(cart.getDimensions().size(), is(1));
        assertThat(cart.getDimensions().get(0).getName(), is("WEEK"));

        assertThat(cart.getMeasures().size(), is(1));
        assertThat(cart.getMeasure("EasyConnect").getName(), is("EasyConnect"));

        assertThat(cart.getChartData().get(0), hasEntry(cleanStringForReferenceInJS("WEEK"), "2016-W28"));
        assertThat(cart.getChartData().get(0), hasEntry(cleanStringForReferenceInJS("EasyConnect"), 100L));

        assertThat(cart.getChartData().get(1), hasEntry(cleanStringForReferenceInJS("WEEK"), "2016-W29"));
        assertThat(cart.getChartData().get(1), hasEntry(cleanStringForReferenceInJS("EasyConnect"), 0L));

        assertThat(cart.getChartData().get(2), hasEntry(cleanStringForReferenceInJS("WEEK"), "2016-W30"));
        assertThat(cart.getChartData().get(2), hasEntry(cleanStringForReferenceInJS("EasyConnect"), 150L));
    }


}
