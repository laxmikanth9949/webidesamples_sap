package com.sap.globalit.tracking.api.internal;

import com.sap.globalit.tracking.StandaloneTest;
import com.sap.globalit.tracking.dao.UsageDAO;
import com.sap.globalit.tracking.dto.ShowroomEntryDTO;
import com.sap.globalit.tracking.model.Application;
import com.sap.globalit.tracking.model.ApplicationPlattform;
import com.sap.globalit.tracking.model.DeviceType;
import com.sap.globalit.tracking.model.Usage;
import com.sap.globalit.tracking.util.Timer;
import org.junit.Test;

import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Created by D053397 on 25.04.2017.
 */
public class RelaybotAPITest extends StandaloneTest {


    @Test
    public void getStatistics_simple() throws SQLException {

        // prepare
        String APP_ID = "App";

        persistence.transactional(em -> {
            Application app = new Application(APP_ID);
            em.persist(app);
            ApplicationPlattform plattform = new ApplicationPlattform(ApplicationPlattform.PlatformType.WEB, app);
            em.persist(plattform);
        });

        // trigger view creation
        target().path("api/status")
                .request()
                .get();

        // create usage
        UsageDAO usageDAO = new UsageDAO();
        usageDAO.setup(() -> connectionFactory.get(), usage_sequence, event_sequence);

        // TODO factory/util to create usage
        Usage u = new Usage();
        u.applicationId = APP_ID;
        u.platformId = ApplicationPlattform.PlatformType.WEB;
        u.deviceType = DeviceType.MOBILE;
        u.usageStart = ZonedDateTime.of(2016, 1, 1, 15, 0, 0, 0, ZoneId.of("UTC")).toInstant();
        u.usageEnd = u.usageStart.plusSeconds(1);
        u.events = Collections.emptyList();
        u.deviceId = "Device 1";

        usageDAO.persistToDatabase(u, new Timer());

        // execute
        setUserContext(OAUTH_RELAY);


        Response responseApps = target()
                .path("api/internal/relaybot/apps")
                .request()
                .header("Authorization", "Bearer VALID")
                .get();


        assertThat(responseApps.getStatus(), is(200));

        Response response = target()
                .path("api/internal/relaybot/statistics")
                .path(APP_ID)
                .queryParam("start", "2016-01-01")
                .queryParam("end", "2016-01-03")
                .queryParam("interval", ReportAPI.TimeInterval.DAY)
                .request()
                .header("Authorization", "Bearer VALID")
                .get();

        // verify
        assertThat(response.getStatus(), is(200));

        List<ShowroomEntryDTO> responseEntity = response.readEntity(new GenericType<List<ShowroomEntryDTO>>() {
        });

        assertThat(responseEntity, notNullValue());
    }
}