1) ensure all necessary information are provided by client
2) map DTO to internal model
3) ensure version info is provided
4) ignore snapshot versions
5) trim device id
6) resolve iOS Native model name
7) update country code from header
8) verify timespan is consistent
9) verify blacklist
10) normalize device information (country code)
11) parse model name (WEB)
12) parse device type
13) apply referer and origin from headers
14) PERSIST
15) Broadcast (optional)

---

