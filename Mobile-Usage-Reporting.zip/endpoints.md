### Usage Reporting

#### Public
- /api/usage
- /tracking/api/usage (deprecated)

- /realtime/oauth
- /realtime/map/oauth
- /realtime/bubbles/oauth

#### Authenticated

- /api/internal/*

- /realtime
- /realtime/map
- /realtime/bubbles

- /swagger-ui

#### Admin
- /api/sa-internal/*