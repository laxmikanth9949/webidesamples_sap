module.exports = function (grunt) {

    grunt.loadNpmTasks('grunt-openui5');

    grunt.initConfig({

        openui5_preload: {
            library: {
                options: {
                    resources: {
                        cwd: 'src/main/webapp/web-client/v3',
                        prefix: 'sap/git/usage',
                        src: 'library.js'
                    },
                    dest: 'src/main/webapp/web-client/v3'
                },
                libraries: 'sap/git/usage'
            }
        }

    });

};