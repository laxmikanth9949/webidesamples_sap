# CoE Capacity Analysis

CoE Team Leads and responsible staffers can use this App to help ensure they have enough resources (supply) to meet the incoming services (demand).  CoE Managers can level the work load for their teams and report various KPI service data.

More details can be found on our [JAM page](https://jam4.sapjam.com/groups/iDrRymI7rWhoNrog2NpHea/overview_page/fISJNCCPKdG4byWSVDBtLt).

## Technical Names
**Repository Name:** coecapacityanalysis

**Name in sapitcloudt:** capacityanalysis

**FLP Name:** Capacity Analysis - CoE Supply/Demand

## Deployments
Deployed Version No: 1.12

Ver 1.12 - Bugfix - Retrieve User Info in the CFLP

Ver 1.11 - Revert to old usage tracking id

Ver 1.10 - Add new usage tracking id

Ver 1.9 - Update component to read reuselib
