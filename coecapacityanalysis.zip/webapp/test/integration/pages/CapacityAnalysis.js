sap.ui.define([
    "sap/ui/test/Opa5",
    "sap/coe/capacity/analysis/test/integration/pages/Common",
    "sap/coe/capacity/analysis/test/integration/util/IntegrationActionHelper",
    "sap/ui/test/actions/Press",
    "sap/ui/test/matchers/Properties",
    "sap/ui/test/matchers/PropertyStrictEquals"
], function(Opa5, Common, IntegrationActionHelper, Press, Properties, PropertyStrictEquals) {
    "use strict";

    Opa5.createPageObjects({
        onCapacityAnalysisPage: {
            actions: {
                Init: function() {
                    IntegrationActionHelper.setTestContext(this);
                },

                iPressButtonWithText: function(sText, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.Button",
                        matchers: [new PropertyStrictEquals({
                            name: "text",
                            value: sText
                        })],
                        success: function(aButtons) {
                            new Press().executeOn(aButtons[0]);
                            ok(true, sSuccessMessage || "Button with text " + sText + " pressed");
                        },
                        errorMessage: sErrorMessage || "Button with text " + sText + " press failed"
                    });
                },

                iPressOnDialogNavButton: function(sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.Dialog",
                        success: function(aDialog) {
                            var oNavBtn = aDialog[0].getContent("page")[0]._navBtn;
                            new Press().executeOn(oNavBtn);
                            ok(true, sSuccessMessage || "Nav button pressed");
                        },
                        errorMessage: sErrorMessage || "Failed to press Nav button"
                    });
                },

                iClickOnIconTabFilter: function(sKey, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.IconTabFilter",
                        check: function(aTabs) {
                            for (var i = 0; i < aTabs.length; i++) {
                                if (aTabs[i].getId().indexOf(sKey) > -1) {
                                    var oSelectedItem = aTabs[i];
                                    var oFilterTab = oSelectedItem.getParent().getParent();
                                    oFilterTab.setSelectedItem(oSelectedItem);
                                    return true;
                                }
                            }
                        },
                        success: function() {
                            ok(true, sSuccessMessage || "Tab " + sKey + " is clicked.");
                        },
                        errorMessage: sErrorMessage || "Tab " + sKey + " does not exist."
                    });
                },

                iPressButton: function(sButtonId, bDialog, sSuccessMessage, sErrorMessage) {
                    IntegrationActionHelper.iPressButton(sButtonId, bDialog, sSuccessMessage, sErrorMessage);
                },

                iPressOnTheTile: function(sTileId, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.GenericTile",
                        check: function(aTiles) {
                            for (var i = 0; i < aTiles.length; i++) {
                                if (aTiles[i].getId().indexOf(sTileId) > -1) {
                                    var oTile = aTiles[i];

                                    oTile.firePress({
                                        tile: oTile
                                    });
                                    return true;
                                }
                            }
                        },
                        success: function() {
                            ok(true, sSuccessMessage || "Tile at  " + sTileId + " was pressed succesfully.");
                        },
                        errorMessage: sErrorMessage || "Tile at  " + sTileId + " press failed."

                    });
                },

                iPressOnValueHelpRequestMultiInput: function(sInputId, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.MultiInput",
                        check: function(aMultiInputs) {
                            for (var i = 0; i < aMultiInputs.length; i++) {
                                if (aMultiInputs[i].getId().indexOf(sInputId) > -1) {
                                    aMultiInputs[i].fireValueHelpRequest();
                                    return true;
                                }
                            }
                        },
                        success: function() {
                            ok(true, sSuccessMessage || "Value help for Multi Input " + sInputId + " triggered.");
                        },
                        errorMessage: sErrorMessage || "Failed to trigger value help for Multi Input " + sInputId + "."
                    });
                },

                iPressOnIcon: function(sInputId, sSrc, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.ui.core.Icon",
                        matchers: [new sap.ui.test.matchers.PropertyStrictEquals({
                            name: "src",
                            value: sSrc
                        })],
                        check: function(aInputs) {
                            for (var i = 0; i < aInputs.length; i++) {
                                if (aInputs[i].getId().indexOf(sInputId) > -1) {
                                    new Press().executeOn(aInputs[i]);
                                    return true;
                                }
                            }
                        },
                        success: function(aInputs) {

                            ok(true, sSuccessMessage || "Value help for MultiInput " + sInputId + " triggered.");
                        },
                        errorMessage: sErrorMessage || "Failed to trigger value help for MultiInput " + sInputId + "."
                    });
                },

                iClickListItem: function(iPosition, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        searchOpenDialogs: true,
                        controlType: "sap.m.StandardListItem",
                        check: function(aInputs) {
                            aInputs[iPosition].$().trigger("tap");
                            return true;
                        },
                        success: function() {
                            ok(true, sSuccessMessage || "The list item " + iPosition + " is clicked.");
                        },
                        errorMessage: sErrorMessage || "The list item " + iPosition + " click failed."
                    });
                },

                iSelectListItem: function(iPosition, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        searchOpenDialogs: true,
                        controlType: "sap.m.StandardListItem",
                        check: function(aInputs) {
                            aInputs[iPosition]._oMultiSelectControl.$().trigger("tap");
                            return true;
                        },
                        success: function() {
                            ok(true, sSuccessMessage || "The list item " + iPosition + " is selected.");
                        },
                        errorMessage: sErrorMessage || "The list item " + iPosition + " selection failed."
                    });
                },

                iDeleteToken: function(sTextOfToken, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.Token",
                        check: function(aTokens) {
                            for (var i = aTokens.length - 1; i >= 0; i--) {
                                if (aTokens[i].getText() === sTextOfToken) {
                                    var oToken = aTokens[i];

                                    oToken.fireDelete({
                                        token: oToken
                                    });

                                    return true;
                                }
                            }
                        },
                        success: function() {
                            ok(true, sSuccessMessage || "Token " + sTextOfToken + " deleted.");
                        },
                        errorMessage: sErrorMessage || "Not possible to delete token " + sTextOfToken + "."
                    });
                },

                iListIsReady: function(sIdOfList, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.List",
                        check: function(aList) {
                            for (var i = 0; i < aList.length; i++) {
                                if (aList[0].getId().indexOf(sIdOfList) > -1 && !aList[i].isBusy()) {
                                    return true;
                                }
                            }
                            return false;
                        },
                        success: function() {
                            ok(true, sSuccessMessage || "List " + sIdOfList + " ready.");
                        },
                        errorMessage: sErrorMessage || "List " + sIdOfList + " ready failed."
                    });
                },

                iClickOnTheNItemInTheList: function(iIndex, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.List",
                        check: function(oList) {
                            oList[0].getItems()[iIndex].$().trigger("tap");
                            return true;
                        },
                        success: function() {
                            ok(true, sSuccessMessage || "Item at index " + iIndex + " clicked on successfully");
                        },
                        errorMessage: sErrorMessage || "Failed to click on item at index " + iIndex
                    });
                },

                iWaitForListRecieveData: function(iIndex, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.List",
                        check: function(oList) {
                            return !oList[0]._bReceivingData;
                        },
                        success: function(oList) {
                            ok(true, sSuccessMessage || "Navigation successful");
                        },
                        errorMessage: sErrorMessage || "Navigation failed"
                    });
                },

                iClickOnMultiSelectRB: function(iIndex, bSelect, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        searchOpenDialogs: true,
                        controlType: "sap.m.List",
                        check: function(oList) {
                            var oItem = oList[0].getItems()[iIndex];
                            oItem.setSelected(bSelect);
                            oList[0].fireSelectionChange({ listItem: oItem });
                            return true;
                        },
                        success: function() {
                            ok(true, sSuccessMessage || "The Radio Button of item at index " + iIndex + "was " +
                                (bSelect ? "selected" : "deselected") + " successfully");
                        },
                        errorMessage: sErrorMessage || "Failed to select the Radio Button of item at index" + iIndex
                    });
                },

                iLookAtTheScreen: function(iPosition) {
                    return true;
                },

                iPressAcceptCancelButton: function(bAccept, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.Dialog",
                        success: function(aDialog) {
                            if(bAccept) {
                                aDialog[0].getBeginButton().$().trigger("tap");
                            }
                            else{
                                aDialog[0].getEndButton().$().trigger("tap");
                            }
                            ok(true, sSuccessMessage || "Focused on " + (bAccept ? "OK" : "Cancel") + "Button");
                        },
                        errorMessage: sErrorMessage || "did not find the " + (bAccept ? "OK" : "Cancel") + " Button"
                    });
                },

                iFocusAway: function(sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.MultiComboBox",
                        success: function(aInputs) {
                            aInputs[0].$().trigger("focusin");
                            ok(true, sSuccessMessage || "Focused on MultiComboBox");
                        },
                        errorMessage: sErrorMessage || "Could not find a MultiComboBox"
                    });
                },
                iFocusAwayClickToken: function(sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.Token",
                        success: function(aTokens) {
                            aTokens[0].$().trigger("tap");
                        },
                        errorMessage: sErrorMessage || "did not find a Button"
                    });
                },

                iSelectOptionInComboBox: function(sOption, sComboBoxID, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.Select",
                        check: function(aComboBox) {
                            var oItem;
                            for (var i = 0; i < aComboBox.length; i++) {
                                if (aComboBox[i].getId().indexOf(sComboBoxID) > -1) {
                                    oItem = aComboBox[i].getItemByKey(sOption);
                                    aComboBox[i].setSelectedItem(oItem);
                                    aComboBox[i].fireChange({selectedItem: oItem});
                                    return true;
                                }
                            }
                            return false;
                        },
                        success: function() {
                            ok(true, sSuccessMessage || "Option " + sOption + " selected.");
                        },
                        errorMessage: sErrorMessage || "Option " + sOption + " not possible to be selected."
                    });
                }

            },
            assertions: {
                iShouldSeeADialog: function(sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.Dialog",
                        success: function(oDialog) {
                            Opa5.assert.ok(oDialog, sSuccessMessage || "Found the dialog.");
                        },
                        errorMessage: sErrorMessage || "Can't see the dialog."
                    });
                },

                iShouldSeeATable: function(sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.Table",
                        success: function(oTable) {
                            Opa5.assert.ok(oTable, sSuccessMessage || "Found the table.");
                        },
                        errorMessage: sErrorMessage || "Can't see the table."
                    });
                },

                iShouldSeeCellWithValueInTable: function(sValue, sTableID, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.Label",
                        success: function(aCells) {
                            var bFound = false;

                            for (var i = aCells.length - 1; i >= 0; i--) {
                                if (aCells[i].getId().indexOf(sTableID) > -1 && aCells[i].getText().indexOf(sValue) > -1) {
                                    bFound = true;
                                    break;
                                }
                            }
                            Opa5.assert.ok(bFound, sSuccessMessage || "Found cell with value " + sValue + " in table " + sTableID + ".");
                        },
                        errorMessage: sErrorMessage || "Can't see the cells."
                    });
                },

                iShouldSeeATileFor: function(sIdOfTile, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.GenericTile",
                        success: function(aTiles) {
                            for (var i = 0; i < aTiles.length; i++) {
                                if (aTiles[i].getId().indexOf(sIdOfTile) > -1) {

                                    Opa5.assert.ok(aTiles, sSuccessMessage || "The tile " + sIdOfTile + " is found.");
                                }
                            }
                        },
                        errorMessage: sErrorMessage || "Can't find " + sIdOfTile + " tile."
                    });
                },

                iShouldSeeAPopover: function(sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.Popover",
                        success: function() {
                            Opa5.assert.ok(true, sSuccessMessage || "The popover is open.");
                        },
                        errorMessage: sErrorMessage || "Can't see the Popover."
                    });
                },

                iShouldSeeFilterBarOpen: function(sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.Button",
                        success: function(oButton) {
                            Opa5.assert.ok(oButton, sSuccessMessage || "Filter Bar is open.");
                        },
                        errorMessage: sErrorMessage || "Can't find filter bar button."
                    });
                },

                iShouldSeeNTokens: function(sIdOfTextField, iAmountOfTokens, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.MultiInput",
                        success: function(aInputs) {
                            for (var i = 0; i < aInputs.length; i++) {
                                if (aInputs[i].getId().indexOf(sIdOfTextField) > -1) {

                                    Opa5.assert.equal(aInputs[i].getTokens().length, iAmountOfTokens, sSuccessMessage || "Correct Amount of tokens found in input field " + sIdOfTextField + ".");

                                }
                            }
                        },
                        errorMessage: sErrorMessage || "No MultiInput found."
                    });
                },

                iShouldSeeNItemsCheckedInList: function(sIdOfList, iExpectedAmountOfSelected, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.List",
                        success: function(aList) {
                            for (var i = 0; i < aList.length; i++) {
                                if (aList[i].getId().indexOf(sIdOfList) > -1) {
                                    Opa5.assert.equal(aList[i].getSelectedItems().length, iExpectedAmountOfSelected, sSuccessMessage || "Found expected amount of selected items in list " + sIdOfList + ".");
                                    break;
                                }
                            }
                        },
                        errorMessage: sErrorMessage || "List " + sIdOfList + " not found."
                    });
                },

                iShouldItemBeDeselectedInList: function(sIdOfList, sTextOfListItem, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.List",
                        success: function(aList) {
                            for (var i = 0; i < aList.length; i++) {
                                if (aList[i].getId().indexOf(sIdOfList) > -1) {
                                    var itemFound = aList[i].getSelectedItems().find(
                                        function(item) {
                                            return item.getTitle() === sTextOfListItem;
                                        }
                                    );
                                    Opa5.assert.notOk(itemFound, sSuccessMessage || "Item " + sTextOfListItem + " deselected in list " + sIdOfList + ".");
                                    break;
                                }
                            }
                        },
                        errorMessage: sErrorMessage || "List " + sIdOfList + " not found."
                    });
                },

                iShouldItemBeSelectedInList: function(sIdOfList, sTextOfListItem, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.List",
                        success: function(aList) {
                            for (var i = 0; i < aList.length; i++) {
                                if (aList[i].getId().indexOf(sIdOfList) > -1) {
                                    var itemFound = aList[i].getSelectedItems().find(
                                        function(item) {
                                            return item.getTitle() === sTextOfListItem;
                                        }
                                    );

                                    Opa5.assert.ok(itemFound, sSuccessMessage || "Item " + sTextOfListItem + " selected in list " + sIdOfList + ".");
                                    break;
                                }
                            }
                        },
                        errorMessage: sErrorMessage || "List " + sIdOfList + " not found."
                    });
                },

                iShouldSeeNItemsInTheList: function(iItems, sSuccessMessage, sErrorMessage) {
                    var iNoOfItems = 0;
                    return this.waitFor({
                        controlType: "sap.m.List",
                        success: function(oList) {
                            Opa5.assert.ok((oList[0].getItems().length === iItems), sSuccessMessage || iItems + " items found in list");
                        },
                        errorMessage: sErrorMessage || "Error: " + iNoOfItems + " found, not " + iItems + " as expected"
                    });
                },

                iShouldSeeThisItemAsTheNItemInList: function(sTextToMatch, iIndex, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.StandardListItem",
                        matchers: new Properties({
                            description: sTextToMatch
                        }),
                        success: function(aItems) {
                            Opa5.assert.ok(aItems[0], sErrorMessage || "Found item at index " + iIndex + " with description: " + sTextToMatch);
                        },
                        errorMessage: sErrorMessage || "Item with description: " + sTextToMatch + "not found"
                    });
                },

                iShouldSeeNItemsSelected: function(iIndex, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.m.StandardListItem",
                        matchers: new Properties({
                            selected: true
                        }),
                        success: function(aItems) {
                            Opa5.assert.equal(aItems.length, iIndex, sSuccessMessage || iIndex + " items are selected");
                        },
                        errorMessage: sErrorMessage || "Fail: " + iIndex + " items are selected"
                    });
                },

                iShouldSeeVizFrameChart: function(sIdOfVizFrame, sSuccessMessage, sErrorMessage) {
                    return this.waitFor({
                        controlType: "sap.viz.ui5.controls.VizFrame",
                        success: function(aVizFrame) {
                            for (var i = 0; i < aVizFrame.length; i++) {
                                if (aVizFrame[i].getId().indexOf(sIdOfVizFrame) > -1) {

                                    Opa5.assert.ok(true, sSuccessMessage || "The Chart for " + sIdOfVizFrame + " is visible.");
                                }
                            }
                        },
                        errorMessage: sErrorMessage || "The Chart for " + sIdOfVizFrame + " is not visible."
                    });
                },

                okAssert: function(sMessage) {
                    Opa5.assert.ok(true, sMessage || "ok assert");
                }

            }
        }

    });

});
