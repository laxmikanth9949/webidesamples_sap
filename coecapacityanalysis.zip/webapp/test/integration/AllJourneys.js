jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;


sap.ui.require([
	"sap/ui/test/Opa5",
	"sap/coe/capacity/analysis/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"sap/coe/capacity/analysis/test/integration/pages/CapacityAnalysis"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "sap.coe.capacity.analysis.view."
	});


	sap.ui.require([
		"sap/coe/capacity/analysis/test/integration/TeamOverviewTabJourney",
		"sap/coe/capacity/analysis/test/integration/StaffedDemandTabJourney",
		"sap/coe/capacity/analysis/test/integration/StaffedDetailsTabJourney",
		"sap/coe/capacity/analysis/test/integration/FilterBarJourney"
	], function () {
		QUnit.start();
	});
	
});
