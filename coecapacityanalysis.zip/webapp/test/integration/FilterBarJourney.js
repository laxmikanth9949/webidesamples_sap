sap.ui.define([
    "sap/ui/test/opaQunit"
], function(opaTest) {
    "use strict";

    QUnit.module("FilterBar");
    opaTest("Should see the filter bar when show FilterBar button is pressed", function(Given, When, Then) {
        Given.iStartTheApp();
        When.onCapacityAnalysisPage.Init();
        When.onCapacityAnalysisPage.iPressButtonWithText("Show Filter Bar");

        Then.onCapacityAnalysisPage.iShouldSeeFilterBarOpen();
    });

    //Service Team

    opaTest("Should See Service Team Dialog", function(Given, When, Then) {  
        When.onCapacityAnalysisPage.iPressOnIcon("idForResServiceTeam----idForServiceTeam", "sap-icon://value-help", "Open Service Team Dialog successful", "Open Service Team Dialog failed");
        Then.onCapacityAnalysisPage.iShouldSeeADialog();
    });

    opaTest("Select Items on the Service Team Dialog.", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iClickListItem(0);

        When.onCapacityAnalysisPage.iSelectListItem(0);
        When.onCapacityAnalysisPage.iSelectListItem(1);

        When.onCapacityAnalysisPage.iPressButton("acceptForEmpId", true, "Close service team dialog sucessful", "Close service team dialog failed");

        Then.onCapacityAnalysisPage.iShouldSeeNTokens("idForResServiceTeam----idForServiceTeam", 2);
    });

    opaTest("Remove token from service team input.", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iDeleteToken("COE CN INTERNS DALIAN");
        Then.onCapacityAnalysisPage.iShouldSeeNTokens("idForResServiceTeam----idForServiceTeam", 1);
    });

    opaTest("Should be checked only the expected tokens on the Service Team Dialog.", function(Given, When, Then) {
        //this test is added because the service team dialog will not re-open unless you open another dialog first. This is a temp soloution 

        When.onCapacityAnalysisPage.iPressOnIcon("idForResQualification----id___Qualificationid", "sap-icon://value-help", "Open Qualification Dialog successful", "Open Qualification Dialog failed");
        When.onCapacityAnalysisPage.iPressButton("acceptForQualificationid", true, "Close qualification dialog sucessful", "Close qualification dialog failed");


        When.onCapacityAnalysisPage.iPressOnIcon("idForResServiceTeam----idForServiceTeam", "sap-icon://value-help", "Open Service Team Dialog successful", "Open Service Team Dialog failed");
        When.onCapacityAnalysisPage.iListIsReady("SelectOrganisationList");

        Then.onCapacityAnalysisPage.iShouldSeeNItemsCheckedInList("SelectOrganisationList", 1);
        Then.onCapacityAnalysisPage.iShouldItemBeDeselectedInList("SelectOrganisationList", "COE CN INTERNS DALIAN");
        Then.onCapacityAnalysisPage.iShouldItemBeSelectedInList("SelectOrganisationList", "AIE BACKOFFICE");
        
    });

    opaTest("Should delete token from field when deselecting on the Service Team Dialog.", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iSelectListItem(0);
        When.onCapacityAnalysisPage.iPressButton("acceptForEmpId", true, "Close service team dialog sucessful", "Close service team dialog failed");

        Then.onCapacityAnalysisPage.iShouldSeeNTokens("idForResServiceTeam----idForServiceTeam", 0);
    });


    /*opaTest("Select Items on the Qualification Dialog.", function(Given, When, Then) {
        When.onTheFilterBar.iClickListItem(0);
        When.onTheFilterBar.iClickListItem(0);

        When.onTheFilterBar.iSelectListItem(0);
        When.onTheFilterBar.iSelectListItem(1);

        When.onTheFilterBar.iPressAcceptButton();

        Then.onTheFilterBar.iShouldSeeNTokens("__xmlview1--idForResQualification----id___Qualificationid", 2);
    });*/

    // Supply Qualification Dialog

    opaTest("Should See Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressOnIcon("idForResQualification", "sap-icon://value-help", "Open Qualification Dialog successful", "Open Qualification Dialog failed");

        Then.onCapacityAnalysisPage.iShouldSeeADialog();
    });

    opaTest("Should should see 9 items in the List of the Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iLookAtTheScreen();
        When.onCapacityAnalysisPage.iWaitForListRecieveData();

        Then.onCapacityAnalysisPage.iShouldSeeNItemsInTheList(9);
    });

    opaTest("Item 93100047 should be the first item in the list of the Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iLookAtTheScreen();

        Then.onCapacityAnalysisPage.iShouldSeeThisItemAsTheNItemInList("93100047", 0);
    });

    opaTest("Should see 14 items in the List of the Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iClickOnTheNItemInTheList(0);
        When.onCapacityAnalysisPage.iWaitForListRecieveData();

        Then.onCapacityAnalysisPage.iShouldSeeNItemsInTheList(14);
    });

    opaTest("Item 93100026 should be the first item in the list of the Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iLookAtTheScreen();

        Then.onCapacityAnalysisPage.iShouldSeeThisItemAsTheNItemInList("93100026", 0);
    });


    opaTest("Select all leaf items of a branch of the Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iClickOnMultiSelectRB(0, true);
        When.onCapacityAnalysisPage.iClickOnTheNItemInTheList(0);
        When.onCapacityAnalysisPage.iWaitForListRecieveData();

        Then.onCapacityAnalysisPage.iShouldSeeNItemsInTheList(12);
        Then.onCapacityAnalysisPage.iShouldSeeNItemsSelected(12);
    });

    opaTest("Accept selected items of the Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressAcceptCancelButton(true);

        Then.onCapacityAnalysisPage.iShouldSeeNTokens("idForResQualification", 12);
    });

    opaTest("Deleted token should not be selcted in list", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iDeleteToken("OSD: CRM DVM");
        // need to focus away to click on value help
        When.onCapacityAnalysisPage.iFocusAway();
        When.onCapacityAnalysisPage.iFocusAwayClickToken();
        // Need to click twice to open dialog
        When.onCapacityAnalysisPage.iPressOnIcon("idForResQualification", "sap-icon://value-help", "Open Qualification Dialog successful", "Open Qualification Dialog failed");
        When.onCapacityAnalysisPage.iPressOnIcon("idForResQualification", "sap-icon://value-help", "Open Qualification Dialog successful", "Open Qualification Dialog failed");
        When.onCapacityAnalysisPage.iWaitForListRecieveData();
        When.onCapacityAnalysisPage.iClickOnTheNItemInTheList(0);
        When.onCapacityAnalysisPage.iWaitForListRecieveData();
        When.onCapacityAnalysisPage.iClickOnTheNItemInTheList(0);
        When.onCapacityAnalysisPage.iWaitForListRecieveData();

        Then.onCapacityAnalysisPage.iShouldSeeNItemsSelected(11);
    });

    opaTest("Unselected Item should be removed from MuliInput", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iClickOnMultiSelectRB(1, false);
        When.onCapacityAnalysisPage.iPressAcceptCancelButton(true);

        Then.onCapacityAnalysisPage.iShouldSeeNTokens("idForResQualification", 10);
    });

    opaTest("Selected Leaf items should appear as tokens on press OK", function(Given, When, Then) {
        // need to focus away to click on value help
        When.onCapacityAnalysisPage.iFocusAway();
        When.onCapacityAnalysisPage.iFocusAwayClickToken();
        // Need to click twice to open dialog
        When.onCapacityAnalysisPage.iPressOnIcon("idForResQualification", "sap-icon://value-help", "Open Qualification Dialog successful", "Open Qualification Dialog failed");
        When.onCapacityAnalysisPage.iPressOnIcon("idForResQualification", "sap-icon://value-help", "Open Qualification Dialog successful", "Open Qualification Dialog failed");
        When.onCapacityAnalysisPage.iWaitForListRecieveData();
        When.onCapacityAnalysisPage.iClickOnTheNItemInTheList(1);
        When.onCapacityAnalysisPage.iWaitForListRecieveData();
        When.onCapacityAnalysisPage.iClickOnMultiSelectRB(0, true);
        When.onCapacityAnalysisPage.iClickOnMultiSelectRB(0, true);
        When.onCapacityAnalysisPage.iPressAcceptCancelButton(true);

        Then.onCapacityAnalysisPage.iShouldSeeNTokens("idForResQualification", 12);
    });    

    // Demand Qualification Dialog

    opaTest("Should See Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressOnIcon("idForDemandQualification", "sap-icon://value-help", "Open Qualification Dialog successful", "Open Qualification Dialog failed");

        Then.onCapacityAnalysisPage.iShouldSeeADialog();
    });

    opaTest("Should should see 9 items in the List of the Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iLookAtTheScreen();
        When.onCapacityAnalysisPage.iWaitForListRecieveData();

        Then.onCapacityAnalysisPage.iShouldSeeNItemsInTheList(9);
    });

    opaTest("Item 93100047 should be the first item in the list of the Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iLookAtTheScreen();

        Then.onCapacityAnalysisPage.iShouldSeeThisItemAsTheNItemInList("93100047", 0);
    });

    opaTest("Should see 14 items in the List of the Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iClickOnTheNItemInTheList(0);
        When.onCapacityAnalysisPage.iWaitForListRecieveData();

        Then.onCapacityAnalysisPage.iShouldSeeNItemsInTheList(14);
    });

    opaTest("Item 93100026 should be the first item in the list of the Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iLookAtTheScreen();

        Then.onCapacityAnalysisPage.iShouldSeeThisItemAsTheNItemInList("93100026", 0);
    });


    opaTest("Select all leaf items of a branch of the Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iClickOnMultiSelectRB(0, true);
        When.onCapacityAnalysisPage.iClickOnTheNItemInTheList(0);
        When.onCapacityAnalysisPage.iWaitForListRecieveData();

        Then.onCapacityAnalysisPage.iShouldSeeNItemsInTheList(12);
        Then.onCapacityAnalysisPage.iShouldSeeNItemsSelected(12);
    });

    opaTest("Accept selected items of the Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressAcceptCancelButton(true);

        Then.onCapacityAnalysisPage.iShouldSeeNTokens("idForDemandQualification", 12);
    });

    opaTest("Deleted token should not be selcted in list", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iDeleteToken("OSD: CRM DVM");
        // need to focus away to click on value help
        When.onCapacityAnalysisPage.iFocusAway();
        When.onCapacityAnalysisPage.iFocusAwayClickToken();
        // Need to click twice to open dialog
        When.onCapacityAnalysisPage.iPressOnIcon("idForDemandQualification", "sap-icon://value-help", "Open Qualification Dialog successful", "Open Qualification Dialog failed");
        When.onCapacityAnalysisPage.iPressOnIcon("idForDemandQualification", "sap-icon://value-help", "Open Qualification Dialog successful", "Open Qualification Dialog failed");
        When.onCapacityAnalysisPage.iWaitForListRecieveData();
        When.onCapacityAnalysisPage.iClickOnTheNItemInTheList(0);
        When.onCapacityAnalysisPage.iWaitForListRecieveData();
        When.onCapacityAnalysisPage.iClickOnTheNItemInTheList(0);
        When.onCapacityAnalysisPage.iWaitForListRecieveData();

        Then.onCapacityAnalysisPage.iShouldSeeNItemsSelected(11);
    });

    opaTest("Unselected Item should be removed from MuliInput", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iClickOnMultiSelectRB(1, false);
        When.onCapacityAnalysisPage.iPressAcceptCancelButton(true);

        Then.onCapacityAnalysisPage.iShouldSeeNTokens("idForDemandQualification", 10);
    });

    opaTest("Selected Leaf items should appear as tokens on press OK", function(Given, When, Then) {
        // need to focus away to click on value help
        When.onCapacityAnalysisPage.iFocusAway();
        When.onCapacityAnalysisPage.iFocusAwayClickToken();
        // Need to click twice to open dialog
        When.onCapacityAnalysisPage.iPressOnIcon("idForDemandQualification", "sap-icon://value-help", "Open Qualification Dialog successful", "Open Qualification Dialog failed");
        When.onCapacityAnalysisPage.iPressOnIcon("idForDemandQualification", "sap-icon://value-help", "Open Qualification Dialog successful", "Open Qualification Dialog failed");
        When.onCapacityAnalysisPage.iWaitForListRecieveData();
        When.onCapacityAnalysisPage.iClickOnTheNItemInTheList(1);
        When.onCapacityAnalysisPage.iWaitForListRecieveData();
        When.onCapacityAnalysisPage.iClickOnMultiSelectRB(0, true);
        When.onCapacityAnalysisPage.iClickOnMultiSelectRB(0, true);
        When.onCapacityAnalysisPage.iPressAcceptCancelButton(true);

        Then.onCapacityAnalysisPage.iShouldSeeNTokens("idForDemandQualification", 12);
    });


    // Supply Org Unit Dialog

    opaTest("Should See Qualification Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressOnIcon("idForOrgId", "sap-icon://value-help", "Open Qualification Dialog successful", "Open Qualification Dialog failed");

        Then.onCapacityAnalysisPage.iShouldSeeADialog();
    });

    opaTest("Should should see 1 item in the List of the Org Unit Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iLookAtTheScreen();
        When.onCapacityAnalysisPage.iWaitForListRecieveData();

        Then.onCapacityAnalysisPage.iShouldSeeNItemsInTheList(1);
    });

    opaTest("Item 30015950 should be the first item in the list of the Org Unit Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iLookAtTheScreen();

        Then.onCapacityAnalysisPage.iShouldSeeThisItemAsTheNItemInList("30015950", 0);
    });

    opaTest("Should see selected item as a token on press Ok", function(Given, When, Then) {

        //Item loaded from the variant. TODO: Rewrite this test in a different way
    /*  When.onCapacityAnalysisPage.iWaitForListRecieveData();
        When.onCapacityAnalysisPage.iClickOnMultiSelectRB(0, true);
        When.onCapacityAnalysisPage.iPressAcceptCancelButton(true);*/

        Then.onCapacityAnalysisPage.iShouldSeeNTokens("idForOrgId", 1);
    });

    //Button press still wont work properly even with work around comment until correct fix 
/*
    opaTest("Should see 14 items in the List of the Org Unit Select Dialog", function(Given, When, Then) {
        //Fix for Press on Value Help
        When.onCapacityAnalysisPage.iPressOnIcon("idForDemandQualification", "sap-icon://value-help");
        When.onCapacityAnalysisPage.iPressAcceptCancelButton(false);   

        When.onCapacityAnalysisPage.iPressOnIcon("idForOrgId", "sap-icon://value-help");
        When.onCapacityAnalysisPage.iWaitForListRecieveData();       
        When.onCapacityAnalysisPage.iPressOnDialogNavButton();
        When.onCapacityAnalysisPage.iWaitForListRecieveData();

        Then.onCapacityAnalysisPage.iShouldSeeThisItemAsTheNItemInList("30014475", 0);
    });

    opaTest("Selected Leaf items should appear as tokens on press OK", function(Given, When, Then) {

        When.onCapacityAnalysisPage.iClickOnMultiSelectRB(0, true);
        When.onCapacityAnalysisPage.iPressAcceptCancelButton(true);

        Then.onCapacityAnalysisPage.iShouldSeeNTokens("idForOrgId", 2);
    });    

    opaTest("Should see 14 items in the List of the Org Unit Select Dialog", function(Given, When, Then) {
        //Fix for Press on Value Help
        When.onCapacityAnalysisPage.iPressOnIcon("idForDemandQualification", "sap-icon://value-help");
        When.onCapacityAnalysisPage.iPressAcceptCancelButton(false);

        When.onCapacityAnalysisPage.iPressOnIcon("idForOrgId", "sap-icon://value-help");
        When.onCapacityAnalysisPage.iWaitForListRecieveData();

        Then.onCapacityAnalysisPage.iShouldSeeNItemsSelected(1);
    });  

    opaTest("Should see 14 items in the List of the Org Unit Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressOnDialogNavButton();
        When.onCapacityAnalysisPage.iWaitForListRecieveData();
        Then.onCapacityAnalysisPage.iShouldSeeNItemsSelected(1);
    });

    opaTest("Should see 14 items in the List of the Org Unit Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iClickOnMultiSelectRB(0, false);
        When.onCapacityAnalysisPage.iPressAcceptCancelButton(true);
        Then.onCapacityAnalysisPage.iShouldSeeNTokens("idForOrgId", 1);
    });  



    opaTest("Should see 14 items in the List of the Org Unit Select Dialog", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iDeleteToken("COE Ireland HANA");
        When.onCapacityAnalysisPage.iPressButtonWithText("Hide Filter Bar");
        When.onCapacityAnalysisPage.iPressButtonWithText("Show Filter Bar");
        When.onCapacityAnalysisPage.iPressOnIcon("idForDemandQualification", "sap-icon://value-help");
        When.onCapacityAnalysisPage.iPressAcceptCancelButton(true);
        When.onCapacityAnalysisPage.iPressOnIcon("idForOrgId", "sap-icon://value-help");
        When.onCapacityAnalysisPage.iWaitForListRecieveData();
        Then.onCapacityAnalysisPage.iShouldSeeNItemsSelected(0);
    });  */

    opaTest("Tear down and clean context", function(Given, When, Then) {
        Given.iTeardownMyAppFrame();

        Then.onCapacityAnalysisPage.okAssert("Worklist context cleaned");
    });    


});
