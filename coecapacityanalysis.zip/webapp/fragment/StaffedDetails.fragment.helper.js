sap.ui.define([
    "sap/coe/capacity/analysis/util/i18n"
], function(i18nCapacity) {
    "use strict";

    return {
        sFragmentId: "StaffedDetails",

        oVizProperties: {
            title: {
                visible: false
            },
            plotArea: {
                dataLabel: {
                    visible: true,
                    type: "value"
                }
            }
        },

        /**
         * Initialises the fragment for staffedDetails and models, etc.
         *
         * @public
         * @param {sap.ui.core.mvc.Controller} oMainController - the controller of the main view
         * @return {void}
         */
        onInit: function(oMainController) {
            this.oMainController = oMainController;
            this.oMainView = oMainController.getView();
            this.oVizFrame = this.byId("idVizFrame");
            this.oTable = this.byId("idForTable");
            this.oDropDown = this.byId("idForSelectChartDimension");

            this._initVizFrame();
            this._initModels();
            this._initTable();

            this.oChartModel = new sap.ui.model.json.JSONModel([{}]);
            this.oVizFrame.setModel(this.oChartModel, "StaffedDetailsChart");
            this.updateChartBinding("roles");
        },

        /**
         * Sets the data returned from the Capacity service to a model and binds it to the view
         *
         * @public
         * @param {Object} response - the data returned from the server for capacity information
         * @return {void}
         */
        onResponseCapacity: function(response) {
            var oModel = new sap.ui.model.json.JSONModel(response);
            this.oMainView.setModel(oModel, "StaffedDetailsTile");
        },

        /**
         * Sets the data returned from the Role service to a model
         *
         * @public
         * @param {Array} aResponse - the data returned from the server for role information
         * @return {void}
         */
        onResponseRoleData: function(aResponse) {
            this.oRoleChartModel.setProperty("/", aResponse);
        },

        /**
         * Sets the data returned from the Service data service to a model
         *
         * @public
         * @param {Array} aResponse - the data returned from the server for service information
         * @return {void}
         */
        onResponseServiceData: function(aResponse) {
            this.oServiceChartModel.setProperty("/", aResponse);
        },

        /**
         * Sets the data returned from the Qualification service to a model
         *
         * @public
         * @param {Array} aResponse - the data returned from the server for qualification information
         * @return {void}
         */
        onResponseQualificationData: function(aResponse) {
            this.oQualificationChartModel.setProperty("/", aResponse);
        },

        /**
         * Sets the data returned from the NonProd service to a model
         *
         * @public
         * @param {Array} aResponse - the data returned from the server for non-prod information
         * @return {void}
         */
        onResponseNonProdData: function(aResponse) {
            this.oNonProdChartModel.setProperty("/", aResponse);
        },

        /**
         * Sets the data returned from the Activity service to a model
         *
         * @public
         * @param {Array} aResponse - the data returned from the server for activity information
         * @return {void}
         */
        onResponseActivityData: function(aResponse) {
            this.oActivityChartModel.setProperty("/", aResponse);
        },

        /**
         * Sets the data returned from the ResourceOrigin service to a model
         *
         * @public
         * @param {Array} aResponse - the data returned from the server for resource origin information
         * @return {void}
         */
        onResponseResourceOriginData: function(aResponse) {
            this.oResourceOriginChartModel.setProperty("/", aResponse);
        },

        /**
         * Retrieves a controller from the fragment based on their id
         *
         * @public
         * @param {String} sControl - the id of the control to be returned
         * @return {Object} - returns the retrieved object (if found)
         */
        byId: function(sControl) {
            return this.oMainView.byId(this.sFragmentId + "--" + sControl);
        },

        /**
         * Updates the charts binding based of the user selection from the data source dropdown
         *
         * @public
         * @param {String} sChartDisplay - the data source that the user wants to view
         * @return {void}
         */
        updateChartBinding: function(sChartDisplay) {
            this.oVizFrame.removeAllFeeds();
            this.oTable.removeAllColumns();

            var oSorter = new sap.ui.model.Sorter("Days", true),
                oDataset,
                oFeedCategoryAxis,
                oFeedValueAxis,
                oDataModel,
                oTableTemplate,
                aCoulums;

            switch (sChartDisplay) {
                case "roles":
                    oDataModel = this.oRoleChartModel;
                    oDataset = this.datasetRole;
                    oFeedCategoryAxis = this.feedRoleCategoryAxis;
                    oFeedValueAxis = this.feedDaysValueAxis;
                    oTableTemplate = this.oRoleTableTemplate;
                    aCoulums = this.aRoleColumns;
                    break;
                case "services":
                    oDataModel = this.oServiceChartModel;
                    oDataset = this.datasetService;
                    oFeedCategoryAxis = this.feedServiceCategoryAxis;
                    oFeedValueAxis = this.feedDaysValueAxis;
                    oTableTemplate = this.oServiceTableTemplate;
                    aCoulums = this.aServiceColumns;
                    break;
                case "qualifications":
                    oDataModel = this.oQualificationChartModel;
                    oDataset = this.datasetQualification;
                    oFeedCategoryAxis = this.feedQualificationCategoryAxis;
                    oFeedValueAxis = this.feedDaysValueAxis;
                    oTableTemplate = this.oQualificationTableTemplate;
                    aCoulums = this.aQualificationColumns;
                    break;
                case "nonproddays":
                    oDataModel = this.oNonProdChartModel;
                    oDataset = this.datasetNonProd;
                    oFeedCategoryAxis = this.feedNonProdCategoryAxis;
                    oFeedValueAxis = this.feedDaysValueAxis;
                    oTableTemplate = this.oNonProdDaysTableTemplate;
                    aCoulums = this.aNonProDaysColumns;
                    break;
                case "activity":
                    oDataModel = this.oActivityChartModel;
                    oDataset = this.datasetActivity;
                    oFeedCategoryAxis = this.feedActivityCategoryAxis;
                    oFeedValueAxis = this.feedDaysValueAxis;
                    oTableTemplate = this.oActivityColumnsTableTemplate;
                    aCoulums = this.aActivityColumns;
                    break;
                case "resourceorigin":
                    oDataModel = this.oResourceOriginChartModel;
                    oDataset = this.datasetResourceOrigin;
                    oFeedCategoryAxis = this.feedResourceOriginCategoryAxis;
                    oFeedValueAxis = this.feedResCountValueAxis;
                    oTableTemplate = this.oResoruceOriginTableTemplate;
                    aCoulums = this.aResourceOriginColumns;
                    break;
            }

            this.oVizFrame.setModel(oDataModel, "StaffedDetailsChart");
            this.oVizFrame.setDataset(oDataset);
            this.oVizFrame.addFeed(oFeedCategoryAxis);
            this.oVizFrame.addFeed(oFeedValueAxis);

            for (var i = aCoulums.length - 1; i >= 0; i--) {
                this.oTable.addColumn(aCoulums[i]);
            }
            this.oTable.setModel(oDataModel);
            this.oTable.bindItems({
                path: "/",
                template: oTableTemplate,
                sorter: oSorter                
            });

        },

        /**
         * Initialises the chart with its properties, feeds and datasets to be used
         *
         * @private
         * @return {void}
         */
        _initVizFrame: function() {
            this.oVizFrame.setVizProperties(this.oVizProperties);
            this._initFeeds();
            this._initDatasets();
        },

        /**
         * Initialises the table with its columns and templates to be used
         *
         * @private
         * @return {void}
         */
        _initTable: function() {
            this._initColumns();
            this._initTemplates();
        },

        /**
         * Initialises the columns to be used by the table for each data source
         *
         * @private
         * @return {void}
         */
        _initColumns: function() {
            this.aRoleColumns = [
                new sap.m.Column({ header: new sap.m.Label({ text: i18nCapacity.getText("FRAGMENT_STAFFED_DETAILS_COLUMN_DAYS") }) }),
                new sap.m.Column({ header: new sap.m.Label({ text: i18nCapacity.getText("FRAGMENT_STAFFED_DETAILS_COLUMN_ROLES") }) })
            ];

            this.aServiceColumns = [
                new sap.m.Column({ header: new sap.m.Label({ text: i18nCapacity.getText("FRAGMENT_STAFFED_DETAILS_COLUMN_DAYS") }) }),
                new sap.m.Column({ header: new sap.m.Label({ text: i18nCapacity.getText("FRAGMENT_STAFFED_DETAILS_COLUMN_SERVICES") }) })
            ];

            this.aQualificationColumns = [
                new sap.m.Column({ header: new sap.m.Label({ text: i18nCapacity.getText("FRAGMENT_STAFFED_DETAILS_COLUMN_DAYS") }) }),
                new sap.m.Column({ header: new sap.m.Label({ text: i18nCapacity.getText("FRAGMENT_STAFFED_DETAILS_COLUMN_QUALIFICATIONS") }) })
            ];

            this.aNonProDaysColumns = [
                new sap.m.Column({ header: new sap.m.Label({ text: i18nCapacity.getText("FRAGMENT_STAFFED_DETAILS_COLUMN_DAYS") }) }),
                new sap.m.Column({ header: new sap.m.Label({ text: i18nCapacity.getText("FRAGMENT_STAFFED_DETAILS_COLUMN_NONPROD") }) })
            ];

            this.aActivityColumns = [
                new sap.m.Column({ header: new sap.m.Label({ text: i18nCapacity.getText("FRAGMENT_STAFFED_DETAILS_COLUMN_DAYS") }) }),
                new sap.m.Column({ header: new sap.m.Label({ text: i18nCapacity.getText("FRAGMENT_STAFFED_DETAILS_COLUMN_ACTIVITY") }) })
            ];

            this.aResourceOriginColumns = [
                new sap.m.Column({ header: new sap.m.Label({ text: i18nCapacity.getText("FRAGMENT_STAFFED_DETAILS_COLUMN_RESOURCES") }) }),
                new sap.m.Column({ header: new sap.m.Label({ text: i18nCapacity.getText("FRAGMENT_STAFFED_DETAILS_COLUMN_RESOURCE_ORIGIN") }) })
            ];
        },

        /**
         * Initialises the templates to be used by the table for each data source
         *
         * @private
         * @return {void}
         */
        _initTemplates: function() {
            this.oRoleTableTemplate = new sap.m.ColumnListItem({
                cells: [
                    new sap.m.Label({ text: "{Role}" }),
                    new sap.m.Label({ text: "{Days}" })
                ]
            });

            this.oServiceTableTemplate = new sap.m.ColumnListItem({
                cells: [
                    new sap.m.Label({ text: "{ServiceText}" }),
                    new sap.m.Label({ text: "{Days}" })
                ]
            });

            this.oQualificationTableTemplate = new sap.m.ColumnListItem({
                cells: [
                    new sap.m.Label({ text: "{QDesc}" }),
                    new sap.m.Label({ text: "{Days}" })
                ]
            });

            this.oNonProdDaysTableTemplate = new sap.m.ColumnListItem({
                cells: [
                    new sap.m.Label({ text: "{TalDes}" }),
                    new sap.m.Label({ text: "{Days}" })
                ]
            });

            this.oActivityColumnsTableTemplate = new sap.m.ColumnListItem({
                cells: [
                    new sap.m.Label({ text: "{ActName}" }),
                    new sap.m.Label({ text: "{Days}" })
                ]
            });

            this.oResoruceOriginTableTemplate = new sap.m.ColumnListItem({
                cells: [
                    new sap.m.Label({ text: "{OrgText}" }),
                    new sap.m.Label({ text: "{ResCount}" })
                ]
            });

        },

        /**
         * Initialises the models to be used by the chart/table for each data source
         *
         * @private
         * @return {void}
         */
        _initModels: function() {
            this.oRoleChartModel = new sap.ui.model.json.JSONModel([{}]);
            this.oServiceChartModel = new sap.ui.model.json.JSONModel([{}]);
            this.oQualificationChartModel = new sap.ui.model.json.JSONModel([{}]);
            this.oNonProdChartModel = new sap.ui.model.json.JSONModel([{}]);
            this.oActivityChartModel = new sap.ui.model.json.JSONModel([{}]);
            this.oResourceOriginChartModel = new sap.ui.model.json.JSONModel([{}]);
        },

        /**
         * Initialises the dimension/measure feeds to be used by the chart for each data source
         *
         * @private
         * @return {void}
         */
        _initFeeds: function() {
            // Dimension Feeds
            this.feedRoleCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                "uid": "color",
                "type": "Dimension",
                "values": ["Role"]
            });
            this.feedServiceCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                "uid": "color",
                "type": "Dimension",
                "values": ["ServiceText"]
            });
            this.feedQualificationCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                "uid": "color",
                "type": "Dimension",
                "values": ["QDesc"]
            });
            this.feedNonProdCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                "uid": "color",
                "type": "Dimension",
                "values": ["TalDes"]
            });
            this.feedActivityCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                "uid": "color",
                "type": "Dimension",
                "values": ["ActName"]
            });
            this.feedResourceOriginCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                "uid": "color",
                "type": "Dimension",
                "values": ["OrgText"]
            });

            // Measure Feeds
            this.feedDaysValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                "uid": "size",
                "type": "Measure",
                "values": ["Days"]
            });
            this.feedResCountValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                "uid": "size",
                "type": "Measure",
                "values": ["ResCount"]
            });
        },

        /**
         * Initialises the datasets to be used by the chart for each data source
         *
         * @private
         * @return {void}
         */
        _initDatasets: function() {
            this.datasetRole = new sap.viz.ui5.data.FlattenedDataset({
                dimensions: [{
                    name: 'Role',
                    value: "{Role}"
                }],
                measures: [{
                    name: 'Days',
                    value: '{Days}'
                }],
                data: {
                    path: "StaffedDetailsChart>/"
                }
            });
            this.datasetService = new sap.viz.ui5.data.FlattenedDataset({
                dimensions: [{
                    name: 'ServiceText',
                    value: "{ServiceText}"
                }],
                measures: [{
                    name: 'Days',
                    value: '{Days}'
                }],
                data: {
                    path: "StaffedDetailsChart>/"
                }
            });
            this.datasetQualification = new sap.viz.ui5.data.FlattenedDataset({
                dimensions: [{
                    name: 'QDesc',
                    value: "{QDesc}"
                }],
                measures: [{
                    name: 'Days',
                    value: '{Days}'
                }],
                data: {
                    path: "StaffedDetailsChart>/"
                }
            });
            this.datasetNonProd = new sap.viz.ui5.data.FlattenedDataset({
                dimensions: [{
                    name: 'TalDes',
                    value: "{TalDes}"
                }],
                measures: [{
                    name: 'Days',
                    value: '{Days}'
                }],
                data: {
                    path: "StaffedDetailsChart>/"
                }
            });
            this.datasetActivity = new sap.viz.ui5.data.FlattenedDataset({
                dimensions: [{
                    name: 'ActName',
                    value: "{ActName}"
                }],
                measures: [{
                    name: 'Days',
                    value: '{Days}'
                }],
                data: {
                    path: "StaffedDetailsChart>/"
                }
            });
            this.datasetResourceOrigin = new sap.viz.ui5.data.FlattenedDataset({
                dimensions: [{
                    name: 'OrgText',
                    value: "{OrgText}"
                }],
                measures: [{
                    name: 'ResCount',
                    value: '{ResCount}'
                }],
                data: {
                    path: "StaffedDetailsChart>/"
                }
            });
        }

    };
});
