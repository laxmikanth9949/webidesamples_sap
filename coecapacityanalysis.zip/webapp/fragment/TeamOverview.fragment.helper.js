sap.ui.define([
    "sap/coe/capacity/analysis/util/i18n",
    "sap/coe/capacity/analysis/util/PopoverHelper",
    "sap/coe/capacity/analysis/util/VizFrameHelper",
    "sap/coe/capacity/analysis/util/dateHelper",
    "sap/coe/capacity/analysis/util/formatter"
], function(i18nCapacity, PopoverHelper, VizFrameHelper, dateHelper, formatter) {
    "use strict";

    return {
        sFragmentId: "TeamOverview",

        oVizProperties: {
            title: {
                visible: true,
                text: i18nCapacity.getText("FRAGMENT_TEAM_OVERVIEW_CHART_TITLE")
            },
            plotArea: {
                dataLabel: {
                    visible: true
                },
                dataShape: {
                    primaryAxis: ["line", "bar", "bar", "bar", "bar", "bar"]
                },
                dataPointStyle: {
                    "rules": [
                    {
                        "dataContext": { "TotalCapacity": "*" },
                        "properties": {
                            "color": "black",
                            "lineColor":"black",
                            "lineType":"line"
                        },
                        "displayName": i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_MEASURE_TOTAL_CAPACITY")

                    }, {
                         "dataContext": { "AvailableCapacity": "*" },
                        "properties": {
                            "color": "#848f94"
                        },
                        "displayName": i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_MEASURE_AVAILABLE_CAPACITY")
                    }, {
                        "dataContext": { "UnstaffedDemDays": "*" },
                        "properties": {
                            "color": "#de890d"
                        },
                        "displayName": i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_MEASURE_UNSTAFFED_DEMAND")
                    },
                        //Demand Forecast feature on hold until Wave 3 2017
/*                        "dataContext": { "DemandForecast": "*" },
                        "properties": {
                            "color": "#f2d249"
                        },
                        "displayName": i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_MEASURE_DEMAND_FORECAST")
                    }, {*/
                       {
                       "dataContext": { "StaffedDemDays": "*" },
                        "properties": {
                            "color": "#3fa45b"
                        },
                        "displayName": i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_MEASURE_STAFFED_DEMAND")
                    }]
                }
            },
            valueAxis: {
                title: {
                    visible: false
                }
            },
            interaction: {
                selectability: {
                    plotLassoSelection: false,
                    legendSelection: false
                }
            }
        },

        /**
         * Initialises the fragment for staffedDetails and models, etc.
         *
         * @public
         * @param {sap.ui.core.mvc.Controller} oMainController - the controller of the main view
         * @return {void}
         */
        onInit: function(oMainController) {
            this.oMainController = oMainController;
            this.oMainView = oMainController.getView();
            this.oVizFrame = this.byId("idVizFrame");

            this._initVizFrame();
            this.oChartModel = new sap.ui.model.json.JSONModel([{}]);
            this.oVizFrame.setModel(this.oChartModel, "TeamOverview");
            this.qualificationViewDisplayed = false;

            this.oCancelIcon = new sap.ui.core.Icon({ src: "sap-icon://decline", press: jQuery.proxy(this.closeQualifications, this), tooltip: i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_CLOSE_QUALIFICATIONS_TOOLTIP"), useIconTooltip: false });
        },

        /**
         * Called when the TeamOverview tab is loaded and sets the chart model
         *
         * @public
         * @return {void}
         */
        onLoadTab: function() {
            this.oVizFrame.setModel(this.oChartModel, "TeamOverview");
        },

        /**
         * Sets the data returned from the data service to a model
         *
         * @public
         * @param {Array} aResponse - the data returned from the server for service information
         * @return {void}
         */
        onResponseData: function(aResponse) {
            this.oChartModel = new sap.ui.model.json.JSONModel(aResponse);
            this.oVizFrame.setModel(this.oChartModel, "TeamOverview");
        },

        /**
         * Sets the data returned from the Capacity service to a model and binds it to the view
         *
         * @public
         * @param {Object} response - the data returned from the server for capacity information
         * @return {void}
         */
        onResponseCapacity: function(response) {
            var oCapacityData = response,
                oModel;

            oModel = new sap.ui.model.json.JSONModel(oCapacityData);
            this.oMainView.setModel(oModel, "TeamOverviewTile");
        },

        /**
         * Retrieves a controller from the fragment based on their id
         *
         * @public
         * @param {String} sControl - the id of the control to be returned
         * @return {Object} - returns the retrieved object (if found)
         */
        byId: function(sControl) {
            return this.oMainView.byId(this.sFragmentId + "--" + sControl);
        },

        /**
         * Switches the TeamOverview chart to display the Qualification view
         *
         * @public
         * @return {void}
         */
        showQualificationView: function() {
            var oChartContainer = this.byId("idChartContainer");

            // checks the amount of icons in the bar to prevent adding duplicate 'cancel' icons
            if (oChartContainer.getCustomIcons().length === 1) {
                oChartContainer.addCustomIcon(this.oCancelIcon);
            }

            this.qualificationViewDisplayed = true;
            this.oVizFrame.removeAllFeeds();

            this.oVizFrame.setModel(this.oQualChartModel, "QualificationDetailsChart");
            this.oVizFrame.setDataset(this.oQualificationDataset);
            this.oVizFrame.addFeed(this.oQualificationFeedCategoryAxis);
            this.oVizFrame.addFeed(this.oQualificationFeedValueAxis);
        },

        /**
         * Closes the qualification view and changes back to the TeamOverview chart
         *
         * @public
         * @return {void}
         */
        closeQualifications: function() {
            this.oVizFrame.removeAllFeeds();
            this.qualificationViewDisplayed = false;

            this.oVizFrame.setModel(this.oChartModel, "TeamOverview");
            this.oVizFrame.setDataset(this.oTeamOverviewDataset);
            this._addFeeds();

            // remove the delete icon from the toolbar
            this.byId("idChartContainer").removeCustomIcon(1);
        },

        /**
         * Sets the correct filters to be used and passes them to the function to read the oData service
         *
         * @public
         * @param {Object} oCwDates - the start/end dates of the selected calendar week
         * @return {void}
         */
        getQualificationForSelection: function(oCwDates) {
            var aQualFilters = this.oMainController.getFilters();

            for (var i = 0; i < aQualFilters.length; i++) {
                if (aQualFilters[i].sPath === "BegDate") {
                    aQualFilters[i].oValue1 = oCwDates.startDate;
                } else if (aQualFilters[i].sPath === "EndDate") {
                    aQualFilters[i].oValue1 = oCwDates.endDate;
                }
            }

            this.oMainController.readQualificationViewData(aQualFilters);
        },

        /**
         * Retrieve and prepare the filters to be used in worklist application and open the app in a new tab.
         *
         * @public
         * @param {Array} aCwDates - the start/end dates of the selected calendar weeks
         * @param {Array} aQualificationsId - the qualifications selected in the chart
         * @return {void}
         */
        navigateToWorklist: function(aCwDates, aQualificationsId) {
            var aFilters = this.oMainController.getFilters(),
                oCWDateStart = dateHelper.getDateRangeFromCalendarWeek(aCwDates[0]),
                oCWDateEnd = dateHelper.getDateRangeFromCalendarWeek(aCwDates[aCwDates.length - 1]),
                aWorklistRequiredParameters = ["BegDate", "EndDate", "OrgId", "DemandServiceTeam", "DemandQualification"],
                oWorklistParam = {},
                oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"),
                sHash,
                sTargetUrl;

            // temp fix for bug with the time zones and calendar week dates, may need to refactor this in the future
            //oCWDateStart.startDate.setHours(0, 0, 0);
            //oCWDateStart.startDate = formatter.removeTimeOffset(oCWDateStart.startDate);
            //oCWDateEnd.endDate = formatter.removeTimeOffset(oCWDateEnd.endDate);

            for (var i = 0; i < aFilters.length; i++) {
                if (aWorklistRequiredParameters.indexOf(aFilters[i].sPath) > -1) {
                    if (aFilters[i].sPath === "BegDate") {
                        oWorklistParam[aFilters[i].sPath] = oCWDateStart.startDate;
                    } else if (aFilters[i].sPath === "EndDate") {
                        oWorklistParam[aFilters[i].sPath] = oCWDateEnd.endDate;
                    } else {
                        if (!oWorklistParam[aFilters[i].sPath]) oWorklistParam[aFilters[i].sPath] = [];
                        oWorklistParam[aFilters[i].sPath].push(aFilters[i].oValue1);
                    }
                }
            }

            if (aQualificationsId.length) oWorklistParam["DemandQualification"] = [];
            for (i = 0; i < aQualificationsId.length; i++) {
                oWorklistParam["DemandQualification"].push(aQualificationsId[i]);
            }

            sHash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                target: {
                    semanticObject: "planningcalendar",
                    action: "Display"
                },
                params: oWorklistParam
            })) || "";

            this.oVizFrame.vizSelection([], { clearSelection: true });

            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: sHash
                }
            });
        },

        /**
         * Sets the oData response to the chart model and calls the function to switch the chart view
         *
         * @public
         * @param {Array} aResponse - the data retrieved from the oData service
         * @return {void}
         */
        onResponseQualData: function(aResponse) {
            var fNonEmptyQualifications = function(oEntry) {
                return parseInt(oEntry.TotalCapacity, 10) > 0;
            };

            aResponse = aResponse.filter(fNonEmptyQualifications);
            this.oQualChartModel.setProperty("/", aResponse);
            this.showQualificationView();
        },

        /**
         * Initialises the chart with its properties and feed to be used
         *
         * @private
         * @return {void}
         */
        _initVizFrame: function() {
            var oPopOver = this._createChartPopover();

            this.oVizFrame = VizFrameHelper.createVizFrame(this, oPopOver);
            this.oVizFrame.setVizProperties(this.oVizProperties);

            this._addFeeds();

            this._initQualificationView();
            this._initTeamOverviewDataset();
            this.oQualChartModel = new sap.ui.model.json.JSONModel([{}]);
        },

        /**
          * `Adds the feeds to the chart to display capacity info
          *
          * @public
          * @return {void}
         */
        _addFeeds: function() {
            var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                    "uid": "valueAxis",
                    "type": "Measure",
                    //Demand Forecast feature on hold until Wave 3 2017
                    "values": ["TotalCapacity", /*"DemandForecast",*/ "AvailableCapacity", "UnstaffedDemDays", "StaffedDemDays"]
                }),
                feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                    "uid": "categoryAxis",
                    "type": "Dimension",
                    "values": [i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_DIMENSION_YEAR"), i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_DIMENSION_CALENDAR_WEEK")]
                });

            this.oVizFrame.addFeed(feedValueAxis);
            this.oVizFrame.addFeed(feedCategoryAxis);
        },

        /**
          * `Creates the popover displayed when user clicks on a calendar week(s)`
          *
          * @public
          * @return {Object} - oParentContext._popover - the newly created popover
         */
        _createChartPopover: function() {
            var oParentContext = this;

            oParentContext._popover = new sap.viz.ui5.controls.Popover({
                customDataControl: function() {
                    var sHTMLContent = "",
                        aSelectedItems = oParentContext.oVizFrame.vizSelection(),
                        iTotalAmount = oParentContext._getTotalAmount(aSelectedItems),
                        aBreakDownData = [],
                        aCwNumbers = oParentContext._getCWsFromSelectionInChart(),
                        oQualifications = oParentContext.qualificationViewDisplayed ? oParentContext._getQualificationsInChart() : [],
                        aQualificationsId = oQualifications.qualID !== undefined ? oQualifications.qualID : [],
                        aQualificationsNames = oQualifications.qualName,
                        oCwDates = {},
                        oUnstaffedDemandButton = {
                            id: "UnstaffedDemandButton",
                            type: "action",
                            text: i18nCapacity.getText("FRAGMENT_TEAM_OVERVIEW_POPOVER_STAFF_UNSTAFFED_DEMAND_BUTTON"),
                            press: jQuery.proxy(oParentContext.navigateToWorklist, oParentContext, aCwNumbers, aQualificationsId)
                        };

                    if (aSelectedItems.length === 0) {
                        setTimeout(function() {
                            oParentContext._popover.close();
                        }, 400);
                        return;
                    }

                    aBreakDownData = oParentContext._getExtraData(oParentContext, aSelectedItems);
                    aSelectedItems = PopoverHelper.combineBarValues(aSelectedItems, 3);

                    oParentContext._attachPercentageValuesToSelectedItems(aSelectedItems, iTotalAmount);

                    var sCWTtile = i18nCapacity.getText("FRAGMENT_TEAM_OVERVIEW_POPOVER_STAFF_UNSTAFFED_DEMAND_WEEKS_LABEL")
                        + ": "
                        + aCwNumbers.join(", ");
                    sHTMLContent += PopoverHelper.createHTMLContentForTopRow(sCWTtile);

                    if (oParentContext.qualificationViewDisplayed) {
                        var sQualTtile = i18nCapacity.getText("FRAGMENT_TEAM_OVERVIEW_POPOVER_QUALIFICATION_UNSTAFFED_DEMAND_WEEKS_LABEL")
                            + ": "
                            + aQualificationsNames.join(", ");
                        sHTMLContent += PopoverHelper.createHTMLContentForTopRow(sQualTtile);
                    }

                    sHTMLContent += PopoverHelper.createHTMLContent(
                        aSelectedItems,
                        oParentContext.oVizProperties.plotArea.dataPointStyle.rules,
                        i18nCapacity.getText("FRAGMENT_TEAM_OVERVIEW_POPOVER_TOTAL_DEMAND"),
                        3);

                    if (!oParentContext.qualificationViewDisplayed) {
                        sHTMLContent += PopoverHelper.createHTMLBreakdown(
                            aBreakDownData,
                            i18nCapacity.getText("FRAGMENT_TEAM_OVERVIEW_POPOVER_STAFFED_DEMAND_BREAKDOWN"));
                    }

                    sHTMLContent += PopoverHelper.createHTMLDemandOvercapacity(aBreakDownData);

                    // display qualification view if theres only one CW selected
                    if (oParentContext.oVizFrame.vizSelection().length <= 5 && !oParentContext.qualificationViewDisplayed) {
                        // get the start and end date of the CW selected

                        oCwDates = dateHelper.getDateRangeFromCalendarWeek(aCwNumbers[0]);
                        oCwDates.startDate.setHours(0, 0, 0);
                        oCwDates.endDate.setHours(23, 59, 59);
                        oCwDates.startDate = formatter.removeTimeOffset(oCwDates.startDate);
                        oCwDates.endDate = formatter.removeTimeOffset(oCwDates.endDate);

                        oParentContext._popover.setActionItems([{
                            id: "oQualificationButton",
                            type: "action",
                            text: i18nCapacity.getText("FRAGMENT_TEAM_OVERVIEW_POPOVER_QUALIFICATION_VIEW_BUTTON"),
                            press: jQuery.proxy(oParentContext.getQualificationForSelection, oParentContext, oCwDates)
                        }, oUnstaffedDemandButton]);
                    } else {
                        oParentContext._popover.setActionItems([oUnstaffedDemandButton]);
                    }

                    return new sap.ui.core.HTML({ content: sHTMLContent });
                }
            });
            oParentContext._popover.addStyleClass("selectionPopover");
            return oParentContext._popover;
        },

        /**
          * Gets the currently selected week numbers from the chart
          *
          * @public
          * @return {Array} - sorted array of CW's
         */
        _getCWsFromSelectionInChart: function() {
            var aSelectedItems = this.oVizFrame.vizSelection(),
                aCWs = [];

            for (var i = 0; i < aSelectedItems.length; i++) {
                if (!this.qualificationViewDisplayed) {
                    aCWs.push(aSelectedItems[i].data["Calendar Week"].split(" ")[1]);
                } else {
                    aCWs.push(aSelectedItems[i].data["CW"].split(" ")[1]);
                    return aCWs;
                }
            }
            aCWs = aCWs.filter(function(item, pos) {
                return aCWs.indexOf(item) === pos;
            });

            return aCWs.sort();
        },

        /**
          * When displaying the qualifications, gets the qualifications that have been selected from the chart
          *
          * @public
          * @return {Array} - aQuID - the list of qualifications
         */
        _getQualificationsInChart: function() {
            var aSelectedItems = this.oVizFrame.vizSelection(),
                oQualifications = {"qualID": [],"qualName": []},
                aQuID = [],
                aQuName = [];

            for (var i = 0; i < aSelectedItems.length; i++) {
                aQuID.push(this.oVizFrame.getModel("QualificationDetailsChart").getProperty("/" + aSelectedItems[i].data._context_row_number).QId);
                aQuName.push(this.oVizFrame.getModel("QualificationDetailsChart").getProperty("/" + aSelectedItems[i].data._context_row_number).QDesc);
            }

            aQuID = aQuID.filter(function(item, pos) {
                return aQuID.indexOf(item) === pos;
            });

            aQuName = aQuName.filter(function(item, pos) {
                return aQuName.indexOf(item) === pos;
            });

            oQualifications.qualID = aQuID.sort();
            oQualifications.qualName = aQuName.sort();

            return oQualifications;
        },

        /**
          * Creates the dateset and feeds needed for qualification chart
          *
          * @public
          * @return {void}
         */
        _initQualificationView: function() {
            this.oQualificationDataset = new sap.viz.ui5.data.FlattenedDataset({
                dimensions: [{
                    name: 'Qualifications',
                    value: "{QDesc}"
                }, {
                    name: 'CW',
                    value: "{path:'CW' , formatter: 'sap.coe.capacity.analysis.util.formatter.addTextToCW'}"
                }],
                measures: [{
                    name: 'TotalCapacity',
                    value: '{TotalCapacity}'
                }, {
                    name: 'AvailableCapacity',
                    value: '{AvailableCapacity}'
                }, {
                    name: 'UnstaffedDemDays',
                    value: '{UnstaffedDemDays}'
                }, {
                    name: 'StaffedDemDays',
                    value: '{StaffedDemDays}'
                }
                //Demand Forecast feature on hold until Wave 3 2017
/*                , {
                    name: 'DemandForecast',
                    value: '{DemandForecast}'
                }*/
                ],
                data: {
                    path: "QualificationDetailsChart>/"
                }
            });

            this.oQualificationFeedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                "uid": "valueAxis",
                "type": "Measure",
                //Demand Forecast feature on hold until Wave 3 2017
                "values": ["TotalCapacity", /*"DemandForecast",*/ "AvailableCapacity", "UnstaffedDemDays", "StaffedDemDays"]
            });

            this.oQualificationFeedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                "uid": "categoryAxis",
                "type": "Dimension",
                "values": ["CW", "Qualifications"]
            });
        },

        /**
          * Creates the datasets and axis for displaying the capacity data
          *
          * @public
          * @return {void}
         */
        _initTeamOverviewDataset: function() {
            this.oTeamOverviewDataset = new sap.viz.ui5.data.FlattenedDataset({
                dimensions: [{
                    name: i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_DIMENSION_CALENDAR_WEEK"),
                    value: "{path:'CW' , formatter: 'sap.coe.capacity.analysis.util.formatter.addTextToCW'}"
                }, {
                    name: i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_DIMENSION_YEAR"),
                    value: "{path:'CW' , formatter: 'sap.coe.capacity.analysis.util.formatter.getCWYear'}"
                }],
                measures: [{
                    name: 'UnstaffedDemDays',
                    value: '{UnstaffedDemDays}'
                }, {
                    name: 'AvailableCapacity',
                    value: '{AvailableCapacity}'
                }, {
                    name: 'StaffedDemDays',
                    value: '{StaffedDemDays}'
                }, {
                    name: 'TotalCapacity',
                    value: '{TotalCapacity}'
                }
                //Demand Forecast feature on hold until Wave 3 2017
/*                , {
                    name: 'DemandForecast',
                    value: '{DemForecast}'
                }*/
                ],
                data: {
                    path: "TeamOverview>/"
                }
            });
        },

        /**
          * Gets the breakdown data of the selected item(s) from the chart to display in the popover
          *
          * @public
          * @param {Object} oParentContext
          * @param {Array} aSelectedItems - the items(s) selected in the chart
          * @return {Array} aExtraData - 
         */
        _getExtraData: function(oParentContext, aSelectedItems) {
            var aExtraData = [],
                oSelectedDataFromModel,
                sBindingPathOfSelectedItem,
                sModelName = "TeamOverview";

            if (this.qualificationViewDisplayed) {
                sModelName = "QualificationDetailsChart";
            }

            for (var i = 0; i < aSelectedItems.length; i += 4) {
                //The _context_row_number is the index of the selected bas in the model/chart.
                sBindingPathOfSelectedItem = "/" + aSelectedItems[i].data._context_row_number;
                oSelectedDataFromModel = oParentContext.oVizFrame.getModel(sModelName).getProperty(sBindingPathOfSelectedItem);

                aExtraData.push(oSelectedDataFromModel);
            }

            return aExtraData;
        },

        /**
          * Calculates property value as a percentage of 'Total Capacity'
          *
          * @public
          * @param {Array} aSelectedItems - the selected item(s) from the chart
          * @param {Integer} iTotalValue - 
         */
        _attachPercentageValuesToSelectedItems: function(aSelectedItems, iTotalAmount) {
            var iCurrentValue = 0,
                sAttributeDayName;

            for (var i = 0; i < aSelectedItems.length; i++) {
                sAttributeDayName = this._getPropertyNameForPercentage(Object.keys(aSelectedItems[i].data), this.oVizProperties.plotArea.dataPointStyle.rules);

                iCurrentValue = parseFloat(aSelectedItems[i].data[sAttributeDayName]);
                aSelectedItems[i].data.percentage = iCurrentValue / iTotalAmount;
            }
        },

        /**
          * Gets the property name based off current item to be calculated
          *
          * @public
          * @param {Array} aSelectedItems - the selected item(s) from the chart
          * @param {Array} aRules - items displayed
         */
        _getPropertyNameForPercentage: function(aSelectedBarKeys, aRules) {
            var sPropertyName,
                iIndexFound;

            for (var i = 0; i < aRules.length; i++) {
                sPropertyName = Object.keys(aRules[i].dataContext)[0];
                iIndexFound = aSelectedBarKeys.indexOf(sPropertyName);
                if (iIndexFound !== -1) {
                    return aSelectedBarKeys[iIndexFound];
                }
            }

            return "";
        },

        /**
          * Sets the oData response to the chart model and calls the function to switch the chart view
          *
          * @public
          * @param {Array} aSelectedItems - the selected item(s) from the chart
          * @return {Integer} iTotalValue - 
         */
        _getTotalAmount: function(aSelectedItems) {
            var iTotalValue = 0;

            for (var i = 0; i < aSelectedItems.length; i++) {

                if (aSelectedItems[i].data["TotalCapacity"]) {
                    iTotalValue += aSelectedItems[i].data["TotalCapacity"];
                }
            }

            return iTotalValue;
        }

    };
});
