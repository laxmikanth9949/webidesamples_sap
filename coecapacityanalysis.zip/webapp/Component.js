sap.ui.getCore().loadLibrary("sap.coe.capacity.reuselib", jQuery.sap.getModulePath("sap.coe.capacity.analysis") + "/reuselib/src/sap/coe/capacity/reuselib/");

sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/coe/capacity/reuselib/utils/DataManager"
], function(UIComponent, DataManager) {
	"use strict";

	return UIComponent.extend("sap.coe.capacity.analysis.Component", {
		metadata: {
			manifest: "json",
			"config": {
				fullWidth: true,
				titleResource: "APPLICATION_TITLE_CAPACITY_ANALYSIS",
				resourceBundle: "i18n/messageBundle.properties",
				/* eslint-disable sap-no-hardcoded-url */
				"jamResource": "https://jam4.sapjam.com/groups/about_page/iDrRymI7rWhoNrog2NpHea",
				/* eslint-enable sap-no-hardcoded-url */
				"categoryResource": "IMFIT_AGS_CRM_TECH",
				"appName": "APPLICATION_TITLE_CAPACITY_ANALYSIS",
				//IT Launchpad Mobile reporting parameter
				reportingId: "Capacity Analysis",
				reportingHosts: ["myapp.hana.ondemand.com", "fiorilaunchpad.sap.com"]
			}
		},

		/**
		 * Initialize the application
		 *
		 * @returns {sap.ui.core.Control} the content
		 */
		createContent: function() {
			var oViewData = {
				component: this
			};

			return sap.ui.view({
				viewName: "sap.coe.capacity.analysis.view.Main",
				type: sap.ui.core.mvc.ViewType.XML,
				viewData: oViewData
			});
		},

		init: function() {
			// call super init (will call function "create content")
			sap.ui.core.UIComponent.prototype.init.apply(this, arguments);

			var oUserContextModel = new sap.ui.model.json.JSONModel();
			this.setModel(oUserContextModel, "praUserContext");

			// Standalone App
			if (sap.ushell.__sandbox__ || sap.ushell.Container.getUser() === "DEFAULT_USER") {
				DataManager.getUserOrgUnit(this, "", this.setUserModel);
				// FLP
			} else {
				var oUser = sap.ushell.Container.getUser();
				var oUserContext = {
					FirstName: oUser.getFirstName(),
					LastName: oUser.getLastName(),
					FullName: oUser.getFullName(),
					EmpId: oUser.getId(),
					/* eslint-disable sap-no-hardcoded-url */
					BaseURLCRM: "https://" + "icp" /*that.getCRMserverFromSystem(jsonResult.system)*/ + ".wdf.sap.corp/"
					/* eslint-enable sap-no-hardcoded-url */
				};
			}
			oUserContextModel.setProperty("/", oUserContext);

			// initialize Mobile reporting
			this._initMobileUsageReporting();

			// initialize router and navigate to the first page
			this.getRouter().initialize();
			
			// set model with logged-in user details
			this.setLoggedInUser();
		},

		// set the model with data returned from service
		setUserModel: function(oData, aParameters, that) {
			var oUserContext = {
				EmpId: oData.EmpId,
				/* eslint-disable sap-no-hardcoded-url */
				BaseURLCRM: "https://" + "icp" /*that.getCRMserverFromSystem(jsonResult.system)*/ + ".wdf.sap.corp/"
				/* eslint-enable sap-no-hardcoded-url */
			};
			that.getModel("praUserContext").setProperty("/", oUserContext);
			that.getModel("praUserContext").firePropertyChange();
		},
		
		setLoggedInUser: function(){
			var oModel = new sap.ui.model.json.JSONModel("/services/userapi/currentUser");
			this.setModel(oModel, "userModel");
		},

		//IT Launchpad Mobile reporting
		_initMobileUsageReporting: function() {
			// Use Enterprise Mobility "Mobile Usage Reporting" framework
			try {
				/* eslint-disable sap-no-hardcoded-url */
				jQuery.sap.registerModulePath("sap.git.usage", "https://trackingshallwe.hana.ondemand.com/web-client/");
				/* eslint-enable sap-no-hardcoded-url */
				jQuery.sap.require("sap.git.usage.MobileUsageReporting");
				sap.git.usage.MobileUsageReporting.startReporting(this);
			} catch (err) {
				jQuery.sap.log.error("Could not load/inject MobileUsageReporting");
			}
		}
	});

});