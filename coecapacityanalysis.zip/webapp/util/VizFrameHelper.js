sap.ui.define([], function() {
    "use strict";

    var VizFrameHelper = {};

    VizFrameHelper.createVizFrame = function(oParentContext, oPopOver){
        var oVizFrame = oParentContext.byId("idVizFrame");


        VizFrameHelper._hideSelectedBar(oPopOver);
        oPopOver.connect(oVizFrame.getVizUid());

        oVizFrame.attachSelectData(null, function(oEvent) {
            var sAxisValue = oVizFrame.getFeeds()[1].getValues()[oVizFrame.getFeeds()[1].getValues().length - 1];
            if (VizFrameHelper._isBarSelected(oEvent)) {
                var sSelectedOrganisation = oEvent.getParameters().data[0].data[sAxisValue];

                var points = [{ "data": {} }];
                points[0].data[sAxisValue] = sSelectedOrganisation;
                this.vizSelection(points, { clearSelection: false });
            }

        });

        oVizFrame.attachDeselectData(null, function(event) {
            oParentContext.oVizFrame.vizSelection([], { clearSelection: true });
        });

        return oVizFrame;
    };

    VizFrameHelper._hideSelectedBar = function(oPopOver){
        if(oPopOver._Popover === undefined || oPopOver._Popover._oSelectedBar === undefined) return;

        oPopOver._Popover._oSelectedBar.setVisible(false);
    };

    VizFrameHelper._isBarSelected = function(oEvent) {
        return oEvent.getParameters().data.length === 1;
    };

    return VizFrameHelper;
});
