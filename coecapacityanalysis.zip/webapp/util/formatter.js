sap.ui.define([
    "sap/coe/capacity/reuselib/utils/baseclasses/Formatter",
    "sap/coe/capacity/analysis/util/i18n"
], function(FormatterBaseClass, i18nCapacity) {

    FormatterBaseClass.extend("sap.coe.capacity.analysis.util.Formatter", {

        /**
         * Return color code according to the number
         *
         * @param {Integer} iVal The number
         * @return {String} The color code
         * @public
         */
        formatColor: function(iVal) {
            if (iVal > 0) {
                return sap.m.ValueColor.Good;
            } else {
                return sap.m.ValueColor.Critical;
            }
        },

        /**
         * Adds 'CW' text to the week number
         *
         * @param {Integer} iCalWeek The CW number
         * @return {String} sCalWeek The formatted string
         * @public
         */
        addTextToCW: function(iCalWeek) {
            var sText = i18nCapacity.getText("FRAGMENT_CALENDAR_WEEK_TAB"),
                sCalWeek = "";

            if (iCalWeek === undefined || iCalWeek === null) {
                sCalWeek = "";
            } else {
                sCalWeek = sText + " " + iCalWeek.toString(10).substring(4, 6);
            }
            return sCalWeek;
        },

        /**
         * Extracts the CW years from the value returned from backend
         *
         * @param {String} sCalWeek The CW and year number
         * @return {String} The formatted string
         * @public
         */
        getCWYear: function(sCalWeek) {
            if (!sCalWeek || sCalWeek === null) return;

            return sCalWeek.toString(10).substring(0, 4);
        },

        formatProductiveTotal: function(sProductive) {
            var sColor;
            if (sProductive < 0) {
                sColor = ["#5cbae6", "#5cbae6", "#5cbae6", "#dc0d0e"];
            } else {
                sColor = ["#5cbae6", "#5cbae6", "#5cbae6", "#5cbae6"];
            }
            return sColor;
        }

    });

    sap.coe.capacity.analysis.util.formatter = new sap.coe.capacity.analysis.util.Formatter();

    return sap.coe.capacity.analysis.util.formatter;
});
