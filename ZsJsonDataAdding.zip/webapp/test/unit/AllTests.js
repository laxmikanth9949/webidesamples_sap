sap.ui.define([
	"ZsJsonDataAdding/ZsJsonDataAdding/test/unit/controller/Main.controller"
], function () {
	"use strict";
});