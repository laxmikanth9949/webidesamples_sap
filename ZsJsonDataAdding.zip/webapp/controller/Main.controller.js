sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/core/format/NumberFormat",
	"../model/formatter"
], function (Controller, MessageBox, NumberFormat , formatter) {
	"use strict";

	return Controller.extend("ZsJsonDataAdding.ZsJsonDataAdding.controller.Main", {
			formatter: formatter,
		onInit: function () {

			var QuantityData = [{
				"QuantityId": "1"
			}, {
				"QuantityId": "2"
			}, {
				"QuantityId": "3"
			}, {
				"QuantityId": "4"
			}, {
				"QuantityId": "5"
			}, {
				"QuantityId": "6"
			}, {
				"QuantityId": "7"
			}, {
				"QuantityId": "9"
			}, {
				"QuantityId": "10"
			}, {
				"QuantityId": "11"
			}];
			var ojosn = new sap.ui.model.json.JSONModel(QuantityData);

			this.getView().byId("idQuantity").setModel(ojosn);

			/*	var newItem = {
					"ProductName": "test add",
					"Quantity": 21,
					"ExtendedPrice": 87.2000,
					"ShipperName": "Fun Inc.",
					"ShippedDate": "2015-04-01T00:00:00",
					"Status": "A"
				};
				var oModel = this.getOwnerComponent().getModel("invoice");
				oModel.setProperty("/Invoices", oModel.getProperty("/Invoices").concat(newItem));*/
			var jsonmodel = new sap.ui.model.json.JSONModel("model/Invoices.json");
			this.getView().byId("idTable").setModel(jsonmodel);

		},
		onButtonSubmit: function (oEvent) {
			debugger;
			var obj = {};
			obj.ProductName = this.getView().byId("idProduct").getValue();
			obj.Quantity = this.getView().byId("idQuantity").getSelectedItem();
			if (obj.Quantity) {
				obj.Quantity = obj.Quantity.getText();
			} else {
				MessageBox.warning("If Your not selected Quantity \n It will take by defaultly 1");
			}
			obj.ShipperName = this.getView().byId("idShipperName").getValue();
			obj.ShippedDate = oEvent.getSource().getParent().getParent().mAggregations.formElements[3].getFields()[0].getDateValue();
			obj.Status = oEvent.getSource().getParent().getParent().mAggregations.formElements[4].getFields()[0].getSelectedKey();
			obj.ExtendedPrice = this.getView().byId("idPrice").getValue();
			obj.currencyType = this.getView().byId("currencyType").getSelectedItem().getText();

			if (!obj.ProductName) {
				this.getView().byId("idProduct").setValueState("Error");
				return;
			}
			if (!obj.ShipperName) {
				this.getView().byId("idShipperName").setValueState("Error");
				return;
			}
			if (!obj.ShippedDate) {
				this.getView().byId("idShippingData").setValueState("Error");
				return;
			}
			if (!obj.ExtendedPrice) {
				this.getView().byId("idPrice").setValueState("Error");
				return;
			}

			var oModel = this.getOwnerComponent().getModel("invoice");
			oModel.setProperty("/Invoices", oModel.getProperty("/Invoices").concat(obj));
			this.getView().byId("idTable").setModel(oModel);
			this.getView().byId("idTable").getModel().refresh(true);
			this.onClearPress(oEvent);
		},
		onClearPress: function (oEvent) {
			debugger;
			this.getView().byId("idProduct").setValue("");
			this.getView().byId("idQuantity").setSelectedKey("1");
			this.getView().byId("idShipperName").setValue("");
			oEvent.getSource().getParent().getParent().mAggregations.formElements[3].getFields()[0].setValue(" ");
			oEvent.getSource().getParent().getParent().mAggregations.formElements[4].getFields()[0].setSelectedKey("1");
			this.getView().byId("idPrice").setValue("");
			this.getView().byId("idProduct").setValueState("None");
			this.getView().byId("idShipperName").setValueState("None");
			this.getView().byId("idPrice").setValueState("None");
			this.getView().byId("idShippingData").setValueState("None");
			/*	this.productNameChange();
				this.shipperNameChange();
				this.priceChange();
				this.shippingDateChange();*/
		},
		onselectSegmentButton: function (oEvent) {
			debugger;
			var selectdBut = this.getView().byId("idSegmentButton").getSelectedKey();
			if (selectdBut === "1") {
				this.getView().byId("idRangeSlider").setValue(10);
			}
			if (selectdBut === "2") {
				this.getView().byId("idRangeSlider").setValue(20);
			}
			if (selectdBut === "3") {
				this.getView().byId("idRangeSlider").setValue(30);
			}
			if (selectdBut === "4") {
				this.getView().byId("idRangeSlider").setValue(40);
			}
			if (selectdBut === "0") {
				this.getView().byId("idRangeSlider").setValue(-10);
			}
		},
		productNameChange: function (oEvent) {
			var ovalue = oEvent.getSource().getValue();
			if (ovalue) {
				this.getView().byId("idProduct").setValueState("None");
			}
		},
		shipperNameChange: function (oEvent) {
			var ovalue = oEvent.getSource().getValue();
			if (ovalue) {
				this.getView().byId("idShipperName").setValueState("None");
			}
		},
		priceChange: function (oEvent) {
			var ovalue = oEvent.getSource().getValue();
			/*	if (ovalue) {
					this.getView().byId("idPrice").setValueState("None");
					var ocurrencyFormat = new NumberFormat.getCurrencyInstance();
				var formattedRate =	ocurrencyFormat.format(ovalue, "EUR");
				this.getView().byId("idPrice").setValue(formattedRate);
		
				}*/
			var oValue = oEvent.getSource().getValue().replace(/[. ,]/g, '');
			if (oValue > 0) {
				this.getView().byId("idPrice").setValueState("None");
				var oCurrency = new Intl.NumberFormat(navigator.language);
				var oFormatValue = oCurrency.format(oValue);
				this.getView().byId("idPrice").setValue(oFormatValue);
			}

		},
		shippingDateChange: function (oEvent) {
			var ovalue = oEvent.getSource().getValue();
			if (ovalue) {
				this.getView().byId("idShippingData").setValueState("None");
			}
		}
	});
});