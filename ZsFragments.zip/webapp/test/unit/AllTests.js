sap.ui.define([
	"com/sample/ZsFragments/test/unit/controller/View1.controller"
], function () {
	"use strict";
});