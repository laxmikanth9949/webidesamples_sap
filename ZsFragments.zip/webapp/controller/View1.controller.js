sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast"
], function (Controller,MessageToast) {
	"use strict";

	return Controller.extend("com.sample.ZsFragments.controller.View1", {
		onInit: function () {

		},
		onPress:function(){
		//	MessageToast.show("hello world");
		if(!this.oFragment){
		 this.oFragment = sap.ui.xmlfragment("com.sample.ZsFragments.fragments.sample",this);
		//this.getView().addDependent(oFragment);
		}
		this.oFragment.open();
		}
	});
});