MCC Workplace Developer's Guide
======
This guide covers how caveats on how the Workplace 

Coding
------

Important folders/ files are:

/CardComponent: This folder includes all MCCWorkplace cards. On its base level, several boilerplate sourcefiles exist such as BaseCardComponent.js, BaseCardController.js, CardErrorHandler.js, CardFormatter.js, CardODataHandler.js
/controller/: Folder, which includes some additional controller for overall functionality, e.g. BaseController.js, FilterBar.controller.js, ErrorHandler.js and CardIntegration.js
/view/fragments/: Stores all fragments, which are used within the MCC Workplace
/controller/Workplace.controller.js: Starting point to create the application content, e.g. load and display profiles based on the signed in user.
/controller/Workplace.view.xml: Basic view / layout. Many code will be created within controllers (Workplace.controller.js, CarIntegration.js, BaseController.js)

Adding of new profiles
------
Please reach out to Marvin, Aaron or Dominic to create new Profiles.

Necessary steps: Create a new database entry in Table "OVP_OVPROLES".

Adding of new cards
------
Recommended option:

Copy and paste the template card "/webapp/CardComponent/_CARD_TEMPLATE_" in CardComponent folder.
Rename the copied folder to your needs.
Rename all namespaces within all files:
Component.js
Manifest.json
<yourCard>.controller.js
<yourCard.view.xml
Please reach out to Marvin, Aaron or Dominic to create a database entry, which represents your card.
Therefore, please provide the exact name and a description - what use case the card covers or high level description -  of your created folder.

Necessary steps: Create a new database entry in Table "OVP_CARDS".
After the database entry has been created you can add the created card via the "Manage Cards" dialog to your UI.
After that, you can start implementing the logic and user interface.

| CardType  | Description | Parameters |
| --- | --- | --- |
| Table | - | - |
| Action | - | - |
| KPI | - | - |
| Chart | - | - |
| Text | - | - |


Deployment
------
If running the application as standalone, running from index.html, cachebusting might be required so endusers have latest version and don't come accross version conflicts.
whenever shipping a new version, change the ts parameter on <script src="cachebuster.js?ts=202005211200"></script> on [index.html](../master/webapp/index.html#L15).


References
------
[Kanban Board](https://github.wdf.sap.corp/mcc/mcc-ui5-workplace/projects/1)
[Issues Creation](https://github.wdf.sap.corp/mcc/mcc-ui5-workplace/issues/new)
[Technical Documentation](https://jam4.sapjam.com/wiki/show/DV09lPzEvndipEkpikji7x)

Terminology
------
Roles = Profile
UserRoles = ProfileInstance


# Services
------

### OData Services

| Description  | Path | Model Name | Alias | Addional Information |
| --- | --- | --- | --- | --- |
| MCC Workplace Service | [https://mcs-test-approuter.cfapps.eu10.hana.ondemand.com/odata/v2/MCSCardsOVP](https://mcs-test-approuter.cfapps.eu10.hana.ondemand.com/odata/v2/MCSCardsOVP) | MCSCardsOVPModel | _oMCCWorkplaceService | - |

### Other Services

| Description  | Path | Addional Information |
| --- | --- | --- |
| - | - | - |



Copyright (c) 2009-2020 SAP SE or an SAP affiliate company.