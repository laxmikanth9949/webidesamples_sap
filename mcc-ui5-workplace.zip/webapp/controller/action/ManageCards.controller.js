sap.ui.define([
	"com/sap/mcc/workplace/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"com/sap/mcc/workplace/model/formatter"
], function (BaseController, JSONModel, Filter, FilterOperator, Sorter, formatter) {
	"use strict";

	return BaseController.extend("com.sap.mcc.workplace.controller.action.ManageCards", {

			formatter: formatter,

			/* =========================================================== */
			/* lifecycle methods                                           */
			/* =========================================================== */

			onInit: function (oEvent) {
				this._oUserInfo = sap.ui.getCore().getModel("UserInfo");
				this._oDialog = this.byId("ManageCardsDialog");
				this._oMCCWorkplaceService = undefined;
				this._oWorkplaceModel = sap.ui.getCore().getModel("workplaceModel"); // Core Model
			},

			onBeforeRendering: function (oEvent) {
				this._resetModel();
				this._oMCCWorkplaceService = this.getView().getModel("MCSCardsOVPModel");
			},

			/**
			 * on Press event to open Manage Profiles settings
			 */
			onManageCardsOpenPress: function (oEvent) {
				this._oDialog.open();
				this._setDefaultBindingForCardsTable();
			},

			/* =========================================================== */
			/* internal methods                                            */
			/* =========================================================== */

			/**
			 * Initialize ManageProfilesModel
			 */
			_resetModel: function () {
				var oModel = new JSONModel({
					"ProfileInstanceCardsUUID": null,
					"busy": true,
					"changeQ": {
						"visible": []
					},
					"Cards": [],
					"bForceReset": false
				});
				this.getView().setModel(oModel, "ManageCardsModel");
			},

			_setDefaultBindingForCardsTable: function (oEvent) {
					this._resetModel();

					// all Cards
					var oAllCardsPromise = new Promise(function (resolve, reject) {
						this._oMCCWorkplaceService.read("/Cards", {
							success: function (oData) {
								resolve(oData.results);
							},
							error: function (oError) {
								reject(oError);
							}
						});
					}.bind(this));

					// TODO: replace with selected profile from core model
					// all User Profiles
					var oAllProfilesPromise = new Promise(function (resolve, reject) {
						this._oMCCWorkplaceService.read("/UserRoles", {
							urlParameters: {
								$expand: "Cards"
							},
							filters: [new Filter("UserID", FilterOperator.EQ, this._oUserInfo.getProperty("/name"))],
							success: function (oData) {
								resolve(oData.results);
							},
							error: function (oError) {
								reject(oError);
							}
						});
					}.bind(this));

					Promise.all([oAllProfilesPromise, oAllCardsPromise]).then(function (oDataSets) {
							var aAllProfiles = oDataSets[0];
							var aAllCards = oDataSets[1];
							var sSelectedProfileUUID = this._oWorkplaceModel.getProperty("/selectedProfileInstance/ProfileInstanceUUID");

							// find Selected Profile instance
							var oSelectedProfile = aAllProfiles.find(function (oProfile) {
								return sSelectedProfileUUID === oProfile.ID;
							});

							oSelectedProfile.CardOrder = (oSelectedProfile.Cards && oSelectedProfile.Cards.CardOrder) ? oSelectedProfile.Cards.CardOrder.split(
								";") : [];

							// merged version of cards with visible
							aAllCards = aAllCards.map(function (oCard) {
									// prepare dataset for table binding
									delete oCard.__metadata;
									oCard.DefaultRoleText = oCard.DefaultRole;
									oCard.DefaultRole = oCard.DefaultRole ? oCard.DefaultRole.split(";") : [];
									oCard._visible = (oSelectedProfile.CardOrder.indexOf(oCard.CardID) > -1) ? true : false;
									oCard._reset = false;
									
									try {
										var oDescription = JSON.parse(oCard.Description);
										if (typeof oDescription === 'object') {
											oCard.shortDesc = oDescription.shortDesc;
										}
									} catch (error) {
										oCard.shortDesc = "Error" + error;
										console.log(error);
									}

								
								return oCard;
							}.bind(this));

						this.getView().getModel("ManageCardsModel").setProperty("/ProfileInstanceCardsUUID", oSelectedProfile.Cards_ID); this.getView().getModel(
							"ManageCardsModel").setProperty("/Cards", aAllCards); this.getView().getModel("ManageCardsModel").setProperty("/busy", false);
					}.bind(this))
				.catch(function () {
					// TODO: implement catch
				});
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Save Cards Visibility. In case there was previous Cards selected, it will keep the order and add the new cards to the end.
		 */
		onSaveDialogPress: function (oEvent) {
			var sSelectedProfileID = this._oWorkplaceModel.getProperty("/selectedProfileInstance/ProfileInstanceUUID");
			var oManageCardsModel = this.getView().getModel("ManageCardsModel");
			var aCardOrder = [];

			// If reset, apply and save
			if (oManageCardsModel.getProperty("/bForceReset")) {
				if (oManageCardsModel.getProperty("/changeQ/visible").length) { // Reset and some modification after
					oManageCardsModel.getProperty("/Cards").forEach(function (oCard) {
						if (oCard._visible) {
							aCardOrder.push(oCard.CardID);
							return;
						}
					});
				} else { // Reset and no modification after
					aCardOrder = oManageCardsModel.getProperty("/Cards").map(function (oCard) {
						// return only values that is flagged to reset and visible
						return (oCard._reset && oCard._visible) ? oCard.CardID : null;
					});
					// clean empty values
					aCardOrder = aCardOrder.filter(function (sCard) {
						return sCard;
					});
				}
			} else {
				// Maintain same order and append new cards to the end
				// First, check old order and check if cards are still visible (or removed)
				this._oWorkplaceModel.getProperty("/selectedProfileInstance/CardOrder").forEach(function (sCardID) {
					oManageCardsModel.getProperty("/Cards").forEach(function (oCard) {
						// TODO: convert to object instead of array, so we could access it by oCard[CardID]
						if (oCard._visible && sCardID === oCard.CardID) {
							aCardOrder.push(sCardID);
							return;
						}
					});
				});
				// Second, Add new Cards
				oManageCardsModel.getProperty("/Cards").forEach(function (oCard) {
					if (oCard._visible && aCardOrder.indexOf(oCard.CardID) === -1) {
						aCardOrder.push(oCard.CardID);
						return;
					}
				});
			}

			var sProfileInstanceCardsUUID = this.getView().getModel("ManageCardsModel").getProperty("/ProfileInstanceCardsUUID");

			this._oMCCWorkplaceService.update("/CardPositions(guid'" + sProfileInstanceCardsUUID + "')", {
				"CardOrder": aCardOrder ? aCardOrder.join(";") : null
			}, {
				success: function (oData) {
					this._oDialog.close();
					sap.ui.getCore().getEventBus().publish("Card", "refresh", {
						"ProfileAlias": this._oWorkplaceModel.getProperty("/selectedProfileInstance/Alias")
					});
				}.bind(this),
				error: function (oError) {
					// TODO: if cannot finc Card Positions, create one. it might happen sometimes for orphan objects

				}
			});
		},

		/**
		 * Flag Cards to be visible/hidden
		 */
		onCardVisibleChange: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContextPath();
			var sCardID = this.getView().getModel("ManageCardsModel").getProperty(sPath + "/CardID");

			var aVisibleChangeQ = this.getView().getModel("ManageCardsModel").getProperty("/changeQ/visible").concat(); // clone Array;

			if (aVisibleChangeQ.indexOf(sCardID) > -1) { // remove Profile from Visible Queue
				aVisibleChangeQ = aVisibleChangeQ.filter(function (sValue) {
					return sValue !== sCardID;
				});
			} else { // add Profile to Visible Queue
				aVisibleChangeQ.push(sCardID);
			}

			this.getView().getModel("ManageCardsModel").setProperty("/changeQ/visible", aVisibleChangeQ);
		},

		/**
		 * Flag Profile to be reset with Default Cards
		 */
		onResetCardsVisibilityPress: function (oEvent) {
			var sSelectedProfileID = this._oWorkplaceModel.getProperty("/selectedProfileInstance/Alias");
			var aCards = this.getView().getModel("ManageCardsModel").getProperty("/Cards").concat(); // clone Array;

			aCards.forEach(function (oCard) {
				oCard._visible = (oCard.DefaultRole.indexOf(sSelectedProfileID) > -1) ? true : false;
				oCard._reset = true;
			});

			this.getView().getModel("ManageCardsModel").setProperty("/Cards", aCards);
			this.getView().getModel("ManageCardsModel").setProperty("/bForceReset", true);
			this.getView().getModel("ManageCardsModel").setProperty("/changeQ/visible", []);
		},

		/**
		 * On Live Change or Search, filter the Profiles on table
		 */
		onCardSearchOrLiveChange: function (oEvent) {
			var aTableSearchState = [];
			var sQuery = oEvent.getParameter(oEvent.getId() === "search" ? "query" : "newValue");
			var oTable = this.byId("cardTable");

			if (sQuery && sQuery.length > 0) {
				aTableSearchState = [
					new Filter("DefaultRoleText", FilterOperator.Contains, sQuery),
					new Filter("CardName", FilterOperator.Contains, sQuery),
					new Filter("CardID", FilterOperator.Contains, sQuery)
				];
				var oFilter = new Filter({
					filters: aTableSearchState,
					and: false
				});
				oTable.getBinding("items").filter(oFilter, "Application");
			} else {
				oTable.getBinding("items").filter(null, "Application");
			}
		},

		/**
		 * on Cancel Dialog press 
		 */
		onCancelDialogPress: function (oEvent) {
			this._oDialog.close();
		}
	});

});