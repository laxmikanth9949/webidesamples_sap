sap.ui.define([
	"com/sap/mcc/workplace/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/MessageBox"
], function (BaseController, JSONModel, Filter, FilterOperator, Sorter, MessageBox) {
	"use strict";

	return BaseController.extend("com.sap.mcc.workplace.controller.action.ManageProfiles", {

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function (oEvent) {
			this._oUserInfo = sap.ui.getCore().getModel("UserInfo");
			this._oDialog = this.byId("ManageProfilesDialog");
			this._oMCCWorkplaceService = undefined;
			this._oWorkplaceModel = sap.ui.getCore().getModel("workplaceModel"); // Core Model
		},
		onBeforeRendering: function (oEvent) {
			this._resetModel();
			this._oMCCWorkplaceService = this.getView().getModel("MCSCardsOVPModel");
		},

		/**
		 * on Press event to open Manage Profiles settings
		 * @param {sap.ui.base.Event} oEvent open Manage Profiles button is pressed
		 */
		onManageProfilesOpenPress: function (oEvent) {
			this._oDialog.open();
			this._setDefaultBindingForProfilesTable();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Initialize ManageProfilesModel
		 */
		_resetModel: function () {
			var oModel = new JSONModel({
				"busy": true,
				"visibleProfileInstanceTotal": 0,
				"changeQ": {
					"delete": [],
					"visible": [],
					"newEntry": [], // used to match if all Created profiles are validated
					"create": [],
					"position": []
				},
				"Profiles": []
			});
			this.getView().setModel(oModel, "ManageProfilesModel");
		},

		/**
		 *  It will merge the "/Roles" and "/UserRoles" so ManageProfiles view can work on same Binding Context
		 *  a local model is defined, with _visible and _delete tracker for lazy saving
		 * TODO: needs to come filtered from CAP model #ISSUE21
		 */
		_setDefaultBindingForProfilesTable: function () {
			this._resetModel();

			// all User Profiles Cards aka /CardPositions
			// TODO: implement navigation /CardPositions so be bellow code could be replaced
			// all User Profile Cards aka "/CardPositions"
			var oAllUserProfileCardsPromise = new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.read("/CardPositions", {
					filters: [
						new Filter("User", FilterOperator.EQ, this._oUserInfo.getProperty("/name"))
					],
					success: function (oData) {
						resolve(oData.results);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			}.bind(this));

			// all User Profiles
			var oAllProfilesPromise = new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.read("/Roles", {
					filters: [new Filter({
						filters: [
							new Filter("createdBy", FilterOperator.EQ, "Default"),
							new Filter("createdBy", FilterOperator.EQ, this._oUserInfo.getProperty("/name"))
						],
						and: false
					})],
					sorters: [new Sorter("RoleName")],
					success: function (oData) {
						resolve(oData.results);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			}.bind(this));

			// only Visible User Profiles
			var oVisibleProfilesPromise = new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.read("/UserRoles", {
					filters: [new Filter("UserID", FilterOperator.EQ, this._oUserInfo.getProperty("/name"))],
					success: function (oData) {
						resolve(oData.results);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			}.bind(this));

			Promise.all([oAllProfilesPromise, oVisibleProfilesPromise, oAllUserProfileCardsPromise]).then(function (oDataSets) {
					var aAllProfiles = oDataSets[0];
					var aVisibleProfiles = oDataSets[1];
					var aAllUserProfileCard = oDataSets[2];
					var iVisibleProfileInstanceTotal = 0;
					// var aPosition = []; // TODO: implement logic for position of profiles 

					// merged version of profiles with visible and position properties
					var aProfiles = aAllProfiles.map(function (oProfile) {

						// find UserProfileCard
						var oUserProfileCard = aAllUserProfileCard.find(function (oProfileCard) {
							return (oProfileCard.RolesID === oProfile.ID);
						});

						if (oUserProfileCard) {
							oProfile.ProfileInstanceCardID = oUserProfileCard.ID;
						}
						// check if Profile is visible
						var oVisibleProfileTemp = aVisibleProfiles.find(function (oVisibleProfile) {
							return (oVisibleProfile.Roles_ID === oProfile.ID);
						});

						// prepare dataset for table binding
						delete oProfile.__metadata;
						oProfile.Position = null;
						oProfile._create = false;
						oProfile._delete = false;
						oProfile.ProfileInstanceID = null;

						if (oVisibleProfileTemp) {
							oProfile.Position = oVisibleProfileTemp.Position;
							oProfile._visible = true;
							oProfile.ProfileInstanceID = oVisibleProfileTemp.ID;
							iVisibleProfileInstanceTotal++;
						} else {
							oProfile._visible = false;
						}

						return oProfile;
					});
					this.getView().getModel("ManageProfilesModel").setProperty("/visibleProfileInstanceTotal", iVisibleProfileInstanceTotal);
					this.getView().getModel("ManageProfilesModel").setProperty("/busy", false);
					this.getView().getModel("ManageProfilesModel").setProperty("/Profiles", aProfiles);
				}.bind(this))
				.catch(function () {
					// TODO: implement catch
				});
		},

		/**
		 * Validation for Create Profile Name 
		 */
		_validateProfileInput: function (oInput, sRoleID, sID) {
			var sValueState = "None";
			var sValueStateText = null;
			var bIsValid = true;
			var oValue = oInput.getValue();
			// check for alphanumeric and should start with a letter
			var regex = /^[a-z]([a-z0-9 ]+)*$/i;
			if (!oValue.match(regex)) {
				bIsValid = false;
				sValueState = "Error";
				sValueStateText = "Profile Name can only have alphanumeric characters and should start with a letter";
			}

			// check if name was not used before in other Profiles
			this.getView().getModel("ManageProfilesModel").getProperty("/Profiles").forEach(function (oProfile) {
				if ((oProfile.RoleName === oValue || oProfile.RoleID === sRoleID) && oProfile.ID !== sID) {
					bIsValid = false;
					sValueState = "Error";
					sValueStateText = "Profile Name already exists";
				}
			});

			oInput.setValueState(sValueState);
			oInput.setValueStateText(sValueStateText);

			return bIsValid;
		},

		/**
		 *  Create Profile (/Roles)
		 */
		_createProfile: function (sProfileAlias, sProfileName, bVisible, sPosition) {
			var sUserID = this._oUserInfo.getProperty("/name");

			this._oMCCWorkplaceService.create("/Roles", {
				//"CreatedBy": sUserID,
				"RoleID": sProfileAlias,
				"RoleName": sProfileName
			}, {
				success: function (oData) {
					var oCardPosition = {
						"User": sUserID,
						"Profile": sProfileAlias,
						"RolesID": oData.ID
					};

					this._oMCCWorkplaceService.create("/CardPositions", oCardPosition, {
						success: function (oResponse) {
							// Manage visibility of Profile on Workplace
							this._manageProfileInstance(sProfileAlias, sProfileName, bVisible, oData.ID, sPosition);
						}.bind(this),
						error: function (oError) {}
					});
				}.bind(this),
				error: function (oError) {}
			});
		},

		/**
		 * Delete Profile from /Roles and /UserRoles and /CardPositions
		 */
		_deleteProfile: function (sProfileUUID, sProfileInstanceUUID, sProfileInstanceCardUUID, sProfileAlias) {
			// delete "/Roles" instance
			this._oMCCWorkplaceService.remove("/Roles(guid'" + sProfileUUID + "')", {
				success: function (oData) {},
				error: function (oError) {}
			});

			// delete "/Roles" instance
			this._oMCCWorkplaceService.remove("/CardPositions(guid'" + sProfileInstanceCardUUID + "')", {
				success: function (oData) {},
				error: function (oError) {}
			});

			// delete "/UserRoles" instance if it exists
			if (sProfileInstanceUUID) {
				this._oMCCWorkplaceService.remove("/UserRoles(guid'" + sProfileInstanceUUID + "')", {
					success: function (oData) {
						sap.ui.getCore().getEventBus().publish("Profile", "remove", {
							"RoleID": sProfileAlias,
							"Roles_ID": sProfileInstanceUUID
						});
					},
					error: function (oError) {}

				});
			}

		},

		/**
		 * Manages visibility status of Profile Instance
		 */
		_manageProfileInstance: function (sProfileId, sProfileName, bProfileVisible, sUUID, sPosition) {
			// Promise used to refresh workplaceModel
			// START REFRESH OF USERROLES
			var fnUpdateWorplaceModelPromise = function () {
				return new Promise(function (resolve, reject) {
					this._oMCCWorkplaceService.read("/UserRoles", {
						sorters: [new Sorter("Position")],
						urlParameters: {
							$expand: "Roles,Cards,Variants"
						},
						success: function (oData) {
							if (oData.results.length > 0) {
								this._oWorkplaceModel.setProperty("/ProfileInstances", oData.results);
								resolve(oData);
							} else {
								resolve(null);
							}
						}.bind(this),
						error: function (oError) {
							// TODO: implement error
							reject(oError);
						}
					});
				}.bind(this));
			}.bind(this);
			// END REFRESH OF USERROLES

			var bRoleExists = false,
				sProfileInstanceUUID;
			this._oWorkplaceModel.getProperty("/ProfileInstances").find(function (oProfile) {
				if (oProfile.RoleID === sProfileId) {
					bRoleExists = true;
					sProfileInstanceUUID = oProfile.ID;
					return;
				}
			});

			if (bRoleExists && !bProfileVisible) {
				//trigger --> delete --> role is displayed on the ui and the visibility was set to false in the wizard
				this._oMCCWorkplaceService.remove("/UserRoles(guid'" + sProfileInstanceUUID + "')", {
					success: function (oResponse) {
						fnUpdateWorplaceModelPromise.apply(this).then(function () {
							sap.ui.getCore().getEventBus().publish("Profile", "remove", {
								"RoleID": sProfileId,
								"Roles_ID": sUUID
							});
						});
					},
					error: function (oError) {}

				});

			} else if (!bRoleExists && bProfileVisible) {
				// trigger --> create --> role is not visible on the ui but the visibility of the profile was set to true in the wizard

				var fnCreateUserRoles = function (oUserRole) {
					this._oMCCWorkplaceService.create("/UserRoles", oUserRole, {
						success: function (oResponse) {
							fnUpdateWorplaceModelPromise.apply(this).then(function () {
								// Publish EventBus
								sap.ui.getCore().getEventBus().publish("Profile", "create", {
									"RoleID": sProfileId,
									"RoleName": sProfileName,
									"Roles_ID": sUUID,
									"Position": sPosition || null
								});
							});

						}.bind(this),
						error: function (oError) {}
					});
				};

				// check first if there isn't any "CardPositions" instance existing
				this._oMCCWorkplaceService.read("/CardPositions", {
					filters: [
						new Filter("User", FilterOperator.EQ, this._oUserInfo.getProperty("/name")),
						new Filter("RolesID", FilterOperator.EQ, sUUID)
					],
					success: function (oData) {
						var sCardsUUID = oData.results[0] && oData.results[0].ID;

						var oUserRole = {
							"UserID": this._oUserInfo.getProperty("/name"),
							"RoleID": sProfileId,
							"Roles_ID": sUUID,
							"Position": sPosition || null,

						};
						if (sCardsUUID) {
							oUserRole["Cards_ID"] = sCardsUUID;

							fnCreateUserRoles.call(this, oUserRole);
						} else {

							var oFilter = new Filter("DefaultRole", FilterOperator.Contains, sProfileId);
							var oDefaultCardsPromise = new Promise(function (resolve, reject) {
								this._oMCCWorkplaceService.read("/Cards", {
									filters: [oFilter],
									success: function (oCards) {

										resolve(oCards.results);

									}.bind(this),
									error: function (oError) {
										// TODO: implement error
										reject(oError);
									}
								});
							}.bind(this));

							oDefaultCardsPromise.then(function (aDefaultCards) {
								var oProfileInstanceCard = {
									"User": this._oUserInfo.getProperty("/name"),
									"Profile": sProfileId,
									"RolesID": sUUID,
									"CardOrder": null // optional
								};
								if (aDefaultCards && aDefaultCards.length > 0) {
									var aCardOrder = [];
									aDefaultCards.forEach(function (oCard) {
										aCardOrder.push(oCard.CardID);
									}.bind(this));
									oProfileInstanceCard.CardOrder = aCardOrder.join(";");
								}
								this._oMCCWorkplaceService.create("/CardPositions", oProfileInstanceCard, {
									success: function (oResponse) {
										oUserRole["Cards_ID"] = oResponse.ID;
										//Create entry
										fnCreateUserRoles.call(this, oUserRole);
									}.bind(this),
									error: function (oError) {
										// TODO: Some error caused when create.

									}
								});
							}.bind(this));

						}

					}.bind(this),
					error: function (oError) {

					}
				});
			}
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Create a new Profile with a temporary hash name Date.now() returns an integer
		 * @param {sap.ui.base.Event} oEvent Create Profile is pressed
		 */
		onCreateProfilePress: function (oEvent) {
			var sUserId = this._oUserInfo.getProperty("/name");
			var oNewProfile = {
				//	CreatedBy: sUserId,
				ID: (Date.now()).toString(), // temporary integer
				Position: -1,
				RoleID: null,
				RoleName: null,
				ProfileInstanceID: null,
				_create: true,
				_delete: false,
				_visible: true
			};
			this.getView().getModel("ManageProfilesModel").setProperty("/Profiles", this.getView().getModel("ManageProfilesModel").getProperty(
				"/Profiles").concat(oNewProfile));

			var aNewEntryChangeQ = this.getView().getModel("ManageProfilesModel").getProperty("/changeQ/newEntry").concat(); // clone Array
			aNewEntryChangeQ.push(oNewProfile.ID);
			this.getView().getModel("ManageProfilesModel").setProperty("/changeQ/newEntry", aNewEntryChangeQ);

			this.getView().getModel("ManageProfilesModel").setProperty("/visibleProfileInstanceTotal", this.getView().getModel(
				"ManageProfilesModel").getProperty("/visibleProfileInstanceTotal") + 1);
		},

		/**
		 * Flag Profile to be created
		 * @param {sap.ui.base.Event} oEvent Profile Name changed
		 */
		onProfileNameLiveChange: function (oEvent) {
			var oSource = oEvent.getSource();
			var sRoleID = oSource.getValue();
			var sPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			sRoleID = sRoleID.replace(/\s/g, "").replace(/\//g, "").replace(/\?/g, "").replace(/\$/g, "");

			var sProfileID = this.getView().getModel("ManageProfilesModel").getProperty(sPath + "/ID");
			this.getView().getModel("ManageProfilesModel").setProperty(sPath + "/RoleID", sRoleID);

			var aCreateChangeQ = this.getView().getModel("ManageProfilesModel").getProperty("/changeQ/create").concat(); // clone Array;

			if (this._validateProfileInput(oSource, sRoleID, sProfileID)) { // if name is valid, add Profile to create Queue
				if (aCreateChangeQ.indexOf(sProfileID) === -1) { // can only have 1 instance of Profile, so checking if it isn't already in array
					aCreateChangeQ.push(sProfileID);
				}
			} else { // if name is invalid, remove Profile from Create Queue
				aCreateChangeQ = aCreateChangeQ.filter(function (sValue) {
					return sValue !== sProfileID;
				});
			}

			this.getView().getModel("ManageProfilesModel").setProperty("/changeQ/create", aCreateChangeQ);
		},

		/**
		 * On Live Change or Search, filter the Profiles on table
		 * @param {sap.ui.base.Event} oEvent Search or LiveChange is triggered
		 */
		onProfileSearchOrLiveChange: function (oEvent) {
			var aTableSearchState = [];
			var sQuery = oEvent.getParameter(oEvent.getId() === "search" ? "query" : "newValue");
			var oTable = this.byId("profilesTable");

			if (sQuery && sQuery.length > 0) {
				aTableSearchState = [
					new Filter("RoleName", FilterOperator.Contains, sQuery),
					new Filter("createdBy", FilterOperator.Contains, sQuery)
				];
				var oFilter = new Filter({
					filters: aTableSearchState,
					and: false
				});
				oTable.getBinding("items").filter(oFilter, "Application");
			} else {
				oTable.getBinding("items").filter(null, "Application");
			}
		},

		/**
		 * Flag Profile to be deleted
		 * @param {sap.ui.base.Event} oEvent delete button is pressed
		 */
		onProfileDeletePress: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getParent().getBindingContextPath();
			var sProfileID = this.getView().getModel("ManageProfilesModel").getProperty(sPath + "/ID");
			var bPreviousState = this.getView().getModel("ManageProfilesModel").getProperty(sPath + "/_delete");
			var bVisible = this.getView().getModel("ManageProfilesModel").getProperty(sPath + "/_visible");

			this.getView().getModel("ManageProfilesModel").setProperty(sPath + "/_delete", !bPreviousState);
			var iVisibleProfileInstanceTotal = this.getView().getModel("ManageProfilesModel").getProperty("/visibleProfileInstanceTotal");

			var aDeleteChangeQ = this.getView().getModel("ManageProfilesModel").getProperty("/changeQ/delete").concat(); // clone Array

			if (bPreviousState) { // remove Profile from Delete Queue
				aDeleteChangeQ = aDeleteChangeQ.filter(function (sValue) {
					return sValue !== sProfileID;
				});
				if (bVisible) {
					iVisibleProfileInstanceTotal++;
				}
			} else { // add Profile to Delete Queue
				aDeleteChangeQ.push(sProfileID);
				if (bVisible) {
					iVisibleProfileInstanceTotal--;
				}
			}

			this.getView().getModel("ManageProfilesModel").setProperty("/changeQ/delete", aDeleteChangeQ);
			this.getView().getModel("ManageProfilesModel").setProperty("/visibleProfileInstanceTotal", iVisibleProfileInstanceTotal);
		},

		/**
		 * Flag Profile to be visible/hidden
		 * @param {sap.ui.base.Event} oEvent switch control state is changed
		 */
		onProfileVisibleChange: function (oEvent) {
			var sPath = oEvent.getSource().getParent().getBindingContextPath();
			var sProfileID = this.getView().getModel("ManageProfilesModel").getProperty(sPath + "/ID");
			var iVisibleProfileInstanceTotal = this.getView().getModel("ManageProfilesModel").getProperty("/visibleProfileInstanceTotal");

			var aVisibleChangeQ = this.getView().getModel("ManageProfilesModel").getProperty("/changeQ/visible").concat(); // clone Array;

			if (aVisibleChangeQ.indexOf(sProfileID) > -1) { // remove Profile from Visible Queue
				aVisibleChangeQ = aVisibleChangeQ.filter(function (sValue) {
					return sValue !== sProfileID;
				});
			} else { // add Profile to Visible Queue
				aVisibleChangeQ.push(sProfileID);
			}

			if (oEvent.getSource().getState()) {
				iVisibleProfileInstanceTotal++;
			} else {
				iVisibleProfileInstanceTotal--;
			}

			this.getView().getModel("ManageProfilesModel").setProperty("/changeQ/visible", aVisibleChangeQ);
			this.getView().getModel("ManageProfilesModel").setProperty("/visibleProfileInstanceTotal", iVisibleProfileInstanceTotal);
		},

		/**
		 * Handle Save Dialog for Create and modification
		 * @param {sap.ui.base.Event} oEvent save button is pressed
		 */
		onSaveDialogPress: function (oEvent) {
			var aProfiles = this.getView().getModel("ManageProfilesModel").getProperty("/Profiles");
			var oChangeQ = this.getView().getModel("ManageProfilesModel").getProperty("/changeQ");
			var fnSave = function (bExecuteDelete) {
				aProfiles.forEach(function (oProfile) {
					var sProfileID = oProfile.ID;

					if (bExecuteDelete) {
						if (oChangeQ.delete.indexOf(sProfileID) > -1) { // if Profile has to be deleted
							this._deleteProfile(sProfileID, oProfile.ProfileInstanceID, oProfile.ProfileInstanceCardID, oProfile.RoleID);
							return;
						}
					}
					if (oChangeQ.visible.indexOf(sProfileID) > -1) { // if Profile visibility has to be changed
						if (!oProfile._create && !oProfile._delete) { // check if Profile is not deleted or a new Profile. since visibility changes a existing Profile, it needs to be prevented
							this._manageProfileInstance(oProfile.RoleID, oProfile.RoleName, oProfile._visible, oProfile.ID, oProfile.Position);
							//delete Card Postitions if Default Profile is set to false
							if (oProfile.createdBy === 'Default' && !oProfile._visible) {
								this._oMCCWorkplaceService.remove("/CardPositions(guid'" + oProfile.ProfileInstanceCardID + "')", {
									success: function (oData) {},
									error: function (oError) {}
								});
							}
							return;
						}
					}
					if (oChangeQ.create.indexOf(sProfileID) > -1) { // if Profile has to be created
						this._createProfile(oProfile.RoleID, oProfile.RoleName, oProfile._visible, oProfile.Position);
						return;
					}
					// if not delete > change visible > create, then only update Position
					if (oProfile._visible) {
						this._manageProfileInstance(oProfile.RoleID, oProfile.RoleName, oProfile._visible, oProfile.ID, oProfile.Position);
					}
				}.bind(this));
			}.bind(this);

			// if any profile is marked to be deleted, a confirmation will be displayed
			if (oChangeQ.delete.length) {
				MessageBox.warning("One or more Profiles will be permanently deleted. Are you sure you want to continue?", {
					actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
					emphasizedAction: MessageBox.Action.OK,
					onClose: function (sAction) {
						if (sAction === "OK") {
							fnSave(true);
						}
					}.bind(this)
				});
			} else {
				fnSave(false);
			}
			this._oDialog.close();
		},

		/**
		 * Close Dialog. Undone actions will be reverted when dialog is opened and _setDefaultBindingForProfilesTable method is called again
		 * @param {sap.ui.base.Event} oEvent cancel dialog is pressed
		 */
		onCancelDialogPress: function (oEvent) {
			this._oDialog.close();
		},
		/**
		 * Handle Profile reordering. It stores the new position and only apply when save is pressed
		 */
		onDropProfileTable: function (oEvent) {
			var oTable = this.getView().byId("profilesTable");
			var oDraggedItem = oEvent.getParameter("draggedControl"),
				oDroppedItem = oEvent.getParameter("droppedControl"),
				oDragParent = oDraggedItem.getParent(),
				oDropParent = oDroppedItem.getParent(),
				sInsertPosition = oEvent.getParameter("dropPosition"),
				iDragPosition = oDragParent.indexOfItem(oDraggedItem),
				iDropPosition = oDropParent.indexOfItem(oDroppedItem);

			oDragParent.removeItem(oDraggedItem);

			if (oDragParent === oDropParent && iDragPosition < iDropPosition) {
				iDropPosition--;
			}

			if (sInsertPosition === "Before") {
				oDropParent.insertItem(oDraggedItem, iDropPosition);
			} else {
				oDropParent.insertItem(oDraggedItem, iDropPosition + 1);
			}

			var aPositionChangeQ = oTable.getItems().map(function (oItem, iIndex) {
				this.getView().getModel("ManageProfilesModel").getProperty(oItem.getBindingContextPath() + "/Position", iIndex);
				return this.getView().getModel("ManageProfilesModel").getProperty(oItem.getBindingContextPath() +
					"/ProfileInstanceID");
				// //Create entry
				// if (sProfileInstanceID) { // not all Profiles should be displayed in the IconTabBar
				// 	this._oMCCWorkplaceService.update("/UserRoles(guid'" + sProfileInstanceID + "')", {
				// 		Position: iIndex
				// 	}, {
				// 		success: function (oData) {},
				// 		error: function (err) {}
				// 	});
				// }
			}.bind(this));

			this.getView().getModel("ManageProfilesModel").setProperty("/changeQ/position", aPositionChangeQ);
		}
	});
});