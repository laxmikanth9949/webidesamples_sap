sap.ui.define([
	"com/sap/mcc/workplace/controller/BaseController",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"com/sap/mcc/workplace/model/formatter"
], function (BaseController, MessageBox, Filter, FilterOperator, Sorter, formatter) {
	"use strict";

	return BaseController.extend("com.sap.mcc.workplace.controller.action.Settings", {
		
		formatter: formatter,
		
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function(oEvent) {},
		onBeforeRendering: function(oEvent) {},
		
		/**
		 * on Press event to open Manage Profiles settings
		 */
		onSettingsPress: function (oEvent) {
			this.byId("SettingsDialog").open();
		},

		onClosePress: function (oEvent) {
			oEvent.getSource().getParent().close();
		}
		
	});

});