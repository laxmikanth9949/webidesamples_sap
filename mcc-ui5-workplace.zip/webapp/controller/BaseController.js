sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/ui/core/UIComponent"
], function (Controller, JSONModel, Filter, FilterOperator, Fragment, UIComponent) {
	"use strict";

	return Controller.extend("com.sap.mcc.workplace.controller.BaseController", {

		// onInit: function() {
		// 	console.log("MCC BaseController initialization");
		// 	this._oMCCWorkplaceService = this.getView().getModel("MCSCardsOVPModel");	
		// },

		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * OData request to load Esacalation cases
		 * Parameter: oCustomfilter --> filter for Responsible oder CaseID
		 */
		loadCases: function (oCustomFilter, sFilterName) {
			return new Promise(function (resolve, reject) {
				var oAppDepModel = this.getOwnerComponent().getModel("appDepModel");

				//var filterResp = new Filter("Responsible", FilterOperator.EQ, sUserId); // D057452 
				var filterStatus = new Filter({
					filters: [new Filter("StatusID", FilterOperator.EQ, "20"), new Filter("StatusID", FilterOperator.EQ, "30")],
					and: false
				});
				var filterType = new Filter("CaseType", FilterOperator.EQ, "ZS01");

				var oFilter = new Filter({
					filters: [oCustomFilter, filterStatus, filterType],
					and: true
				});

				oAppDepModel.read("/CaseSet", {
					filters: [oFilter],
					urlParameters: {
						$expand: "toCheckPoint" // required for Roadmap Card
					},
					success: function (oData) {
						resolve({
							filterName: sFilterName,
							data: oData.results
						});
					}.bind(this),
					error: function (err) {
						reject(err);
					}
				});
			}.bind(this));
		},

		loadCasesAppDepSrv: function (aFilter, oUrlParameter) {
			return new Promise(function (resolve, reject) {
				var oAppDepModel = this.getOwnerComponent().getModel("appDepModel");

				oAppDepModel.read("/CaseSet", {
					filters: aFilter,
					urlParameters: oUrlParameter,
					success: function (oData) {
						resolve(oData.results);
					}.bind(this),
					error: function (err) {
						reject(err);
					}
				});
			}.bind(this));
		},

		/**
		 * Gets User Information set to "UserInfo" model
		 *
		 * @function _getUserInfo
		 * @private
		 * @returns {Promise} Promise with service response
		 */
		_getUserInfo: function () {
			return this.startMccWorkplaceAjaxRequest({
				url: "/services/userapi/currentUser"
			}).then(function (oData) {
				this.getView().setModel(new JSONModel(oData), "UserInfo");
				sap.ui.getCore().setModel(new JSONModel(oData), "UserInfo");
				return oData;
			}.bind(this));
		},

		/**
		 * Gets ServiceTeam and Service Regions Information set to "Workplace" model
		 *
		 * @function _getUserInfo
		 * @private
		 * @returns {Promise} Promise with service response
		 */
		_getServiceTeamsRegions: function () {
			var oCCTModel = this.getModel("CTTAppModel");
			var oFilter = new Filter({
				filters: [
					new Filter("ServiceTeamRegion", FilterOperator.EQ, "Global"),
					new Filter("ServiceTeamRegion", FilterOperator.EQ, "NA"),
					new Filter("ServiceTeamRegion", FilterOperator.EQ, "Greater China"),
					new Filter("ServiceTeamRegion", FilterOperator.EQ, "LAC"),
					new Filter("ServiceTeamRegion", FilterOperator.EQ, "EMEA")

				],
				and: false
			});

			var oServiceTeamPromise = new Promise(function (resolve, reject) {
				oCCTModel.read("/ServiceTeams", {
					filters: [oFilter],
					success: function (oData) {
						resolve(oData.results);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			}.bind(this));

			oServiceTeamPromise.then(function (aData) {
				aData.forEach(function (oEntry) {
					if (oEntry.ServiceTeamRegion === "Greater China") {
						oEntry.ServiceTeamRegion = "APJ";
					}
				});

				this.getModel("workplaceModel").setProperty("/ServiceTeamsTest", aData);

			}.bind(this));

			return oServiceTeamPromise;

		},

		_getRecommendationsValueHelps: function () {
			this._loadRecommendationDropdownValues().then(function (oDropdownValues) {
				this.getModel("workplaceModel").setProperty("/RecommendationTargetResult", oDropdownValues.ValueHelpTargetResult);
				this.getModel("workplaceModel").setProperty("/RecommendationStatus", oDropdownValues.ValueHelpStatus);
				this.getModel("workplaceModel").setProperty("/RecommendationType", oDropdownValues.ValueHelpType);
			}.bind(this));
		},

		_loadRecommendationDropdownValues: function () {
			return new Promise(function (resolve, reject) {
				var aFilter = [new Filter({
					filters: [
						new Filter("DropdownName", FilterOperator.StartsWith, "Recommendation-Dropdown"),
						new Filter("DropdownName", FilterOperator.NotEndsWith, "-Inactive"),
					],
					and: true
				})]
				this.getModel("workbenchModel").read("/DropdownValues", {
					filters: aFilter,
					success: function (oData) {
						var aStatusDropDown = [];
						var aTypeDropDown = [];
						var aStatusReasonDropDown = [];
						var aTargetResultDropDown = [];
						//var aOrganizationDropdown = [];
						oData.results.forEach(function (oEntry) {
							if (oEntry.DropdownName.indexOf("Type") > 0) {
								aTypeDropDown.push(oEntry);
							} else if (oEntry.DropdownName.indexOf("StatusReason") > 0) {
								aStatusReasonDropDown.push(oEntry);
							} else if (oEntry.DropdownName.indexOf("Status") > 0) {
								aStatusDropDown.push(oEntry);
							} else if (oEntry.DropdownName.indexOf("TargetResult") > 0) {
								aTargetResultDropDown.push(oEntry);
							}

							/*else if (oEntry.DropdownName.indexOf("Organization") > 0) {
								aOrganizationDropdown.push(oEntry);
							}*/
						});
						var oObject = {};
						oObject.ValueHelpStatus = aStatusDropDown;
						oObject.ValueHelpType = aTypeDropDown;
						aTypeDropDown.reverse();
						oObject.ValueHelpStatusReason = aStatusReasonDropDown;
						aTargetResultDropDown.forEach(function (o) {
							var s = o.DropdownValue.split(" - ");
							o.DropdownValue = s[1];
							o.DropdownValueGroup = s[0];
						});
						oObject.ValueHelpTargetResult = aTargetResultDropDown;
						//oObject.ValueHelpOrganization = aOrganizationDropdown;
						resolve(oObject);
					}.bind(this),
					error: function (err) {
						reject();
					}
				});
			}.bind(this));
		},

		/**
		 * Gets public variants and stores it in "Workplace" model
		 *
		 * @function _getPublicVariants
		 * @private
		 * @returns {Promise} Promise with public variants
		 */
		_getPublicVariants: function () {
			var oCCTModel = this.getModel("MCSCardsOVPModel");
			var oFilter = new Filter("UserID", FilterOperator.EQ, "Public");

			var oPublicVariantsPromise = new Promise(function (resolve, reject) {
				oCCTModel.read("/VariantManagement", {
					filters: [oFilter],
					success: function (oData) {
						resolve(oData.results);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			}.bind(this));

			oPublicVariantsPromise.then(function (aData) {

				this.getModel("workplaceModel").setProperty("/publicVariants", aData);

			}.bind(this));

			return oPublicVariantsPromise;

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Convenience method for getting the Core model by name in every controller of the application.
		 * Note: cards are implemented in a multicomponent approach, so acess to the common Model is via sap.ui.getCore()
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getCoreModel: function (sName) {
			return sap.ui.getCore().getModel(sName);
		},

		/**
		 * Convenience method for getting the view model by name in every controller of the application.
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		killMccWorkplacePendingRequests: function () {
			sap.ui.getCore().getEventBus().publish("Request", "kill", {});
		},

		startMccWorkplaceAjaxRequest: function (oInputParams) {
			var sUniqueId = Math.random().toString(36).substring(2) + Date.now().toString(36);
			var iLiveRequestId = "ajax_" + sUniqueId;
			var oOldRequestQueue = this.getCoreModel("workplaceModel").getProperty("/liveRequestQueue");

			// default values
			var oParams = {
				url: oInputParams.url,
				type: oInputParams.type || "GET",
				contentType: oInputParams.contentType || "application/json",
				dataType: oInputParams.dataType || "json"
			};

			return new Promise(function (resolve, reject) {
				var oCall = jQuery.ajax({
					url: oParams.url,
					type: oParams.type,
					contentType: oParams.contentType,
					dataType: oParams.dataType,
					success: function (oData) {
						resolve(oData);
					},
					error: function (oError) {
						reject(oError);
					},
					complete: function () {
						// release step
						var oNewRequestQueue = this.getCoreModel("workplaceModel").getProperty("/liveRequestQueue");
						if (oNewRequestQueue[iLiveRequestId]) {
							delete oNewRequestQueue[iLiveRequestId];
							// console.log("destroying: " + iLiveRequestId + " total alive:" + Object.keys(oNewRequestQueue).length);
							this.getCoreModel("workplaceModel").setProperty("/liveRequestQueue", oNewRequestQueue);
							this.getCoreModel("workplaceModel").setProperty("/liveRequestQueueCount", this.getCoreModel("workplaceModel").getProperty(
								"/liveRequestQueueCount") - 1);
						}
					}.bind(this)
				});
				// enqueue step 
				oOldRequestQueue[iLiveRequestId] = oCall;
				// console.log("starting: " + iLiveRequestId + " total alive:" + Object.keys(oOldRequestQueue).length);
				this.getCoreModel("workplaceModel").setProperty("/liveRequestQueue", oOldRequestQueue);
				this.getCoreModel("workplaceModel").setProperty("/liveRequestQueueCount", this.getCoreModel("workplaceModel").getProperty(
					"/liveRequestQueueCount") + 1);

				// subscribe to kill event bus
				sap.ui.getCore().getEventBus().subscribe("Request", "kill", function (oData) {
					var oRequestQueue = this.getCoreModel("workplaceModel").getProperty("/liveRequestQueue");
					var aRequestQueueKeys = Object.keys(oRequestQueue);

					aRequestQueueKeys.forEach(function (sRequestKey) {
						if (sRequestKey.split("_")[0] === "ajax") {
							oRequestQueue[sRequestKey].abort();
						}
					});
				}.bind(this));

			}.bind(this));
		},

		openInformationDialog: function (oEvent) {
			var oButton = oEvent.getSource();

			var sViewName = this.getView().getProperty("viewName");
			var sDescrition;
			if (sViewName === "com.sap.mcc.workplace.view.action.ManageCards") {
				sDescrition = oEvent.getSource().getBindingContext("ManageCardsModel").getObject().Description;
			} else {
				var sCardId = sViewName.split(".").pop();
				var oWorkplaceModel = this.getCoreModel("workplaceModel");
				var sSelectedProfileID = oWorkplaceModel.getProperty("/selectedProfileInstance/Alias");
				var aProfileCards = sap.ui.getCore().getModel("workplaceModel").getProperty("/_cardIntegration/" + sSelectedProfileID);

				var oCard = this.findObjectByKey(aProfileCards, "cardId", sCardId);
				sDescrition = oCard.Description;
			}

			if (sDescrition !== null) {
				var oObject = {};
				var bValidJson = true;

				try {
					oObject = JSON.parse(sDescrition);
				} catch (error) {
					console.log("==> Invalid JSON (Card Description)" + error);
					bValidJson = false;
				}
				if (!bValidJson) {
					var descriptions = oCard.Description.split(";");
					var displayString = "";
					for (var k = 0; k < descriptions.length; k++) {
						if (k === 2) {
							displayString = displayString + descriptions[k] + "\n";
						} else {
							displayString = displayString + descriptions[k] + "\n" + "\n";
						}
					}

					oObject.description = displayString; //oObject.descriptions

				}
				var oJsonModel = new sap.ui.model.json.JSONModel(oObject);
				this.onInformationDialog(oButton, oJsonModel);
			}
		},

		openFilterBarInformation: function (oEvent) {
			var oButton = oEvent.getSource();

			var sViewName = this.getView().getProperty("viewName");
			var sFilterBarInformation;
			if (sViewName === "com.sap.mcc.workplace.view.action.ManageCards") {
				sFilterBarInformation = oEvent.getSource().getBindingContext("ManageCardsModel").getObject().FilterProperty;
			} else {
				var sCardId = sViewName.split(".").pop();
				var oWorkplaceModel = this.getCoreModel("workplaceModel");
				var sSelectedProfileID = oWorkplaceModel.getProperty("/selectedProfileInstance/Alias");
				var aProfileCards = sap.ui.getCore().getModel("workplaceModel").getProperty("/_cardIntegration/" + sSelectedProfileID);

				var oCard = this.findObjectByKey(aProfileCards, "cardId", sCardId);
				sFilterBarInformation = oCard.FilterProperty;
			}

			if (sFilterBarInformation !== null) {
				var oObject = {};

				oObject = {
					"groups": [{
						"heading": "Filterbar Details",
						"elements": [{
							"label": "Affected by filterbar items",
							"value": oCard.FilterProperty.replace(";", ", "),
							"elementType": "text"
						}]
					}]
				};

				var oJsonModel = new sap.ui.model.json.JSONModel(oObject);
				this.onInformationDialog(oButton, oJsonModel);
			}
		},

		onInformationDialog: function (oButton, oJsonModel) {
			if (!this._oInformationDialog) {
				Fragment.load({
					name: "com.sap.mcc.workplace.view.fragments.Information",
					controller: this
				}).then(function (oInformationFragment) {
					this._oInformationDialog = oInformationFragment;
					this._oInformationDialog.setModel(oJsonModel, "data");
					this._oInformationDialog.close();
					this._oInformationDialog.openBy(oButton);

				}.bind(this));
			} else {
				this._oInformationDialog.setModel(oJsonModel, "data");
				this._oInformationDialog.close();
				this._oInformationDialog.openBy(oButton);
			}
		},

		onExit: function () {
			if (this._oQuickView) {
				this._oQuickView.destroy();
			}
		},

		findObjectByKey: function (array, key, value) {
			for (var i = 0; i < array.length; i++) {
				if (array[i][key] === value) {
					return array[i];
				}
			}
			return null;
		}
	});

});