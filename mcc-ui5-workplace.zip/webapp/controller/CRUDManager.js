sap.ui.define([
	"com/sap/mcc/workplace/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"
], function (BaseController, JSONModel, Filter, FilterOperator, Sorter) {
	"use strict";

	return BaseController.extend("com.sap.mcc.workplace.controller.CRUDManager", {
		/**
		 * @alias com.sap.mcc.workplace.controller.CRUDManager
		 */
		constructor: function (oView) {
			// console.log("MCC CRUDManager initialization");
			this._oMCCWorkplaceService = oView.getModel("MCSCardsOVPModel");
		},

		/* =========================================================== */
		/* Profile "/Roles"	                                           */
		/* =========================================================== */

		/**
		 * Load Profiles (Default and self) 
		 */
		readProfiles: function (sUserID) {
			// TODO: validate sUserID
			var aFilters = [new Filter("createdBy", FilterOperator.EQ, "Default")];

			if (sUserID) {
				aFilters.push(new Filter("createdBy", FilterOperator.EQ, sUserID));
			}

			return new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.read("/Roles", {
					filters: [
						new Filter(aFilters, false)
					],
					success: function (oResponse) {
						resolve(oResponse);
					},
					error: function (oError) {
						// TODO: Some error caused when read Profile.
						reject(oError);
					}
				});
			}.bind(this));
		},
		/**
		 * Load Profile by ProfileAlias (/Roles/RoleID) OR ProfileUUID (/Roles/ID) OR UserID (/Roles/CreatedBy) 
		 */
		readProfile: function (sProfileAlias, sProfileUUID, sUserID) {
			// TODO: validate sProfileAlias, sProfileName, sUserID
			var aFilters = [];

			if (sProfileAlias) {
				aFilters.push(new Filter("RoleID", FilterOperator.EQ, sProfileAlias));
			}
			if (sProfileUUID) {
				aFilters.push(new Filter("ID", FilterOperator.EQ, sProfileUUID));
			}
			if (sUserID) {
				aFilters.push(new Filter("createdBy", FilterOperator.EQ, sUserID));
			}

			return new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.read("/Roles", {
					filters: aFilters,
					success: function (oResponse) {
						resolve(oResponse);
					},
					error: function (oError) {
						// TODO: Some error caused when read Profile.
						reject(oError);
					}
				});
			}.bind(this));
		},

		createProfile: function (sProfileName, sUserID) {
			// TODO: validate sProfileName, sUserID and sProfileAlias
			var oProfile = {
				"RoleID": sProfileName.replace(/\s/g, "").replace(/\//g, "").replace(/\?/g, "").replace(/\$/g, ""), // sProfileAlias
				"RoleName": sProfileName, // sProfileName
				//"createdBy": sUserID // sUserID
			};

			return new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.create("/Roles", oProfile, {
					success: function (oResponse) {
						resolve(oResponse);
					},
					error: function (oError) {
						// TODO: Some error caused when creating.
						// possibly missing RoleID, RoleName, CreatedBy or Profile is already created
						reject(oError);
					}
				});
			}.bind(this));

		},

		deleteProfile: function (sProfileUUID) {
			// TODO: validate sProfileUUID and prevent deleting Profile where CreatedBy is Default

			return new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.remove("/Roles(guid'" + sProfileUUID + "')", {
					success: function (oResponse) {
						resolve(oResponse);
					},
					error: function (oError) {
						// TODO: Some error caused when deleting.
						reject(oError);
					}
				});
			}.bind(this));
		},

		/* =========================================================== */
		/* ProfileInstance "/UserRoles"                                */
		/* =========================================================== */

		readProfileInstances: function (sUserID) {
			// TODO: validate sUserID

			return new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.read("/UserRoles", {
					filters: [
						new Filter("UserID", FilterOperator.EQ, sUserID),
						new Filter("Roles_ID", FilterOperator.NE, null)
					],
					sorters: [new Sorter("Position")],
					urlParameters: {
						$expand: "Roles,Cards,Variants"
					},
					success: function (oResponse) {
						resolve(oResponse);
					},
					error: function (oError) {
						// TODO: Some error caused when read Profile.
						reject(oError);
					}
				});
			}.bind(this));
		},

		readProfileInstance: function (sUserID, sProfileInstanceUUID, sProfileAlias, sProfileUUID) {
			// TODO: validate UserID, UserID, sProfileAlias and sProfileUUID
			var aFilters = [];

			if (sUserID) {
				aFilters.push(new Filter("UserID", FilterOperator.EQ, sUserID));
			}
			if (sProfileAlias) {
				aFilters.push(new Filter("RoleID", FilterOperator.EQ, sProfileAlias));
			}
			if (sProfileUUID) {
				aFilters.push(new Filter("Roles_ID", FilterOperator.EQ, sProfileUUID));
			}
			if (sProfileUUID) {
				aFilters.push(new Filter("ID", FilterOperator.EQ, sProfileUUID));
			}

			return new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.read("/UserRoles", {
					filters: aFilters,
					urlParameters: {
						$expand: "Roles,Cards"
					},
					success: function (oResponse) {
						resolve(oResponse);
					},
					error: function (oError) {
						// TODO: Some error caused when read Profile.
						reject(oError);
					}
				});
			}.bind(this));
		},

		createProfileInstance: function (sUserID, sProfileAlias, sProfileUUID, sCardsUUID, sPosition) {
			var oProfileInstance = {
				"UserID": sUserID,
				"RoleID": sProfileAlias,
				"Roles_ID": sProfileUUID,
				"Cards_ID": sCardsUUID,
				"Position": (isNaN(sPosition) ? null : sPosition) // optional
			};

			return new Promise(function (resolve, reject) {
				// TODO: validate sUserID, sProfileAlias, sProfileUUID, sCardsUUID
				if (!(sUserID || sProfileAlias || sProfileUUID || sCardsUUID)) {
					reject("sUserID, sProfileAlias, sProfileUUID, sCardsUUID fields are mandatory");
				}

				this._oMCCWorkplaceService.create("/UserRoles", oProfileInstance, {
					success: function (oResponse) {
						resolve(oResponse);
					},
					error: function (oError) {
						// TODO: Some error caused when creating.
						reject(oError);
					}
				});
			}.bind(this));
		},

		updateProfileInstanceProfileInstanceCard: function (sProfileInstanceUUID, sProfileInstanceCardUUID) {
			// TODO: validate sProfileInstanceUUID and sPosition
			var oProfileInstance = {
				"Cards_ID": sProfileInstanceCardUUID
			};

			return new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.update("/UserRoles(guid'" + sProfileInstanceUUID + "')", oProfileInstance, {
					success: function (oResponse) {
						resolve(oResponse);
					},
					error: function (oError) {
						// TODO: Some error caused when updating.
						reject(oError);
					}
				});
			}.bind(this));
		},

		updateProfileInstancePosition: function (sProfileInstanceUUID, sPosition) {
			// TODO: validate sProfileInstanceUUID and sPosition
			var oProfileInstance = {
				"Position": sPosition
			};

			return new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.update("/UserRoles(guid'" + sProfileInstanceUUID + "')", oProfileInstance, {
					success: function (oResponse) {
						resolve(oResponse);
					},
					error: function (oError) {
						// TODO: Some error caused when updating.
						reject(oError);
					}
				});
			}.bind(this));
		},

		deleteProfileInstance: function (sProfileInstanceUUID) {
			// TODO: validate sProfileInstanceUUID

			return new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.remove("/UserRoles(guid'" + sProfileInstanceUUID + "')", {
					success: function (oResponse) {
						resolve(oResponse);
					},
					error: function (oError) {
						// TODO: Some error caused when deleting.
						reject(oError);
					}
				});
			}.bind(this));
		},

		/* =========================================================== */
		/* ProfileInstanceCards "/CardPositions"                       */
		/* =========================================================== */

		readProfileInstanceCards: function (sUserID) {
			return new Promise(function (resolve, reject) {
				// TODO: validate sUserID

				this._oMCCWorkplaceService.read("/CardPositions", {
					filters: [new Filter("User", FilterOperator.EQ, sUserID)],
					success: function (oResponse) {
						resolve(oResponse);
					},
					error: function (oError) {
						// TODO: Some error caused when create.
						reject(oError);
					}
				});
			}.bind(this));
		},

		createProfileInstanceCard: function (sUserID, sProfileAlias, sProfileUUID, sCardOrder) {
			return new Promise(function (resolve, reject) {
				// TODO: validate sUserID, sProfileAlias, sProfileUUID
				if (!(sUserID || sProfileAlias || sProfileUUID)) {
					reject("sUserID, sProfileAlias, sProfileUUID fields are mandatory");
				}

				var oProfileInstanceCard = {
					"User": sUserID,
					"Profile": sProfileAlias,
					"RolesID": sProfileUUID,
					"CardOrder": sCardOrder || null // optional
				};

				this._oMCCWorkplaceService.create("/CardPositions", oProfileInstanceCard, {
					success: function (oResponse) {
						resolve(oResponse);
					},
					error: function (oError) {
						// TODO: Some error caused when create.
						reject(oError);
					}
				});
			}.bind(this));
		},

		updateProfileInstanceCard: function (sProfileInstanceCardUUID, sCardOrder) {
			// TODO: validate sProfileInstanceCardUUID and sPosition
			var oProfileInstanceCard = {
				"CardOrder": sCardOrder
			};

			return new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.update("/CardPositions(guid'" + sProfileInstanceCardUUID + "')", oProfileInstanceCard, {
					success: function (oResponse) {
						resolve(oResponse);
					},
					error: function (oError) {
						// TODO: Some error caused when updating.
						reject(oError);
					}
				});
			}.bind(this));
		},
		
		deleteProfileInstanceCard: function (sProfileInstanceCardUUID) {
			return new Promise(function (resolve, reject) {
				// TODO: validate sProfileInstanceCardUUID

				this._oMCCWorkplaceService.remove("/CardPositions(guid'" + sProfileInstanceCardUUID + "')", {
					success: function (oResponse) {
						resolve(oResponse);
					},
					error: function (oError) {
						// TODO: Some error caused when delete.
						reject(oError);
					}
				});
			}.bind(this));
		},

		/* =========================================================== */
		/* Cards "/Cards"                               	           */
		/* =========================================================== */

		/**
		 * Read Cards "/Cards". There is a bug? in the CAP service with batch requests throwing CDSRuntimeException.INTERNAL_ERROR when batch is used to read Cards.
		 * as a workaround, useBatch is disabled when reading Cards
		 */
		readCards: function () {
			return new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.setUseBatch(false); // workaround to CDSRuntimeException.INTERNAL_ERROR
				this._oMCCWorkplaceService.read("/Cards", {
					success: function (oResponse) {
						this._oMCCWorkplaceService.setUseBatch(true); // workaround to CDSRuntimeException.INTERNAL_ERROR
						resolve(oResponse);
					}.bind(this),
					error: function (oError) {
						// TODO: Some error caused when read Cards.
						this._oMCCWorkplaceService.setUseBatch(true); // workaround to CDSRuntimeException.INTERNAL_ERROR
						reject(oError);
					}.bind(this)
				});
			}.bind(this));
		},

		/**
		 * Read Card "/Card".
		 */
		readCard: function (sCardID) {
			// TODO: validate sCardID
			return new Promise(function (resolve, reject) {
				this._oMCCWorkplaceService.read("/Cards('" + sCardID + "')", {
					success: function (oResponse) {
						resolve(oResponse);
					}.bind(this),
					error: function (oError) {
						// TODO: Some error caused when read Cards.
						reject(oError);
					}.bind(this)
				});
			}.bind(this));
		}
	});
});