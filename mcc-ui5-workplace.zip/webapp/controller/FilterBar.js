sap.ui.define([
	"com/sap/mcc/workplace/controller/BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("com.sap.mcc.workplace.controller.FilterBar", {
		constructor: function () {
			this.getCoreModel("workplaceModel").setProperty("/FilterCases", {});

			this.refreshSelectedFilters = this.refreshSelectedFilters;
		},

		/**
		 * Global Escalation Manager Profile specific implementation of the filter bar
		 * it is possible to 
		 */
		handleFilterbarSearch: function (aFilterGroupItems) {
			return new Promise(function (resolve, reject) {
				var aPromises = [];
				var oFilterValues = {};

				aFilterGroupItems.forEach(function (oFilterGroupItem) {
					if (oFilterGroupItem.getVisible()) {

						var sFilterGroupItemName = oFilterGroupItem.getName();
						var sFilterProperty = "";
						//filter for Responsible Person or CaseID

						if (sFilterGroupItemName && (sFilterGroupItemName == "ResponsiblePerson" || sFilterGroupItemName == "CaseId" ||
								sFilterGroupItemName == "Processor")) {

							switch (sFilterGroupItemName) {
							case 'ResponsiblePerson':
								sFilterProperty = "Responsible";
								break;
							case 'CaseId':
								sFilterProperty = "CaseID";
								break;
							case 'Processor':
								sFilterProperty = "Processor";
							}

							var aTokens = oFilterGroupItem.getControl().getTokens();
							var aFilter = [];
							aTokens.forEach(function (oToken) {
								var oCustomFilter = new Filter(sFilterProperty, FilterOperator.EQ, oToken.getText()); // D057452 
								aFilter.push(oCustomFilter);
							}.bind(this));

							if (aFilter.length > 0) {
								var oFilter = new Filter({
									filters: aFilter,
									and: false
								});
								oFilterValues[sFilterGroupItemName] = oFilter;
							}
						} else if (sFilterGroupItemName === "Region") {
							/*var oCustomFilter;
							sFilterProperty = "ServiceOrg";
							var bIsDefault = false;
							var sSelectedKey = oFilterGroupItem.getControl().getSelectedKey();
							var sServiceOrg;
							switch (sSelectedKey) {
							case "EMEA":
								sServiceOrg = "O 50008010";
								break;
							case "APJ":
								sServiceOrg = "O 50008134";
								break;
							case "NA":
								sServiceOrg = "O 50008167";
								break;
							case "LA":
								sServiceOrg = "O 50008174";
								break;
							default:
								bIsDefault = true;
								break;
							}

							var aServiceOrgFilter = [];
							if (bIsDefault) {
								var aHelperRegion = ["O 50008010", "O 50008134", "O 50008167", "O 50008174"];
								aHelperRegion.forEach(function (sRegion) {
									oCustomFilter = new Filter(sFilterProperty, FilterOperator.EQ, sRegion);
									aServiceOrgFilter.push(oCustomFilter);
								}.bind(this));
							} else {
								oCustomFilter = new Filter(sFilterProperty, FilterOperator.EQ, sServiceOrg); // D057452 

								aServiceOrgFilter.push(oCustomFilter);
							}
							if (aServiceOrgFilter.length > 0) {
								var oServiceOrgFilter = new Filter({
									filters: aServiceOrgFilter,
									and: false
								});
								oFilterValues["Region"] = oServiceOrgFilter;
							}*/
							var aItems = oFilterGroupItem.getControl().getSelectedItems();
							var aServiceOrgFilter = [];
							aItems.forEach(function (oItem) {

								var sServiceOrg = oItem.getKey();
								aServiceOrgFilter.push(new Filter("ServiceOrg", FilterOperator.EQ, sServiceOrg));
							}.bind(this));

							if (aServiceOrgFilter.length > 0) {
								var oServiceTeamFilter = new Filter({
									filters: aServiceOrgFilter,
									and: false
								});
								oFilterValues["Region"] = oServiceTeamFilter;
							}

						} else if (sFilterGroupItemName === "ServiceTeam") {
							var aItems = oFilterGroupItem.getControl().getSelectedItems();
							var aServiceTeamFilter = [];
							aItems.forEach(function (oItem) {

								var sServiceTeam = oItem.getKey();
								var iLength = oItem.getKey().length;
								//add leading 0's
								sServiceTeam = "0000000000" + sServiceTeam;
								sServiceTeam = sServiceTeam.substr(iLength);
								aServiceTeamFilter.push(new Filter("ServiceTeam", FilterOperator.EQ, sServiceTeam));
							}.bind(this));

							if (aServiceTeamFilter.length > 0) {
								var oServiceTeamFilter = new Filter({
									filters: aServiceTeamFilter,
									and: false
								});
								oFilterValues["ServiceTeam"] = oServiceTeamFilter;
							}

						} else if (sFilterGroupItemName === "RecommendationStatus") {
							var aSelectedKeys = oFilterGroupItem.getControl().getSelectedKeys();
							var aRecommendationStatusFilters = [];
							aSelectedKeys.forEach(function(elm) {
								aRecommendationStatusFilters.push(new Filter("Status", FilterOperator.EQ, elm));
							})
							
							if (aRecommendationStatusFilters.length > 0) {
								var oRecommendationStatusFilter = new Filter({
									filters: aRecommendationStatusFilters,
									and: false
								});
								oFilterValues["RecommendationStatus"] = oRecommendationStatusFilter;
							}
						} else if (sFilterGroupItemName === "RecommendationType") {
							var aSelectedKeys = oFilterGroupItem.getControl().getSelectedKeys();
							var aRecommendationTypeFilters = [];
							aSelectedKeys.forEach(function(elm) {
								aRecommendationTypeFilters.push(new Filter("RecommendationType", FilterOperator.EQ, elm));
							})
							
							if (aRecommendationTypeFilters.length > 0) {
								var oRecommendationTypeFilter = new Filter({
									filters: aRecommendationTypeFilters,
									and: false
								});
								oFilterValues["RecommendationType"] = oRecommendationTypeFilter;
							}
						} else if (sFilterGroupItemName === "RecommendationTargetResult") {
							var aSelectedKeys = oFilterGroupItem.getControl().getSelectedKeys();
							var aRecommendationTargetResultFilters = [];
							aSelectedKeys.forEach(function(elm) {
								aRecommendationTargetResultFilters.push(new Filter("TargetResult", FilterOperator.EQ, elm));
							})
							
							if (aRecommendationTargetResultFilters.length > 0) {
								var oRecommendationTargetResultFilter = new Filter({
									filters: aRecommendationTargetResultFilters,
									and: false
								});
								oFilterValues["RecommendationTargetResult"] = oRecommendationTargetResultFilter;
							}
						}
					}
				}.bind(this));

				this.getCoreModel("workplaceModel").setProperty("/FilterValues", oFilterValues);
 
				Promise.all(aPromises).then(function (aData) {

					resolve('Cases successfully loaded.');
				}.bind(this)).catch(function (oError) {
					reject('ERROR - cases could not be loaded.');
				});
			}.bind(this));
		},

		refreshSelectedFilters: function (aFilterGroupItems) {
			return new Promise(function (resolve, reject) {
				var aFilterValues = {};
				aFilterGroupItems.forEach(function (oFilterGroupItem) {
					if (oFilterGroupItem.getVisible()) {
						var oControl = oFilterGroupItem.getControl();
						var sControlName = oFilterGroupItem.getName();
						var sControlValue;
						if (oControl instanceof sap.m.MultiInput) {
							sControlValue = oControl.getTokens();
						} else if (oControl instanceof sap.m.Select) {
							sControlValue = oControl.getSelectedKey();
						}

						aFilterValues[sControlName] = sControlValue;
					}
				});

				this.getCoreModel("workplaceModel").setProperty("/selectedProfileInstance/FilterValues", aFilterValues);
				resolve("new values loaded");
			}.bind(this));
		}
	});
});