sap.ui.define([
	"sap/ui/base/Object"
], function (UI5Object) {
	"use strict";

	return UI5Object.extend("com.sap.mcc.workplace.controller.ODataHandler", {

		/**
		 * Handles application OData by automatically attaching to the model events and aborting it when Profile is changed.
		 * @class
		 * @param {sap.ui.core.UIComponent} oComponent reference to the app's component
		 * @public
		 * @alias com.sap.mcc.workplace.CardComponent.CardODataHandler
		 */
		constructor: function (oComponent, sModelName) {
			this._oResourceBundle = oComponent.getModel("i18n").getResourceBundle();
			this._oComponent = oComponent;
			this._oModel = sModelName ? oComponent.getModel(sModelName) : oComponent.getModel();

			// TODO: check if need to implement attachBatchRequestSent
			var oOldRequestQueue = sap.ui.getCore().getModel("workplaceModel").getProperty("/liveRequestQueue");

			this._oModel.attachRequestSent(function (oEvent) {
				var sUniqueId = Math.random().toString(36).substring(2) + Date.now().toString(36);
				var iLiveRequestId = "odata_" + sUniqueId;

				var sServiceUrl = oEvent.getSource().sServiceUrl;
				// console.log("STARTED: Card request. Service URL: "  + sServiceUrl);

				var oSourceModel = oEvent.getSource();
				// enqueue step 
				oOldRequestQueue[iLiveRequestId] = oSourceModel;
				// console.log("starting: " + iLiveRequestId + " total alive:" + Object.keys(oOldRequestQueue).length);
				sap.ui.getCore().getModel("workplaceModel").setProperty("/liveRequestQueue", oOldRequestQueue);
				sap.ui.getCore().getModel("workplaceModel").setProperty("/liveRequestQueueCount", sap.ui.getCore().getModel("workplaceModel").getProperty(
					"/liveRequestQueueCount") + 1);

				oSourceModel.attachRequestCompleted(function (oEvent) {
					// release step
					var oNewRequestQueue = sap.ui.getCore().getModel("workplaceModel").getProperty("/liveRequestQueue");
					if (oNewRequestQueue[iLiveRequestId]) {
						delete oNewRequestQueue[iLiveRequestId];
						// console.log("destroying: " + iLiveRequestId + " total alive:" + Object.keys(oNewRequestQueue).length);
						sap.ui.getCore().getModel("workplaceModel").setProperty("/liveRequestQueue", oNewRequestQueue);
						sap.ui.getCore().getModel("workplaceModel").setProperty("/liveRequestQueueCount", sap.ui.getCore().getModel("workplaceModel")
							.getProperty("/liveRequestQueueCount") - 1);
					}
				});

				oSourceModel.attachRequestFailed(function (oEvent) {
					// console.log("ABORTED: Card request. " + oEvent.getParameter("responseText"));
				}, this);

				// subscribe to kill event bus
				sap.ui.getCore().getEventBus().subscribe("Request", "kill", function (oData) {
					var oRequestQueue = sap.ui.getCore().getModel("workplaceModel").getProperty("/liveRequestQueue");
					var aRequestQueueKeys = Object.keys(oRequestQueue);

					aRequestQueueKeys.forEach(function (sRequestKey) {
						if (sRequestKey.split("_")[0] === "odata") {
							var oSourceModel2 = oRequestQueue[sRequestKey];
							if (oSourceModel2) {
								// TODO: check if need to iterate over other aPendingRequestHandles in case of BatchRequest
								var oCall = oSourceModel2 && oSourceModel2.aPendingRequestHandles;
								oCall && oCall[0] && oCall[0].abort();
								oSourceModel2.fireRequestFailed({
									message: "MCCWorkplace: Aborted due to change on Profile",
									responseText: "Service URL: " + sServiceUrl,
									statusCode: "(Aborted)",
									statusText: "MCCWorkplace-Aborted"
								});
							}
						}
					});
				}.bind(this));
			}, this);
		}

	});

});