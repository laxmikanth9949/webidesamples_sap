sap.ui.define([
	"com/sap/mcc/workplace/controller/BaseController",
	"com/sap/mcc/workplace/controller/CRUDManager",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/ui/integration/library",
	"sap/ui/core/dnd/DragInfo",
	"sap/f/dnd/GridDropInfo",
	"sap/ui/integration/widgets/Card",
	"sap/f/GridContainerItemLayoutData",
	"sap/ui/core/Fragment"
], function (BaseController, CRUDManager, JSONModel, DateFormat, Filter, FilterOperator, MessageToast, integrationLibrary, DragInfo,
	GridDropInfo, Card,
	GridContainerItemLayoutData, Fragment) {
	"use strict";

	var CardsLayoutController = BaseController.extend("com.sap.mcc.workplace.controller.CardIntegration", {
		/**
		 * @alias com.sap.mcc.workplace.controller.CardIntegration
		 */
		constructor: function (oView) {
			this.getView = function () {
				return oView;
			};
			this.CRUDManager = new CRUDManager(oView);
			this.getView().setModel(new JSONModel({}), "CurrentCardPositions");
		},

		loadCards: function (sProfileAlias) {
			var oGrid = this.getView().byId(sProfileAlias + "gridIconTabBar");
			oGrid.removeAllItems();

			//TODO: validate sProfileAlias
			var oModelCardPos = this.getOwnerComponent().getModel("MCSCardsOVPModel");
			var sUserID = this.getCoreModel("UserInfo").getProperty("/name");
			this.CRUDManager.readProfileInstance(sUserID, null, sProfileAlias, null)
				.then(function (oData) {
					// promise to tigger filter on Initial Loading
					var aPromises = [];
					var fnPromise = function (aPromises) {
						if (aPromises.length > 0) {
							Promise.all(aPromises).then(function (oPromiseData) {
								sap.ui.getCore().getEventBus().publish("Filter", "InitialLoading");
							}).catch(function () {
								sap.ui.getCore().getEventBus().publish("Filter", "InitialLoading");
							});
						}

						this.getCoreModel("workplaceModel").setProperty("/busy/profileIconTabBar", false);
					}.bind(this);

					if (oData.results && oData.results.length > 0) {
						var oProfileInstance = oData.results[0];
						var aCardOrder = (oProfileInstance.Cards && oProfileInstance.Cards.CardOrder) ? oProfileInstance.Cards.CardOrder.split(";") : [];

						// cleanup cards from /_cardIntegration/sProfileAlias if they were removed
						var aGeneratedCardArray = this.getCoreModel("workplaceModel").getProperty("/_cardIntegration/" + sProfileAlias) ? this.getCoreModel(
							"workplaceModel").getProperty("/_cardIntegration/" + sProfileAlias) : [];
						aGeneratedCardArray = aGeneratedCardArray.map(function (oCard, iIndex) { // will only return cards that are still present
							if (aCardOrder.indexOf(oCard.cardId) !== -1) {
								return oCard;
							} else {
								return undefined;
							}
						});
						this.getCoreModel("workplaceModel").setProperty("/_cardIntegration/" + sProfileAlias, aGeneratedCardArray.filter(function (
							oCard) {
							return oCard;
						}));

						// add new cards that were included
						aCardOrder.forEach(function (sCardID) {
							if (sCardID !== "") {
								var oPromise = this._loadCardById(oGrid, sCardID, sProfileAlias);

								// in case current ProfileInstance is selected
								if (this.getCoreModel("workplaceModel").getProperty("/selectedProfileInstance/Alias") === sProfileAlias) {
									aPromises.push(oPromise);
								}
							}
						}.bind(this));
						fnPromise(aPromises);

					}
				}.bind(this))
				.catch(function (oError) {
					//TODO: implement error when cards cannot be loaded
				});
		},

		_loadCardById: function (oGrid, sCardID, sProfileAlias) {
			return new Promise(function (resolve, reject) {
				this.CRUDManager.readCard(sCardID)
					.then(function (oCard) {
						if (oCard) {
							var aArray = this.getCoreModel("workplaceModel").getProperty("/_cardIntegration/" + sProfileAlias) ? this.getCoreModel(
								"workplaceModel").getProperty("/_cardIntegration/" + sProfileAlias) : [];

							var bCardExist = false;
							if (aArray.length > 0) {
								for (var i = 0; i < aArray.length; i++) {
									if (oCard.CardID === aArray[i].cardId) {
										bCardExist = true;
										break;
									}
								}
							}

							if (!bCardExist) {
								var sModulePath = jQuery.sap.getModulePath("com.sap.mcc.workplace");
								var oObject = {
									cardId: oCard.CardID,
									CardType: oCard.CardType,
									CardName: oCard.CardName,
									LayoutColumns: oCard.LayoutColumns,
									FilterProperty: oCard.FilterProperty,
									Description: oCard.Description,
									ReloadInterval: this._getReloadInterval(oCard.Description),
									AuthorizationRole: this._getAuthorizationRole(oCard.Description),
									sCardManifestBindingPath: sModulePath + "/CardComponent/" + oCard.CardID + "/manifest.json"
								};

								aArray.push(oObject);

								this.getCoreModel("workplaceModel").setProperty("/_cardIntegration/" + sProfileAlias, aArray);
							}

							//enable filterItems on Filterbar when initally starting the application or updating the cards per profile
							if (sap.ui.getCore().getModel("workplaceModel").getProperty("/selectedProfileInstance/Alias") === sProfileAlias) {
								//trigger update filter bar items
								this.updateFilterBarItems(sProfileAlias);
							}
						}
						resolve(oCard);
					}.bind(this))
					.catch(function (oError) {
						// Error catch in ErrorHandler.js
						// TODO: disable entire application in case no Profile is loaded.
						reject(oError);
					});

			}.bind(this));
		},

		initDragDropGridContainer: function (sProfileAlias) {
			var oGrid = this.getView().byId(sProfileAlias + "gridIconTabBar");
			oGrid.removeAllItems();
			var that = this;

			oGrid.addDragDropConfig(new DragInfo({
				sourceAggregation: "items",
				groupName: sProfileAlias + "gridIconTabBar"
			}));
			oGrid.addDragDropConfig(new GridDropInfo({
				targetAggregation: "items",
				groupName: sProfileAlias + "gridIconTabBar",
				dropPosition: "Between",
				dropLayout: "Horizontal",
				drop: function (oInfo) {
					var oDragged = oInfo.getParameter("draggedControl"),
						oDropped = oInfo.getParameter("droppedControl"),
						oDragParent = oDragged.getParent(),
						oDropParent = oDropped.getParent(),
						sInsertPosition = oInfo.getParameter("dropPosition"),
						iDragPosition = oDragParent.indexOfItem(oDragged),
						iDropPosition = oDropParent.indexOfItem(oDropped);

					oDragParent.removeItem(oDragged);

					if (oDragParent === oDropParent && iDragPosition < iDropPosition) {
						iDropPosition--;
					}

					if (sInsertPosition === "Before") {
						oDropParent.insertItem(oDragged, iDropPosition);
					} else {
						oDropParent.insertItem(oDragged, iDropPosition + 1);
					}

					var oItemOrder = oGrid.getItems();
					var sItemOrder = "";
					oItemOrder.forEach(function (Item) {
						var id = Item.getId();
						sItemOrder = sItemOrder + id + ";";
					});
					that.saveCardPositions(sProfileAlias, that.getCoreModel("workplaceModel").getProperty(
						"/selectedProfileInstance/ProfileInstanceCardUUID"));
				}
			}));
		},

		saveCardPositions: function (sProfileAlias, sProfileInstanceCardUUID) {
			var oGrid = this.getView().byId(sProfileAlias + "gridIconTabBar");
			var aItemOrder = oGrid.getItems();
			var aItemOrderFinal = [];
			aItemOrder.forEach(function (oItem) {
				var sCardId = this.getCoreModel("workplaceModel").getProperty(oItem.getBindingContext("workplaceModel").getPath() + "/cardId");
				aItemOrderFinal.push(sCardId);
			}.bind(this));

			this.CRUDManager.updateProfileInstanceCard(sProfileInstanceCardUUID, aItemOrderFinal.join(";"));
		},

		updateFilterBarItems: function (sProfileAlias) {
			var aVisibleCards = this.getView().getModel("workplaceModel").getProperty("/_cardIntegration/" + sProfileAlias);
			var oWorkplaceModel = this.getView().getModel("workplaceModel");

			var oVisibleFilterItems = {};

			if (aVisibleCards) {
				aVisibleCards.forEach(function (oCard) {
					if (oCard.FilterProperty) {
						var aFilterItems = oCard.FilterProperty.split(";");
						aFilterItems.forEach(function (sItem) {
							oVisibleFilterItems[sItem] = true;
						}.bind(this));
					}
				}.bind(this));
			}

			oWorkplaceModel.setProperty("/FilterBarVisibleItems", oVisibleFilterItems);
		},

		//extract reload intervall from card description json object
		_getReloadInterval: function (sJsonString) {
			var oDescription;
			try {
				oDescription = JSON.parse(sJsonString);
			} catch (error) {
				console.log("JSON String Error" + error);
				return 0;
			}

			if (oDescription.groups && oDescription.groups.length > 0) {
				for (var i = 0; i < oDescription.groups.length; i++) {
					if (oDescription.groups[i].heading === "Card Details") {
						var aElements = oDescription.groups[i].elements;
						if (aElements) {
							for (var x = 0; x < aElements.length > 0; x++) {
								if (aElements[x].label === "Reload Interval") {
									var iReloadInterval = parseInt(aElements[x].value.replace(/\D/g, ''), 10) || 0;
									//convert minutes into milliseconds
									iReloadInterval = iReloadInterval * 60 * 1000;
									return iReloadInterval;
								}

							}
						}
					}
				}
			}
			return 0;

			//var aValues = oCard.Description["Reload Interval"].match(/[0-9]*$/);
			//1. Step loop through groups and find heading Card Details --> no group return 0
			//2. step loop elements and find "Reload Inteval" --> not found return 0 otherwise return reload interval

		},
		
		_getAuthorizationRole: function (sJsonString) {
			var oDescription;
			try {
				oDescription = JSON.parse(sJsonString);
			} catch (error) {
				console.log("JSON String Error" + error);
				return [];
			}
			
			if (oDescription.groups && oDescription.groups.length > 0) {
				for (var i = 0; i < oDescription.groups.length; i++) {
					if (oDescription.groups[i].heading === "Card Details") {
						var aElements = oDescription.groups[i].elements;
						if (aElements) {
							for (var x = 0; x < aElements.length > 0; x++) {
								if (aElements[x].label === "Authorization Role") {
									return aElements[x].value.split(";");
								}
							}
						}
					}
				}
			}
			return [];
		}
	});
	return CardsLayoutController;
});