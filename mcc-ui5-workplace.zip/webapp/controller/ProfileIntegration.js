sap.ui.define([
	"com/sap/mcc/workplace/controller/BaseController",
	"com/sap/mcc/workplace/controller/CRUDManager"
], function (BaseController, CRUDManager) {
	"use strict";

	return BaseController.extend("com.sap.mcc.workplace.controller.ProfileIntegration", {
		/**
		 * @alias com.sap.mcc.workplace.controller.ProfileIntegration
		 */
		constructor: function (oView) {
			this.getView = function () {
				return oView;
			};
			this.CRUDManager = new CRUDManager(oView);
		},

		/**
		 * This method will make sure the basic structure is present between Profiles and ProfileInstanceCard,
		 * by adding the missing references and deleting orphan InstanceProfilesCards
		 */
		rebuildBasicProfileStructure: function (sUserID) {
			return new Promise(function (resolve, reject) {
				Promise.all([this.CRUDManager.readProfileInstanceCards(sUserID), this.CRUDManager.readProfiles(sUserID), this.CRUDManager.readProfileInstances(
						sUserID)])
					.then(function (oResponse) {
						var oProfileInstanceCards = oResponse[0].results;
						var oProfiles = oResponse[1].results;
						var oProfileInstances = oResponse[2].results;
						// will keep track if all ProfileInstanceCardPromises had been executed
						var aProfileInstanceCardPromisesToBeFixed = [];

						// if ProfileInstances is empty, it is the user first access;
						if (oProfileInstances.length === 0) {
							resolve();
							return;
						}

						// double check if all Profile has a corresponding ProfileInstanceCard (/CardPositions)
						oProfiles.forEach(function (oProfile) {
							var bMissingProfileInstanceCard = true;
							oProfileInstanceCards.forEach(function (oProfileInstanceCard) {
								if (oProfileInstanceCard.RolesID === oProfile.ID) {
									bMissingProfileInstanceCard = false;
								}
							});

							// if ProfileInstanceCard is missing, create it.
							if (bMissingProfileInstanceCard) {
								aProfileInstanceCardPromisesToBeFixed.push(new Promise(function (resolve2, reject2) {
									this.CRUDManager.createProfileInstanceCard(sUserID, oProfile.RoleID, oProfile.ID, null)
										.then(function (oProfileInstanceCardResponse) {
											resolve2(oProfileInstanceCardResponse);
										}.bind(this))
										.catch(function (oError) {
											reject2(oError);
										});
								}.bind(this)));

							}
						}.bind(this));

						Promise.all(aProfileInstanceCardPromisesToBeFixed)
							.then(function (oData) {
								this.CRUDManager.readProfileInstanceCards(sUserID)
									.then(function (oData2) {
										var aProfileInstancePromisesToBeFixed = [];
										var oProfileInstanceCards2 = oData2.results;
										// re-map ProfileInstance to latest ProfileInstanceCards
										oProfileInstances.forEach(function (oProfileInstance) {
											oProfileInstanceCards2.forEach(function (oProfileInstanceCard) {
												if (oProfileInstance.Roles_ID === oProfileInstanceCard.RolesID) {
													if (oProfileInstance.Cards_ID !== oProfileInstanceCard.ID) {
														// update ProfileInstance with ProfileInstanceCard reference only if it is different
														aProfileInstancePromisesToBeFixed.push(new Promise(function (resolve2, reject2) {
															this.CRUDManager.updateProfileInstanceProfileInstanceCard(oProfileInstance.ID, oProfileInstanceCard.ID)
																.then(function (oProfileInstanceResponse) {
																	resolve2(oProfileInstanceResponse);
																}.bind(this))
																.catch(function (oError) {
																	reject2(oError);
																});
														}.bind(this)));
													}
												}
											}.bind(this));
										}.bind(this));

										// if all ProfileInstance is ok, return 
										Promise.all(aProfileInstancePromisesToBeFixed)
											.then(function () {
												// Delete orphan ProfileInstance and ProfileInstanceCard
												this.deleteOrphanProfileInstancesAndProfileInstanceCards(sUserID)
													.then(function () {
														resolve();
													})
													.catch(function (oError) {
														reject(oError);
													});
											}.bind(this))
											.catch(function (oError) {
												reject(oError);
											});
									}.bind(this))
									.catch(function (oError) {
										reject(oError);
									});
							}.bind(this))
							.catch(function (oError) {
								reject(oError);
							});
					}.bind(this))
					.catch(function (oError) {
						reject(oError);
					});
			}.bind(this));
		},

		/**
		 * Check and delete orphan ProfileInstance and ProfileInstanceCard
		 */
		deleteOrphanProfileInstancesAndProfileInstanceCards: function (sUserID) {
			return new Promise(function (resolve, reject) {
				Promise.all([this.CRUDManager.readProfileInstanceCards(sUserID), this.CRUDManager.readProfiles(sUserID), this.CRUDManager.readProfileInstances(
						sUserID)])
					.then(function (oResponse) {
						var oProfileInstanceCards = oResponse[0].results;
						var oProfiles = oResponse[1].results;
						var oProfileInstances = oResponse[2].results;
						var aToBeDeleted = [];
						
						oProfileInstances.forEach(function (oProfileInstance) {
							var bIsOrphan = true;
							// check if there is any orphan ProfileInstance
							oProfiles.forEach(function (oProfile) {
								if (oProfileInstance.Roles_ID === oProfile.ID) {
									bIsOrphan = false;
								}
							});
							if (bIsOrphan) {
								aToBeDeleted.push(new Promise(function (resolve2, reject2) {
									this.CRUDManager.deleteProfileInstance(oProfileInstance.ID)
										.then(function (oData) {
											resolve2();
										}.bind(this))
										.catch(function (oError) {
											reject2(oError);
										});
								}.bind(this)));
							}
						}.bind(this));

						oProfileInstanceCards.forEach(function (oProfileInstanceCard) {
							var bIsOrphan = true;
							// check if there is any orphan ProfileInstanceCard
							oProfileInstances.forEach(function (oProfileInstance) {
								if (oProfileInstanceCard.ID === oProfileInstance.Cards_ID) {
									bIsOrphan = false;
								}
							});
							if (bIsOrphan) {
								aToBeDeleted.push(new Promise(function (resolve2, reject2) {
									this.CRUDManager.deleteProfileInstanceCard(oProfileInstanceCard.ID)
										.then(function (oData) {
											resolve2();
										}.bind(this))
										.catch(function (oError) {
											reject2(oError);
										});
								}.bind(this)));
							}

						}.bind(this));

						Promise.all(aToBeDeleted)
							.then(function (oData) {
								resolve(oData);
							})
							.catch(function (oError) {
								reject(oError);
							});
					}.bind(this))
					.catch(function (oError) {
						reject(oError);
					});

			}.bind(this));
		},

		/**
		 * Initialize ProfileInstance and Cards based on Default. It usually gets executed when user access the application for first time.
		 * It is performedin 2 steps:
		 * 1. Delete all existing custom Roles, RoleInstance and RoleInstanceCard (TODO: implement)
		 * 2. Create ProfileInstance based on default
		 * 
		 * @param {string} sUserID userID (D-/I-/S-number)
		 * @param {string} fnCallback callback function
		 * @param {string} oContextBinding "this" context from caller
		 */
		initializeDefaultProfileInstance: function (sUserID, fnCallback, oContextBinding) {
			// TODO: validate UserID
			// STEP 1: Delete orphan ProfileInstance and ProfileInstanceCard
			// TODO: implement step 1

			// STEP 2: Create initial ProfileInstance and ProfileInstanceCard
			Promise.all([this.CRUDManager.readCards(), this.CRUDManager.readProfiles(sUserID)])
				.then(function (oResponse) {
					var oCards = oResponse[0].results;
					var oProfiles = oResponse[1].results;

					// map all Default Cards for a given Profile (sProfileAlias)
					if (oProfiles.length > 0) {
						oProfiles.forEach(function (oProfile, iProfileIndex) {
							var sProfileAlias = oProfile.RoleID;
							var sProfileUUID = oProfile.ID;
							var aCardOrder = [];

							if (oCards.length > 0) {
								oCards.forEach(function (oCard) {
									var aDefRole = oCard.DefaultRole ? oCard.DefaultRole.split(";"):[];

									for (var i = 0; i < aDefRole.length; i++) {
										if (aDefRole[i] === sProfileAlias) {
											aCardOrder.push(oCard.CardID);
										}
									}
								});
							}
							// Create Profile Instance Card
							this.CRUDManager.createProfileInstanceCard(sUserID, sProfileAlias, sProfileUUID, aCardOrder.join(";"))
								.then(function (oData) {
									var sCardsUUID = oData.ID;

									// Create Profile Instance
									this.CRUDManager.createProfileInstance(sUserID, sProfileAlias, sProfileUUID, sCardsUUID, iProfileIndex)
										.then(function () {
											// if last Profile to be created and fnCallback, call fnCallback function
											if (fnCallback && oProfiles.length === iProfileIndex + 1) {
												fnCallback.apply(oContextBinding, [sUserID]);
											}
										})
										.catch(function (oError) {
											console.log(oError);
											//TODO: catch error when creating Profile Instance
										});
								}.bind(this))

							.catch(function (oError) {
								console.log(oError);
								//TODO: catch error when creating Profile Instance Card
							});
						}.bind(this));
					} else {
						// if fnCallback, call function
						if (fnCallback) {
							fnCallback(sUserID);
						}
					}

				}.bind(this))
				.catch(function (oError) {

					console.log(oError);
					//TODO: catch error and display error.
				});
		}
	});
});