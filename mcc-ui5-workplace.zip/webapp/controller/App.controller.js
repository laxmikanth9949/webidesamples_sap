sap.ui.define([
	"com/sap/mcc/workplace/controller/BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("com.sap.mcc.workplace.controller.App", {

		onInit: function () {

		}

	});

});

