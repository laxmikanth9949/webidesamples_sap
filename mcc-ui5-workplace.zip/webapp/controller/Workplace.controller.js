sap.ui.define([
	"com/sap/mcc/workplace/controller/BaseController",
	"com/sap/mcc/workplace/controller/CardIntegration",
	"com/sap/mcc/workplace/controller/ProfileIntegration",
	"com/sap/mcc/workplace/controller/FilterBar",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/f/GridContainerSettings",
	"sap/f/GridContainerItemLayoutData",
	"sap/m/IconTabFilter",
	"sap/f/GridContainer",
	"com/sap/mcc/workplace/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/Token",
	"sap/m/MultiInput",
	"sap/ui/integration/widgets/Card",
	"sap/m/MessageStrip",
	"sap/base/util/UriParameters",
		"sap/m/MessageBox",
], function (BaseController, CardIntegration, ProfileIntegration, FilterBar, JSONModel, Fragment, GridContainerSettings,
	GridContainerItemLayoutData,
	IconTabFilter,
	GridContainer, formatter, Filter, FilterOperator, Sorter, Token, MultiInput, Card, MessageStrip, UriParameters, MessageBox) {
	"use strict";

	return BaseController.extend("com.sap.mcc.workplace.controller.Workplace", {

		formatter: formatter,

		/**
		 * Called when the controller is instantiated.
		 * @public
		 */
		onInit: function () {
			var oRouter = this.getRouter();
			oRouter.getRoute("workplace").attachMatched(this._onRouteMatched, this);

			var oRegionModel = new JSONModel({
				"RegionCollection": [{
					"RegionId": "World"
				}, {
					"RegionId": "EMEA"
				}, {
					"RegionId": "NA"
				}, {
					"RegionId": "LA"
				}, {
					"RegionId": "APJ"
				}],
				"RegionCollection2" : [{
					"Key": "O 50008010",
					"RegionId": "EMEA"
				}, {
					"Key": "O 50008167",
					"RegionId": "NA"
				}, {
					"Key": "O 50008174",
					"RegionId": "LA"
				}, {
					"Key": "O 50008134",
					"RegionId": "APJ"
				}]
			});
			
			this.getView().setModel(oRegionModel, "Region");
		},

		_onRouteMatched: function (oEvent) {
		 
			this._checkWorkplaceUrl();
			var oArgs, oView;
			oArgs = oEvent.getParameter("arguments");
			oView = this.getView();
			if (oArgs && oArgs.profile) {
				var oIconTabBar = this.getView().byId("profileIconTabBar");
				oIconTabBar.setSelectedKey(oArgs.profile);
			}

		},

		onAfterRendering: function () {

			// workplaceModel controls all aspect of the app and belongs to the workplace core logic
			this.getView().setModel(this.getCoreModel("workplaceModel"), "workplaceModel");

			// initialize ProfileIntegration and CardIntegration
			this._ProfileIntegration = new ProfileIntegration(this.getView());
			this._CardIntegration = new CardIntegration(this.getView());
			this._FilterBar = new FilterBar(this.getView());

			var oPromiseUserLoaded = this._getUserInfo(); // from BaseController

			var oServiceTeamRegionModel = this._getServiceTeamsRegions();
			
			this._getRecommendationsValueHelps();

			var oPublicVariantPromise = this._getPublicVariants();

			// Initialization will start only after basic user information is loaded

			Promise.all([oPromiseUserLoaded, oServiceTeamRegionModel, oPublicVariantPromise]).then(function (oData) {

				var sUserId = oData[0].name;

				// healing Basic Structure (Profiles, ProfileInstance and ProfileInstanceCard)
				this._ProfileIntegration.rebuildBasicProfileStructure(sUserId)
					.then(function () { // Basic Profile Structure healing successfull
						// Load Profiles after user is loaded
						this._renderProfileInstanceTabs(sUserId);
					}.bind(this))
					.catch(function (oError) {
						console.log(oError);
						// TODO: error in the basic structure. Existing data couldn't be rebuild. Delete all Profiles and refresh app.
					});
				//
				this.getCoreModel("workplaceModel").setProperty("/UserId", sUserId);
				this.getCoreModel("workplaceModel").setProperty("/FilterBar/ResponsiblePerson", [{
					key: sUserId,
					text: sUserId
				}]);
				this.getCoreModel("workplaceModel").setProperty("/FilterBar/Region", ["O 50008010", "O 50008134", "O 50008167", "O 50008174"]);
			}.bind(this));

			//sap.ui.getCore().getEventBus().subscribe("Notification", "NotificationTriggered", this.onTriggerNotification);

			sap.ui.getCore().getEventBus().subscribe("Filter", "InitialLoading", this._initialDataLoading.bind(this));

			// Workplace Actions (menu)
			sap.ui.getCore().getEventBus().subscribe("Profile", "remove", this._onProfileRemoveEvent.bind(this));
			sap.ui.getCore().getEventBus().subscribe("Profile", "create", this._onProfileAddEvent.bind(this));
			sap.ui.getCore().getEventBus().subscribe("Card", "refresh", this._onCardRefreshEvent.bind(this));

		},

		/* =========================================================== */
		/* begin: event bus methods                                    */
		/* =========================================================== */

		/** 
		 *	Event handler to start initial loading of card data
		 *	event is triggered when all cards are loaded (in the selected) are loaded 
		 **/
		_initialDataLoading: function () {
			var sFilterBarId = "GenericFilterBar";
			var sSelectedProfileAlias = sap.ui.getCore().getModel("workplaceModel").getProperty("/selectedProfileInstance/Alias");
			var sFragmentId = sSelectedProfileAlias + "FilterBarFragment";
			var oFilterBar = this.byId(sap.ui.core.Fragment.createId(sFragmentId, sFilterBarId));
			if (oFilterBar) {
				oFilterBar.fireSearch();
			}
		},

		_onProfileRemoveEvent: function (sChannel, sEventId, oData) {
			var oIconTabBar = this.getView().byId("profileIconTabBar");
			var sRoleID = oData.RoleID;
			oIconTabBar.getItems().forEach(function (oItem) {
				if (oItem.getKey() === sRoleID) {
					oItem.destroy();
					oIconTabBar.fireSelect();
					return;
				}
			});

			var sUserId = this.getCoreModel("workplaceModel").getProperty("/UserId");
			this._ProfileIntegration.CRUDManager.readProfileInstances(sUserId)
				.then(function (oData) {
					var oProfileInstances = oData.results;
					// update ProfileInstances
					sap.ui.getCore().getModel("workplaceModel").setProperty("/ProfileInstances", oProfileInstances);
				});

		},

		_onProfileAddEvent: function (sChannel, sEventId, oData) {
			var oIconTabBar = this.getView().byId("profileIconTabBar");
			oIconTabBar.addItem(this._createProfileInstanceIconTabFilter(oData.RoleID, oData.RoleName));
			// Initialize Profile Cards
			this._CardIntegration.initDragDropGridContainer(oData.RoleID);
			this._CardIntegration.loadCards(oData.RoleID);
			oIconTabBar.setSelectedKey(oData.RoleID);
			oIconTabBar.fireSelect({
				key: oData.RoleID + "Tab"
			});

			var sUserId = this.getCoreModel("workplaceModel").getProperty("/UserId");
			this._ProfileIntegration.CRUDManager.readProfileInstances(sUserId)
				.then(function (oData) {
					var oProfileInstances = oData.results;
					// update ProfileInstances
					sap.ui.getCore().getModel("workplaceModel").setProperty("/ProfileInstances", oProfileInstances);
				});
		},

		_onCardRefreshEvent: function (sChannel, sEventId, oData) {
			var sUserId = this.getCoreModel("workplaceModel").getProperty("/UserId");
			this._ProfileIntegration.CRUDManager.readProfileInstances(sUserId)
				.then(function (oData2) {
					var oProfileInstances = oData2.results;
					var oIconTabBar = this.getView().byId("profileIconTabBar");
					// update ProfileInstances
					sap.ui.getCore().getModel("workplaceModel").setProperty("/ProfileInstances", oProfileInstances);

					// Initialize Profile Cards
					this._CardIntegration.initDragDropGridContainer(oData.ProfileAlias);
					this._CardIntegration.loadCards(oData.ProfileAlias);

					// workaround to retrigger the profile selection. On a normal scenario it won't rerender the profile if user hasn't switch, causing the page not to be refresh
					// this workaround will reset the previousSelectedProfileInstance value
					this.getCoreModel("workplaceModel").setProperty("/previousSelectedProfileInstance/Alias", oData.RoleID + "-old");
					oIconTabBar.setSelectedKey(oData.ProfileAlias);
					oIconTabBar.fireSelect({
						key: oData.ProfileAlias + "Tab"
					});

				}.bind(this));

		},

		onTokenUpdate: function (oEvent) {
			var sEventType = oEvent.getParameters().type;
			var sModelProperty = this._mapMultiInputToFilterValues(oEvent.getSource().getId());
			var aArray;

			if (sModelProperty && sEventType === "added") {
				//add token to 
				var oToken = oEvent.getParameters().addedTokens[0];
				var sTokenText = oToken.getText();
				aArray = this.getCoreModel("workplaceModel").getProperty("/FilterBar/" + sModelProperty) ? this.getCoreModel("workplaceModel").getProperty(
					"/FilterBar/" + sModelProperty) : [];
				var oObject = {
					key: sTokenText,
					text: sTokenText
				};
				aArray.push(oObject);
				this.getCoreModel("workplaceModel").setProperty("/FilterBar/" + sModelProperty, aArray);
			} else if (sModelProperty && sEventType === "removed") {
				//remove token 
				var aAllTokens = oEvent.getSource().getTokens();
				var aUpdatedTokens = [];
				var oRemovedTokenKey = oEvent.getParameters().removedTokens[0].getKey();
				aAllTokens.forEach(function (oTokenUpdate) {
					if (oRemovedTokenKey !== oTokenUpdate.getText()) {
						var oObj = {
							key: oTokenUpdate.getText(),
							text: oTokenUpdate.getText()
						};
						aUpdatedTokens.push(oObj);
					}
				});
				this.getCoreModel("workplaceModel").setProperty("/FilterBar/" + sModelProperty, aUpdatedTokens);

			}

		},

		onMultiBoxFinished: function (oEvent) {
			var sModelProperty = "ServiceTeam";
			var aSelectedKeys = oEvent.getSource().getSelectedKeys();
			this.getCoreModel("workplaceModel").setProperty("/FilterBar/" + sModelProperty, aSelectedKeys);
		},

		onMultiBoxRecommendationStatusFinished: function (oEvent) {
			var sModelProperty = "RecommendationStatus";
			var aSelectedKeys = oEvent.getSource().getSelectedKeys();
			this.getCoreModel("workplaceModel").setProperty("/FilterBar/" + sModelProperty, aSelectedKeys);
		},
		
		onMultiBoxRecommendationTypeFinished: function (oEvent) {
			var sModelProperty = "RecommendationType";
			var aSelectedKeys = oEvent.getSource().getSelectedKeys();
			this.getCoreModel("workplaceModel").setProperty("/FilterBar/" + sModelProperty, aSelectedKeys);
		},
		
		onMultiBoxRecommendationTargetResultFinished: function (oEvent) {
			var sModelProperty = "RecommendationTargetResult";
			var aSelectedKeys = oEvent.getSource().getSelectedKeys();
			this.getCoreModel("workplaceModel").setProperty("/FilterBar/" + sModelProperty, aSelectedKeys);
		},
		
		onMultiBoxRegionFinished: function(oEvent){
			var sModelProperty = "Region";
			var aSelectedKeys = oEvent.getSource().getSelectedKeys();
			this.getCoreModel("workplaceModel").setProperty("/FilterBar/" + sModelProperty, aSelectedKeys);
		},
	
		_mapMultiInputToFilterValues: function (sId) {
			var aId = sId.split("--");
			var sMultiInputId = aId[aId.length - 1];
			var sProperty;
			switch (sMultiInputId) {
			case 'respPersonMulitiInput':
				sProperty = "ResponsiblePerson";
				break;
			case 'processorMultiInput':
				sProperty = "Processor";
				break;
			case 'caseIdMulitiInput':
				sProperty = "CaseId";
				break;
			default:
				sProperty = null;
			}

			return sProperty;
		},

		/* =========================================================== */
		/* end: event bus methods                                      */
		/* =========================================================== */

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/** 
		 * Build scafolding for Workplace - IconTabFilter, FilterBar, Cards Grid, etc
		 * @private
		 * @param {string} sUserID User Id.
		 * @returns {void}
		 */
		_renderProfileInstanceTabs: function (sUserID) {
			var sUserId = sUserID || this.getCoreModel("UserInfo").getProperty("/name");
			var oIconTabBar = this.getView().byId("profileIconTabBar");

			this._ProfileIntegration.CRUDManager.readProfileInstances(sUserId)
				.then(function (oData) {
					var oProfileInstances = oData.results;
					var sSelectedProfileAlias;
					var sParameterProfile = this.getRouter().getHashChanger().getHash();
					var aProfileAliases = [];

					//check if any Profile Instance exists
					if (oProfileInstances.length > 0) {
						aProfileAliases = oProfileInstances.map(function (oProfile) {
							return oProfile.RoleID;
						});
						// update ProfileInstances
						sap.ui.getCore().getModel("workplaceModel").setProperty("/ProfileInstances", oProfileInstances);

						oProfileInstances.forEach(function (oProfile) {
							oIconTabBar.addItem(this._createProfileInstanceIconTabFilter(oProfile.Roles.RoleID, oProfile.Roles.RoleName));
							// Initialize Profile Cards
							this._CardIntegration.initDragDropGridContainer(oProfile.RoleID);
							this._CardIntegration.loadCards(oProfile.RoleID);
						}.bind(this));
						// set Profile in iconTabBar and update parameters
						sSelectedProfileAlias = (aProfileAliases.indexOf(sParameterProfile) > -1) ? sParameterProfile : aProfileAliases[0];
						this._setSelectedProfileInstance(sSelectedProfileAlias);
						oIconTabBar.setSelectedKey(sSelectedProfileAlias);
						oIconTabBar.fireSelect({
							key: sSelectedProfileAlias + "Tab"
						});
						// Press Search Button
						Fragment.byId(this.getView().createId(sSelectedProfileAlias + "FilterBarFragment"), "GenericFilterBar").fireSearch();
					} else { // If first time accessing the application
						this._displayWelcomeDialog();
						// Create ProfileIntances and call _renderProfileInstanceTabs recursively
						this._ProfileIntegration.initializeDefaultProfileInstance(sUserId, this._renderProfileInstanceTabs, this);
					}
				}.bind(this))
				.catch(function (oError) {
					console.log(oError);
					// TODO: disable entire application in case no Profile is loaded.
				});
		},

		/**
		 * Create IconTabFilter for ProfileInstance
		 * @private
		 * @param {string} sProfileAlias Profile Alias (/Roles/RoleID).
		 * @param {string} sProfileName Profile Name (/Roles/RoleName).
		 * @returns {sap.m.IconTabFilter} instance of IconTabFilter
		 */
		_createProfileInstanceIconTabFilter: function (sProfileAlias, sProfileName) {
			/**************************************
			 * BEGIN: Creating IconTabBar content *
			 **************************************/
			var oScrollContainer = new sap.m.ScrollContainer({
				id: this.getView().createId(sProfileAlias + "scrollContainer"),
				height: "100%",
				width: "100%",
				vertical: true,
				content: [] // items can be prepended here before FilterBarFragment or GridContainer(Cards)
			});

			var oGridContainer = new GridContainer({
				id: this.getView().createId(sProfileAlias + "gridIconTabBar"),
				visible: "{= ${workplaceModel>/selectedProfileInstance/CardOrder}.length > 0 ? true : false }",
				snapToRow: false,
				allowDenseFill: true,
				layout: new GridContainerSettings({
					rowSize: "5rem",
					columnSize: "5rem",
					gap: "1rem"
				}),
				layoutS: new GridContainerSettings({
					rowSize: "5rem",
					columnSize: "5rem",
					gap: "0.5rem"
				}),
				items: {
					path: "workplaceModel>/_cardIntegration/" + sProfileAlias, // no curly brackets here!
					template: new Card({
						busy: true, // Requires direct boolean. Tried using binding, but the .refresh() breaks the layoutData.
						manifest: "{workplaceModel>sCardManifestBindingPath}",
						layoutData: new GridContainerItemLayoutData({
							columns: "{workplaceModel>LayoutColumns}"
						})
					})
				}
			}).addStyleClass("sapUiSmallMargin");

			// if no cards in Profile, display message to add cards and hide FilterBar
			var oNoCardsVBox = new sap.m.VBox({
				alignItems: "Center",
				items: [
					new sap.ui.core.Icon({
						src: "sap-icon://bbyd-dashboard",
						color: "#6a6d70"
					}).addStyleClass("mccNoCardsIcon sapUiMediumMarginTop"),
					new sap.m.Title({
						text: "You have no cards assigned to this Profile.",
						titleStyle: "H3"
					}).addStyleClass("sapUiMediumMargin"),
					new sap.m.Text({
						text: "Start customizing your Profile by adding Cards to it."
					}),
					new sap.m.HBox({
						items: [
							new sap.m.Text({
								text: "You can manage cards anytime by navigation to "
							}),
							new sap.ui.core.Icon({
								src: "sap-icon://key-user-settings",
								color: "#0854a0",
								tooltip: "Workplace Settings",
								press: function () {
									this.getView().byId("workplaceSettingsPopoverButton").firePress();
								}.bind(this)
							}).addStyleClass("sapUiTinyMarginBeginEnd"),
							new sap.m.Text({
								text: " > 'Manage Cards' settings."
							})
						]
					}).addStyleClass("sapUiMediumMarginBottom")
				]
			});
			var oNoCardsFlexBox = new sap.m.FlexBox({
				visible: "{= (${workplaceModel>/selectedProfileInstance/CardOrder}.length === 0 ? true : false) }",
				height: "100%",
				justifyContent: "Center",
				items: [oNoCardsVBox]
			});

			var oManageCardsView = sap.ui.core.mvc.XMLView.create({
				viewName: "com.sap.mcc.workplace.view.action.ManageCards"
			});
			oManageCardsView.then(function (oView) {
				oNoCardsVBox.addItem(oView);
				oView.byId("manageCardsButton").setType("Emphasized");

			});

			var sFragmentId = this.getView().createId(sProfileAlias + "FilterBarFragment");
			Fragment.load({
				id: sFragmentId,
				name: "com.sap.mcc.workplace.view.fragments.FilterBar",
				controller: this
			}).then(function (oFilterBar) {
				oScrollContainer.addContent(oFilterBar); // connect Fragment to ScrollContainer
				oScrollContainer.addContent(oGridContainer);
				oScrollContainer.addContent(oNoCardsFlexBox);
				this._createValidatorForMultiInput(sFragmentId, "respPersonMulitiInput");
				this._createValidatorForMultiInput(sFragmentId, "caseIdMulitiInput");
				this._createValidatorForMultiInput(sFragmentId, "processorMultiInput");
			}.bind(this));

			// Profile Tabs
			var oProfileTab = new IconTabFilter({
				id: sProfileAlias + "Tab",
				key: sProfileAlias,
				text: sProfileName,
				content: oScrollContainer // connect container to Profile Tab
			});

			/*this._createValidatorForMultiInput(sFragmentId, "respPersonMulitiInput");
			this._createValidatorForMultiInput(sFragmentId, "caseIdMulitiInput");
			this._createValidatorForMultiInput(sFragmentId, "processorMultiInput");*/

			/**************************************
			 *  END: Creating IconTabBar content  *
			 **************************************/
			return oProfileTab;
		},

		/** 
		 * Create validators to create new multiInput Tokens.
		 * @private
		 * @param {string} sFragmentId fragment Id.
		 * @param {string} sControlId control Id.
		 * @returns {void}
		 */
		_createValidatorForMultiInput: function (sFragmentId, sControlId) {
			var oMultiInput = Fragment.byId(sFragmentId, sControlId);
			if (oMultiInput) {
				var fValidator = function (args) {
					return new Token({
						text: args.text
					});

				};
				oMultiInput.addValidator(fValidator);
			}
		},

		/** 
		 * Set Selected Profile Instance
		 * @private
		 * @param {string} sProfileAlias Profile Alias (/Roles/RoleID).
		 * @returns {void}
		 */
		_setSelectedProfileInstance: function (sProfileAlias) {
			//if url parameter and selected region are different update the url 
			/*if ($.sap.getUriParameters().get("profile") !== sProfileAlias) {
			this._updateURLParameters(sProfileAlias);
			}*/

			sap.ui.getCore().getModel("workplaceModel").setProperty("/selectedProfileInstance/Alias", sProfileAlias);
		},

		_displayWelcomeDialog: function () {
			if (!this._oWelcomeDialog) {
				Fragment.load({
					name: "com.sap.mcc.workplace.view.fragments.Welcome",
					controller: this
				}).then(function (oWelcomeFragment) {
					this._oWelcomeDialog = oWelcomeFragment;
					this.getView().addDependent(this._oWelcomeDialog);
					this._oWelcomeDialog.open();
				}.bind(this));
			} else {
				this._oWelcomeDialog.open();
			}
		},

		_closeWelcomeDialog: function () {
			if (this._oWelcomeDialog) {
				this._oWelcomeDialog.close();
			}
		},
		
		_checkWorkplaceUrl: function(){
			var bProfileParameter = UriParameters.fromQuery(window.location.search).has("profile");
			if(bProfileParameter){
				var sHostname = window.location.hostname;
				var oRessourceBundle = this.getResourceBundle();
				var sFLPUrl = oRessourceBundle.getText("mccWorkplaceProd");
				if (sHostname.lastIndexOf("a44f228ad") > -1) {
					sFLPUrl = oRessourceBundle.getText("mccWorkplaceFlpTest");
				}
				MessageBox.warning("Please open the MCC Workplace in the SAP Fiori Launchpad.", {
					title: "Warning - Invalid URL",
					actions: [MessageBox.Action.OK, "[FLP] MCC Workplace"], 
					emphasizedAction: "[FLP] MCC Workplace",
					details: "<p>The current URL isn't valid anymore:</p>\n"+ 
					"<ul>" +
					"<li>Please open the app in <a href=" + sFLPUrl + " target='_top' >SAP Fiori Launchpad - MCC Workplace</a>.</li>" +
					"<li>If applicable, update your MCC Workplace bookmark(s).</li>" +
					"</ul>" ,
					styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer",
					onClose: this._openFlpMCCWorkplace.bind(this)
				});
			}
			
		},
		_openFlpMCCWorkplace: function (sAction) {
			if (sAction === "[FLP] MCC Workplace") {
				var sHostname = window.location.hostname;
				var oRessourceBundle = this.getResourceBundle();
				var sFLPUrl = oRessourceBundle.getText("mccWorkplaceProd");
				if (sHostname.lastIndexOf("a44f228ad") > -1) {
					sFLPUrl = oRessourceBundle.getText("mccWorkplaceFlpTest");
				}
				sap.m.URLHelper.redirect(sFLPUrl);
			}
		},

		/* =========================================================== */
		/* end: internal methods                                       */
		/* =========================================================== */

		/* =========================================================== */
		/* begin: event handlers                                       */
		/* =========================================================== */

		/**
		 * Handle Profile select event
		 * @public
		 * @param {oEvent} event.
		 */
		onProfileSelect: function (oEvent) {
			this.getCoreModel("workplaceModel").setProperty("/selectedProfileInstance/CardOrder", ["dummy"]); // reset CardOrder as busy indicator depends on it

			var aProfileInstances = this.getCoreModel("workplaceModel").getProperty("/ProfileInstances");
			var oSelectedProfileInstance;
			var sSelectedProfileAlias = oEvent.getSource().getSelectedKey();
			var sPreviousSelectedProfileAlias = this.getCoreModel("workplaceModel").getProperty("/previousSelectedProfileInstance/Alias");

			// do not perform any action if profile is already selected
			if (sPreviousSelectedProfileAlias === sSelectedProfileAlias) {
				return;
			}
			this.getRouter().navTo("workplace", {
				profile: sSelectedProfileAlias
			});

			// Before any action, abort all OData pending requests from any Cards. Any other resource like *.js, *.css will still load
			this.killMccWorkplacePendingRequests();
			sap.ui.getCore().getEventBus().publish("Profile", "changed", {
				selectedProfile: sSelectedProfileAlias,
				previousSelectedProfile: sPreviousSelectedProfileAlias
			});

			oSelectedProfileInstance = aProfileInstances.find(function (oItem) {
				return (oItem.RoleID === sSelectedProfileAlias);
			});

			if (oSelectedProfileInstance) {
				// set previousSelectedProfileInstance before assigning a new one.
				this.getCoreModel("workplaceModel").setProperty("/previousSelectedProfileInstance/Alias", Object.assign({}, this.getCoreModel(
					"workplaceModel").getProperty("/selectedProfileInstance/Alias")));

				// update "workplaceModel>/selectedProfileInstance"
				this.getCoreModel("workplaceModel").setProperty("/selectedProfileInstance/ProfileUUID", oSelectedProfileInstance.Roles.ID);
				this.getCoreModel("workplaceModel").setProperty("/selectedProfileInstance/Alias", sSelectedProfileAlias);
				this.getCoreModel("workplaceModel").setProperty("/selectedProfileInstance/Name", oSelectedProfileInstance.Roles.RoleName);
				this.getCoreModel("workplaceModel").setProperty("/selectedProfileInstance/ProfileInstanceUUID", oSelectedProfileInstance.ID);
				this.getCoreModel("workplaceModel").setProperty("/selectedProfileInstance/ProfileInstanceCardUUID", oSelectedProfileInstance.Cards
					.ID);
				this.getCoreModel("workplaceModel").setProperty("/selectedProfileInstance/CardOrder", oSelectedProfileInstance.Cards.CardOrder ?
					oSelectedProfileInstance.Cards.CardOrder.split(";") : []);
				this.getCoreModel("workplaceModel").setProperty("/selectedProfileInstance/Variants", oSelectedProfileInstance.Variants.results);
				var aPublicVariants = this.getCoreModel("workplaceModel").getProperty("/publicVariants");
				var allVariants = oSelectedProfileInstance.Variants.results ? oSelectedProfileInstance.Variants.results.concat(aPublicVariants) :
					aPublicVariants;
				this.getCoreModel("workplaceModel").setProperty("/variants", allVariants);
				var aDefaultVariant = allVariants.filter(oVariant => oVariant.defaultVariant === true);
				var oDefaultVariantId = "";
				if (aDefaultVariant.length) {
					oDefaultVariantId = aDefaultVariant[0].variantId;
				}
				this.getCoreModel("workplaceModel").setProperty("/initialVariant", oDefaultVariantId);
				this.getCoreModel("workplaceModel").setProperty("/defaultVariant", oDefaultVariantId);
				var sUserId = this.getCoreModel("workplaceModel").getProperty("/UserId");
				//reset FilterBar Values --> Variants may changed it. Set default values again
				this.getCoreModel("workplaceModel").setProperty("/FilterBar", {
					"ResponsiblePerson": [{
						key: sUserId,
						text: sUserId
					}]
				});

			}

			// update visibility of filter
			this._CardIntegration.updateFilterBarItems(sSelectedProfileAlias);

			Fragment.byId(this.getView().createId(sSelectedProfileAlias + "FilterBarFragment"), "filterVariantManagement").fireSelect();
			// Press Search Button
			Fragment.byId(this.getView().createId(sSelectedProfileAlias + "FilterBarFragment"), "GenericFilterBar").fireSearch();

		},

		/**
		 * Event triggered after ProfileTab is reordered.
		 * @public
		 * @param {oEvent} event.
		 */
		onAfterProfileTabReorder: function (oEvent) {
			var aProfileInstances = this.getModel("workplaceModel").getProperty("/ProfileInstances");
			oEvent.getParameter("newTabKeysOrder").forEach(function (sProfileAlias, iIndex) {
				var oProfileInstance = aProfileInstances.find(function (oItem) {
					return (oItem.RoleID === sProfileAlias);
				});

				this._ProfileIntegration.CRUDManager.updateProfileInstancePosition(oProfileInstance.ID, iIndex);

			}.bind(this));
		},

		/**
		 *	Event-Handler for Filterbar Go-Button Pressed 
		 *	This method acts as the general event handler and then calls the appropriate Controller of the profile to load workplace related data (e.g. load Cases)
		 *  It publishes two events to the 'Filterbar' channel of the EventBus:
		 *		1. 'search': indicates that a search is processed --> cards can already show the busy indicator 
		 *		2. 'dataLoaded': the workplace model stores general data (e.g. Cases for Global Escalation Manager Profile), 
		 *			such that all cards can update itself by using the centrally stored data of the workplace model.
		 */
		onGoBtn: function (oEvent) {

			var oFilterBar = oEvent.getSource();
			var aFilterGroupItems = oFilterBar.getFilterGroupItems();

			if (this._FilterBar) {
				/**
				 * Every profile controller provides a 'handleFilterbarSearch'
				 * The FilterGroupItems are passed as parameter, such that each profile can handle the request individually
				 * The 'handleFilterbarSearch' function return a promise which manages the event bus
				 */

				this._FilterBar.refreshSelectedFilters(aFilterGroupItems).then(function () {
					this.killMccWorkplacePendingRequests();
					//fire an event to notify cards that a search has started
					sap.ui.getCore().getEventBus().publish("FilterBar", "search", {
						status: 'started',
						profile: sap.ui.getCore().getModel("workplaceModel").getProperty("/selectedProfileInstance/Name")
					});

					oFilterBar._oSearchButton.setEnabled(false); // Button is too small to use busy indicator

					this._FilterBar.handleFilterbarSearch.call(this, aFilterGroupItems).then(function (oData) {

						oFilterBar._oSearchButton.setEnabled(true);
						//fire an event to notify cards that the related profile data has been loaded --> cards can refresh themself
						sap.ui.getCore().getEventBus().publish("FilterBar", "dataLoaded");
					}.bind(this)).catch(function (oError) {
						oFilterBar._oSearchButton.setEnabled(true);
					});
				}.bind(this));
			} else {
				//if no appropriate controller can be found in the switch case statement, notify all cards that the search has finished
				sap.ui.getCore().getEventBus().publish("FilterBar", "search", {
					status: 'finished'
				});
			}
		},

		onSaveVariant: function (oEvent) {
			// get variant parameters:
			var bUpdateEntity = oEvent.getParameter("overwrite");
			var oVariantParam = oEvent.getParameters();
			var sFilterValues = this._getVariantFilterValues();
			var oCoreModel = this.getCoreModel("workplaceModel");
			var sUserRoleId = oCoreModel.getProperty("/selectedProfileInstance/ProfileInstanceUUID");
			var sProfileAlias = oCoreModel.getProperty("/selectedProfileInstance/Alias");

			if (sFilterValues !== "") {
				var sVariantKey = oVariantParam.key;
				var sVariantText = oVariantParam.name;
				var sDefault = oVariantParam.def;
				//variant must not start with "*"
				// If the first character is a '*', it indicates a public variant, which can't be set as default. therefore it must be distinguished between public vairants and user-specific ones
				if (!sVariantText.startsWith('*')) {

					var oDataModel = this.getView().getModel("MCSCardsOVPModel");
					var sPath = "/VariantManagement";
					var sUserId = oCoreModel.getProperty("/UserId");
					var oEntry = {};
					oEntry["variantId"] = sVariantKey;
					oEntry["UserID"] = sUserId;
					oEntry["UserRoles_ID"] = sUserRoleId;
					oEntry["FilterValues"] = sFilterValues;
					oEntry["variantName"] = sVariantText;
					oEntry["defaultVariant"] = sDefault;
					
					//reset previous default variant
					if (sDefault && oCoreModel.getProperty("/initialVariant")) {
						var sInitialVariant = oCoreModel.getProperty("/initialVariant");
						var oOldDefaultVariant = {};
						oOldDefaultVariant["variantId"] = sInitialVariant;
						oOldDefaultVariant["UserID"] = sUserId;
						oOldDefaultVariant["defaultVariant"] = false;
						this._updateVariant(oOldDefaultVariant);
					}

					// bUpdate Entity = false --> create new Variant
					if (!bUpdateEntity) {
						oDataModel.create(sPath, oEntry, {
							success: function (oData, response) {
								this._refreshVariant(); //sUserRoleId, sProfileAlias)
								//	that._refreshVariantManagement();
								//	MessageToast.show("Variant has been saved");
							}.bind(this),
							error: function (oError) {
								//	MessageToast.show(oError.message);
							}
						});
					} else {
						sPath = sPath + "(variantId='" + sVariantKey + "',UserID='" + sUserId + "')"; //  VariantManagement(variantId='SV11223344',UserID='D062519')
						oDataModel.update(sPath, oEntry, {
							success: function (oData, response) {
								//	that._refreshVariantManagement();
								//	MessageToast.show("Variant has been saved");
								this._refreshVariant();
							},
							error: function (oError) {
								//	MessageToast.show(oError.message);
							}
						});
					}
					
				} else {
					var oMsgStrip = new MessageStrip("msgStrip", {
						text: "Variant name must not start with '*'. Please try again.",
						showCloseButton: true,
						showIcon: true,
						customIcon: "sap-icon://error",
						type: "Error"
					});

					var sSelectedProfileAlias = oCoreModel.getProperty("/selectedProfileInstance").Alias;
					Fragment.byId(this.getView().createId(sSelectedProfileAlias + "FilterBarFragment"), "GenericFilterBar").addContent(oMsgStrip);
					oCoreModel.refresh(true);
				}

			} else {
				//	MessageToast.show("Please select a filter value");
			}

		},

		_refreshVariant: function () {
			var oCoreModel = this.getCoreModel("workplaceModel");
			var sUserRoleId = oCoreModel.getProperty("/selectedProfileInstance/ProfileInstanceUUID");
			var sProfileAlias = oCoreModel.getProperty("/selectedProfileInstance/Alias");
			var oDataModel = this.getView().getModel("MCSCardsOVPModel");
			var sPath = "/UserRoles(guid'" + sUserRoleId + "')/Variants";

			var oPromise = new Promise(function (resolve, reject) {
				oDataModel.read(sPath, {
					success: function (oData, response) {
						resolve(oData);
						//	._refreshVariantManagement();
						//	MessageToast.show("Variant has been saved");
					}.bind(this),
					error: function (oError) {
						console.log(oError);
						reject(oError);
						//	MessageToast.show(oError.message);
					}
				});
			}.bind(this));

			oPromise.then(function (oData) {
				//update selectedProfile instance 
				// update Profile Instances
				var aProfileInstances = this.getCoreModel("workplaceModel").getProperty("/ProfileInstances");
				var iIndex = aProfileInstances.findIndex(function (oItem) {
					return (oItem.RoleID === sProfileAlias);

				});
				aProfileInstances[iIndex].Variants = oData;
				this.getCoreModel("workplaceModel").setProperty("/ProfileInstances", aProfileInstances);
				this.getCoreModel("workplaceModel").setProperty("/selectedProfileInstance/Variants", oData.results);
				var aPublicVariants = this.getCoreModel("workplaceModel").getProperty("/publicVariants");
				var allVariants = oData.results ? aPublicVariants.concat(oData.results) : aPublicVariants;
				this.getCoreModel("workplaceModel").setProperty("/variants", allVariants);
				//this.getCoreModel("workplaceModel").refresh(true);
			}.bind(this));

		},

		_updateVariant: function (oVariant) {
			var oDataModel = this.getView().getModel("MCSCardsOVPModel");
			var sPath = "/VariantManagement(variantId='" + oVariant.variantId + "',UserID='" + oVariant.UserID + "')";
			oDataModel.update(sPath, oVariant, {
				success: function (oData, response) {
					this._refreshVariant();
					//	that._refreshVariantManagement();
					//	MessageToast.show("Variant has been saved");
				}.bind(this),
				error: function (oError) {
					//	MessageToast.show(oError.message);
				}
			});
		},

		_deleteVariant: function (oVariant) {
			var oDataModel = this.getView().getModel("MCSCardsOVPModel");
			var sPath = "/VariantManagement(variantId='" + oVariant.variantId + "',UserID='" + oVariant.UserID + "')";
			oDataModel.remove(sPath, {
				success: function (oData, response) {
					this._refreshVariant();
					//	that._refreshVariantManagement();
					//	MessageToast.show("Variant has been saved");
				}.bind(this),
				error: function (oError) {
					//	MessageToast.show(oError.message);
				}
			});
		},

		onManageVariant: function (oEvent) {
			var aParameters = oEvent.getParameters();
			var oWorkplaceModel = this.getCoreModel("workplaceModel");
			var sUserId = oWorkplaceModel.getProperty("/UserId");
			var sInitialVariant = oWorkplaceModel.getProperty("/initialVariant");
			var sDefaultVariant = oWorkplaceModel.getProperty("/defaultVariant");
			//var aData = this.getView().byId("filterVariantManagement").getModel("filterVariantModel").getData().results;

			// rename variants
			if (aParameters.renamed.length > 0) {
				aParameters.renamed.forEach(function (aRenamedVariant) {
					var oVariant = {};
					oVariant["variantId"] = aRenamedVariant.key;
					oVariant["UserID"] = sUserId;
					oVariant["variantName"] = aRenamedVariant.name;
					this._updateVariant(oVariant);
				}.bind(this));
			}

			// update the default variant
			if (aParameters.def && aParameters.def !== "*standard*" && aParameters.def != sInitialVariant) {
				//find selected variant to check if it is a public variant 
				// if not set the selected variant as default
				// if yes copy the variant and create a user specific variant to set it as default
				if (sInitialVariant) {
					var oOldDefaultVariant = {};
					oOldDefaultVariant["variantId"] = sInitialVariant;
					oOldDefaultVariant["UserID"] = sUserId;
					oOldDefaultVariant["defaultVariant"] = false;
					this._updateVariant(oOldDefaultVariant);
				}
				var oSelectedVariant = oWorkplaceModel.getProperty("/variants").filter(o => o.variantId === aParameters.def)[0];
				if (oSelectedVariant.UserID !== 'Public') {

					var oNewDefaultVariant = {};
					oNewDefaultVariant["variantId"] = aParameters.def;
					oNewDefaultVariant["UserID"] = sUserId;
					oNewDefaultVariant["defaultVariant"] = true;
					this._updateVariant(oNewDefaultVariant);
					//update default variant to be displayed in the manage variant dialog
					oWorkplaceModel.setProperty("/initialVariant", aParameters.def);
					oWorkplaceModel.setProperty("/defaultVariant", aParameters.def);
					//trigger variant select and go button press such that the new default variant will be used and the cards are notified to update themself
					var sProfileAlias = oWorkplaceModel.getProperty("/selectedProfileInstance").Alias;
					Fragment.byId(this.getView().createId(sProfileAlias + "FilterBarFragment"), "filterVariantManagement").fireSelect();
					Fragment.byId(this.getView().createId(sProfileAlias + "FilterBarFragment"), "GenericFilterBar").fireSearch();
				} else if (oSelectedVariant.UserID === 'Public') {
					// copy the variant and set it as user specific variant
					var oDataModel = this.getView().getModel("MCSCardsOVPModel");
					var sPath = "/VariantManagement";
					//remove the leading * and then ending * --> indicator for public variant
					var sVariantName = oSelectedVariant.variantName.slice(1).slice(0, -1);
					var oEntry = {};
					var sCopyVariantKey = "SV" + new Date().getTime();
					oEntry["variantId"] = sCopyVariantKey;
					oEntry["UserID"] = sUserId;
					oEntry["UserRoles_ID"] = oWorkplaceModel.getProperty("/selectedProfileInstance").ProfileInstanceUUID;
					oEntry["FilterValues"] = oSelectedVariant.FilterValues;
					oEntry["variantName"] = sVariantName;
					oEntry["defaultVariant"] = true;

					// bUpdate Entity = false --> create new Variant

					oDataModel.create(sPath, oEntry, {
						success: function (oData, response) {
							this._refreshVariant(); //sUserRoleId, sProfileAlias)
							//	that._refreshVariantManagement();
							//	MessageToast.show("Variant has been saved");
							var oMsgStrip = new MessageStrip("msgStrip", {
								text: "A public variant can't be set as default. New variant '" + sVariantName +
									"' was created as a copy of the public  variant and set as Default.",
								showCloseButton: true,
								showIcon: true,
								customIcon: "sap-icon://information",
								type: "Information"
							});

							var sSelectedProfileAlias = oWorkplaceModel.getProperty("/selectedProfileInstance").Alias;
							Fragment.byId(this.getView().createId(sSelectedProfileAlias + "FilterBarFragment"), "GenericFilterBar").addContent(oMsgStrip);
						}.bind(this),
						error: function (oError) {
							//	MessageToast.show(oError.message);
						}
					});
				}
			}
			// case:: Default Variant is set
			// set the previous default variant to false
			else if (aParameters.def && aParameters.def === "*standard*" && sInitialVariant) {
				var oResetDefaultVariant = {};
				oResetDefaultVariant["variantId"] = sInitialVariant;
				oResetDefaultVariant["UserID"] = sUserId;
				oResetDefaultVariant["defaultVariant"] = false;
				this._updateVariant(oResetDefaultVariant);
				//reset the values
				//update default variant to be displayed in the manage variant dialog
				oWorkplaceModel.setProperty("/initialVariant", "");
				oWorkplaceModel.setProperty("/defaultVariant", "");
				//trigger variant select and go button press such that the new default variant will be used and the cards are notified to update themself
				var sProfileAlias = oWorkplaceModel.getProperty("/selectedProfileInstance").Alias;
				Fragment.byId(this.getView().createId(sProfileAlias + "FilterBarFragment"), "filterVariantManagement").fireSelect();
				Fragment.byId(this.getView().createId(sProfileAlias + "FilterBarFragment"), "GenericFilterBar").fireSearch();
			}

			// delete variants
			if (aParameters.deleted.length > 0) {
				aParameters.deleted.forEach(function (sVariantId) {
					var oVariant = {};
					oVariant["variantId"] = sVariantId;
					oVariant["UserID"] = sUserId;
					this._deleteVariant(oVariant);
				}.bind(this));
			}

			//  refresh the Variant Container
			/*	this._refreshVariantManagement();*/
		},

		onSelectVariant: function (oEvent) {
			var sVariantKey = oEvent.getParameter("key") ? oEvent.getParameter("key") : oEvent.getSource().getSelectionKey();
			var aVariants = this.getCoreModel("workplaceModel").getProperty("/variants");
			var oSelectedVariant = aVariants.find(function (oItem) {
				return (oItem.variantId === sVariantKey);
			});
			
			this._resetFilterBar();

			if (oSelectedVariant) {
				this._setVariantFilterValues(oSelectedVariant.FilterValues);
			} 
		},
		
		_resetFilterBar: function() {
			var oResponsiblePerson = this.getView().getModel("workplaceModel").getProperty("/FilterBar/ResponsiblePerson");
			// reset filterbar property
			this.getView().getModel("workplaceModel").setProperty("/FilterBar",{});
			// set responsible person
			this.getView().getModel("workplaceModel").setProperty("/FilterBar/ResponsiblePerson",oResponsiblePerson)
		},

		_setVariantFilterValues: function (sValues) {
			var aFilterWithValues = sValues.split(";");
			var oWorkplaceModel = this.getCoreModel("workplaceModel");
			aFilterWithValues.forEach(function (aFilterWithValue) {
				if (aFilterWithValue) {
					var aFilterValuePair = aFilterWithValue.split(":");

					if (aFilterValuePair[0] === "Region") {
						var aRegionKeys = aFilterValuePair[1].split(",");
						oWorkplaceModel.setProperty("/FilterBar/Region", aRegionKeys);
					} else if (aFilterValuePair[0] === "ServiceTeam") {
						var aServiceTeamFilter = aFilterWithValue.split(":");
						//transform array to be set to selected keys attribute
						var aServiceTeamKeys = aServiceTeamFilter[1].split(",");
						oWorkplaceModel.setProperty("/FilterBar/ServiceTeam", aServiceTeamKeys);
					} else if (aFilterValuePair[0].indexOf("Recommendation") != -1 ) {
						var sFilterName = aFilterValuePair[0];
						var aRecommendationFilter = aFilterWithValue.split(":");
						//transform array to be set to selected keys attribute
						var aRecommendationKeys = aRecommendationFilter[1].split(",");
						oWorkplaceModel.setProperty("/FilterBar/" +sFilterName, aRecommendationKeys);
					} else {
						var sPath = aFilterValuePair[0];
						var aTokenObject = [];
						var aFilterValues = aFilterValuePair[1].split(",");
						aFilterValues.forEach(function (sValue) {
							var oObject = {
								key: sValue,
								text: sValue
							};
							aTokenObject.push(oObject);
						});
						oWorkplaceModel.setProperty("/FilterBar/" + sPath, aTokenObject);
					}

				}
			}.bind(this));
			//	oWorkplaceModel.refresh(true);
		},

		_getVariantFilterValues: function () {
			var oWorkplaceModel = this.getCoreModel("workplaceModel");
			var oFilterBarValues = oWorkplaceModel.getProperty("/FilterBar");
			var oVisibleItems = oWorkplaceModel.getProperty("/FilterBarVisibleItems");
			var sFilterValues = "";
			for (var akeyValues of Object.entries(oVisibleItems)) {
				if (akeyValues[0] === 'Region' && akeyValues[1]) {
					//sFilterValues = sFilterValues + akeyValues[0] + ":" + oFilterBarValues[akeyValues[0]] + ";";
					var aHelper = oFilterBarValues[akeyValues[0]];
					var sValues = "";
					if (aHelper && aHelper.length > 0) {
						aHelper.forEach(function (sFilterValue) {
							sValues = sValues + sFilterValue + ",";
						});
						//remove last comma
						sValues = sValues.substring(0, sValues.length - 1);
						sFilterValues = sFilterValues + akeyValues[0] + ":" + sValues + ";";
					}
				} else if (akeyValues[0] === 'ServiceTeam' && akeyValues[1]) {
					var aHelper = oFilterBarValues[akeyValues[0]];
					var sValues = "";
					if (aHelper && aHelper.length > 0) {
						aHelper.forEach(function (sFilterValue) {
							sValues = sValues + sFilterValue + ",";
						});
						//remove last comma
						sValues = sValues.substring(0, sValues.length - 1);
						sFilterValues = sFilterValues + akeyValues[0] + ":" + sValues + ";";
					}
				} else if (akeyValues[0].indexOf("Recommendation") != -1 && akeyValues[1]) {
					var aHelper = oFilterBarValues[akeyValues[0]];
					var sValues = "";
					if (aHelper && aHelper.length > 0) {
						aHelper.forEach(function (sFilterValue) {
							sValues = sValues + sFilterValue + ",";
						});
						//remove last comma
						sValues = sValues.substring(0, sValues.length - 1);
						sFilterValues = sFilterValues + akeyValues[0] + ":" + sValues + ";";
					}
				} else if (akeyValues[1]) {
					var aHelper = oFilterBarValues[akeyValues[0]];
					var sValues = "";
					if (aHelper && aHelper.length > 0) {
						aHelper.forEach(function (sFilterValue) {
							sValues = sValues + sFilterValue.key + ",";
						});
						//remove last comma
						sValues = sValues.substring(0, sValues.length - 1);
						sFilterValues = sFilterValues + akeyValues[0] + ":" + sValues + ";";
					}
				}
			}
			return sFilterValues;
		},

		/* =========================================================== */
		/* end: event handlers                                         */
		/* =========================================================== */

		/* =========================================================== */
		/* begin: Popover methods                                      */
		/* =========================================================== */

		/**
		 * Event to open Workplace Action Popover
		 * Approach was followed due to limitation exposed here https://github.com/SAP/openui5/issues/55
		 */
		onWorkplaceActionPress: function (oEvent) {
			var oButton = oEvent.getSource();

			if (!this._oWorkplaceActionPopover) {
				Fragment.load({
					name: "com.sap.mcc.workplace.view.fragments.WorkplaceActionPopover",
					controller: this
				}).then(function (oWorkplaceActionPopover) {
					this._oWorkplaceActionPopover = oWorkplaceActionPopover;
					this.getView().addDependent(this._oWorkplaceActionPopover);
					this._oWorkplaceActionPopover.openBy(oButton);
				}.bind(this));
			} else {
				this._oWorkplaceActionPopover.openBy(oButton);
			}
		},

		onOpenHelpPopover: function (oEvent) {
			this._oHelpBtn = this.getView().byId("helpPopoverButton");
			if (!this._oHelpPopover) {
				Fragment.load({
					name: "com.sap.mcc.workplace.view.fragments.HelpPopover",
					controller: this
				}).then(function (pAvatarPopover) {
					this._oHelpPopover = pAvatarPopover;
					this.getView().addDependent(this._oHelpPopover);
					this._oHelpPopover.openBy(this._oHelpBtn);
				}.bind(this));
			} else {
				this._oHelpPopover.openBy(this._oHelpBtn);
			}
		},

		onOpenDocumentation: function (oEvent) {
			window.open("https://" + "jam4.sapjam.com/groups/5LnWdLXIx1B6iNVAa24kiC/content?folder_id=lHENBSQ5dERz2HO0CkslnI", "_blank").focus();
		},

		onOpenJAMPage: function (oEvent) {
			window.open("https://" + "jam4.sapjam.com/groups/5LnWdLXIx1B6iNVAa24kiC/content?folder_id=lHENBSQ5dERz2HO0CkslnI", "_blank").focus();
		},

		onOpenTicketingApp: function (oEvent) {
			window.open("https://" +
				"fiorilaunchpad.sap.com/sites#Help-Inbox&/create/ZINE/IMFIT_DBS_MCC/Issue%20with%20%27MCC%20Workplace%27/2//SCP/Issue%20Description%20and%20steps%20to%20reproduce%20this%20issue//////01/01/////Federated%20IT%20(Presales%2C%20DBS%2C%20Education%20%26%20Training%2C...)",
				"_blank").focus();
		},

		onOpenMCCToolsJAMPage: function (oEvent) {
			window.open("https://" + "jam4.sapjam.com/groups/5LnWdLXIx1B6iNVAa24kiC/overview_page/gfzAsARcdTtVuM5bREq8xD", "_blank").focus();
		},
		/* =========================================================== */
		/* end: Popover methods                                        */
		/* =========================================================== */

	});
});