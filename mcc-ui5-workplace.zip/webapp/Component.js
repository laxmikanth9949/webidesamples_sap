sap.ui.define(["sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"com/sap/mcc/workplace/controller/ErrorHandler",
	"com/sap/mcc/workplace/controller/ODataHandler",
	"sap/ui/Device"
], function (UIComponent, JSONModel, ErrorHandler, ODataHandler, Device) {
	"use strict";

	var Component = UIComponent.extend("com.sap.mcc.workplace.Component", {

		metadata: {
			manifest: "json",
			config: {
				fullWidth: true
			}
		},

		init: function () {

			// ===============================================
			// init mobile usage reporting
			// ===============================================
			this._initMobileUsageReporting();
			// end of init mobile usage reporting ============

			var sHostname = window.location.hostname;
			var oWorplaceJsonModel = new JSONModel({
				disclaimerMessage: "<strong>Disclaimer</strong>: This is a <em><u>Test Environment</u></em>. Any information or KPIs do not reflect real or live data. Also any related links or URLs may direct you to a non-productive system. For any Questions or Ideas please contact:",
				disclaimerMessageProd: "<strong>Disclaimer</strong>: This is the MCC Workplace - Standalone Application. To provide you full functionality, please use the following link:", 
				disclaimerLinkText: "MCC Tools Team",
				disclaimerLinkURL: "mailto:DL MCC Tools Core Team <DL_5D8A25C555A2D7027F3294F7@global.corp.sap>?subject=MCC Workplace - Questions or Ideas",
				disclaimerVisible: (sHostname.lastIndexOf("sapitcloudt") > -1 || sHostname.lastIndexOf("a44f228ad") > -1) ? true : false, // set Visible if testing environment
				disclaimerVisibleProd: (sHostname.lastIndexOf("a87daa223") > -1) ? true : false, // set Visible if testing environment
				FilterBarVisibleItems: {}, // FilterBar Items visible
				FilterBar: { // FilterBar binding values
					responsiblePerson: []
				},
				FilterValues: {},
				publicVariants: [],
				device: {
					desktop: Device.system.desktop,
					tablet: Device.system.tablet,
					phone: Device.system.phone
				},
				previousSelectedProfileInstance: {
					Alias: "" // "/Roles/RoleID"
				},
				// The terminology is confusing so bellow is an attempt to unify it
				selectedProfileInstance: {
					ProfileUUID: "", // "/Roles/RoleID" or "/UserRoles/Roles_ID"
					ProfileInstanceUUID: "", // "/UserRoles/ID"
					CardOrder: [], // "/UserRoles/CardOrder"
					Name: "", // "/Roles/RoleName"
					Alias: "" // "/Roles/RoleID"
				},
				ProfileInstances: [], // All loaded ProfileInstances
				_cardIntegration: {},
				busy: {
					profileIconTabBar: true
				},
				liveRequestQueue: {},
				liveRequestQueueCount: 0
			});
			sap.ui.getCore().setModel(oWorplaceJsonModel, "workplaceModel");

			// Error Handler for Model
			this._oCardsOVPErrorHandler = new ErrorHandler(this, "MCSCardsOVPModel");
			this._oAppDepErrorHandler = new ErrorHandler(this, "appDepModel");

			// Handler to intercept and abort requests when Profile is changed or cancelled
			this._oCardsOVPODataHandler = new ODataHandler(this, "MCSCardsOVPModel");
			this._oAppDepODataHandler = new ODataHandler(this, "appDepModel");

			// call the init function of the parent
			UIComponent.prototype.init.apply(this, arguments);

			this.getRouter().initialize();
		},

		/* Mobile Usage Reporting - Version v3 */

		_initMobileUsageReporting: function () {
			sap.git = sap.git || {};
			sap.git.usage = sap.git.usage || {};
			sap.git.usage.Reporting = {
				_lp: null,
				_load: function (a) {
					this._lp = this._lp || sap.ui.getCore().loadLibrary("sap.git.usage", {
						url: "https://" + "trackingshallwe.hana.ondemand.com/web-client/v3",
						async: !0
					});
					this._lp.then(function () {
						a(sap.git.usage.MobileUsageReporting);
					}, this._loadFailed);
				},
				_loadFailed: function (a) {
					jQuery.sap.log.warning("[sap.git.usage.MobileUsageReporting]", "Loading failed: " + a);
				},
				setup: function (a) {
					this._load(function (b) {
						b.setup(a);
					});
				},
				addEvent: function (a, b) {
					this._load(function (c) {
						c.addEvent(a, b);
					});
				},
				setUser: function (a, b) {
					this._load(function (c) {
						c.setUser(a, b);
					});
				}
			};
			sap.git.usage.Reporting.setup(this);
		}
	});

	return Component;

});