sap.ui.define([
	"sap/m/IconTabBar",
	"sap/m/IconTabBarRenderer",
	"com/sap/mcc/workplace/control/CustomIconTabHeader"
], function (IconTabBar, IconTabBarRenderer, CustomIconTabHeader) {
	"use strict";

	var CustomIconTabBar = IconTabBar.extend("com.sap.mcc.workplace.control.CustomIconTabBar", {

		metadata: {
			aggregations: {
				buttons: {
					type: "sap.m.Button",
					multiple: true,
					singularName: "button",
					forwarding: {
						getter: "_getIconTabHeader",
						aggregation: "buttons",
						forwardBinding: true
					}
				}
			},
			events: {
				beforeTabReorder: {},
				afterTabReorder: {}
			}
		},

		init: function () {
			IconTabBar.prototype.init.apply(this, arguments);
		},

		renderer: IconTabBarRenderer
	});

	/**
	 * Lazy initializes the customIconTabHeader aggregation.
	 *
	 * @private
	 * @returns {sap.m.IconTabBar} Aggregation for the IconTabBar.
	 */
	CustomIconTabBar.prototype._getIconTabHeader = function () {
		var oControl = this.getAggregation("_header");
		
		if (!oControl) {
			oControl = new CustomIconTabHeader(this.getId() + "--header", {});
			this.setAggregation("_header", oControl, true);
		}
		return oControl;
	};

	return CustomIconTabBar;

});