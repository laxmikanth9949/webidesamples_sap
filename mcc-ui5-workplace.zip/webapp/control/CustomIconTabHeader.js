// Based on SAPUI5 v1.77.2

sap.ui.define([
	"sap/m/IconTabHeader",
	"sap/m/IconTabHeaderRenderer",
	"sap/m/Button",
	"sap/m/library",
	"com/sap/mcc/workplace/control/CustomIconTabBarDragAndDropUtil"
], function (IconTabHeader, IconTabHeaderRenderer, Button, library, CustomIconTabBarDragAndDropUtil) {
	"use strict";

	// shortcut for sap.m.IconTabFilterDesign
	var IconTabFilterDesign = library.IconTabFilterDesign;

	var CustomIconTabHeader = IconTabHeader.extend("com.sap.mcc.workplace.control.CustomIconTabHeader", {
		metadata: {
			aggregations: {
				buttons: {
					type: "sap.m.Button",
					multiple: true,
					singularName: "button"
				}
			}
		},

		init: function () {
			IconTabHeader.prototype.init.apply(this, arguments);
		},

		// renderer: IconTabHeaderRenderer,
		renderer: function (oRM, oControl) {
			if (!oControl.getVisible()) {
				return;
			}

			var sId = oControl.getId(),
				aItems = oControl.getItems(),
				aButtons = oControl.getButtons(),
				iButtonsCount = aButtons.length,
				oButton,
				iVisibleTabFiltersCount = oControl.getVisibleTabFilters().length,
				iVisibleTabFilterIndex = 0,
				bTextOnly = oControl._checkTextOnly(),
				bNoText = oControl._checkNoText(aItems),
				bInLine = oControl._checkInLine(aItems) || oControl.isInlineMode();

			var oIconTabBar = oControl.getParent(),
				bUpperCase = oIconTabBar && oIconTabBar.isA('sap.m.IconTabBar') && oIconTabBar.getUpperCase();

			// render wrapper div
			oRM.openStart("div", oControl)
				.class("mccWorkplaceContainer")
				.class("sapMITH")
				.class("sapContrastPlus")
				.class("sapMITHBackgroundDesign" + oControl.getBackgroundDesign());

			if (aItems.length) {
				oRM.class("sapMITHOverflowList");
			}

			// Check for upperCase property on IconTabBar
			if (bUpperCase) {
				oRM.class("sapMITBTextUpperCase");
			}

			if (bTextOnly) {
				oRM.class("sapMITBTextOnly");
			}

			if (bNoText) {
				oRM.class("sapMITBNoText");
			}

			if (bInLine) {
				oRM.class("sapMITBInLine");
			}

			oRM.accessibilityState(oControl, {
				role: "navigation"
					// label: oRB.getText("ICONTABHEADER_LABEL")
			});

			oRM.openEnd();

			oRM.renderControl(oControl._oAriaHeadText);

			oRM.openStart("div", sId + "-head")
				.class("sapMITBHead");

			oRM.accessibilityState({
				role: "tablist",
				orientation: "horizontal",
				describedby: oControl.getId() + "-ariaHeadText"
			});

			oRM.openEnd();

			for (var i = 0; i < aItems.length; i++) {
				var oItem = aItems[i];
				oItem.render(oRM, iVisibleTabFilterIndex, iVisibleTabFiltersCount);

				if (oItem.isA("sap.m.IconTabFilter")) {
					if (oItem.getVisible()) {
						iVisibleTabFilterIndex++;
					}
				}
			}

			oRM.close("div");

			if (aItems.length) {
				oRM.openStart("div")
					.class("sapMITHOverflow")
					.openEnd();

				oControl._getOverflow().render(oRM);

				oRM.close("div");
			}
			
			// Custom implementation to add Buttons
			oRM.write('<div class=" mccWorkplaceCustomButtons">');
			for (var i = 0; i < iButtonsCount; i++) {
				oButton = aButtons[i];
				oRM.renderControl(oButton);
			}
			oRM.write("</div>"); // close mccWorkplaceCustomButtons

			oRM.close("div");
		}
	});

		/* =========================================================== */
	/*           start: tab drag-drop                              */
	/* =========================================================== */

	/**
	 * Handles drop event for drag &  drop functionality in sap.m.IconTabHeader
	 * @param {jQuery.Event} oEvent
	 * @private
	 */
	IconTabHeader.prototype._handleDragAndDrop = function (oEvent) {
		var sDropPosition = oEvent.getParameter("dropPosition"),
			oDraggedControl = oEvent.getParameter("draggedControl"),
			oDroppedControl = oEvent.getParameter("droppedControl");

		CustomIconTabBarDragAndDropUtil.handleDrop(this, sDropPosition, oDraggedControl._getRealTab(), oDroppedControl, false);

		this._setItemsForStrip();
		this._initItemNavigation();

		this._getSelectList()._initItemNavigation();

		oDraggedControl._getRealTab().$().focus();
	};

	/* =========================================================== */
	/*           end: tab drag-drop                                */
	/* =========================================================== */

	/* =========================================================== */
	/*           start: tab keyboard handling - drag-drop          */
	/* =========================================================== */

	/**
	 * Moves a tab by a specific key code
	 *
	 * @param {object} oTab The event object
	 * @param {number} iKeyCode Key code
	 * @private
	 */
	IconTabHeader.prototype._moveTab = function (oTab, iKeyCode) {
		CustomIconTabBarDragAndDropUtil.moveItem.call(this, oTab, iKeyCode);
		this._setItemsForStrip();
		this._initItemNavigation();
	};

	/**
	 * Handle keyboard drag&drop
	 * @param {jQuery.Event} oEvent
	 * @private
	 */
	IconTabHeader.prototype.ondragrearranging = function (oEvent) {
		if (!this.getEnableTabReordering()) {
			return;
		}

		var oTab = oEvent.srcControl;
		this._moveTab(oTab, oEvent.keyCode);
		oTab.$().focus();
	};

	/**
	 * Moves tab on first position
	 * Ctrl + Home
	 * @param {jQuery.Event} oEvent
	 */
	IconTabHeader.prototype.onsaphomemodifiers = IconTabHeader.prototype.ondragrearranging;

	/**
	 * Move focused tab of IconTabHeader to last position
	 * Ctrl + End
	 * @param {jQuery.Event} oEvent
	 */
	IconTabHeader.prototype.onsapendmodifiers = IconTabHeader.prototype.ondragrearranging;

	/**
	 * Moves tab for Drag&Drop keyboard handling
	 * Ctrl + Left Right || Ctrl + Arrow Up
	 * @param {jQuery.Event} oEvent
	 */
	IconTabHeader.prototype.onsapincreasemodifiers = IconTabHeader.prototype.ondragrearranging;

	/**
	 * Moves tab for Drag&Drop keyboard handling
	 * Ctrl + Left Arrow || Ctrl + Arrow Down
	 * @param {jQuery.Event} oEvent
	 */
	IconTabHeader.prototype.onsapdecreasemodifiers = IconTabHeader.prototype.ondragrearranging;

	/* =========================================================== */
	/*           end: tab keyboard handling - drag-drop            */
	/* =========================================================== */

	return CustomIconTabHeader;

});