// If the cachebuster.js file is changed, change the ts parameter on <script src="cachebuster.js?ts=202005211200"></script> on index.html
function runCacheBuster() {
	sap.ui.require(
		[
			"sap/m/Shell",
			"sap/ui/core/ComponentContainer",
			"sap/ui/core/routing/HashChanger",
			"sap/ui/core/BusyIndicator"
		],
		function (Shell, ComponentContainer, HashChanger, BusyIndicator) {
			"use strict";

			// CacheBuster Timestamp - get from index.html file
			var sTimestamp = jQuery("#cachebuster").attr("src").split("?ts=")[1];
			// Busy application
			// BusyIndicator.show(0);

			// cachebuster load functions
			var fnCacheBuster = function (sUrl) {
				var sTSUrl = sUrl + "?ts=" + sTimestamp;
				/* eslint-disable */
				var oLink = document.createElement("script");

				oLink.setAttribute("src", sTSUrl);
				document.getElementsByTagName("head")[0].appendChild(oLink);
				/* eslint-enable */
			};
			// add ts (local cachebuster)
			fnCacheBuster("Component-preload.js");

			jQuery.sap.registerModulePath("com.sap.mcc.workplace", "./");

			// Set root component at content div
			new Shell({
				id: "shellHome",
				appWidthLimited: false,
				app: new ComponentContainer({
					height: "100%",
					name: "com.sap.mcc.workplace"
				})
			}).placeAt("content");
		}
	);
}