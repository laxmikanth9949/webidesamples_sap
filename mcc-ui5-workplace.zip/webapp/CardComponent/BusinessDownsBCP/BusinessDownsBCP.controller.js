sap.ui.define([
	"jquery.sap.global",
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"./formatter",
], function (jQuery, BaseCardController, JSONModel, formatter) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.BusinessDownsBCP.BusinessDownsBCP", {

		// Initialize the view and make a call to the refresh method
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */
			this.onUpdateCard();
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count
			
			var oFilter = [];
			var model = this.getModel("critsitDashboardService");
			var f1 = new sap.ui.model.Filter("EscltnStatus", sap.ui.model.FilterOperator.EQ, "15");
			oFilter.push(f1);
			var oModel = new JSONModel();
			var sText1 = this.getView().getModel("i18n").getResourceBundle().getText("businessDownsBCP");
			model.read("/Critical_IncidentsSet", {
				filters: oFilter,
				success: function (oResult1) {
					this.getView().byId("table-mcs-bcp").setBusy(false);
					var oResult = this.bubbleSort(oResult1);
					this.setCardProperty("/results",oResult.results);	
					this.setCardProperty("/customHeader/additionalCardTitle", " (" + oResult.results.length + ") - Global View");
					this.setCardSuccessState();
				}.bind(this),
				error: function (oError) {
					this.setCardErrorState();
				}.bind(this)
			});
		},

		//method for sorting the activites by create date
		bubbleSort: function (oResult) {
			var n = oResult.results.length;
			for (var i = 0; i < n - 1; i++) {
				for (var j = 0; j < n - i - 1; j++) {
					if ((oResult.results[j].EsclTimestamp) > (oResult.results[j + 1].EsclTimestamp)) {
						var temp = oResult.results[j];
						oResult.results[j] = oResult.results[j + 1];
						oResult.results[j + 1] = temp;
					}
				}
			}
			return oResult;
		},

		onSelectionChange: function (oEvent) {
			var sPath = oEvent.getParameters().rowBindingContext.sPath;
			var incidentId = this.getModel("cardModel").getProperty(sPath).IncidentId
			var urlMess = this.getView().getModel("i18n").getResourceBundle().getText("urlMess");
			var url = urlMess + incidentId;
			var win = window.open(url, "_blank");
			win.focus();
		},

		//returns a date in form days and hours
		//param(information) date in string format
		getDays: function (information) {
			if (information) {
				// get total seconds between the times
				var delta = Math.abs(new Date() - (information)) / 1000;

				// calculate (and subtract) whole days
				var days = Math.floor(delta / 86400);
				delta -= days * 86400;

				// calculate (and subtract) whole hours
				var hours = Math.floor(delta / 3600) % 24;
				delta -= hours * 3600;

				// calculate (and subtract) whole minutes
				var minutes = Math.floor(delta / 60) % 60;
				delta -= minutes * 60;

				// what's left is seconds
				var seconds = delta % 60;
				var text = days + " d " + hours + " h ";
				if ((days === 0) && hours === 0) {
					return "< 1 hour";
				}
				return text;
			}
		},

		//returns a date in date format
		//param(temp) date in string format
		createDate: function (temp) {
			if (temp) {
				var year = temp.substring(0, 4);
				var month = temp.substring(4, 6);
				var day = temp.substring(6, 8);
				var hour = temp.substring(8, 10);
				var minute = temp.substring(10, 12);
				var seconds = temp.substring(12, 14);

				return new Date(year, month - 1, day, hour, minute, seconds);
			}
		},

		//Convert date format to month day year ex: "February 2, 2019"
		//param(date) date in date format
		getmDate: function (date) {
			if (date) {
				var month = ["January", "February", "March", "April", "May", "June",
					"July", "August", "September", "October", "November", "December"
				][date.getMonth()];
				var str = month + " " + date.getDate() + " " + date.getFullYear();
				return str;
			}
		}
	});
});