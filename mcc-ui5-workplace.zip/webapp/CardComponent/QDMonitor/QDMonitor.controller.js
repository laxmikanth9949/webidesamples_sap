sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/FilterType"
], function (BaseCardController, JSONModel, Filter, FilterOperator, Filtertype) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.QDMonitor.QDMonitor", {

		// Initialize the view and make a call to the refresh method
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */
		//	this.onUpdateCard();
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			//	var oModel = this.getView().getModel("agsDashboardService");
			var oModel = this.getModel("zsAppDepService");
		

			var oFilter = [];
			var fActivityType = new Filter("ActivityType", FilterOperator.EQ, "ZS46");
			var fStatusID = new Filter({
				filters: [
					new Filter("StatusID", FilterOperator.EQ, "E0010"),
					new Filter("StatusID", FilterOperator.EQ, "E0011"),
				],
				and: false
			});
			// filters:[ { path: 'activity_process_type', operator: 'EQ', value1:'ZS46'}, 
		/*	{ path: 'activity_status', operator: 'EQ', value1:'E0010'}, { path: 'activity_status', operator: 'EQ', value1:'E0011'}, 
			{ path: 'activity_cat', operator: 'EQ', value1:'Z90'}, { path: 'activity_cat', operator: 'EQ', value1:'Z91'}, 
			{ path: 'activity_cat', operator: 'EQ', value1:'Z93'}, { path: 'activity_cat', operator: 'EQ', value1:'ZB9'}, 
			{ path: 'activity_reason', operator: 'EQ', value1:'A1ZS0000010100'}, { path: 'activity_priority', operator: 'EQ', value1:'1'}
			], parameters : {expand:'ActivityCases' } }"*/
			var fCategoryID = new Filter({
				filters: [
					new Filter("CategoryID", FilterOperator.EQ, "Z90"),
					new Filter("CategoryID", FilterOperator.EQ, "Z91"),
					new Filter("CategoryID", FilterOperator.EQ, "Z93"),
					new Filter("CategoryID", FilterOperator.EQ, "ZB9")
					//new Filter("CategoryID", FilterOperator.EQ, "ZZH"),
					//new Filter("CategoryID", FilterOperator.EQ, "ZZE"),
					//new Filter("CategoryID", FilterOperator.EQ, "ZSF")
				],
				and: false
			});
			var fPriorityID = new Filter("PriorityID", FilterOperator.EQ, "1");
			var fReasonID = new Filter("ReasonID", FilterOperator.EQ, "A1#ZS000001#0100");

			oFilter.push(fActivityType);
			oFilter.push(fStatusID);
			oFilter.push(fCategoryID);
			oFilter.push(fPriorityID);
			oFilter.push(fReasonID);
			
			var list = [];
			var problemlist = [];
			var holder = $.Deferred();
			oModel.read("/ActivitySet", {
				filters: oFilter,
				$expand: "CaseSet",
				success: function (oData) {
					holder.resolve(oData);

				}.bind(this),
				error: function (oError) {
					this.setCardErrorState();
				}.bind(this)
			});

			$.when(holder).done(function (oData) {
			//inconsistency detection removed
			// if interested in coding see previous commit
				this.setCardProperty("/data", oData.results);
				this.setCardSuccessState();

			}.bind(this));

		},

		//On selecting an activity in the table, navigate to the activity link in the CRM
		onSelectionChange: function (oEvent) {
			var sPath = oEvent.getParameters().rowBindingContext.sPath;
			var activityId = this.getModel("cardModel").getProperty(sPath).ActivityID;
			var currentUrl = window.location.href;
			var relativeUrl =
				"/sap/bc/bsp/sap/crm_ui_start/default.htm?saprole=ZSU_DEFAULT&crm-object-type=BT126_APPT&crm-object-action=B&crm-object-keyname=OBJECT_ID&crm-object-value=" +
				activityId;
			var urlICP = this.getView().getModel("i18n").getResourceBundle().getText("urlICPSAP");
			var urlICT = this.getView().getModel("i18n").getResourceBundle().getText("urlICTSAP");
			var url = urlICP + relativeUrl;
			if (currentUrl.includes("a44f228ad.dispatcher.hana.ondemand.com")) {
				//we are in test environment
				url = urlICT + relativeUrl;
			}
			var win = window.open(url, "_blank");
			win.focus();
		},
		
		onBCPIncidentPress: function(oEvent){
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sBCPIncident = this.getCardProperty(sBindingContextPath).BCPIncident;

			this.navToApp(
				this.getResourceBundle().getText("qaSupportTicket", [sBCPIncident]),
				this.getResourceBundle().getText("supportTicket", [sBCPIncident]), {}, false);
		}
	});
});