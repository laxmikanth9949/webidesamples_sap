sap.ui.define([
	'jquery.sap.global',
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	'sap/ui/model/json/JSONModel',
	'sap/viz/ui5/data/FlattenedDataset',
	'sap/viz/ui5/controls/common/feeds/FeedItem',
	'sap/viz/ui5/format/ChartFormatter',
	'sap/viz/ui5/api/env/Format',
	'./InitPage1'
], function (jQuery, BaseCardController, JSONModel, FlattenedDataset, FeedItem, ChartFormatter, Format, InitPageUtil) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.GlobalEscalationByStatus.GlobalEscalationByStatus", {

		chartTypeSelect: null,
		chart: null,
		/**
		 * Subscirbe to the event bus for changes in the filter criteria, Initialize the view and make a call to the refresh method
		 * 
		 */
		onInit: function (evt) {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "search", this.onUpdateCard, this);

			Format.numericFormatter(ChartFormatter.getInstance());

			this._initializeVizFrame();

		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			var regionFilter;
			var finalRegion = this.getCoreModel("workplaceModel").getProperty("/selectedProfileInstance/FilterValues/Region");

			/*	var sCardId = this.getView().getId().slice(0, -8);
				var bCardExists = sap.ui.controller("MCS.EMEADASHBOARD.DASHBOARDEMEA.ext.custom").checkCardVisibility(sCardId);

				if (bCardExists) {*/
			var oVizFrame = this.byId("idVizFramePLM");

			var region;
			if (finalRegion) {
				switch (finalRegion) {
				case "EMEA":
					region = "O 50008010";
					break;
				case "APJ":
					region = "O 50008134";
					break;
				case "NA":
					region = "O 50008167";
					break;
				case "LA":
					region = "O 50008174";
					break;
				}
				if (region) {
					regionFilter = new sap.ui.model.Filter("service_org", sap.ui.model.FilterOperator.EQ, region);
				}
			}
			var that = this;

			Format.numericFormatter(ChartFormatter.getInstance());

			var dataModel = new JSONModel();

			//var nModel = sap.ui.getCore().getComponent("__component1").getModel("ZS_DBS_MCS_DASHBOARD_SRV");
			var oFilter = [];
			var oFilter1 = [];
			var f1 = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, 'ZSPRCTYP01');
			var f11 = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, 'ZSPRCTYP06');
			//var f2 = new sap.ui.model.Filter("service_org",sap.ui.model.FilterOperator.EQ,'O 50008010');
			var fRegion = new sap.ui.model.Filter("region", sap.ui.model.FilterOperator.EQ, 'EMEA');
			var fOpen1 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, '20');
			var fOpen2 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, '30');

			this.printDate(this.getPreviousMonday());
			this.printDate(this.getThisMonday());
			var fClosedDate = new sap.ui.model.Filter("closing_time", sap.ui.model.FilterOperator.BT,
				this.printDate(this.getPreviousMonday()), this.printDate(this.getThisMonday()));

			var f12 = new sap.ui.model.Filter({
				filters: [f1, f11],
				and: false
			});

			var fOpen = new sap.ui.model.Filter({
				filters: [fOpen1, fOpen2],
				and: false
			});
			var all;
			var filter;
			if (regionFilter) {
				all = new sap.ui.model.Filter({
					filters: [f12, regionFilter, fOpen],
					and: true
				});

				filter = new sap.ui.model.Filter({
					filters: [f12, regionFilter, fClosedDate],
					and: true
				});
			} else {
				all = new sap.ui.model.Filter({
					filters: [f12, fOpen],
					and: true
				});

				filter = new sap.ui.model.Filter({
					filters: [f12, fClosedDate],
					and: true
				});
			}
			var filter1 = new sap.ui.model.Filter({
				filters: [all, filter],
				and: true
			});
			var d1 = $.Deferred();
			var d2 = $.Deferred();
			oFilter.push(all);
			oFilter1.push(filter);
			var model = this.getModel("mcsDashboardService");
			model.read("/MCSDashboardSet/", {
				filters: oFilter1,
				success: function (oResult1) {
					d1.resolve(oResult1);

				}
			});
			model.read("/MCSDashboardSet/", {
				filters: oFilter,
				success: function (oResult) {
					//	console.log(oResult.results);
					d2.resolve(oResult);

				}
			});
			$.when(d1, d2).done(function (v1, v2) {
				var closedArr = v1.results;
				//console.log(closedArr);
				var countT = 0;
				var countR = 0;
				var countG = 0;
				var countY = 0;
				var countTLW = 0;
				var countRLW = 0;
				var countGLW = 0;
				var countYLW = 0;
				var countN = 0;
				var oModel = new sap.ui.model.json.JSONModel();
				var merged = v2.results.concat(closedArr);
				countT = v2.results.length;
				//console.log(countT);
				var filterR = v2.results;
				var filterG = v2.results;
				var filterY = v2.results;
				var filterN = v2.results;
				filterR = filterR.filter(function (item) {
					return item.rating == "C";
				});
				filterG = filterG.filter(function (item) {
					return item.rating == "A";
				});
				filterY = filterY.filter(function (item) {
					return item.rating == "B";
				});
				//console.log(filterR);
				countR = filterR.length;
				countG = filterG.length;
				countY = filterY.length;

				var filterLW = merged;
				filterLW = filterLW.filter(function (item) {
					return item.status_text == "Closed";
				});
				//console.log(filterLW);
				var filterLW2 = v2.results;
				filterLW2 = filterLW2.filter(function (item) {
					return item.create_time < that.printDate(that.getThisMonday());
				});
				//console.log(filterLW2);
				countTLW = filterLW.length + filterLW2.length;

				var filterLWR = filterLW.filter(function (item) {
					return item.rating == "C";
				});

				var filterLW2R = filterLW2.filter(function (item) {
					return item.rating == "C";
				});
				countRLW = filterLWR.length + filterLW2R.length;

				var filterLWY = filterLW.filter(function (item) {
					return item.rating == "B";
				});

				var filterLW2Y = filterLW2.filter(function (item) {
					return item.rating == "B";
				});
				countYLW = filterLWY.length + filterLW2Y.length;

				var filterLWG = filterLW.filter(function (item) {
					return item.rating == "A";
				});

				var filterLW2G = filterLW2.filter(function (item) {
					return item.rating == "A";
				});
				countGLW = filterLWG.length + filterLW2G.length;
				//console.log(countTLW);
				//console.log(countRLW);
				//console.log(countYLW);
				//console.log(countGLW);

				filterN = filterN.filter(function (item) {
					//	console.log(item.create_time);
					//	console.log(that.printDate(that.getThisMonday()));
					return item.create_time >= that.printDate(that.getThisMonday());
				});
				countN = filterN.length;
				var data = {
					'Data': [{
						"Category": "Total",
						"Ongoing": countT,
						"LastWeek": countTLW
					}, {
						"Category": "Red",
						"Ongoing": countR
					}, {
						"Category": "Yellow",
						"Ongoing": countY
					}, {
						"Category": "Green",
						"Ongoing": countG
					}, {
						"Category": "New",
						"Ongoing": countN
					}]
				};
				dataModel.setData(data);
				that.getView().setModel(dataModel, "dataModel");
				that.setCardSuccessState();
				/*	bCardExists = sap.ui.controller("MCS.EMEADASHBOARD.DASHBOARDEMEA.ext.custom").checkCardVisibility(sCardId);
					if (bCardExists) {
						that.byId("idVizFramePLM").setBusy(false);
					}*/

				/*var oPopOver = that.getView().byId("idPopOver");
				 oPopOver.connect(oVizFrame.getVizUid());
				 oPopOver.setFormatString({
				     "Cost": ChartFormatter.DefaultPattern.STANDARDFLOAT,
				     "Revenue": ChartFormatter.DefaultPattern.STANDARDFLOAT
				 });*/

			});

			/*}*/

		},
		/**
		 * initialize vizframe properties
		 * 
		 */
		_initializeVizFrame: function () {

			var oVizFrame = this.byId("idVizFramePLM");
			oVizFrame.setVizProperties({
				title: {
					visible: "true",
					text: "Global Escalations"
				},
				valueAxis: {
					title: {
						visible: false,
						text: "Amount"
					}
				},
				categoryAxis: {
					title: {
						visible: false,
						text: "Category"
					}
				},
				plotArea: {
					dataLabel: {
						visible: true
					}
				}
			});

		},

		onAfterRendering: function () {
			this.chartTypeSelect = this.getView().byId('chartTypeSelect');
		},
		/**
		 * Given a date, compute the week number of that date
		 * param(d) date
		 */
		getWeekNumber: function (d) {
			// Copy date so don't modify original
			//console.log(d);
			d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
			// Set to nearest Thursday: current date + 4 - current day number
			// Make Sunday's day number 7
			d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
			// Get first day of year
			var yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
			// Calculate full weeks to nearest Thursday
			var weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
			// Return array of year and week number
			return [d.getUTCFullYear(), weekNo];
			//return weekNo;
		},
		/**
		 * returns the date of the monday last week
		 * 
		 */
		getPreviousMonday: function () {
			var date = new Date();
			var day = date.getDay();
			var prevMonday;
			if (date.getDay() === 0) {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate() - 6);

			} else {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate() - day - 6);

			}

			return prevMonday;
		},
		/**
		 * returns the date of the monday this week
		 * 
		 */
		getThisMonday: function () {
			var date = new Date();
			var day = date.getDay();
			var prevMonday;
			if (date.getDay() === 0) {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate());
			} else {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate() - day + 1);
			}

			return prevMonday;
		},
		padStr: function (i) {
			return (i < 10) ? "0" + i : "" + i;
		},
		/**
		 * returns the date in string format
		 * param(temp) date in date format
		 */
		printDate: function (temp) {
			//var temp = new Date();
			var temp1 = new Date(temp);
			var dateStr = this.padStr(temp.getFullYear()) +
				this.padStr(1 + temp.getMonth()) +
				this.padStr(temp.getDate()) +
				this.padStr(temp.getHours()) +
				this.padStr(temp.getMinutes()) +
				this.padStr(temp.getSeconds());
			return (dateStr);
		},
		/**
		 * returns a date in date format
		 * param(temp) date in string format
		 */
		getDateOfWeek: function (w, y) {
			var date = new Date();
			var tdate = new Date(date.getFullYear(), 0, 1);
			var day = tdate.getDay();
			var d;
			switch (day) {
			case 0:
				d = (-5 + (w - 1) * 7);
				break;
			case 1:
				d = (1 + (w - 1) * 7);
				break;
			case 2:
				d = (0 + (w - 1) * 7);
				break;
			case 3:
				d = (-1 + (w - 1) * 7);
				break;
			case 4:
				d = (-2 + (w - 1) * 7);
				break;
			case 5:
				d = (-3 + (w - 1) * 7);
				break;
			case 6:
				d = (-4 + (w - 1) * 7);
				break;
			}
			//console.log(new Date(y, 0, d));
			// 1st of January + 7 days for each week

			return new Date(y, 0, d);
		},
		/**
		 * returns a date in date format
		 * param(temp) date in string format
		 */
		createDate: function (temp) {
			var year = temp.substring(0, 4);
			var month = temp.substring(4, 6);
			var day = temp.substring(6, 8);
			var hour = temp.substring(8, 10);
			var minute = temp.substring(10, 12);
			var seconds = temp.substring(12, 14);

			return new Date(year, month - 1, day, hour, minute, seconds);
		}
	});

});