sap.ui.define([
	"jquery.sap.global",
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"sap/m/Dialog",
	"sap/ui/core/Icon"
], function (jQuery, BaseCardController, JSONModel, Dialog, Icon) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.QuickLinks.QuickLinks", {
		// set the root path of the folder and load the image from the correct path
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", [
				new Icon({
					src: "sap-icon://add",
					tooltip: "{i18n>addLink}",
					color: "#FFFFFF",
					press: [this.onAddLink, this]
				}).addStyleClass("sapUiTinyMarginBeginEnd")
			]);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			this._getLinks();

			var oObject = {
				Links: [],
				personalLinks: [],
				defaultLinks: false
			};
			var oJSONModel = new sap.ui.model.json.JSONModel(oObject);
			this.getView().setModel(oJSONModel, "quickLinks");
		},

		_getLinks: function () {
			var oPromise = this._getUserInfo();
			oPromise.then(function (oData) {

				this.getView().setModel(new sap.ui.model.json.JSONModel(oData), "userModel");
				return new Promise(function (resolve, reject) {
					this._readPersonalLinks(resolve, reject);
				}.bind(this));
			}.bind(this)).then(function (aPersonalLinks) {
				if (aPersonalLinks.length > 0) {
					this.getView().getModel("quickLinks").setProperty("/Links", aPersonalLinks);
					this.getView().getModel("quickLinks").setProperty("/defaultLinks", false);
					this.getView().getModel("quickLinks").setProperty("/LinkListBusy", false);
					//set property card order exist to true
				} else {
					//card order doesn't exist
					// show default links
					this.getView().getModel("quickLinks").setProperty("/defaultLinks", true);

					var oPromiseDefaultLinks = this._readDefaultLinks();
					oPromiseDefaultLinks.then(function (aDefaultLinks) {
						this.getView().getModel("quickLinks").setProperty("/Links", aDefaultLinks);
						this.getView().getModel("quickLinks").setProperty("/LinkListBusy", false);
					}.bind(this));

				}
				this.getView().getModel("quickLinks").refresh(true);
			}.bind(this));

		},

		onReorderItems: function (oEvent) {},

		onDrop: function (oInfo) {
			this.getView().getModel("quickLinks").setProperty("/LinkListBusy", true);

			var oDragged = oInfo.getParameter("draggedControl"),
				oDropped = oInfo.getParameter("droppedControl"),
				sInsertPosition = oInfo.getParameter("dropPosition"),

				oDraggedParent = oDragged.getParent(),
				oDroppedParent = oDropped.getParent(),

				oDragModel = oDraggedParent.getModel("quickLinks"),
				oDropModel = oDroppedParent.getModel("quickLinks"),
				oDragModelData = oDragModel.getProperty("/Links"),
				oDropModelData = oDropModel.getProperty("/Links"),

				iDragPosition = oDraggedParent.indexOfItem(oDragged),
				iDropPosition = oDroppedParent.indexOfItem(oDropped);

			/*var aDragModelData = [];
			var aDragModelDataKeys = Object.keys(oDragModelData);
			aDragModelDataKeys.forEach(function (sKey) {
				aDragModelData.push(oDragModelData[sKey]);
			}.bind(this));

			var aDropModelData = [];
			var aDropModelDataKeys = Object.keys(oDropModelData);
			aDropModelDataKeys.forEach(function (sKey) {
				aDropModelData.push(oDragModelData[sKey]);
			}.bind(this));*/

			// remove the item
			var oItem = oDragModelData[iDragPosition];
			oDragModelData.splice(iDragPosition, 1);

			if (oDragModel === oDropModel && iDragPosition < iDropPosition) {
				iDropPosition--;
			}

			// insert the control in target aggregation
			if (sInsertPosition === "Before") {
				oDragModelData.splice(iDropPosition, 0, oItem);
			} else {
				oDropModelData.splice(iDropPosition + 1, 0, oItem);
			}

			if (oDragModel !== oDropModel) {
				oDragModel.setProperty("/Links", oDragModelData);
				oDropModel.setProperty("/Links", oDropModelData);
			} else {
				oDropModel.setProperty("/Links", oDropModelData);
			}

			this._updateCardOrder();
		},

		_readPersonalLinks: function (resolve, reject) {
			var oMCSCardsOVPModel = this.getView().getModel("MCSCardsOVPModel");
			var sUserId = this.getView().getModel("userModel").getProperty("/name");
			var aFilter = [];
			var oFilter = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
			var oSorter = new sap.ui.model.Sorter("LinkOrder");
			aFilter.push(oFilter);
			oMCSCardsOVPModel.read("/UserLinks", {
				filters: aFilter,
				sorters: [oSorter],
				urlParameters: {
					"$expand": "Links"
				},
				success: function (oData) {
					resolve(oData.results);

				}.bind(this),
				error: function (err) {
					reject(err);
				}
			});

		},

		_readDefaultLinks: function () {
			var oMCSCardsOVPModel = this.getView().getModel("MCSCardsOVPModel");
			var sUserId = this.getView().getModel("userModel").getProperty("/name");
			var oFilter = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter("createdBy", sap.ui.model.FilterOperator.EQ, sUserId),
					new sap.ui.model.Filter("createdBy", sap.ui.model.FilterOperator.EQ, "Default")
				],
				and: false
			});
			var aFilter = [oFilter];
			return new Promise(function (resolve, reject) {
				oMCSCardsOVPModel.read("/Links", {
					filters: aFilter,
					success: function (oData) {
						resolve(oData.results);

					}.bind(this),
					error: function (err) {
						reject(err);
					}
				});
			}.bind(this));
		},

		_updateCardOrder: function () {
			var bDefaultLinks = this.getView().getModel("quickLinks").getProperty("/defaultLinks");
			var oList = this.getView().byId("LinkList");
			var aLinksOrder = this.getView().getModel("quickLinks").getProperty("/Links");
			var oModel = this.getView().getModel("MCSCardsOVPModel");
			var sUserId = this.getView().getModel("userModel").getProperty("/name");

			var i = 0;
			aLinksOrder.forEach(function (oLink) {
				if (oLink) {
					var oObject = {
						"UserID": sUserId,
						"LinkOrder": i,
						"Links_LinkID": oLink.LinkID
					};
					var sPath = "/UserLinks";

					if (bDefaultLinks) {
						oModel.createEntry(sPath, {
							properties: oObject,
							success: function (odata) {},
							error: function (err) {}
						});
					} else {
						var sPath = sPath + "(guid'" + oLink.ID + "')";
						oModel.update(sPath, oObject, {
							success: function (odata) {},
							error: function (err) {}
						});
					}
					i++;
				}

			}.bind(this));

			/*var i = 0;
			aLinksOrder.forEach(function (oLink) {
				var oObject = {
					"UserID": sUserId,
					"LinkOrder": i,
					"Links_LinkID": oLink.LinkID
				};

				i++;
			}.bind(this));*/
			if (this.getView().getModel("MCSCardsOVPModel").hasPendingChanges()) {
				this.getView().getModel("MCSCardsOVPModel").submitChanges();

			}
			this._getLinks();
		},

		onItemPress: function (oEvent) {
			var oSource = oEvent.getSource();
			var sBindingPath = oSource.getBindingContext("quickLinks").getPath();
			var oLink = this.getView().getModel("quickLinks").getProperty(sBindingPath);
			var bDefaultLinks = this.getView().getModel("quickLinks").getProperty("/defaultLinks");
			var sUrl = "";
			if (bDefaultLinks) {
				sUrl = oLink.Url;

			} else {
				sUrl = oLink.Links.Url;
			}

			if (sUrl.indexOf("https://") === -1 && sUrl.indexOf("https://") === -1) {
				sUrl = "https://" + sUrl;
			}

			sap.m.URLHelper.redirect(sUrl, true);

		},

		//Press event of "+" Button
		//A dialog opens to fill in required data 
		//submit event persists the data in the database
		onAddLink: function (oEvent) {

			var oDialog = new Dialog({
				title: 'New Quick Link',
				type: 'Message',
				content: [
					new sap.m.Label({
						text: 'Text / Description:',
						labelFor: 'linkText',
						required: true
					}),
					new sap.m.Input('linkText', {
						liveChange: function (oEvent) {
							var sText = oEvent.getParameter('value');
							var parent = oEvent.getSource().getParent();
							var sUrlInputValue = sap.ui.getCore().byId("sUrlInput").getValue();
							if (sText.length > 0 && sUrlInputValue.length > 0) {
								parent.getBeginButton().setEnabled(true);
							}
						},
						width: '100%',
						placeholder: 'Text / Description'
					}),
					new sap.m.Label({
						text: 'URL:',
						labelFor: 'sUrlInput',
						required: true
					}),
					new sap.m.Input('sUrlInput', {
						liveChange: function (oEvent) {
							var sText = oEvent.getParameter('value');
							var parent = oEvent.getSource().getParent();

							var sLinkText = sap.ui.getCore().byId("linkText").getValue();
							if (sText.length > 0 && sLinkText.length > 0) {
								parent.getBeginButton().setEnabled(true);
							}
						},
						width: '100%',
						placeholder: 'URL, e.g. www.sap.com'
					})
				],
				beginButton: new sap.m.Button({
					type: sap.m.ButtonType.Emphasized,
					text: 'Submit',
					enabled: false,
					press: function () {
						var sDescription = sap.ui.getCore().byId('linkText').getValue();
						var sUrl = sap.ui.getCore().byId('sUrlInput').getValue();
						//sap.m.MessageToast.show('Note is: ' + sDescription);
						var oPromise = this._createLink(sDescription, sUrl);

						oPromise.then(function (oData) {
							var bDefaultLinks = this.getView().getModel("quickLinks").getProperty("/defaultLinks");
							if (!bDefaultLinks) {
								//create UserLinks Entry
								var aLinksOrder = this.getView().getModel("quickLinks").getProperty("/Links");
								aLinksOrder.push(oData);
								/*this.getView().getModel("quickLinks").setProperty("/Links", aLinksOrder);
								this._updateCardOrder()
									//add entry 
									//updateLinkOrder

								this._updateCardOrder();*/
								var oPromise2 = this._createUserLink(oData.LinkID);
								oPromise2.then(function (oUserLink) {
									this._getLinks();
								}.bind(this));
							} else {
								this._getLinks();
							}
						}.bind(this));
						oDialog.close();
					}.bind(this)
				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function () {
						oDialog.close();
					}
				}),
				afterClose: function () {
					oDialog.destroy();
				}
			});

			oDialog.open();
		},

		_createLink: function (sDecription, sUrl) {
			var sCreatedBy = this.getView().getModel("userModel").getProperty("/name");
			var oObject = {
				//"createdBy": sCreatedBy,
				"Description": sDecription,
				"Url": sUrl
			};
			var oModel = this.getView().getModel("MCSCardsOVPModel");
			return new Promise(function (resolve, reject) {
				oModel.create("/Links", oObject, {
					success: function (odata) {
						resolve(odata);
					},
					error: function (err) {
						reject(err);

					}
				});
			}.bind(this));
		},

		_createUserLink: function (sLinkId) {
			var sCreatedBy = this.getView().getModel("userModel").getProperty("/name");
			var oObject = {
				"Links_LinkID": sLinkId,
				"UserID": sCreatedBy
			};
			var oModel = this.getView().getModel("MCSCardsOVPModel");
			return new Promise(function (resolve, reject) {
				oModel.create("/UserLinks", oObject, {
					success: function (odata) {
						resolve(odata);
					},
					error: function (err) {
						reject(err);

					}
				});
			}.bind(this));
		},

		onDeleteListItem: function (oEvent) {
			//set Busy Indicator for Link list to true
			this.getView().getModel("quickLinks").setProperty("/LinkListBusy", true);

			var oItem = oEvent.getParameter("listItem");
			var oBindingContext = oItem.getBindingContext("quickLinks");
			var oQuickLinksModel = this.getView().getModel("quickLinks");

			var oQuickLinkPressed = oQuickLinksModel.getProperty(oBindingContext.getPath());
			//this.getView().getModel("quickLinks").getProperty(oBindingContext.getPath()).CreatedBy
			var bDefaultLinks = this.getView().getModel("quickLinks").getProperty("/defaultLinks");
			var sPath = "";
			var aPromises = [];

			if (bDefaultLinks && oQuickLinkPressed.createdBy !== "Default") {
				//--> delete Link in /Links
				//console.log("Default View + NON-Default Link (CUSTOM) ");
				sPath = "/Links(guid'" + oQuickLinkPressed.LinkID + "')";
				var oPromise = this._deleteLinks(sPath);
				aPromises.push(oPromise);
				/*oMCSCardsOVPModel.remove(sPath, {
					success: function(oData){
						debugger;
						this._getLinks();
					}.bind(this),
					error: function(err){
						debugger;
					}
				});*/
			} else if (bDefaultLinks && oQuickLinkPressed.createdBy === "Default") {
				// --> create UserLinks entries without selecte entry
				//console.log("Default View + Default Link ");
				oQuickLinksModel.setProperty(oBindingContext.getPath(), null);
				this._updateCardOrder();
			} else if (!bDefaultLinks && oQuickLinkPressed.Links.createdBy === "Default") {
				// --> delete entry in UserLinks list
				//console.log("NON-Default View + Default Link ");
				var sPath = "/UserLinks(guid'" + oQuickLinkPressed.ID + "')";
				var oPromise = this._deleteLinks(sPath);
				aPromises.push(oPromise);

			} else if (!bDefaultLinks && oQuickLinkPressed.Links.createdBy !== "Default") {
				// --> delete Entry in UserLinks und Links entity
				//console.log("NON-Default View + NON-Default Link (CUSTOM) ");
				//delete Link in Link Entity
				var oPromiseLink = this._deleteLinks("/Links(guid'" + oQuickLinkPressed.Links_LinkID + "')");
				var oPromiseUserLink = this._deleteLinks("/UserLinks(guid'" + oQuickLinkPressed.ID + "')");
				aPromises.push(oPromiseLink);
				aPromises.push(oPromiseUserLink);
			}
			if (aPromises.length > 0) {
				Promise.all(aPromises).then(function (oData) {

					this._getLinks();
				}.bind(this));
			}

			//if personal items --> delete link and user link entry
			//if personal items --> default item delete  user link entry
			//if default items -->  and no default item is klicked --> delete Link
			//if default item --> and default item ist klick --> create user links without the clicked item
		},

		_deleteLinks: function (sPath) {
			var oMCSCardsOVPModel = this.getView().getModel("MCSCardsOVPModel");
			return new Promise(function (resolve, reject) {
				oMCSCardsOVPModel.remove(sPath, {
					success: function (oData) {
						resolve("succes");

					}.bind(this),
					error: function (err) {
						reject(err);
					}
				});
			});
		}
	});
});