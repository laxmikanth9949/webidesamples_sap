sap.ui.define([
	"sap/ui/base/ManagedObject"
], function (
	ManagedObject
) {
	"use strict";

	return {
		getStaffings: function (pThisFromController, pUserIDs) {
			var that = pThisFromController;
			var staffings = this.createTree(pUserIDs);
			var promises = [];
			var today = new Date();
			for (var i = 0; i < 15; i++) {
				promises.push(this.getDayStaffings(that, this.addDays(today, i).toISOString().split('T')[0]));
			}
			return new Promise((resolve, reject) => {
				Promise.all(promises).then(function (results) {
					resolve(results);
				})
			})
		},
		getDayStaffings: function (pThisFromController, pDay) {
			var that = pThisFromController;
			var oModel = pThisFromController.getModel("BOOST_Service");
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, "MCS-MCC%20POOL"));
			aFilters.push(new sap.ui.model.Filter("Date", sap.ui.model.FilterOperator.EQ, "datetime'" + pDay + "'"));
			aFilters.push(new sap.ui.model.Filter("Workload", sap.ui.model.FilterOperator.EQ, "X"));
			return new Promise((resolve, reject) => {
				oModel.read("/Staffing", {
					filters: aFilters,
					success: function (data) {
						resolve(data);
					},
					error: function (err) {
						reject(err);
					}
				});
			});
		},
		createTree: function (pUserIDs) {
			var TreeStructure = {
				users: []
			};
			for (var i = 0; i < pUserIDs.length; i++) {
				var UserObject = {
					UserID: pUserIDs[i],
					StaffingCount: 0,
					Staffings: [],
				};
				TreeStructure.users.push(UserObject);
			}
			return TreeStructure;
		},
		createStaffingObject: function (pStaffingDate, pStaffingTitle, pStaffedUser) {
			return {
				StaffingTitle: pStaffingTitle,
				StaffingDate: pStaffingDate,
				StaffedUser: pStaffedUser
			}
		},
		addDays: function (date, days) {
			date.setDate(date.getDate() + days);
			return date;
		}
	};
});