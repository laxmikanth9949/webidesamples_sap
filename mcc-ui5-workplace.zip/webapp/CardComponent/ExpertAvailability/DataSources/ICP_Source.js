sap.ui.define([
	"sap/ui/base/ManagedObject"
], function (
	ManagedObject
) {
	"use strict";

	return {
		/**
		 * Function returning information about Escalations/Engagement of a certain user.
		 * 
		 * @param {string} pUserID - D/I/C User Code
		 * @param {string} pCaseType - ZS01 for Escalations, ZS02 for Engagements
		 * @param {string} pAction  - "data" for a full set of information as JSON, "count" for a int
		 * 
		 * @return {promise} - Promise that resolves with Action defined.
		 * 
		 * @example  
		 * 		getCases('I123456', 'ZS01', 'count);
		 * 
		 */
		getCases: function (pUserID, pCaseType, pAction, thisFromController) {
			var oModel = thisFromController.getModel("ICP_OData_Service");
			var that = this;
			var aFilters = [];
			var UserFilter = new sap.ui.model.Filter("Responsible", sap.ui.model.FilterOperator.EQ, pUserID);
			aFilters.push(UserFilter);
			switch (pCaseType) {
			case "ZS01":
				var CaseTypeFilter = new sap.ui.model.Filter("CaseType", sap.ui.model.FilterOperator.EQ, "ZS01");
				var StatusFilter = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("StatusID", sap.ui.model.FilterOperator.EQ, "20"),
						new sap.ui.model.Filter("StatusID", sap.ui.model.FilterOperator.EQ, "30")
					],
					and: false
				});
				aFilters.push(CaseTypeFilter);
				aFilters.push(StatusFilter);
				break;
			case "ZS02":
				var CaseTypeFilter = new sap.ui.model.Filter("CaseType", sap.ui.model.FilterOperator.EQ, "ZS02");
				var StatusFilter = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("StatusID", sap.ui.model.FilterOperator.EQ, "71"),
						new sap.ui.model.Filter("StatusID", sap.ui.model.FilterOperator.EQ, "80"),
						new sap.ui.model.Filter("StatusID", sap.ui.model.FilterOperator.EQ, "81"),
						new sap.ui.model.Filter("StatusID", sap.ui.model.FilterOperator.EQ, "99")
					],
					and: false
				});
				aFilters.push(CaseTypeFilter);
				aFilters.push(StatusFilter);
				break;
			}
			switch (pAction) {
			case "data":
				return new Promise((resolve, reject) => {
					oModel.read("/CaseSet", {
						filters: aFilters,
						success: function (data) {
							var returnObject = {
								DataType: pCaseType + "_data",
								User: pUserID,
								Data: data
							};
							resolve(returnObject);
						},
						error: function (err) {
							reject(err);
						}
					});
				});
			case "count":
				return new Promise((resolve, reject) => {
					oModel.read("/CaseSet/$count", {
						filters: aFilters,
						success: function (data) {
							var returnObject = {
								DataType: pCaseType + "_count",
								User: pUserID,
								Data: data
							};
							resolve(returnObject);
						},
						error: function (err) {
							reject(err);
						}
					});
				});
			}

		}
	}
});