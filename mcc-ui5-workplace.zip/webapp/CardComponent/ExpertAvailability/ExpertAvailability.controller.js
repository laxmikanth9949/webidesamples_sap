sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"com/sap/mcc/workplace/CardComponent/ExpertAvailability/formatter",
	"com/sap/mcc/workplace/CardComponent/ExpertAvailability/DataProvider"
], function (BaseCardController, JSONModel, formatter, DataProvider) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.ExpertAvailability.ExpertAvailability", {
		formatter: formatter,
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			this.onUpdateCard();
			// this.setCardAutoRefresh(300000); // Autorefresh in ms - if card needs to be autorefreshed, set the time in ms

			/* YOUR CODE HERE */
			var oView = this.getView();
			var oTable = this.byId("ZS01");
			formatter;
			var oTemplate = new sap.m.ColumnListItem({
				cells: [new sap.m.Text({
					text: "{UserID}"
				}), new sap.m.Text({
					text: "{WorkloadIndicator}"
				}), new sap.m.Text({
					text: "{EscalationCount}"
				}), new sap.m.Text({
					text: "{EngagementCount}"
				}), new sap.m.List({
					id: "Esca_List",
					items: {
						path: "Escalations",
						template: new sap.m.StandardListItem({
							title: "{CustomerName}",
							description: "{CaseTitle}",
							info: "{path: 'RatingText', formatter: 'self.formatter.EscalationColorFormat'}"
						}),
						templateShareable: false
					},
				})]
			});
			var that = this;
			DataProvider;
			DataProvider.provideData(this).then(function (RecievedResponse) {
				oTable.setModel(RecievedResponse);
				oTable.bindAggregation("items", {
					path: "/zs01_set/users",
					template: oTemplate
				});
			});
		},
		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardSuccessState();
			
		}
	});
});