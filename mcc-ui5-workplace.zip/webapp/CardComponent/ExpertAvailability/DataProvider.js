sap.ui.define([
	"sap/ui/base/ManagedObject",
	"./DataSources/ICP_Source",
	"./DataSources/BOOST_Source"
], function (
	ManagedObject,
	ICP_Source,
	BOOST_Source
) {
	"use strict";

	return {
		provideData: function (thisFromController) {
			ICP_Source;
			BOOST_Source;
			var that = this;
			return new Promise(function (resolve, reject) {
				var aUserIDs = [];
				var aMetaData = [];
				aUserIDs.push("D057452"); //TODO Marvin Hoffmann
				aUserIDs.push("D054768"); //TODO Susanne Joeling
				aUserIDs.push("I353511");
				var aPromises = [];
				for (var i = 0; i < aUserIDs.length; i++) {
					//Add Promises
					aPromises.push(ICP_Source.getCases(aUserIDs[i], "ZS01", "data", thisFromController));
					aPromises.push(ICP_Source.getCases(aUserIDs[i], "ZS02", "data", thisFromController));
					aPromises.push(ICP_Source.getCases(aUserIDs[i], "ZS01", "count", thisFromController));
					aPromises.push(ICP_Source.getCases(aUserIDs[i], "ZS02", "count", thisFromController));
				}
				//aPromises.push(BOOST_Source.getStaffings(thisFromController, aUserIDs));
				var DataTree = that.instantiateModel(aUserIDs);
				Promise.all(aPromises).then(function (allDataPoints) {
					//Add the Data to the DataTree
					for (var i = 0; i < allDataPoints.length; i++) {
						var CurrentDataPoint = allDataPoints[i];
						var currentUser = CurrentDataPoint.User;
						switch (allDataPoints[i].DataType) {
						case "ZS01_data":
							var Cases = CurrentDataPoint.Data.results;
							for (var CasePointer = 0; CasePointer < Cases.length; CasePointer++) {
								var TreeObject = that.createEscalationObject(Cases[CasePointer]);
								var UserPosition = DataTree.users.findIndex(s => s.UserID == currentUser)
								var UserPosition = DataTree.users.findIndex(s => s.UserID == currentUser)
								DataTree.users[UserPosition].Escalations.push(TreeObject);
							}
							break;
						case "ZS02_data":
							var Cases = CurrentDataPoint.Data.results;
							for (var CasePointer = 0; CasePointer < Cases.length; CasePointer++) {
								var TreeObject = that.createEscalationObject(Cases[CasePointer]);
								var UserPosition = DataTree.users.findIndex(s => s.UserID == currentUser)
								DataTree.users[UserPosition].Engagements.push(TreeObject);
							}
							break;
						case "ZS01_count":
							for (var UserPointer = 0; UserPointer < DataTree.users.length; UserPointer++) {
								if (DataTree.users[UserPointer].UserID == currentUser) {
									DataTree.users[UserPointer].EscalationCount = CurrentDataPoint.Data;
								}
							}
							break;
						case "ZS02_count":
							for (var UserPointer = 0; UserPointer < DataTree.users.length; UserPointer++) {
								if (DataTree.users[UserPointer].UserID == currentUser) {
									DataTree.users[UserPointer].EngagementCount = CurrentDataPoint.Data;
								}
							}
							break;

						}
					}
					var IndicatedTree = that.calculateIndicator(DataTree);
					var returnModel = new sap.ui.model.json.JSONModel();
					returnModel.setData({
						zs01_set: IndicatedTree
					});
					resolve(returnModel);
				}).catch(error => {
					console.error(error.message)
				});
			});
		},
		calculateIndicator: function (DataTreeOld) {
			for (var i = 0; i < DataTreeOld.users.length; i++) {
				var Indicator = (DataTreeOld.users[i].EscalationCount * 3) + (DataTreeOld.users[i].EngagementCount * 2);
				DataTreeOld.users[i].WorkloadIndicator = Indicator;
			}
			return DataTreeOld;
		},
		createEscalationObject: function (pCaseObject) {
			var eObject = {
				CaseID: pCaseObject.CaseID,
				CaseType: pCaseObject.CaseType,
				CaseTitle: pCaseObject.CaseTitle,
				CustomerName: pCaseObject.CustomerName,
				StatusID: pCaseObject.StatusID,
				StatusText: pCaseObject.StatusText,
				RatingText: pCaseObject.RatingText,
				RoleID: pCaseObject.RoleID,
			}
			return eObject;
		},

		instantiateModel: function (pUserIDs) {
			var TreeStructure = {
				users: []
			};
			for (var i = 0; i < pUserIDs.length; i++) {
				var UserObject = {
					UserID: pUserIDs[i],
					EscalationCount: 0,
					EngagementCount: 0,
					Escalations: [],
					Engagements: [],
					BoostAssignments: [],
					VacationDays: [],
					WorkloadIndicator: 0
				};
				TreeStructure.users.push(UserObject);
			}
			return TreeStructure;
		}
	}
});