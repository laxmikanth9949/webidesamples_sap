jQuery.sap.declare("com.sap.mcc.workplace.CardComponent.ExpertAvailability.formatter");
sap.ui.define([], function () {
	"use strict";

	return {
		EscalationColorFormat: function (status) {
			switch (status) {
			case "Green":
				return "Success";
				break;
			case "Yellow":
				return "Warning";
				break;
			case "Red":
				return "Error";
				break;
			default:
				return sap.ui.core.IndicationColour.Neutral;
				break;
			}
		}
	}
});