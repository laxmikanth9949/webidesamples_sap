sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function (BaseCardController, JSONModel, MessageToast) {
	"use strict";

	return BaseCardController.extend(
		"com.sap.mcc.workplace.CardComponent.WorklistDutyManager.WorklistDutyManager", {
			onInit: function () {
				/* BEGIN: CARD INITIALIZATION */
				// add custom control to header
				this.setCardProperty("/customHeader/action/right", []);
				this.setCardProperty("/customHeader/action/left", []);
				this.setCardProperty("/customHeader/additionalCardTitle", []);
				// Initialize view and CardHeader
				BaseCardController.prototype.onInit.apply(this, arguments);
				/* END: CARD INITIALIZATION */

				/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

				this.onUpdateCard();
				//	sap.ui.getCore().getEventBus().subscribe("mcs.emea.esca.overview", "reload", this.onUpdateCard, this);
			},

			/**
			 * onUpdateCard is triggered for refreshing the data.
			 * IMPORTANT: the onUpdateCard method name cannot be modified
			 */
			onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
				this.setCardUpdateStartState();
				this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

				var oModel = this.getOwnerComponent().getModel("sc2_critsit_dashboard_srv");
				var oModel2 = this.getModel("zsAppDepService");
				var holder = $.Deferred();
				var list = [];

				oModel.read("/Critical_IncidentsSet", {
					urlParameters: {
						$filter: "(QdJudgement eq '2' or QdJudgement eq '4') and EscltnStatus eq '15'"
					},
					success: function (oData) {
						var oResult = this.bubbleSort(oData);
						//	this.getView().getModel("WorklistModel").setData(oResult);
						list = oResult;
						if (oResult.results.length > 5) {

						}
						/*	this.setCardProperty("/customHeader/additionalCardTitle", " (" + oResult.results.length + ")");
							var scroll = this.getView().byId("s1");
							if (oResult.results.length > 9) {
								scroll.setHeight("31rem");
							}*/
						holder.resolve();
					}.bind(this),
					error: function (oError) {
						this.setCardErrorState();
					}.bind(this)
				});

				$.when(holder).done(function () {
					if (list.results.length > 0) {
						list.results.forEach(n => {
							oModel2.read("/ActivitySet", {
								urlParameters: {
									$filter: "BCPIncident eq '" + n.IncidentId + "'"
								},
								success: function (oData) {
									try {
										n.result = oData.results[0].ResultDesc;
									} catch (error) {}
									var oResultModel = new JSONModel();
									this.setCardProperty("/data", list.results);
									this.setCardProperty("/customHeader/additionalCardTitle", " (" + list.results.length + ")");
									this.setCardSuccessState();
									this.getCardModel().refresh(true);
								}.bind(this),
								error: function (oError) {}.bind(this)
							});
						});
					} else {
						this.setCardNoDataState();
					}

					//	this.getView().getModel("Information").refresh(true);
				}.bind(this));
			},

			/*onTriggerNotification: function (sChannel, oEvent, oData) {
				MessageToast.show("Threshold exceeded: There are more then 5 Activities in the BCP Worklist");
			},*/

			// returns a date in form days and hours
			// param(information) date in string format
			getDays: function (information) {
				if (information) {
					// get total seconds between the times
					var delta = Math.abs(new Date() - (information)) / 1000;

					// calculate (and subtract) whole days
					var days = Math.floor(delta / 86400);
					delta -= days * 86400;

					// calculate (and subtract) whole hours
					var hours = Math.floor(delta / 3600) % 24;
					delta -= hours * 3600;

					// calculate (and subtract) whole minutes
					var minutes = Math.floor(delta / 60) % 60;
					delta -= minutes * 60;

					// what's left is seconds
					var seconds = delta % 60;
					var text = days + "d " + hours + "h " + minutes + "m";
					if ((days === 0) && hours === 0) {
						return minutes + "m";
					}
					return text;

				}
			},

			bubbleSort: function (oResult) {
				var n = oResult.results.length;
				for (var i = 0; i < n - 1; i++) {
					for (var j = 0; j < n - i - 1; j++) {
						if ((oResult.results[j].EsclTimestamp) > (oResult.results[j + 1].EsclTimestamp)) {
							var temp = oResult.results[j];
							oResult.results[j] = oResult.results[j + 1];
							oResult.results[j + 1] = temp;
						}
					}
				}
				return oResult;
			},
			formatQdJudgement: function (sStatus) {
				switch (sStatus) {
				case "1":
					return "HandOver to Q&D Lead";
				case "2":
					return "Business Down";
				case "3":
					return "PE Critical";
				case "4":
					return "Go-Live Endangered";
				case "5":
					return "Not relevant for MCC";
				default:
					return "";
				}
			},

			//On selecting an activity in the table, navigate to the activity link in the CRM
			onSelectionChange: function (oEvent) {
				var sPath = oEvent.getParameters().rowBindingContext.sPath;
				var incidentId = this.getModel("cardModel").getProperty(sPath).IncidentId;

				this.navToApp(
					this.getResourceBundle().getText("qdAssistantWorklistDMTest", [incidentId]),
					this.getResourceBundle().getText("qdAssistantWorklistDM", [incidentId]), {}, false);
			},

			onCustomerPressed: function (oEvent) {
				var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
				var sCustomerId = this.getModel("cardModel").getProperty(sBindingContextPath).ErpCustNo;

				this.navToApp(
					this.getResourceBundle().getText("mccOneDashboardTest", [sCustomerId]),
					this.getResourceBundle().getText("mccOneDashboardProd", [sCustomerId]), {}, false);

			}
		});
});