sap.ui.define([
	"jquery.sap.global",
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (jQuery, BaseCardController, Filter, FilterOperator) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.QDWorkloadMonitor.QDWorkloadMonitor", {
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			//	this.onUpdateCard();

			/* YOUR CODE HERE */
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			var oVariantPromise = this._loadVariants();

			// ###################################################################################################
			// ##		Filter Logic used from QD Backoffice Assistant Application								##
			// ##		see https://github.wdf.sap.corp/mcc/mcs-ui5-backoffice-assistant						##
			// ##		Files: webapp>model>connectors>TicketConnector --> function: getAllTicketsFiltered		##
			// ##																								##
			// ##																								##
			// ##		1. Get Variants to get the predefined filter values										##
			// ##		2. Get Critical Incidents (SC2 CRITC SIT Dashboard SRV)									##
			// ##		3. Apply local filters (filter values save in Variants) to get Customer Ticket Types	##
			// ##																								##
			// ###################################################################################################

			//get all Variant to count the differnt customer ticket types
			oVariantPromise.then(function (aVariant) {

				// get alls incidents
				var oPromise = this._loadIncidents();
				oPromise.then(function (aIncidents) {
					aVariant.forEach(function (oVariant) {

						var oObject = JSON.parse(oVariant.FilterValues);
						if (!oObject.JudgingFilter) {
							oObject.JudgingFilter = "Judging eq All";
						}
						if (!oObject.CategoryFilter) {
							oObject.CategoryFilter = "Category eq All";
						}
						if (!oObject.SourceFilter) {
							oObject.SourceFilter = "Source eq All";
						}
						if (!oObject.StatusFilter) {
							oObject.StatusFilter = "Status eq All";
						}
						//debugger; //StatusFilter, SourceFilter
						var iCount = this._filterTickets(JSON.parse(JSON.stringify(aIncidents)), oObject.JudgingFilter, oObject.CategoryFilter,
							oObject.StatusFilter, oObject.SourceFilter); // JudgingFilter, CategoryFilter, StatusFilter, SourceFilter

						//'Non-Premium Engagement incidents'
						if (oVariant.variantId === "SV1599488559280") {
							this.setCardProperty("/nonPE", iCount);
						}
						//'Q&D Lead'
						if (oVariant.variantId === "SV1598359604494") {
							this.setCardProperty("/QDTL", iCount);
						}
						//'Premium Engagement incidents'
						if (oVariant.variantId === "SV1599488725394") {
							this.setCardProperty("/PE", iCount);
						}

					}.bind(this));

					this.setCardSuccessState();
				}.bind(this)).catch(function (oError) {
					this.setCardErrorState();
				}.bind(this));
			}.bind(this)).catch(function (oError) {
				this.setCardErrorState();
			}.bind(this));
		},

		openQDAssistant: function (id) {
			var oRessourceBundle = this.getResourceBundle();
			var sTestUrl, sProdUrl;
			if (id === "NON-PE") {
				sTestUrl = oRessourceBundle.getText("nonPEWorkloadTest");
				sProdUrl = oRessourceBundle.getText("nonPEWorkload");

			} else if (id === "PE") {
				sTestUrl = oRessourceBundle.getText("PEWorkloadTest");
				sProdUrl = oRessourceBundle.getText("PEWorkload");
			} else if (id === "QD") {
				sTestUrl = oRessourceBundle.getText("qdLeadWorkloadTest");
				sProdUrl = oRessourceBundle.getText("qdLeadWorkload");
			}
			if (sTestUrl && sProdUrl) {
				var sHostname = window.location.hostname;

				// SAP IT Cloud T - https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites
				if (sHostname.lastIndexOf("sapitcloudt") > -1 || sHostname.lastIndexOf("a44f228ad") > -1) {
					window.open(sTestUrl);
				} else if (sHostname === "fiorilaunchpad.sap.com" || sHostname.lastIndexOf("a87daa223") > -1) {
					window.open(sProdUrl);
				}

			}
		},

		//load variants from HANA Database
		//3 global Variants are specified to differentiate customer tickets for (PE, non-PE, QD Lead)
		//each variants stores different filter values to determine the ticket category
		_loadVariants: function () {
			var oP1CModel = this.getModel("MCSHanaP1cTool");

			var oFilter = new Filter({
				filters: [
					new Filter("variantId", FilterOperator.EQ, "SV1599488559280"),
					new Filter("variantId", FilterOperator.EQ, "SV1598359604494"),
					new Filter("variantId", FilterOperator.EQ, "SV1599488725394")
				],
				bAnd: false
			});

			return new Promise(function (resolve, reject) {
				oP1CModel.read("/Variants", {
					filters: [oFilter],
					success: function (oData) {
						resolve(oData.results);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			});
		},

		//Get all Cusotmer Tickets 
		_loadIncidents: function () {
			var bcpModel = this.getModel("sc2critsitdashboardsrv");
			var oAllFilter = new sap.ui.model.Filter([
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0001"), //new
					new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0002"), //In Process
					new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0006"), //Sent to Partner
					new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0007"), //Partner Customer Act
					new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0004"), //Customer Action
					new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0005"), //Solution Provided
					new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0015"), //Pending Development
					new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0016"), //Pending Operations
					new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0017"), //Pending Partner ???
					new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0018"), //Pending Release
					new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0019"), //Sent to Operations
					new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0020"), //Sent to ServiceNow
					new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0003") //On Hold ???
				], false),
				new sap.ui.model.Filter([
					new sap.ui.model.Filter("MccStatus", sap.ui.model.FilterOperator.EQ, "1"), //New
					new sap.ui.model.Filter("MccStatus", sap.ui.model.FilterOperator.EQ, "2") //InProccess
				], false),
				new sap.ui.model.Filter("Priority", sap.ui.model.FilterOperator.EQ, "1")
			], true);

			return new Promise(function (resolve, reject) {
				bcpModel.read("/Critical_IncidentsSet", {
					filters: [oAllFilter],
					success: function (oData) {
						resolve(oData.results);
						//	debugger;
					}.bind(this),
					error: function (oError) {
						reject(oError);
					}

				});
			});
		},

		// ###################################################################################################
		// ##		Filter Logic used from QD Backoffice Assistant Application								##
		// ##		see https://github.wdf.sap.corp/mcc/mcs-ui5-backoffice-assistant						##
		// ##		Files: webapp>model>connectors>TicketConnector --> function: getAllTicketsFiltered		##
		// ###################################################################################################
		_filterTickets: function (aTickets, JudgingFilter, CategoryFilter, StatusFilter, SourceFilter) {

			var oTickets = {};
			var i, index;
			if (CategoryFilter.includes("eq All")) {
				for (var k = aTickets.length - 1; k >= 0; k--) {
					if (this._isOver10Minutes(aTickets[k])) {
						oTickets[aTickets[k].IncidentId] = aTickets[k];
					} else {
						aTickets.splice(k, 1);
					}
				}
			} else {
				if (CategoryFilter.includes("eq NON-PE")) {
					for (i = aTickets.length - 1; i >= 0; i--) {
						if (this._isRelevantForP1C(aTickets[i]) && this._isOver10Minutes(aTickets[i])) {
							oTickets[aTickets[i].IncidentId] = aTickets[i];
						} else {
							aTickets.splice(i, 1);
						}
					}
				}
				if (CategoryFilter.includes("eq PE")) {
					for (var j = aTickets.length - 1; j >= 0; j--) {
						if (!this._isRelevantForP1C(aTickets[j]) && this._isOver10Minutes(aTickets[j])) {
							oTickets[aTickets[j].IncidentId] = aTickets[j];
						} else {
							aTickets.splice(j, 1);
						}
					}
				}
			}
			var aFilter = [];
			var sFilter;
			if (!(JudgingFilter.includes('eq All') && StatusFilter.includes('eq All') && SourceFilter.includes('eq All'))) {

				for (i = Object.keys(oTickets).length - 1; i >= 0; i--) {
					aFilter = [];
					sFilter = "";
					index = Object.keys(oTickets)[i];

					if (!JudgingFilter.includes('eq All')) {
						if (!JudgingFilter.includes('eq To be judged')) {
							sFilter = oTickets[index].QdJudgement === '' || oTickets[index].QdJudgement === null || oTickets[index].QdJudgement ===
								undefined;
							aFilter.push(sFilter);
						}
						if (!JudgingFilter.includes('eq HandOver to Q&D Lead')) {
							sFilter = oTickets[index].QdJudgement === '1' && oTickets[index].MccStatus === '2';
							aFilter.push(sFilter);
						}
						if (!JudgingFilter.includes('eq Business Down')) {
							sFilter = oTickets[index].QdJudgement === '2';
							aFilter.push(sFilter);
						}
						if (!JudgingFilter.includes('eq PE Critical')) {
							sFilter = oTickets[index].QdJudgement === '3';
							aFilter.push(sFilter);
						}
						if (!JudgingFilter.includes('eq Go-Live Endangered')) {
							sFilter = oTickets[index].QdJudgement === '4';
							aFilter.push(sFilter);
						}
						if (!JudgingFilter.includes('eq Not relevant for MCC')) {
							sFilter = oTickets[index].QdJudgement === '5';
							aFilter.push(sFilter);
						}
						if (!JudgingFilter.includes('eq HandOver to CCT')) {
							sFilter = oTickets[index].QdJudgement === '1' && oTickets[index].MccStatus === '1';
							aFilter.push(sFilter);
						}

					}
					if (!StatusFilter.includes('eq All')) {
						if (!StatusFilter.includes('eq New')) {
							sFilter = oTickets[index].MccStatus === '1';
							aFilter.push(sFilter);
						}
						if (!StatusFilter.includes('eq In Process')) {
							sFilter = oTickets[index].MccStatus === '2';
							aFilter.push(sFilter);
						}
					}

					if (!SourceFilter.includes('eq All')) {
						if (SourceFilter.includes('eq Filtered for NON-PE')) {
							var sFilterByD = oTickets[index].Source === '019';
							var sFilterSPC_PT = oTickets[index].Source === '020';
							var sFilterJIRATask = oTickets[index].Source === '013';
							var sFilterHealthCheck = oTickets[index].Source === '022';
							aFilter.push(sFilterByD);
							aFilter.push(sFilterSPC_PT);
							aFilter.push(sFilterJIRATask);
							aFilter.push(sFilterHealthCheck);
						}
					}

					aFilter = aFilter.filter(function (bFilter) {
						return bFilter === true;
					});

					if (aFilter.length > 0) {
						delete oTickets[index];
					}
				}

			}
			return Object.keys(oTickets).length;
		},

		_isOver10Minutes: function (oResult) {
			try {
				var CreatedAt = new Date(oResult.CreatedAt);

				var diff = (new Date().getTime() - CreatedAt.getTime()) / 1000;
				diff /= 60;
				diff = Math.abs(Math.round(diff));
				if (diff > 10) {
					return true;
				} else {
					return false;
				}
			} catch (err){
				return false;
			}
		},

		_isRelevantForP1C: function (oResult) {
			var sSuppDelivModel = oResult.SuppDelivModel;
			return !(sSuppDelivModel.includes("MA") || sSuppDelivModel.includes("MA4") || sSuppDelivModel.includes("AE"));
		}

	});
});