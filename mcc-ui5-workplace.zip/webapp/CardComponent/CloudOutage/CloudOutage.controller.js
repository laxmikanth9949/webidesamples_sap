sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/FilterType"
], function (BaseCardController, JSONModel, MessageToast, Filter, FilterOperator, FilterType) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.CloudOutage.CloudOutage", {

		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			this.onUpdateCard();
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			var oModel = this.getView().getModel("agsDashboardService");
			var fTableFilter = new Filter({
				filters: [
					new Filter("activity_activity_partner", FilterOperator.EQ, "19467420"),
					new Filter("activity_priority", FilterOperator.EQ, "1"),
					new Filter({
						filters: [
							new Filter("activity_status", FilterOperator.EQ, "E0010"),
							new Filter("activity_status", FilterOperator.EQ, "E0011")
						],
						and: false
					})
				],
				and: true
			});
			
			oModel.read("/ActivityList", {
				filters: [fTableFilter],
				success: function (oData) {
					this.setCardProperty("/data", oData.results);
					this.setCardSuccessState();
				}.bind(this),
				error: function (oError) {
					this.setCardErrorState();
				}.bind(this)
			});
		},

		onSelectionChange: function (oEvent) {
			var sPath = oEvent.getParameters().rowBindingContext.sPath;
			var activityId = this.getModel("Information").getProperty(sPath).activity_id;

			var currentUrl = window.location.href;
			var relativeUrl =
				"/sap(bD1lbiZjPTAwMSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?saprole=ZSU_DEFAULT&crm-object-type=BT126_APPT&crm-object-action=B&crm-object-keyname=OBJECT_ID&crm-object-value=" +
				activityId;
			var urlICP = this.getView().getModel("i18n").getResourceBundle().getText("urlICPSAP");
			var urlICT = this.getView().getModel("i18n").getResourceBundle().getText("urlICTSAP");
			var url = urlICP + relativeUrl;
			if (currentUrl.includes("a44f228ad.dispatcher.hana.ondemand.com")) {
				//we are in test envrionment
				url = urlICT + relativeUrl;
			}
			var win = window.open(url, "_blank");
			win.focus();
		},

		getDays: function (date, time) {
			//respect date and time 
			//create a new date object
			if(date && time){
			var myDate = new Date(date);
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyy-MM-dd"
			});
			var sDateTmp = dateFormat.format(myDate);
			var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern: "HH:mm:ss",
				UTC: true
			});
			var TZOffsetMs = myDate.getTimezoneOffset() * 60 * 1000;
			var timeStr = timeFormat.format(new Date(time.ms - TZOffsetMs));
			var sDate = sDateTmp + "T" + timeStr;
			var oDateTime = new Date(sDate);

			// get total seconds between the times
			var delta = Math.abs(new Date() - (oDateTime)) / 1000;

			// calculate (and subtract) whole days
			var days = Math.floor(delta / 86400);
			delta -= days * 86400;

			// calculate (and subtract) whole hours
			var hours = Math.floor(delta / 3600) % 24;
			delta -= hours * 3600;

			// calculate (and subtract) whole minutes
			var minutes = Math.floor(delta / 60) % 60;
			delta -= minutes * 60;

			// what's left is seconds
			var seconds = delta % 60;
			var text = days + " d " + hours + " h ";
			if ((days === 0) && hours === 0) {
				return "< 1 hour";
			}
			return text;
			} else{
				return  "";
			}
		}
	});
});