sap.ui.define([
	"jquery.sap.global",
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"com/sap/mcc/workplace/CardComponent/CardFormatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (jQuery, BaseCardController, JSONModel, CardFormatter, Filter, FilterOperator) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.Roadmap.Roadmap", {

		CardFormatter: CardFormatter,

		/**
		 * Called when the card controller is instantiated. It sets up the event handling for the card communication and other lifecycle tasks.
		 * @public
		 */
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			sap.ui.getCore().getEventBus().subscribe("FilterBar", "dataLoaded", this.onUpdateCard, this);
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "search", this._handleBusyIndicator, this);

			//trigger inital loading of data
			this.onUpdateCard();
		},

		/**
		 * Method triggered by Eventbus, filterbar (workplaceController) fires the event
		 * If at least one case exist, load and display the related roadmap results
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			// get Cases from FilterBar
			var aFilterArray = this.getFilterBarValues("Roadmap");
			var filterStatus = new Filter({
				filters: [new Filter("StatusID", FilterOperator.EQ, "20"), new Filter("StatusID", FilterOperator.EQ, "30")],
				and: false
			});
			var filterType = new Filter("CaseType", FilterOperator.EQ, "ZS01");

			aFilterArray.push(filterStatus);
			aFilterArray.push(filterType);

			this.loadCasesAppDepSrv(aFilterArray, {
				$expand: "toCheckPoint" // required for Roadmap Card
			}).then(function (aCases) {
				if (aCases && aCases.length > 0) {
					var aDuplicatesRemoved = [];
					this.setCardProperty("/cases", []);
					aCases.forEach(function (oCase) {
						if (aDuplicatesRemoved.findIndex(x => x.CaseID === oCase.CaseID) == -1) {
							aDuplicatesRemoved.push(oCase);
							if (aDuplicatesRemoved && aDuplicatesRemoved.length > 0) {
								this._getCaseDetails(aDuplicatesRemoved);
							}
						}
					}.bind(this));

					

				} else {
					this._handleBusyIndicator("", "", {
						status: false
					});
					this.getCardProperty("/cases", []);

					this.setCardNoDataState();
				}
			}.bind(this));

		},

		_handleBusyIndicator: function (sChannel, sEventId, oData) {
			if (sChannel === 'FilterBar' && sEventId === 'search') {
				if (oData.status === "started") {
					this.setCardProperty("/busy", true);
				} else {
					this.setCardProperty("/busy", false);
				}
			} else {
				this.setCardProperty("/busy", oData.status);
			}
		},

		/*
		 * Get all Case Details with roadmap information
		 */
		_getCaseDetails: function (aCases) {
			var aPromises = [];
			if (aCases && aCases.length) {
				aCases.forEach(function (oCase) {
					var oCasePromise = this._createRoadmapPromise(oCase);
					aPromises.push(oCasePromise);
				}.bind(this));

				Promise.all(aPromises).then(function (oData) {
						// oData = this.sortArrayOfObjects(oData, "CustomerName");
						this.setCardProperty("/cases", oData);

						//disable loading indicator and error indicator
						if (oData.length === 0) {
							this.setCardNoDataState();
						} else {
							this.setCardSuccessState();
						}
					}.bind(this))
					.catch(function (oError) {
						// when any odata requests failed
						this.setCardErrorState();
					}.bind(this));
			}
		},

		/*
		 * create Promise for Roadmap.svc service for Roadmap information for specific case and prepare roadmap calculation for each phase
		 */
		_createRoadmapPromise: function (oCase) {
			if (oCase && oCase.CaseID && oCase.ServiceOrg) {
				var oRoadmapPromise = new Promise(function (resolve, reject) {
					this.getModel("roadmapService").read("/getRoadMapInfo", {
						urlParameters: {
							id: "'" + oCase.CaseID + "'",
							region: "'" + oCase.ServiceOrg + "'"
						},
						success: function (oData) {

							var sScenario;
							//distinguish if phase needs to be respected (based on scenario level)

							//first step: derive scenario type from Case property "EscalScenarioText"
							if (oCase.EscalScenarioText.indexOf("Scenario 1") !== -1) {
								sScenario = "1";
							} else if (oCase.EscalScenarioText.indexOf("Scenario 2") !== -1) {
								sScenario = "2";
							} else if (oCase.EscalScenarioText.indexOf("Scenario 3") !== -1) {
								sScenario = "3";
							}

							//2nd step: filter each phase elements based on scenario 
							//therefore compare the scenario type of the case with the scenario of each step of each phase
							var oPhases = JSON.parse(oData.getRoadMapInfo);
							oPhases.phases.forEach(function (oPhase, iIndex, arr) {
								arr[iIndex].elements = oPhase.elements.filter(function (oElement) {
									return oElement.scenario.indexOf(sScenario) !== -1;
								});
							}.bind(this));

							oCase.Roadmap = oPhases; //JSON.parse(oData.getRoadMapInfo);
							resolve(oCase);
						},
						error: function (oError) {
							// Catch by CardErrorHandler.js
							reject(oError);
						}
					});
				}.bind(this));

				oRoadmapPromise.then(function (oCaseObject) {
						// Process data to fit Roadmap To-do
						var aCasesWithRoadmap = this.getCardProperty("/cases") ? this.getCardProperty("/cases") : [];
						var iProcessMandatoryTotal = 0;
						var iProcessDone = 0;
						var aVisibleSteps = [];

						// calculate % Done
						oCaseObject.Roadmap.phases.forEach(function (oPhase) {
							oPhase.elements.forEach(function (oElement) {
								// element of type checkpoint doesn't store state properly.
								// According to logic on https://github.wdf.sap.corp/mcc/mcs-ui5-emroadmap/blob/master/webapp/view/App.controller.js#L410
								// need to loop on all /toCheckPoint and check if oElement.type === "C" oElement.targetLink === checkpoint.Name and checkpoint.Status = "C" - completed
								oCaseObject.toCheckPoint.results.forEach(function (oCheckpoint) {
									// same implementation as https://github.wdf.sap.corp/mcc/mcs-ui5-emroadmap/blob/master/webapp/view/App.controller.js#L410
									if (oElement.type === "C" && oCheckpoint.Name === oElement.targetLink && oCheckpoint.Status === "C") {
										oElement.state = "D";
									}
								}.bind(oElement));

								// for all mandatory list elements from which the status is editable increase iProcessMandatoryTotal
								if ((oElement.mandatory === "M" || oElement.mandatory === "MO") && oElement.statusEditable === "Y") {
									iProcessMandatoryTotal++;
									oElement.phaseName = oPhase.phaseName;
									// for all mandatory list elements from which the status is editable AND which are Done, increase iProcessDone
									if (oElement.state === "D") {
										iProcessDone++;
									} else {
										aVisibleSteps.push(oElement);
									}
								}
							}.bind(oCaseObject));
						});

						oCaseObject.Roadmap.Steps = aVisibleSteps;
						oCaseObject.Roadmap.Progress = (iProcessDone / iProcessMandatoryTotal * 100).toFixed(2);

						aCasesWithRoadmap.push(oCaseObject);
						return aCasesWithRoadmap;
						// }.bind(this)).catch(function (err) {
						// 	//this._handleBusyIndicator
					}.bind(this))
					.catch(function (oError) {
						return oError;
					});

				return oRoadmapPromise;
			}
			return null;
		},

		onItemPress: function (oEvent) {
			this.navToApp(
				this.getResourceBundle().getText("emroadmapTest", [oEvent.getSource().data("caseID")]),
				this.getResourceBundle().getText("emroadmapProd", [oEvent.getSource().data("caseID")]), {}, false);
		}
	});
});