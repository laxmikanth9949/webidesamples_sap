sap.ui.define([
	"jquery.sap.global",
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (jQuery, BaseCardController, JSONModel, Filter, FilterOperator) {
	"use strict";

	var oController = BaseCardController.extend("com.sap.mcc.workplace.CardComponent.OpenCases.OpenCases", {
		// set the root path of the folder and load the image from the correct path
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			//register AttachChange event for binding change to update the card title when for example a column filter is applied		
			this.getView().byId("tableOpenCases").getBinding("rows").attachChange(this.updateCardTitle.bind(this, "options"));

			/**
			 * Eventbus subscriptions: Events are fired by the workplace controller
			 * dataLoaded --> workplace model stores profile specific data --> card can be updated
			 * search --> new filter query were triggered --> card is notified to update itself when the dataLoaded event is received. 
			 *			  until then the busyindicator should be visible at the ui.
			 */
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "dataLoaded", this.onUpdateCard, this);
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "search", this._handleBusyIndicator, this);

			this.onUpdateCard();
			
			//set busy state to true
			this._handleBusyIndicator("", "", {
				status: true
			});
			
		},

		/**
		 * Method triggered by Eventbus, filterbar (workplaceController) fires the event
		 * If at least one case exist, load and display the related casechecker results
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified

			this.setCardUpdateStartState();
			var aFilterArray = this.getFilterBarValues("OpenCases");
			var filterStatus = new Filter({
				filters: [new Filter("StatusID", FilterOperator.EQ, "20"), new Filter("StatusID", FilterOperator.EQ, "30")],
				and: false
			});
			var oProcessTypeFilter = new Filter({
				filters: [
					new Filter("ProcessTypeId", FilterOperator.EQ, "ZSPRCTYP01"),
					new Filter("ProcessTypeId", FilterOperator.EQ, "ZSPRCTYP06")
				],
				and: false
			});
			var filterType = new Filter("CaseType", FilterOperator.EQ, "ZS01");

			aFilterArray.push(oProcessTypeFilter);
			aFilterArray.push(filterStatus);
			aFilterArray.push(filterType);
			
			this.loadCasesAppDepSrv(aFilterArray, {}).then(function (aCases) {
				this.setCardProperty("/options", this.getCaseRegion(aCases));
				if (aCases && aCases.length > 0) {
					//	this._getCaseCheckerDetails(aCases); 
					this.getCQIScore("options", "mcs-gem-global-manager").then(function (oData) {
						this.setCardSuccessState();
						this.getCardModel().refresh(true);
					}.bind(this)).catch(function(){
						this.setCardSuccessState();
					}.bind(this));
				} else {
					this._handleBusyIndicator("", "", {
						status: false
					});
					this.setCardProperty("/options", []);
					this.getCardModel().refresh(true);
					this.setCardSuccessState();
				}
			}.bind(this));
		},

		formatState: function (sValue) {
			if (sValue) {
				if (sValue >= 75) {
					return 'Success';
				} else if (sValue >= 50) {
					return 'Warning';
				}
				return 'Error';
			}
		},

		onLinkPress: function (oEvent) {
			this.navToApp(
				this.getResourceBundle().getText("CaseSearchTest", [oEvent.getSource().getText()]),
				this.getResourceBundle().getText("CaseSearch", [oEvent.getSource().getText()]), {}, false);
		},

		/*_getCaseCheckerDetails: function (aCases) {
			var aPromises = [];
			for (var i = 0; i < aCases.length; i++) {
				var CasecheckerPromise = this._readCaseCheckerDetails(aCases[i].CaseID, aCases[i].CustomerName);
				aPromises.push(CasecheckerPromise);

			}

			Promise.all(aPromises).then(function (oData) {
					this.setCardProperty("/customHeader/additionalCardTitle", " (" + oData.length + ")");
					this.setCardSuccessState();
				}.bind(this))
				.catch(function (oError) {
					// when any odata requests failed
					this.setCardErrorState();
				}.bind(this));
		},

		_readCaseCheckerDetails: function (sCaseId, sCsutomername) {
			return this.startMccWorkplaceAjaxRequest({
				url: "/executeRuleCheck?profile=mcs-gem&object=CaseSet(CaseID=%27" + sCaseId +
					"%27,CaseType=%27ZS01%27,CaseObject=%27C%27)&expand=toNote,toCheckPoint,toTopIssue,toAffectedProduct,toActivity,toPartiesInvolved"
			}).then(function (oData) {
				var aData = this.getCardProperty("/options") ? this.getCardProperty("/options") : [];

				var oObject = this.findObjectByKey(aData, "CaseID", sCaseId);
				oObject.CQI = oData.OverallCQI;
				if (oData.Data && oData.Data.length > 0) {
					oObject.Rules = oData.Data[0].Rules.filter((item) => item.RuleResult !== "Success");

				}

			}.bind(this)).catch(function (err) {
				//this._handleBusyIndicator
			}.bind(this));
		},*/

		_handleBusyIndicator: function (sChannel, sEventId, oData) {
			var oCaseCheckerModel = this.getCardModel();
			if (sChannel === 'FilterBar' && sEventId === 'search') {
				if (oData.status === "started") {
					oCaseCheckerModel.setProperty("/busy", true);
				} else {
					oCaseCheckerModel.setProperty("/busy", false);
				}
			} else {
				oCaseCheckerModel.setProperty("/busy", oData.status);
			}
		},

		onCustomerPressed: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCustomerId = this.getCardProperty(sBindingContextPath).CustomerR3No;

			this.navToApp(
				this.getResourceBundle().getText("mccOneDashboardTest", [sCustomerId]),
				this.getResourceBundle().getText("mccOneDashboardProd", [sCustomerId]), {}, false);

		}
	});
	return oController;
});