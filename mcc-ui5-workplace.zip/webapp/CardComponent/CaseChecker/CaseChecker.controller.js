sap.ui.define([
	"jquery.sap.global",
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (jQuery, BaseCardController, JSONModel, Filter, FilterOperator) {
	"use strict";

	var oController = BaseCardController.extend("com.sap.mcc.workplace.CardComponent.CaseChecker.CaseChecker", {
		// set the root path of the folder and load the image from the correct path
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			/**
			 * Eventbus subscriptions: Events are fired by the workplace controller
			 * dataLoaded --> workplace model stores profile specific data --> card can be updated
			 * search --> new filter query were triggered --> card is notified to update itself when the dataLoaded event is received. 
			 *			  until then the busyindicator should be visible at the ui.
			 */
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "dataLoaded", this.onUpdateCard, this);
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "search", this._handleBusyIndicator, this);

			//set busy state to true
			this._handleBusyIndicator("", "", {
				status: true
			});

			//trigger inital loading of casechecker data
			this.onUpdateCard();
		},

		/**
		 * Method triggered by Eventbus, filterbar (workplaceController) fires the event
		 * If at least one case exist, load and display the related casechecker results
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			this.setCardProperty("/options", []);

			//get Cases for casechecker card
			var aFilterArray = this.getFilterBarValues("CaseChecker");
			if (!aFilterArray.length) {
				var oDefaultFilter = new Filter("MyCase", FilterOperator.EQ, "X");
				aFilterArray.push(oDefaultFilter);
			}
			var filterStatus = new Filter({
				filters: [new Filter("StatusID", FilterOperator.EQ, "20"), new Filter("StatusID", FilterOperator.EQ, "30")],
				and: false
			});
			var filterType = new Filter("CaseType", FilterOperator.EQ, "ZS01");

			aFilterArray.push(filterStatus);
			aFilterArray.push(filterType);

			this.loadCasesAppDepSrv(aFilterArray, {}).then(function (aReturnArray) {
				if (aReturnArray && aReturnArray.length > 0) {
					aReturnArray = this._removeObjectDuplicatesInArray(aReturnArray);
					this.setCardProperty("/options", aReturnArray);
					this._getCaseCheckerDetails(aReturnArray);

				} else {
					this._handleBusyIndicator("", "", {
						status: false
					});
					this.setCardProperty("/options", []);
					this.getCardModel().refresh(true);

					this.setCardNoDataState();
				}
			}.bind(this));

		},

		onAfterRendering: function () {
			/*var sSelectedItemText = this.getView().byId("typeSelect").getSelectedItem().getText();
			this._setPlaceholderForInputQuery(sSelectedItemText);*/
		},

		formatState: function (sValue) {
			if (sValue) {
				if (sValue >= 75) {
					return 'Success';
				} else if (sValue >= 50) {
					return 'Warning';
				}
				return 'Error';
			}
		},

		onTitlePress: function (oEvent) {
			this.navToApp(
				this.getResourceBundle().getText("caseckeckerTest"),
				this.getResourceBundle().getText("casecheckerProd"), {}, false);
		},

		_getCaseCheckerDetails: function (aCases) {
			var aPromises = [];
			for (var i = 0; i < aCases.length; i++) {
				var CasecheckerPromise = this._readCaseCheckerDetails(aCases[i].CaseID, aCases[i].CustomerName);
				aPromises.push(CasecheckerPromise);

			}

			Promise.all(aPromises).then(function (oData) {
					//disable loading indicator and error indicator
					if (oData.length === 0) {
						this.setCardNoDataState();
					} else {
						this.setCardSuccessState();
					}
				}.bind(this))
				.catch(function (oError) {
					// when any odata requests failed set card to to success state. it still displays the base
					this.setCardSuccessState();
				}.bind(this));
		},

		_readCaseCheckerDetails: function (sCaseId, sCsutomername) {
			return this.startMccWorkplaceAjaxRequest({
				url: "/executeRuleCheck?profile=mcs-gem&object=CaseSet(CaseID=%27" + sCaseId +
					"%27,CaseType=%27ZS01%27,CaseObject=%27C%27)&expand=toNote,toCheckPoint,toTopIssue,toAffectedProduct,toActivity,toPartiesInvolved"
			}).then(function (oData) {
				var aWarningRules = [];
				var aErrorRules = [];
				var aRules = [];
				if (oData.CaseCountError > 0 || oData.CaseCountWarning > 0) {
					var aAllRules = oData.Data[0].Rules;

					aAllRules.forEach(function (oRule) {
						if (oRule.RuleResult === "Warning") {
							aWarningRules.push(oRule);
						} else if (oRule.RuleResult === "Error") {
							aErrorRules.push(oRule);
						}
					});

					var compareIntegerValues = function compare(a, b) {
						if (a.RuleWeight < b.RuleWeight) {
							return -1;
						}
						if (a.RuleWeight > b.RuleWeight) {
							return 1;
						}
						return 0;
					};

					if (aWarningRules.length) {
						aWarningRules.sort(compareIntegerValues);
					}

					if (aErrorRules.length) {
						aErrorRules.sort(compareIntegerValues);
					}

					//reverse array: the higher the ruleweight the higher the priority --> reverse = descending
					aErrorRules.reverse();
					aWarningRules.reverse();

					for (var i = 0; i < aWarningRules.length; i++) {
						aRules.push(aWarningRules[i]);
					}

					for (var y = 0; y < aErrorRules.length; y++) {
						aRules.push(aErrorRules[y]);
					}

				}

				var aData = this.getCardProperty("/options") ? this.getCardProperty("/options") : [];
				var oObject = this.findObjectByKey(aData, "CaseID", sCaseId);
				
				if (oObject) {
					oObject.CQI = oData.OverallCQI;
					oObject.Rules = aRules;
				} else {
					var oNewObject = {
						"CaseID": sCaseId,
						"CustomerName": sCsutomername,
						"CQI": oData.OverallCQI,
						"Rules": aRules
					};

					aData.push(oNewObject);
					this.setCardProperty("/options", aData);
				}
				this.getCardModel().refresh(true);
			}.bind(this)).catch(function (err) {

			}.bind(this));
		},

		_handleBusyIndicator: function (sChannel, sEventId, oData) {
			if (sChannel === 'FilterBar' && sEventId === 'search') {
				if (oData.status === "started") {
					this.getCardModel().setProperty("/busy", true);
				} else {
					this.getCardModel().setProperty("/busy", false);
				}
			} else {
				this.getCardModel().setProperty("/busy", oData.status);
			}

			this.setCardProperty("/lastRefreshDateTime", new Date());

		}
	});
	return oController;
});