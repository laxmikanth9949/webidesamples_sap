sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseCardController, Filter, FilterOperator) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.QDStatistics.QDStatistics", {
		//Open MCS Dashboard when pressing on any of the statistics tiles
		press: function (oEvent) {
			var url = this.getView().getModel("i18n").getResourceBundle().getText("mcsDashboardURL");
			var win = window.open(url, "_blank");
			win.focus();
		},

		//Subscribe to the event bus for changes in the filter criteria, Initialize the view and make a call to the refresh method
		onInit: function (evt) {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

		},
	
		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			// this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count
			var oAppDepModel = this.getModel("appDepModel");

			var oFilterActivityType = new Filter("ActivityType", FilterOperator.EQ, "ZS31");
			var oFilterStatusID = new Filter({
				filters: [
					new Filter("StatusID", FilterOperator.EQ, "E0010"),
					new Filter("StatusID", FilterOperator.EQ, "E0011"),
				],
				and: false
			});
			var oPromise = new Promise(function (resolve, reject) {
				oAppDepModel.read("/ActivitySet", {
					filters: [oFilterActivityType, oFilterStatusID],
					success: function (oData) {
						resolve(oData.results);
					},
					error: function (oData) {
						reject(oError);
					}
				});
			}.bind(this));

			oPromise.then(function (aData) {

				var oCountObject = {
					Total: aData.length,
					APJ: 0,
					EMEA: 0,
					NA: 0,
					LA: 0,
					Unassigned: 0
				};
				for (var i = 0; i < aData.length; i++) {
					var sMainServiceTeam = aData[i].MainServiceTeam;
					if (sMainServiceTeam === "3612380") {
						oCountObject.APJ = oCountObject.APJ + 1;
					} else if (sMainServiceTeam === "3584574") {
						oCountObject.EMEA = oCountObject.EMEA + 1;
					} else if (sMainServiceTeam === "3612382") {
						oCountObject.NA = oCountObject.NA + 1;
					} else if (sMainServiceTeam === "9804549") {
						oCountObject.LA = oCountObject.LA + 1;
					} else {
						oCountObject.Unassigned = oCountObject.Unassigned + 1;
					}
				}
				debugger;
				this.setCardProperty("/data", oCountObject);
				/*	new sap.ui.model.Filter("activity_service_team", sap.ui.model.FilterOperator.NE, "0003612380"), //APJ
						new sap.ui.model.Filter("activity_service_team", sap.ui.model.FilterOperator.NE, "0003584574"), //EMEA
						new sap.ui.model.Filter("activity_service_team", sap.ui.model.FilterOperator.NE, "0003612382"), //NA
						new sap.ui.model.Filter("activity_service_team", sap.ui.model.FilterOperator.NE, "0009804549") //LA*/
				this.setCardSuccessState();
			}.bind(this)).catch(function (oError) {
				this.setCardErrorState();
			}.bind(this));

		},

	});
});