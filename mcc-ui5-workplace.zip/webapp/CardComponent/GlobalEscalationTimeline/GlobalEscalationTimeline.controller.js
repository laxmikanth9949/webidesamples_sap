sap.ui.define([
	"jquery.sap.global",
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"sap/viz/ui5/data/FlattenedDataset",
	"sap/viz/ui5/controls/common/feeds/FeedItem",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/viz/ui5/api/env/Format",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Text",
	"./InitPage1"
], function (jQuery, BaseCardController, JSONModel, FlattenedDataset, FeedItem, ChartFormatter, Format, Dialog, Button,
	Text,
	InitPageUtil) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.GlobalEscalationTimeline.GlobalEscalationTimeline", {
		_constants: {
			name: "Global Escalations Timeline",
			chartContainerId: "idChartContainer",
			vizFrame: {
				id: "idVizFrame",
				dataset: {
					dimensions: [{
						name: "Date",
						value: "{view1>Date}",
						dataType: "date"
					}],
					measures: [{
						name: "Global Escalations",
						value: "{view1>Global Escalations}"
					}],
					data: {
						path: "view1>/Data"
					}
				},
				type: "timeseries_line",
				feedItems: [{
					"uid": "valueAxis",
					"type": "Measure",
					"values": ["Global Escalations"]
				}, {
					"uid": "timeAxis",
					"type": "Dimension",
					"values": ["Date"]
				}],
				vizProperties: {
					plotArea: {
						window: {
							start: "firstDataPoint",
							end: "lastDataPoint"
						},
						dataLabel: {
							formatString: ChartFormatter.DefaultPattern.SHORTFLOAT_MFD2,
							visible: false
						}
					},
					valueAxis: {
						visible: true,
						label: {
							formatString: ChartFormatter.DefaultPattern.SHORTFLOAT
						},
						title: {
							visible: false
						}
					},
					timeAxis: {
						title: {
							visible: false
						},
						interval: {
							unit: ""
						}
					},
					title: {
						text: "Global Escalations Timeline",
						visible: true
					},
					interaction: {
						syncValueAxis: false
					}
				}
			}
		},

		oVizFrame: null,
		chartTypeSelect: null,
		chart: null,

		// Method responsible for initializing the view, getting the current value of the region, and setting the refresh interval
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "search", this.onUpdateCard, this);
			
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			var oCurrentDate = new Date();
			var oFirstDayOfTheYear = new Date(new Date().getFullYear(), 0, 1);
			this.populateView(oFirstDayOfTheYear, oCurrentDate);
		},

		// Method responsible for destroying the vizframe every time an update is done to the view, to avoid duplicate elements in the view
		_destroyVizFrame: function () {
			var vizFrame = this.oVizFrame = this.getView().byId(this._constants.vizFrame.id);
			vizFrame.destroyFeeds();
			vizFrame.destroyDataset();
		},

		// Method responsible for updating the view every time is changed is made
		_updateVizFrame: function (oData) {
			var vizFrame = this.oVizFrame = this.getView().byId(this._constants.vizFrame.id);
			var oVizFrame = this._constants.vizFrame;
			var oDataset = new FlattenedDataset(this._constants.vizFrame.dataset);
			var oModel = new JSONModel(oData);
			vizFrame.setDataset(oDataset);
			vizFrame.setModel(oModel, "view1");
			this._addFeedItems(vizFrame, oVizFrame.feedItems);
			vizFrame.setVizType(oVizFrame.type);
			vizFrame.setVizProperties(oVizFrame.vizProperties);
		},

		// Adds the passed feed items to the passed Viz Frame.
		// @param {sap.viz.ui5.controls.VizFrame} vizFrame Viz Frame to add feed items to
		// @param {Object[]} feedItems Feed items to add
		_addFeedItems: function (vizFrame, feedItems) {
			for (var i = 0; i < feedItems.length; i++) {
				vizFrame.addFeed(new FeedItem(feedItems[i]));
			}
		},

		//Method responsible for displaying the view given the filter parameters
		// param(finalRegion): current value of the region in global filter, param(date1): current start date,
		// param(date2) current value of end date
		populateView: function (date1, date2) {
			var regionFilter;
			var finalRegion = this.getCoreModel("workplaceModel").getProperty("/selectedProfileInstance/FilterValues/Region");
			
			if (finalRegion === "EMEA" || finalRegion === "APJ" || finalRegion === "NA" || finalRegion === "LA") {
				var region;
				switch (finalRegion) {
				case "EMEA":
					region = "O 50008010";
					break;
				case "APJ":
					region = "O 50008134";
					break;
				case "NA":
					region = "O 50008167";
					break;
				case "LA":
					region = "O 50008174";
					break;
				}
				regionFilter = new sap.ui.model.Filter("service_org", sap.ui.model.FilterOperator.EQ, region);
			}
			var that = this;
			var cy = new Date();
			var dc = new Date(new Date().getFullYear(), 0, 1);
			var lastDay = new Date(cy.getFullYear(), 11, 31);
			Format.numericFormatter(ChartFormatter.getInstance());
			var oFilter = [];
			var oFilter1 = [];
			var f1 = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP01");
			var f11 = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP06");
			var fOpen1 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "20");
			var fOpen2 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "30");
			var closed1 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "40");
			var fOpen = new sap.ui.model.Filter({
				filters: [fOpen1, fOpen2],
				and: false
			});
			var f12 = new sap.ui.model.Filter({
				filters: [f1, f11],
				and: false
			});
			var fCreatedDate = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
				that.printDate(date1), that.printDate(date2));
			var fClosedDate = new sap.ui.model.Filter("closing_time", sap.ui.model.FilterOperator.BT,
				that.printDate(date1), that.printDate(date2));
			var fClosed = new sap.ui.model.Filter({
				filters: [closed1, fClosedDate],
				and: true
			});
			var last = new sap.ui.model.Filter({
				filters: [fCreatedDate, fClosed],
				and: false
			});
			var all = new sap.ui.model.Filter({
				filters: [f12, fOpen],
				and: true
			});
			var all1 = new sap.ui.model.Filter({
				filters: [f12, fClosedDate],
				and: true
			});
			var countT;
			oFilter.push(all);
			oFilter1.push(all1);
			if (regionFilter) {
				oFilter.push(regionFilter);
				oFilter1.push(regionFilter);
			}
			var model = this.getModel("mcsDashboardService");
			model.read("/MCSDashboardSet/", {
				filters: oFilter1,
				success: function (oResult1) {
					var closedArr = oResult1.results;
					model.read("/MCSDashboardSet", {
						filters: oFilter,
						success: function (oResult) {
							var merged = oResult.results.concat(closedArr);
							var data = {
								"Data": []
							};
							var filterT;
							var filterR;
							var temporary = [];
							var temporary1 = [];
							var currentWeek = that.getWeekNumber(new Date())[1];
							var t1;
							if (date1.getFullYear() !== date2.getFullYear()) {
								var diff = date2.getFullYear() - date1.getFullYear();
								for (var i = that.getDay(date1); i <= 365; i++) {
									countT = 0;
									filterT = merged;
									filterR = filterT.filter(function (item) {
										temporary1 = that.getWeekNumber(that.createDate(item.create_time));
										var cond1 = (item.status === "20" || item.status === "30");
										var ts = date1;
										var testDate = new Date(ts.getFullYear(), 0, i + 1);
										var cond2 = that.createDate(item.create_time) <= testDate;
										var dt = date1;
										var date = new Date(dt.getFullYear(), 0, i);
										var condN = date < new Date();
										temporary = that.getWeekNumber(that.createDate(item.closing_time));
										var condition = that.getDateOfWeek(i, new Date().getFullYear()) <= that.createDate(item.closing_time);
										var cond3 = that.createDate(item.closing_time) >= date;
										var cond4 = that.createDate(item.closing_time) > that.createDate(that.printDate(date1));
										return ((cond1 && cond2 && condN) || (cond3 && cond4 && cond2));
									});
									countT = filterR.length;
									filterR = [];
									var dt = new Date();
									var date = new Date(date1.getFullYear(), 0, i);
									data.Data.push({
										"Global Escalations": countT,
										"Date": date
									});
								}
								if (diff > 1) {
									for (var k = 1; k < diff; k++) {
										var dDate = new Date(date1.getFullYear() + k, 0, 1);
										var endDate1 = new Date(date1.getFullYear() + k + 1, 0, 0);
										for (i = that.getDay(dDate); i <= 365; i++) {
											countT = 0;
											filterT = merged;
											filterR = filterT.filter(function (item) {
												temporary1 = that.getWeekNumber(that.createDate(item.create_time));
												var cond1 = (item.status === "20" || item.status === "30");
												var ts = dDate;
												var testDate = new Date(ts.getFullYear(), 0, i + 1);
												var cond2 = that.createDate(item.create_time) <= testDate;
												var dt = dDate;
												var date = new Date(dt.getFullYear(), 0, i);
												var condN = date < new Date();
												temporary = that.getWeekNumber(that.createDate(item.closing_time));
												var condition = that.getDateOfWeek(i, new Date().getFullYear()) <= that.createDate(item.closing_time);
												var cond3 = that.createDate(item.closing_time) >= date;
												var cond4 = that.createDate(item.closing_time) > that.createDate(that.printDate(dDate));
												return ((cond1 && cond2 && condN) || (cond3 && cond4 && cond2));
											});
											countT = filterR.length;
											filterR = [];
											var dt = new Date();
											date = new Date(dDate.getFullYear(), 0, i);
											data.Data.push({
												"Global Escalations": countT,
												"Date": date
											});
										}
									}
								}
								for (i = 1; i <= that.getDay(date2); i++) {
									countT = 0;
									filterT = merged;
									filterR = filterT.filter(function (item) {
										temporary1 = that.getWeekNumber(that.createDate(item.create_time));
										var cond1 = (item.status === "20" || item.status === "30");
										var ts = date2;
										var testDate = new Date(ts.getFullYear(), 0, i + 1);
										var cond2 = that.createDate(item.create_time) <= testDate;
										dt = date2;
										date = new Date(dt.getFullYear(), 0, i);
										var condN = date < new Date();
										temporary = that.getWeekNumber(that.createDate(item.closing_time));
										var condition = that.getDateOfWeek(i, new Date().getFullYear()) <= that.createDate(item.closing_time);
										var cond3 = that.createDate(item.closing_time) >= date;
										var cond4 = that.createDate(item.closing_time) > that.createDate(that.printDate(date1));
										return ((cond1 && cond2 && condN) || (cond3 && cond4 && cond2));
									});
									countT = filterR.length;
									filterR = [];
									var dt = new Date();
									date = new Date(date2.getFullYear(), 0, i);
									data.Data.push({
										"Global Escalations": countT,
										"Date": date
									});
								}
							} else {
								for (i = that.getDay(date1); i <= that.getDay(date2); i++) {
									countT = 0;
									filterT = merged;
									filterR = filterT.filter(function (item) {
										temporary1 = that.getWeekNumber(that.createDate(item.create_time));
										var cond1 = (item.status === "20" || item.status === "30");
										var ts = date2;
										var testDate = new Date(ts.getFullYear(), 0, i + 1);
										var cond2 = that.createDate(item.create_time) <= testDate;
										var dt = date2;
										var date = new Date(dt.getFullYear(), 0, i);
										var condN = date < new Date();
										temporary = that.getWeekNumber(that.createDate(item.closing_time));
										var condition = that.getDateOfWeek(i, new Date().getFullYear()) <= that.createDate(item.closing_time);
										var cond3 = that.createDate(item.closing_time) >= date;
										var cond4 = that.createDate(item.closing_time) > that.createDate(that.printDate(date1));
										return ((cond1 && cond2 && condN) || (cond3 && cond4 && cond2));
									});
									countT = filterR.length;
									filterR = [];
									var dt = new Date();
									var date = new Date(date1.getFullYear(), 0, i);
									data.Data.push({
										"Global Escalations": countT,
										"Date": date
									});
								}
							}
							that._destroyVizFrame();
							that._updateVizFrame(data);
							this.setCardSuccessState();
						}.bind(this),
						error: function (oError) {
							this.setCardErrorState();
						}.bind(this)
					});
				}.bind(this),
				error: function (oError) {
					this.setCardErrorState();
				}.bind(this)
			});
		},

		onAfterRendering: function () {
			this.chartTypeSelect = this.getView().byId("chart-mcs-escaTimeline");
		},

		getWeekNumber: function (d) {
			// Copy date so don't modify original
			d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
			// Set to nearest Thursday: current date + 4 - current day number
			// Make Sunday's day number 7
			d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
			// Get first day of year
			var yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
			// Calculate full weeks to nearest Thursday
			var weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
			// Return array of year and week number
			return [d.getUTCFullYear(), weekNo];
			//return weekNo;
		},

		//returns the date of the monday last week
		getPreviousMonday: function () {
			var date = new Date();
			var day = date.getDay();
			var prevMonday;
			if (date.getDay() === 0) {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate() - 6);
			} else {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate() - day - 6);
			}
			return prevMonday;
		},

		//returns the date of the monday this week
		getThisMonday: function () {
			var date = new Date();
			var day = date.getDay();
			var prevMonday;
			if (date.getDay() === 0) {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate());
			} else {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate() - day + 1);
			}
			return prevMonday;
		},
		padStr: function (i) {
			return (i < 10) ? "0" + i : "" + i;
		},

		//returns the date in string format
		//param(temp) date in date format
		printDate: function (temp) {
			//var temp = new Date();
			var temp1 = new Date(temp);
			var dateStr = this.padStr(temp.getFullYear()) +
				this.padStr(1 + temp.getMonth()) +
				this.padStr(temp.getDate()) +
				this.padStr(temp.getHours()) +
				this.padStr(temp.getMinutes()) +
				this.padStr(temp.getSeconds());
			return (dateStr);
		},

		//returns the date of a monday given week and year
		// param (w), param(y) week and year
		getDateOfWeek: function (w, y) {
			var date = new Date();
			var tdate = new Date(date.getFullYear(), 0, 1);
			var day = tdate.getDay();
			var d;
			switch (day) {
			case 0:
				d = (-5 + (w - 1) * 7);
				break;
			case 1:
				d = (1 + (w - 1) * 7);
				break;
			case 2:
				d = (0 + (w - 1) * 7);
				break;
			case 3:
				d = (-1 + (w - 1) * 7);
				break;
			case 4:
				d = (-2 + (w - 1) * 7);
				break;
			case 5:
				d = (-3 + (w - 1) * 7);
				break;
			case 6:
				d = (-4 + (w - 1) * 7);
				break;
			}
			// 1st of January + 7 days for each week
			return new Date(y, 0, d);
		},

		//returns a date in date format
		//param(temp) date in string format
		createDate: function (temp) {
			var year = temp.substring(0, 4);
			var month = temp.substring(4, 6);
			var day = temp.substring(6, 8);
			var hour = temp.substring(8, 10);
			var minute = temp.substring(10, 12);
			var seconds = temp.substring(12, 14);
			return new Date(year, month - 1, day, hour, minute, seconds);
		},

		onChartTypeChanged: function (oEvent) {
			var cy = new Date();
			var dc = new Date(new Date().getFullYear(), 0, 1);
			var lastDay = new Date(cy.getFullYear(), 11, 31);
			if (this.oVizFrame) {
				var selectedKey = this.chart = Number(oEvent.getSource().getSelectedKey());
				var bindValue = this.settingsModel.chartType.values[selectedKey];
				this.oVizFrame.destroyDataset();
				this.oVizFrame.destroyFeeds();
				this.oVizFrame.setVizType(bindValue.vizType);

				if (selectedKey === 1) {
					var that = this;
					var oVizFrame = this.getView().byId("idVizFrame");

					//var nModel = sap.ui.getCore().getComponent("__component1").getModel("ZS_DBS_MCS_DASHBOARD_SRV");
					var oFilter = [];
					var oFilter1 = [];
					var f1 = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP01");
					var f11 = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP06");
					var f2 = new sap.ui.model.Filter("service_org", sap.ui.model.FilterOperator.EQ, "O 50008010");
					var fRegion = new sap.ui.model.Filter("region", sap.ui.model.FilterOperator.EQ, "EMEA");
					var fOpen1 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "20");
					var fOpen2 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "30");
					this.printDate(this.getPreviousMonday());
					this.printDate(this.getThisMonday());
					var fClosedDate = new sap.ui.model.Filter("closing_time", sap.ui.model.FilterOperator.BT,
						this.printDate(this.getPreviousMonday()), this.printDate(this.getThisMonday()));
					var f12 = new sap.ui.model.Filter({
						filters: [f1, f11],
						and: false
					});
					var fOpen = new sap.ui.model.Filter({
						filters: [fOpen1, fOpen2],
						and: false
					});
					var all = new sap.ui.model.Filter({
						filters: [f12, f2, fOpen],
						and: true
					});
					var filter = new sap.ui.model.Filter({
						filters: [f12, f2, fClosedDate],
						and: true
					});
					var filter1 = new sap.ui.model.Filter({
						filters: [all, filter],
						and: true
					});
					oFilter.push(all);
					oFilter1.push(filter);
					var that = this;
					this.getModel("ZS_DBS_MCS_DASHBOARD_SRV").read("/MCSDashboardSet/", {
						filters: oFilter1,
						success: function (oResult1) {
							var closedArr = oResult1.results;
							var countT = 0;
							var countR = 0;
							var countG = 0;
							var countY = 0;
							var countTLW = 0;
							var countRLW = 0;
							var countGLW = 0;
							var countYLW = 0;
							var countN = 0;
							var oModel = new sap.ui.model.json.JSONModel();
							that.getModel().read("/MCSDashboardSet/", {
								filters: oFilter,
								success: function (oResult) {
									var merged = oResult.results.concat(closedArr);
									countT = oResult.results.length;
									var filterR = oResult.results;
									var filterG = oResult.results;
									var filterY = oResult.results;
									var filterN = oResult.results;
									filterR = filterR.filter(function (item) {
										return item.rating === "C";
									});
									filterG = filterG.filter(function (item) {
										return item.rating === "A";
									});
									filterY = filterY.filter(function (item) {
										return item.rating === "B";
									});
									countR = filterR.length;
									countG = filterG.length;
									countY = filterY.length;
									var filterLW = merged;
									filterLW = filterLW.filter(function (item) {
										return item.status_text === "Closed";
									});
									var filterLW2 = oResult.results;
									filterLW2 = filterLW2.filter(function (item) {
										return item.create_time < that.printDate(that.getThisMonday());
									});
									countTLW = filterLW.length + filterLW2.length;
									var filterLWR = filterLW.filter(function (item) {
										return item.rating === "C";
									});
									var filterLW2R = filterLW2.filter(function (item) {
										return item.rating === "C";
									});
									countRLW = filterLWR.length + filterLW2R.length;
									var filterLWY = filterLW.filter(function (item) {
										return item.rating === "B";
									});
									var filterLW2Y = filterLW2.filter(function (item) {
										return item.rating === "B";
									});
									countYLW = filterLWY.length + filterLW2Y.length;
									var filterLWG = filterLW.filter(function (item) {
										return item.rating === "A";
									});
									var filterLW2G = filterLW2.filter(function (item) {
										return item.rating === "A";
									});
									countGLW = filterLWG.length + filterLW2G.length;
									filterN = filterN.filter(function (item) {
										return item.create_time >= that.printDate(that.getThisMonday());
									});
									countN = filterN.length;
									var data = {
										"Data": [{
											"Category": "Total",
											"Value1": countT,
											"Value2": countTLW
										}, {
											"Category": "Red",
											"Value1": countR,
											"Value2": 0
										}, {
											"Category": "Yellow",
											"Value1": countY,
											"Value2": 0
										}, {
											"Category": "Green",
											"Value1": countG,
											"Value2": 0
										}, {
											"Category": "New",
											"Value1": countN,
											"Value2": "0"
										}]
									};
									oModel.setData(data);
									that.oVizFrame.setModel(oModel);
									var oDataset = new FlattenedDataset(bindValue.dataset);
									that.oVizFrame.setDataset(oDataset);
									var props = bindValue.vizProperties;
									if (selectedKey !== 8 && props.plotArea) {
										props.plotArea.dataPointStyle = null;
									}
									that.oVizFrame.setVizProperties(props);
									var feedValueAxis, feedValueAxis2, feedActualValues, feedTargetValues;
									feedValueAxis = new FeedItem({
										"uid": "valueAxis",
										"type": "Measure",
										"values": ["This Week", "Last Week"]
									});
									var feedTimeAxis = new FeedItem({
										"uid": "categoryAxis",
										"type": "Dimension",
										"values": ["Category"]
									});
									that.oVizFrame.addFeed(feedValueAxis);
									that.oVizFrame.addFeed(feedTimeAxis);
								}
							});
						}
					});
				} else {
					var that = this;
					Format.numericFormatter(ChartFormatter.getInstance());
					// set explored app's demo model on this sample
					var oModel = new JSONModel(this.settingsModel);
					oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
					this.getView().setModel(oModel, "view1");
					var tempModel = new sap.ui.model.json.JSONModel();
					oFilter = [];
					oFilter1 = [];
					var f1 = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP01");
					var f11 = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP06");
					var f2 = new sap.ui.model.Filter("service_org", sap.ui.model.FilterOperator.EQ, "O 50008010");
					var fOpen1 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "20");
					var fOpen2 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "30");
					var closed1 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "40");
					var fOpen = new sap.ui.model.Filter({
						filters: [fOpen1, fOpen2],
						and: false
					});
					var f12 = new sap.ui.model.Filter({
						filters: [f1, f11],
						and: false
					});
					var fCreatedDate = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
						that.printDate(dc), that.printDate(lastDay));
					var fClosedDate = new sap.ui.model.Filter("closing_time", sap.ui.model.FilterOperator.BT,
						that.printDate(dc), that.printDate(lastDay));
					var fClosed = new sap.ui.model.Filter({
						filters: [closed1, fClosedDate],
						and: true
					});
					var last = new sap.ui.model.Filter({
						filters: [fCreatedDate, fClosed],
						and: false
					});
					var all = new sap.ui.model.Filter({
						filters: [f12, f2, fOpen],
						and: true
					});
					var all1 = new sap.ui.model.Filter({
						filters: [f12, f2, fClosedDate],
						and: true
					});
					var countT;
					oFilter.push(all);
					oFilter1.push(all1);
					that.getModel().read("/MCSDashboardSet/", {
						filters: oFilter1,
						success: function (oResult1) {
							var closedArr = oResult1.results;
							that.getModel().read("/MCSDashboardSet/", {
								filters: oFilter,
								success: function (oResult) {
									var merged = oResult.results.concat(closedArr);
									//console.log(oResult.results);
									//console.log(merged);
									var data = {
										"Data": []
									};
									var filterT;
									var filterR;
									var temporary = [];
									var temporary1 = [];
									var currentWeek = that.getWeekNumber(new Date())[1];
									for (var i = 1; i <= currentWeek; i++) {
										countT = 0;
										filterT = merged;
										filterR = filterT.filter(function (item) {
											temporary1 = that.getWeekNumber(that.createDate(item.create_time));
											var cond1 = (item.status === "20" || item.status === "30");
											var cond2 = that.createDate(item.create_time) <= (that.getDateOfWeek(i + 1, new Date().getFullYear()));
											var condN = (that.getDateOfWeek(i, new Date().getFullYear()) < new Date());
											temporary = that.getWeekNumber(that.createDate(item.closing_time));
											var condition = that.getDateOfWeek(i, new Date().getFullYear()) <= that.createDate(item.closing_time);
											var cond3 = temporary[1] >= i;
											var cond4 = item.closing_time > "0";
											return ((cond1 && cond2 && condN) || (cond3 && cond4 && cond2));
										});
										countT = filterR.length;
										filterR = [];
										data.Data.push({
											"Global Escalations": countT,
											"Date": that.getDateOfWeek(i, new Date().getFullYear())
										});
									}
									var oVizFrame = that.oVizFrame = that.getView().byId("idVizFrame");
									oVizFrame.setVizProperties(that.settingsModel.chartType.values[2].vizProperties);
									var dataModel = new JSONModel();
									dataModel.setData(data);
									oVizFrame.setModel(dataModel);
									var oDataset = new FlattenedDataset(bindValue.dataset);
									that.oVizFrame.setDataset(oDataset);
									var props = bindValue.vizProperties;
									if (selectedKey !== 8 && props.plotArea) {
										props.plotArea.dataPointStyle = null;
									}
									that.oVizFrame.setVizProperties(props);
									var feedValueAxis, feedValueAxis2, feedActualValues, feedTargetValues;
									feedValueAxis = new FeedItem({
										"uid": "valueAxis",
										"type": "Measure",
										"values": ["Global Escalations"]
									});
									var feedTimeAxis = new FeedItem({
										"uid": "timeAxis",
										"type": "Dimension",
										"values": ["Date"]
									});
									that.oVizFrame.addFeed(feedValueAxis);
									that.oVizFrame.addFeed(feedTimeAxis);
									InitPageUtil.initPageSettings(that.getView());
								}
							});
						}
					});
				}
			}
		},

		//Method responsible for calculating the number of days from the beginning of the year to
		//a given date param(now) date for which the calculation needs to be done
		getDay: function (now) {
			var start = new Date(now.getFullYear(), 0, 0);
			var diff = now - start;
			var oneDay = 1000 * 60 * 60 * 24;
			var day = Math.floor(diff / oneDay);
			return day;
		}
	});
});