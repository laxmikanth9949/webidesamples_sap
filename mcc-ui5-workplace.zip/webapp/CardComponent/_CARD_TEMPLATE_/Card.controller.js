sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseCardController, Filter, FilterOperator) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent._CARD_TEMPLATE_.Card", {
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			/*
			 * Prerequisite: sap.ui.table 
			 * register AttachChange event binding change for table rows to update the card title when for example a column filter is applied
			 */
			//this.getView().byId("<tableid>"").getBinding("rows").attachChange(this.updateCardTitle.bind(this, "<sBindingProperty>"));

			this.onUpdateCard();
			// this.setCardAutoRefresh(300000); // Autorefresh in ms - if card needs to be autorefreshed, set the time in ms

			/* YOUR CODE HERE */
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			// this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			//only need if card is filterable by global filterbar
			var aFilterArray = this.getFilterBarValues("CaseChecker");

			this.loadCasesAppDepSrv(aFilterArray, {}).then(function (aCases) {
				if (aCases && aCases.length > 0) {
					/* YOUR CODE HERE */
					this.setCardSuccessState();
				} else {
					this.setCardNoDataState();
				}
			}.bind(this));

		}
	});
});