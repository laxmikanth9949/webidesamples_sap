sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"com/sap/mcc/workplace/CardComponent/CardErrorHandler",
	"com/sap/mcc/workplace/controller/ODataHandler"
], function (UIComponent, JSONModel, CardErrorHandler, ODataHandler) {
	"use strict";

	var Component = UIComponent.extend("com.sap.mcc.workplace.CardComponent.Roadmap.BaseCardComponent", {

		init: function () {
			var oCardModelTemplate = {
				busy: false,
				error: false,
				noData: false,
				metadataError: false,
				metadataErrorStatusCode: null,
				errorMessage: null,
				lastRefreshDateTime: null,
				lastRefreshText: "",
				autoRefreshTime: 0, // in miliseconds. 0 = disable
				autoRefreshCountdownTime: 0,
				autoRefreshText: "",
				CardInfo: {}, // reference from Workplace,
				customHeader: { // for CardType = CustomAction
					additionalCardTitle: null,
					action: {
						left: [],
						right: []
					}
				}
			};

			// Initialize cardModel
			this.setModel(new JSONModel(oCardModelTemplate), "cardModel");
			console.log("component: " + this.getMetadata().getManifest()["sap.app"].id);

			if (this.aServerModels && this.aServerModels.length) {
				this.aServerModels.forEach(function (sModelName) {
					// Models are required to be defined on sap.ui5.models at Card manifest.json file

					// Error Handler for Model
					this._oCardErrorHandler = new CardErrorHandler(this, sModelName);
					// Handler to intercept and abort requests when Profile is changed or cancelled
					this._oODataHandler = new ODataHandler(this, sModelName);
				}.bind(this));
			}

			// call the init function of the parent
			UIComponent.prototype.init.apply(this, arguments);
		}
	});

	return Component;
});