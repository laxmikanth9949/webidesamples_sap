sap.ui.define([
	"sap/ui/model/odata/type/DateTime"
], function (DateTime) {
	"use strict";

	var oFormatter = {
		
		formatDate: function (date) {
			var dDate = new Date(date);
			var dateFormatted = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd"
			});
			var sDate = dateFormatted.format(dDate);
			
			return sDate;
		},
		
		formatLastRefreshedTime: function (dDateTime) {
			var oType = new DateTime({
				pattern: "h:mm:ss a"
			});
			dDateTime = dDateTime ? dDateTime : new Date();
			return this.getModel("i18n").getResourceBundle().getText("cardFormatterLastRefreshedTime", [oType.formatValue(new Date(dDateTime),
				"string")]);
		},

		getDaysSince: function (date) {
			if (date) {
				var dDate = new Date(date);

				// get total seconds between the times
				var delta = Math.abs(new Date() - (dDate)) / 1000;

				// calculate (and subtract) whole days
				var days = Math.floor(delta / 86400);
				delta -= days * 86400;

				return days + " days";
			}
			return "";
		},

		/**
		 * Calculates the amount of days between given date and today 
		 */
		getDays: function (date, time) {
			//respect date and time 
			//create a new date object
			if (date) {
				var myDate = new Date(date);
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyy-MM-dd"
				});
				var sDateTmp = dateFormat.format(myDate);
				var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					pattern: "HH:mm:ss",
					UTC: true
				});
				var TZOffsetMs = myDate.getTimezoneOffset() * 60 * 1000;
				if (time) {
					var timeStr = timeFormat.format(new Date(time.ms - TZOffsetMs));
					var sDate = sDateTmp + "T" + timeStr;
				} else {
					sDate = date;
				}
				var oDateTime = new Date(sDate);

				// get total seconds between the times
				var delta = Math.abs(new Date() - (oDateTime)) / 1000;

				// calculate (and subtract) whole days
				var days = Math.floor(delta / 86400);
				delta -= days * 86400;

				// calculate (and subtract) whole hours
				var hours = Math.floor(delta / 3600) % 24;
				delta -= hours * 3600;

				// calculate (and subtract) whole minutes
				var minutes = Math.floor(delta / 60) % 60;
				delta -= minutes * 60;

				// what's left is seconds
				var seconds = delta % 60;
				var text = days + " d " + hours + " h ";
				if ((days === 0) && hours === 0) {
					return "< 1 hour";
				}

				return text;
			} else {
				return "";
			}
		},

		millisToMinutesAndSeconds: function (millis) {
			var minutes = Math.floor(millis / 60000);
			var seconds = ((millis % 60000) / 1000).toFixed(0);
			return minutes + ":" + (seconds < 10 ? '0' : '') + seconds;
		},

		ratingColor: function (sColor) {
			if (sColor === "Green") {
				return "#2B7C2B";
			} else if (sColor === "Yellow") {
				return "#E09D00";
			} else if (sColor === "Red") {
				return "#bb0000";
			}
			return "Neutral";
		},
		
		formatSeverityTextColor: function (sSeverityText) {
			if (sSeverityText === "OK") return "#2cde2c";
			if (sSeverityText === "Critical") return "#E09D00";
			if (sSeverityText === "Very Critical") return "#bb0000";
			return "Neutral";
		},
		
		formatLastQGateTextColor: function (sSeverityText) {
			if (sSeverityText === "OK") return "Success";
			if (sSeverityText === "Critical") return "Warning";
			if (sSeverityText === "Very Critical") return "Error";
			return "None";
		},

		//Numeric Content at ERAcceptanceRateCard
		NumericContentColor: function (aValue) {
			//aValue = aValue.slice(0, -1);
			var value = parseInt(aValue, 10);
			if (value <= 49) {
				return "Good";

			} else if (value < 80) {
				return "Critical";
			} else {
				return "Error";
			}
		},

		setTextColorOpenFor: function (oValue) {
			if (oValue) {
				var sOpenFor = oFormatter.getDaysSince(oValue);
				var iDays = parseInt(sOpenFor.slice(0, -5), 10);
				if (iDays >= 10 && iDays < 20) {
					return "Warning";

				} else if (iDays >= 20) {
					return "Error";
				}
				return "None";
			}
		},

		overdueDate: function (oDate) {
			if (oDate) {
				var oDateNow = new Date();
				if (oDateNow > oDate) {
					return "Error";
				}
			}
			return "None";
		},

		transformServiceOrg: function (sServiceTeam) {
			if (sServiceTeam) {
				// example = SEORG-02-001SOLS-EMEA => expected result EMEA
				var aValues = sServiceTeam.split("-");
				return aValues[aValues.length - 1];
			}
			return "";
		},

		transformServiceTeam: function (sServiceTeamName) {
			if (sServiceTeamName) {
				// example = SEORG-02-001SOLS-EMEA => expected result EMEA
				return sServiceTeamName.substring(sServiceTeamName.indexOf(" "));
			}
			return "";
		},
		
		formatIncidentId: function (id) {
			if (id) {
				var year = id.substring(id.length - 4);
				var ID = parseInt(id.substring(10, id.length - 4));
				return ID + "/" + year;
			} else {
				return "";
			}
		}
	};

	return oFormatter;
});