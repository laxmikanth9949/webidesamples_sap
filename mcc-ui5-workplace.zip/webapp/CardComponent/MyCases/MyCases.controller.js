sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseCardController, Filter, FilterOperator) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.MyCases.MyCases", {
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			//register AttachChange event for binding change to update the card title when for example a column filter is applied		
			this.getView().byId("tableMyCases").getBinding("rows").attachChange(this.updateCardTitle.bind(this, "cases"));

			this.onUpdateCard();
			// this.setCardAutoRefresh(300000); // Autorefresh in ms - if card needs to be autorefreshed, set the time in ms

			this.setCardProperty("/visibleCQI", true);

			/* YOUR CODE HERE */
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();

			this._getMyCases().then(function (aCases) {

				if (aCases && aCases.length > 0) {
					this.setCardProperty("/cases", aCases);

					var aPromises = [];
					for (var i = 0; i < aCases.length; i++) {
						var sCaseCheckerProfile = "mcc-global";
						if (aCases[i].CaseType == "ZS01") {
							sCaseCheckerProfile = "mcs-gem";
						} else if (aCases[i].CaseType == "ZS02") {
							sCaseCheckerProfile = "mcs-ccm";
						}
						var CasecheckerPromise = this._readCaseCheckerDetails(aCases[i].CaseID, sCaseCheckerProfile);
						aPromises.push(CasecheckerPromise);
					}

					Promise.all(aPromises).then(function (oData) {
							this.setCardSuccessState();
						}.bind(this))
						.catch(function (oError) {
							// if additional request fails don't block the whole card
							// set the card to success state such that the data can still be viewed
							this.setCardSuccessState();

						}.bind(this));

				} else {
					this.setCardNoDataState();
				}
			}.bind(this)).catch(function (oError) {
				this.setCardErrorState();
			}.bind(this));

		},

		_getMyCases: function () {
			var oAppDepModel = this.getModel("appDepModel");
			var oFilter = new Filter("MyCase", FilterOperator.EQ, 'X');
			var oStatusFilter = new Filter({
				filters: [
					new Filter("StatusID", FilterOperator.EQ, "71"),
					new Filter("StatusID", FilterOperator.EQ, "80"),
					new Filter("StatusID", FilterOperator.EQ, "99"),
					new Filter("StatusID", FilterOperator.EQ, "81"),
					new Filter("StatusID", FilterOperator.EQ, "20"),
					new Filter("StatusID", FilterOperator.EQ, "30")
				],
				and: false
			});

			return new Promise(function (resolve, reject) {
				oAppDepModel.read("/CaseSet", {
					filters: [oFilter, oStatusFilter],
					success: function (oData) {
						var aCases = this.getCaseRegion(oData.results);
						resolve(aCases);
					}.bind(this),
					error: function (oError) {
						reject(oError);
					}
				});
			}.bind(this));
		},

		_readCaseCheckerDetails: function (sCaseId, sProfile) {
			return this.startMccWorkplaceAjaxRequest({
				url: "/executeRuleCheck?profile=" + sProfile + "&object=CaseSet(CaseID=%27" + sCaseId +
					"%27,CaseType=%27ZS01%27,CaseObject=%27C%27)&expand=toNote,toCheckPoint,toTopIssue,toAffectedProduct,toActivity,toPartiesInvolved"
			}).then(function (oData) {
				var aData = this.getCardProperty("/cases") ? this.getCardProperty("/cases") : [];

				var oObject = this.findObjectByKey(aData, "CaseID", sCaseId);
				oObject.CQI = oData.OverallCQI;
				if (oData.Data && oData.Data.length > 0) {
					oObject.Rules = oData.Data[0].Rules.filter((item) => item.RuleResult !== "Success");

				}

			}.bind(this)).catch(function (err) {
				//this._handleBusyIndicator
				this.setCardProperty("/visibleCQI", false);
				this.getCardModel().refresh(true);
			}.bind(this));
		},

		onCaseIdPressed: function (oEvent) {
			this.navToApp(
				this.getResourceBundle().getText("CaseSearchTest", [oEvent.getSource().getText()]),
				this.getResourceBundle().getText("CaseSearch", [oEvent.getSource().getText()]), {}, false);
		},

		onCustomerPressed: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCustomerId = this.getCardProperty(sBindingContextPath).CustomerR3No;

			this.navToApp(
				this.getResourceBundle().getText("mccOneDashboardTest", [sCustomerId]),
				this.getResourceBundle().getText("mccOneDashboardProd", [sCustomerId]), {}, false);

		}
	});
});