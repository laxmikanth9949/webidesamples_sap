sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	'sap/ui/export/Spreadsheet',
	'sap/ui/export/library'
], function (BaseCardController, JSONModel, Filter, FilterOperator, Spreadsheet, exportLibrary) {
	"use strict";

	var EdmType = exportLibrary.EdmType;

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.OpenCCMCases.OpenCCMCases", {

		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", [
				new sap.ui.core.Icon({
					visible: "{= !(${/busy})}",
					src: "sap-icon://download",
					tooltip: "Download",
					press: [this.openConfidentialDialog, this],
					color: "#FFFFFF"
				})
			]);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			this.setCardProperty("/visibleCQI", false);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			this.setCardProperty("/busy", false);

			this.onUpdateCard();

			//register AttachChange event for binding change to update the card title when for example a column filter is applied		
			this.getView().byId("open-ccm-cases").getBinding("rows").attachChange(this.updateCardTitle.bind(this, "data"));

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "dataLoaded", this.onUpdateCard, this);
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "search", this.setCardUpdateStartState, this);

		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified

			this.setCardUpdateStartState();

			var aArray = this.getFilterBarValues("OpenCCMCases");

			var oCasesLoaded = this._loadCases(aArray);

			oCasesLoaded.then(function (aData) {

				var aPromises = [];
				if (aData.length > 0) {
					var aPromises = [];
					var oCQIPromise = this.getCQIScore("data", "mcs-ccm-global-manager");

					//do single expand requests due to performance improvements
					var oPromiseActivity = this._getCaseDetailsAppDepSrv("toActivity");
					aPromises.push(oPromiseActivity);
					var oPromiseTopIssues = this._getCaseDetailsAppDepSrv("toTopIssue");
					aPromises.push(oPromiseTopIssues);
					var oPromiseCustomSet = this._getCaseDetailsAppDepSrv("toCustomSet");
					aPromises.push(oPromiseCustomSet);
					var oPromiseAffectedProduct = this._getCaseDetailsAppDepSrv("toAffectedProduct");
					aPromises.push(oPromiseAffectedProduct);

					//set success state when all requests have finished
					Promise.all(aPromises).then(function (oData) {
							this.setCardSuccessState();
						}.bind(this))
						.catch(function (oError) {
							// when any odata requests failed
							this.setCardErrorState();
						}.bind(this));

				}
			}.bind(this)).catch(function (oError) {
				console.log("[Open CCM Cases]: Request Failed " + oError);
			});

		},

		_loadCases: function (aFilterBar) {
			//	var oZSAppDepModel = this.getModel("appDepModel");
			var aFilters = [];
			//merge array when filters are set in filter bar
			aFilters = aFilters.concat(aFilterBar);
			var oFilterCaseType = new Filter('CaseType', FilterOperator.EQ, "ZS02");
			var oFilterCustomerType = new Filter({
				filters: [
					new Filter("CustomerTypeID", FilterOperator.EQ, "ZSCUSTYP04"),
					new Filter("CustomerTypeID", FilterOperator.EQ, "ZSCUSTYP05"),
				],
				and: false
			});

			var oReasonFilter = new Filter("ReasonId", FilterOperator.EQ, "ENGA");

			var oStatusFilter = new Filter({
				filters: [
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 71
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 80
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 81
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 99
					})
				],
				and: false
			});

			//push filter to array
			aFilters.push(oReasonFilter);
			aFilters.push(oFilterCustomerType);
			aFilters.push(oFilterCaseType);
			aFilters.push(oStatusFilter);

			return new Promise(function (resolve, reject) {

				this.loadCasesAppDepSrv(aFilters, {}).then(function (aData) {
					if (aData && aData.length > 0) {
						aData.forEach(function (oCase) {
							oCase.Region = this._getRegion(oCase.ServiceOrg);
							oCase.CustomerType = this._getCustomerType(oCase.CustomerTypeID);
						}.bind(this));
						this.setCardProperty("/data", aData);

						//resolve promise to request additional information from ZS APP DEP SRV (CustomerTypeID)
						resolve(aData);
					} else {
						this.setCardProperty("/data", aData)
						this.setCardNoDataState();
						// resolve promise with empty array --> no additinal data (CustomerTypeID) from ZS APP DEP SRV is requested
						resolve([]);
					}
				}.bind(this)).catch(function (oError) {
					this.setCardProperty("/customHeader/additionalCardTitle", "");
					this.setCardErrorState(oError);
					resolve(oError);
				}.bind(this));
			}.bind(this));

			/*return new Promise(function (resolve, reject) {
				oZSAppDepModel.read("/CaseSet", {
					filters: aFilters,
					success: function (oData) {
						if (oData.results && oData.results.length > 0) {
							oData.results.forEach(function (oCase) {
								oCase.Region = this._getRegion(oCase.ServiceOrg);
								oCase.CustomerType = this._getCustomerType(oCase.CustomerTypeID);
							}.bind(this));
							this.setCardProperty("/data", oData.results);
							//resolve promise to request additional information from ZS APP DEP SRV (CustomerTypeID)
							resolve(oData.results);
						} else {

							this.setCardNoDataState();
							// resolve promise with empty array --> no additinal data (CustomerTypeID) from ZS APP DEP SRV is requested
							resolve([]);
						}
					}.bind(this),
					error: function (oError) {
						this.setCardProperty("/customHeader/additionalCardTitle", "");
						this.setCardErrorState(oError);
						resolve(oError);
					}.bind(this)
				});
			}.bind(this));*/

		},

		_getCaseDetailsAppDepSrv: function (sExpandProperty) {
			var oZSAppDepModel = this.getModel("appDepModel");
			var aFilters = [];
			var oFilterCaseType = new Filter('CaseType', FilterOperator.EQ, "ZS02");
			var oFilterCustomerType = new Filter({
				filters: [
					new Filter("CustomerTypeID", FilterOperator.EQ, "ZSCUSTYP04"),
					new Filter("CustomerTypeID", FilterOperator.EQ, "ZSCUSTYP05"),
				],
				and: false
			});

			var oStatusFilter = new Filter({
				filters: [
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 71
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 80
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 81
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 99
					})
				],
				and: false
			});
			aFilters.push(oFilterCaseType);
			aFilters.push(oFilterCustomerType);
			aFilters.push(oStatusFilter);

			var oUrlParameter = {};
			if (sExpandProperty) {
				oUrlParameter = {
					"$expand": sExpandProperty
				};
			}

			return new Promise(function (resolve, reject) {
				oZSAppDepModel.read("/CaseSet", {
					filters: aFilters,
					urlParameters: oUrlParameter,
					success: function (oData) {
						this._updateModel(oData.results);
						resolve(oData.results);
					}.bind(this),
					error: function (oError) {
						resolve(oError);
					}.bind(this)
				});
			}.bind(this));

			/*oCaseTypePromise.then(function (aResults) {
				var aData = this.getModel("cardModel").getProperty("/data");
				aResults.forEach(function (oCase) {
					var oObject = this.findObjectByKey(aData, "CaseID", oCase.CaseID);

					//count open / closed activities
					if (oCase.toActivity && oCase.toActivity.results.length > 0) {
						var iOpenActivities = 0;
						var iClosedActivities = 0;
						oCase.toActivity.results.forEach(function (oActivity) {
							//skip this --> Status = OBSOLETE
							if ((oActivity.CategoryID === 'ZYP' || oActivity.CategoryID === 'ZYO') && oActivity.StatusID !== "E0020") {

								if (oActivity.StatusID === "E0013" || oActivity.StatusID === "E0014") {
									iClosedActivities++;
								} else {
									iOpenActivities++;
								}
							}
						});
						oObject.ActivitiesOpenClosed = iOpenActivities + " / " + iClosedActivities;
					}

					if (oCase.toTopIssue && oCase.toTopIssue.results.length > 0) {
						var iOpenTopIssues = 0;
						var iClosedTopIssues = 0;
						oCase.toTopIssue.results.forEach(function (oTopIssue) {
							if (oTopIssue.StatusID === "E0012") {
								//skip this --> Status = Rejected
							} else if (oTopIssue.StatusID === "E0013") {
								iClosedTopIssues++;
							} else {
								iOpenTopIssues++;
							}
						});
						oObject.TopIssuesOpenClosed = iOpenTopIssues + " / " + iClosedTopIssues;
					}

					//merge all Products (AffectedProductText attributes into one single property "ProductLinesMerged" of case )
					if (oCase.toAffectedProduct && oCase.toAffectedProduct.results.length > 0) {
						var aProducts = oCase.toAffectedProduct.results;
						var aProductLines = [];
						aProducts.forEach(function (oProduct) {
							aProductLines.push(oProduct.AffectedProductText);
						});

						aProductLines = [...new Set(aProductLines)];
						//split all values with ", " and prevent the last value having a comma at the end
						if (aProductLines.length > 1) {
							oObject.ProductLinesMerged = aProductLines.slice(0, -1).join(', ') + ", " + aProductLines.slice(-1);
						} else {
							oObject.ProductLinesMerged = aProductLines.toString();
						}
					}

					if (oCase.toCustomSet && oCase.toCustomSet.results.length > 0) {
						if (oCase.toCustomSet.results[0].Golive) {
							oObject.GoLive = oCase.toCustomSet.results[0].Golive;
						}
					}
				}.bind(this));

			}.bind(this)).catch(function () {

			});

			return oCaseTypePromise;*/

		},

		// update the card model depending on which associated entity is expanded from root entity case 
		_updateModel: function (aResults) {
			var aData = this.getModel("cardModel").getProperty("/data");
			aResults.forEach(function (oCase) {
				var oObject = this.findObjectByKey(aData, "CaseID", oCase.CaseID);
				if (oObject) {
					//count open / closed activities
					if (oCase.toActivity.results && oCase.toActivity.results.length > 0) {
						var iOpenActivities = 0;
						var iClosedActivities = 0;
						oCase.toActivity.results.forEach(function (oActivity) {
							//skip this --> Status = OBSOLETE
							if ((oActivity.CategoryID === 'ZYP' || oActivity.CategoryID === 'ZYO') && oActivity.StatusID !== "E0020") {

								if (oActivity.StatusID === "E0013" || oActivity.StatusID === "E0014") {
									iClosedActivities++;
								} else {
									iOpenActivities++;
								}
							}
						});
						oObject.ActivitiesOpenClosed = iOpenActivities + " / " + iClosedActivities;
					}

					if (oCase.toTopIssue.results && oCase.toTopIssue.results.length > 0) {
						var iOpenTopIssues = 0;
						var iClosedTopIssues = 0;
						oCase.toTopIssue.results.forEach(function (oTopIssue) {
							if (oTopIssue.StatusID === "E0012") {
								//skip this --> Status = Rejected
							} else if (oTopIssue.StatusID === "E0013") {
								iClosedTopIssues++;
							} else {
								iOpenTopIssues++;
							}
						});
						oObject.TopIssuesOpenClosed = iOpenTopIssues + " / " + iClosedTopIssues;
					}

					//merge all Products (AffectedProductText attributes into one single property "ProductLinesMerged" of case )
					if (oCase.toAffectedProduct.results && oCase.toAffectedProduct.results.length > 0) {
						var aProducts = oCase.toAffectedProduct.results;
						var aProductLines = [];
						var sIsMainProduct = "";
						aProducts.forEach(function (oProduct) {
							if (oProduct.IsMainProduct) {
								sIsMainProduct = oProduct.AffectedProductText;
							} else {
								aProductLines.push(oProduct.AffectedProductText);
							}
						});
						aProductLines = sIsMainProduct ? [sIsMainProduct].concat(aProductLines) : aProductLines;

						aProductLines = [...new Set(aProductLines)];
						//split all values with ", " and prevent the last value having a comma at the end
						if (aProductLines.length > 1) {
							oObject.ProductLinesMerged = aProductLines.slice(0, -1).join(', ') + ", " + aProductLines.slice(-1);
							if (aProductLines.length > 2) {
								oObject.ProductLinesMergedFormatted = "<p><strong>" + aProductLines.slice(0, 1) + ", </strong>" + aProductLines.slice(1, -1)
									.join(
										', ') + ", " + aProductLines.slice(-1) + "</p>";
							} else {
								oObject.ProductLinesMergedFormatted = "<p><strong>" + aProductLines.slice(0, 1) + ", </strong>" + aProductLines.slice(1, -1)
									.join(
										', ') + aProductLines.slice(-1) + "</p>";
							}
						} else if (sIsMainProduct) {
							oObject.ProductLinesMerged = aProductLines.toString();
							oObject.ProductLinesMergedFormatted = "<p><strong>" + aProductLines.toString() + "</strong></p>";
						} else {
							oObject.ProductLinesMerged = aProductLines.toString();
							oObject.ProductLinesMergedFormatted = "<p>" + aProductLines.toString() + "</p>";
						}
					}

					if (oCase.toCustomSet.results && oCase.toCustomSet.results.length > 0) {
						if (oCase.toCustomSet.results[0].Golive) {
							oObject.GoLive = oCase.toCustomSet.results[0].Golive;
						}
					}
				}
			}.bind(this));

			this.getModel("cardModel").refresh(true);
		},

		/*_getCQIScore: function (sCaseId) {
			var CasecheckerPromise = new Promise(function (resolve, reject) {
				jQuery.ajax({
					type: "GET",
					contentType: "application/json",
					url: "/executeRuleCheck?profile=mcs-ccm-global-manager", //"/executeRuleCheck?profile=mcs-gem&object=CaseSet(CaseID=%27" + sCaseId +"%27,CaseType=%27ZS01%27,CaseObject=%27C%27)",
					dataType: "json",
					success: function (data, textStatus, jqXHR) {
						resolve(data);
					},
					error: function (err) {
						reject(err);
					}
				});
			});

			CasecheckerPromise.then(function (oData) {

				if (oData.Data && oData.Data.length > 0) {
					//set Column CQI visible
					this.setCardProperty("/visibleCQI", true);
					var aData = this.getCardProperty("/data");
					oData.Data.forEach(function (oCaseCQI) {
						//	oCaseCQI.Identifier // CaseId
						var oObject = this.findObjectByKey(aData, "CaseID", oCaseCQI.Identifier);
						if (oObject) {
							oObject.CQI = oCaseCQI.CQI;
							oObject.CQIStatus = oCaseCQI.RuleCheckResult; oCaseCQI.Rules
							if (oCaseCQI.Rules &&oCaseCQI.Rules.length > 0) {
								oObject.Rules = oCaseCQI.Rules.filter((item) => item.RuleResult !== "Success");
							}
						}
					}.bind(this));
					//this.getCardModel().refresh();
				} else {
					this.setCardProperty("/visibleCQI", false);

				}

			}.bind(this));
		},*/

		_getCustomerType: function (sCaseTypeID) {
			var sCasetype = "";
			switch (sCaseTypeID) {
			case 'ZSCUSTYP01':
				sCasetype = "PES Active";
				break;
			case 'ZSCUSTYP02':
				sCasetype = "PES Complete";
				break;
			case 'ZSCUSTYP03':
				sCasetype = " VIP";
				break;
			case 'ZSCUSTYP04':
				sCasetype = "CPC";
				break;
			case 'ZSCUSTYP05':
				sCasetype = "CCM";
				break;
			default:
				sCasetype = "";
				break;
			}

			return sCasetype;
		},

		_getRegion: function (sServiceOrg) {
			var sRegion = "";
			switch (sServiceOrg) {
			case "O 50008010":
				sRegion = "EMEA";
				break;
			case "O 50008134":
				sRegion = "APJ";
				break;
			case "O 50008167":
				sRegion = "NA";
				break;
			case "O 50008174":
				sRegion = "LA";
				break;
			}
			return sRegion;
		},

		onCustomerPressed: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCustomerId = this.getCardModel().getProperty(sBindingContextPath).CustomerR3No;

			this.navToApp(
				this.getResourceBundle().getText("mccOneDashboardTest", [sCustomerId]),
				this.getResourceBundle().getText("mccOneDashboardProd", [sCustomerId]), {}, false);

		},
		//https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites#mccissuetracking-Display&/20083313
		onLinkPress: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCustomerId = this.getCardModel().getProperty(sBindingContextPath).CaseId;
			this.navToApp(
				this.getResourceBundle().getText("mccWorkbenchTest", [oEvent.getSource().getText()]),
				this.getResourceBundle().getText("mccWorkbenchProd", [oEvent.getSource().getText()]), {}, false);
		},

		onDataExport: function (oEvent) {
			this.oConfidentialFragment.close()

			var aCols, aExportingData, oSettings, oSheet;

			aCols = this._createColumnConfig();
			aExportingData = this._addMCCWorkplaceUrlForSpreadsheet(this.getModel("cardModel").getProperty('/data'));

			oSettings = {
				workbook: {
					columns: aCols,
					context: {
						sheetName: "Open CCM Cases"
					}
				},
				dataSource: aExportingData,
				fileName: "OpenCCMCases.xlsx",
				showProgress: false
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build()
				.finally(function () {
					//ToDo oSheet.destroy();
				});
		},

		_createColumnConfig: function () {
			return [{
				label: 'Rating',
				property: 'RatingText',
				type: EdmType.String,
			}, {
				label: 'Case ID',
				property: 'CaseID',
				type: EdmType.String,
			}, {
				label: 'MCC Workplace',
				property: 'workplaceURl',
				type: EdmType.String,
			}, {
				label: 'Case Title',
				property: 'CaseTitle',
				type: EdmType.String,
			}, {
				label: 'Customer Name',
				property: 'CustomerName',
				type: EdmType.String,
			}, {
				label: 'Customer Type',
				property: 'CustomerType',
				type: EdmType.String,
			}, {
				label: 'Responsible',
				property: 'ResponsiblePerson',
				type: EdmType.String,
			}, {
				label: 'Status',
				property: 'StatusText',
				type: EdmType.String,
			}, {
				label: 'Service Team ',
				property: 'ServiceTeamName',
				type: EdmType.String,
			}, {
				label: 'Service Team',
				property: 'ServiceTeam',
				type: EdmType.String,
			}, {
				label: 'Region',
				property: 'Region',
				type: EdmType.String,
			}, {
				label: 'Case Quality Index',
				property: 'CQI',
				type: EdmType.String,
			}, {
				label: 'Case Quality Index - Status',
				property: 'CQIStatus',
				type: EdmType.String,
			}, {
				label: 'Top Issues (Open / Closed)',
				property: 'TopIssuesOpenClosed',
				type: EdmType.String,
			}, {
				label: 'Issues (Open / Closed)',
				property: 'ActivitiesOpenClosed',
				type: EdmType.String,
			}, {
				label: 'Create Date',
				property: 'CreateTime',
				type: EdmType.DateTime,
			}, {
				label: 'Go Live',
				property: 'GoLive',
				type: EdmType.DateTime,
			}, {
				label: 'Product Lines',
				property: 'ProductLinesMerged',
				type: EdmType.String,
			}];
		},

		_addMCCWorkplaceUrlForSpreadsheet: function (aArray) {
			var sHostname = window.location.hostname;
			var sURL = null;

			aArray.forEach(function (oItem, iIndex, aArray) {
				// SAP IT Cloud T - https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites
				if (sHostname.lastIndexOf("sapitcloudt") > -1 || sHostname.lastIndexOf("a44f228ad") > -1) {
					sURL = this.getResourceBundle().getText("mccWorkbenchTest", [oItem.CaseId]);
				} else if (sHostname === "fiorilaunchpad.sap.com" || sHostname.lastIndexOf("a87daa223") > -1) {
					sURL = this.getResourceBundle().getText("mccWorkbenchProd", [oItem.CaseId]);
				}

				aArray[iIndex].workplaceURl = sURL;
			}.bind(this));

			return aArray;

		}

	});
});