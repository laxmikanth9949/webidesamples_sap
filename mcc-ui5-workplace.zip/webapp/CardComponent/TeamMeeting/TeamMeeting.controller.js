sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"com/sap/mcc/workplace/CardComponent/BaseCardController"
], function (jQuery, Controller, JSONModel, BaseCardController) {
	"use strict";

	var TableController = BaseCardController.extend("com.sap.mcc.workplace.CardComponent.TeamMeeting.TeamMeeting", {
		 // set the root path of the folder and load the image from the correct path
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
				// add custom control to header
				this.setCardProperty("/customHeader/action/right", []);
				this.setCardProperty("/customHeader/action/left", []);
				this.setCardProperty("/customHeader/additionalCardTitle", []);
				// Initialize view and CardHeader
				BaseCardController.prototype.onInit.apply(this, arguments);
				/* END: CARD INITIALIZATION */
			
			var sRootPath = jQuery.sap.getModulePath("com.sap.mcc.workplace");
			var sImagePath = sRootPath + "/images/head.png";
			var oImageControl = this.getView().byId("teamMeetingImage");
			oImageControl.setSrc(sImagePath);
		}
	});
	return TableController;
});