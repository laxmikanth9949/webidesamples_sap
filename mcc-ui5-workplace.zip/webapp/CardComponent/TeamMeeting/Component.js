sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardComponent"
], function (BaseCardComponent) {
	"use strict";

	var Component = BaseCardComponent.extend("com.sap.mcc.workplace.CardComponent.TeamMeeting.Component", {

		metadata: {
			manifest: "json"
		},

		init: function () {
			// initialize CardErrorHandler and CardODataHandler for models in array
			// Models are required to be defined on sap.ui5.models at Card manifest.json file
			this.aServerModels = [];

			// call the init function of the parent
			BaseCardComponent.prototype.init.apply(this, arguments);
		}
	});

	return Component;
});