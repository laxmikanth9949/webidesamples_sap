sap.ui.define([
		"jquery.sap.global",
		"sap/m/MessageToast",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"com/sap/mcc/workplace/CardComponent/BaseCardController"
	],
	function (jQuery, MessageToast, Filter, FilterOperator, BaseCardController) {
		"use strict";

		return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.BDStatistics.BDStatistics", {

			onInit: function (evt) {
				/* BEGIN: CARD INITIALIZATION */
				// add custom control to header
				this.setCardProperty("/customHeader/action/right", []);
				this.setCardProperty("/customHeader/action/left", []);
				this.setCardProperty("/customHeader/additionalCardTitle", []);
				// Initialize view and CardHeader
				BaseCardController.prototype.onInit.apply(this, arguments);
				/* END: CARD INITIALIZATION */

				//sap.ui.getCore().getEventBus().subscribe("mcs.emea.esca.overview", "reload", this.onUpdateCard, this);
				this.onUpdateCard();
			},
			padStr: function (i) {
				return (i < 10) ? "0" + i : "" + i;
			},

			//Get the date in date format.
			//@returns a date in string format.
			printDate: function (temp) {
				//var temp = new Date();
				var temp1 = new Date(temp);
				var dateStr = this.padStr(temp.getFullYear()) +
					this.padStr(1 + temp.getMonth()) +
					this.padStr(temp.getDate()) +
					this.padStr(temp.getHours()) +
					this.padStr(temp.getMinutes()) +
					this.padStr(temp.getSeconds());
				return (dateStr);

			},

			//Get the date in String format.
			//@returns a date in Date format.
			createDate: function (temp) {
				var year = temp.substring(0, 4);
				var month = temp.substring(4, 6);
				var day = temp.substring(6, 8);
				var hour = temp.substring(8, 10);
				var minute = temp.substring(10, 12);
				var seconds = temp.substring(12, 14);

				return new Date(year, month - 1, day, hour, minute, seconds);
			},

			/**
			 * onUpdateCard is triggered for refreshing the data.
			 * IMPORTANT: the onUpdateCard method name cannot be modified
			 */
			onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
				this.setCardUpdateStartState();

				var oFilterProcessType = new Filter({
					filters: [
						new Filter("ProcessTypeId", FilterOperator.EQ, "ZSPRCTYP02"),
						new Filter("ProcessTypeId", FilterOperator.EQ, "ZSPRCTYP03")
					],
					bAnd: false
				});

				var oFilterOpenInProgress = new Filter({
					filters: [
						new Filter("StatusID", FilterOperator.EQ, "20"),
						new Filter("StatusID", FilterOperator.EQ, "30"),
					],
					bAnd: false
				});

				var oFilterStatusClosed = new Filter("StatusID", FilterOperator.EQ, "40");

				var aFilterClosed = [oFilterProcessType, oFilterStatusClosed];
				var aFilterOpen = [oFilterProcessType, oFilterOpenInProgress];

				var aPromises = [];
				var oPromiseOpen = this._loadCases(aFilterOpen, {});
				aPromises.push(oPromiseOpen);
				var oPromiseClosed = this._loadCases(aFilterClosed, {});
				aPromises.push(oPromiseClosed);

				Promise.all(aPromises).then(function (aData) {
						var iClosedCount;
						var iOpenCount;
						
					// distinguish by the status id which array element stores all closed cases and which all open ones
					if(aData[0][0].StatusID === "40"){
						 iClosedCount = aData[0].length;
						 iOpenCount = aData[1].length;
					} else {
							 iClosedCount = aData[1].length;
						 iOpenCount = aData[0].length;
					}
					
					var oCountObject = {
						titleOpen: "Open",
						openCount: iOpenCount,
						titleClosed: "Closed", 
						closedCount: iClosedCount
					};
					
					this.setCardProperty("/data", oCountObject);
					this.setCardSuccessState();
				}.bind(this)).catch(function (oError) {
					this.setCardErrorState();
				}.bind(this));
			
			},

			_loadCases: function (aFilter, oUrlParameters) {
				var oAppDepModel = this.getModel("appDepModel");
				return new Promise(function (resolve, reject) {

					oAppDepModel.read("/CaseSet", {
						filters: aFilter,
						urlParameters: oUrlParameters,
						success: function (oData) {
							resolve(oData.results);
						},
						error: function (oError) {
							reject(oError);
						}
					});
				}.bind(this));
			},

		});
	});