sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel"
], function (BaseCardController, JSONModel) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.CCTMonitor.CCTMonitor", {
		// Method responsible for initializing the view, getting the current value of the region and setting the timer for refreshing the view
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			this.setCardProperty("/rows", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "search", this.onUpdateCard, this);
			$.sap.globalDate2 = new Date();

		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			this._getCardData(this.getCardProperty("/region"));
		},

		/*_onUpdateCardOld: function (finalRegion) {

			finalRegion = finalRegion;
			var oModel = new sap.ui.model.json.JSONModel();
			var aColumnData = [{
				columnId: "Name"
			}, {
				columnId: "Count"
			}];
			oModel.setData({
				columns: aColumnData,
				rows: []
			});
			var dbModel = this.getModel("mccDataManagerService");
			if (finalRegion === "EMEA" || finalRegion === "APJ" || finalRegion === "NA" || finalRegion === "LA") {
				var region;
				switch (finalRegion) {
				case "EMEA":
					region = "0003584574";
					break;
				case "APJ":
					region = "0003612380";
					break;
				case "NA":
					region = "0003612382";
					break;
				case "LA":
					region = "0009804549";
					break;
				}
				regionFilter = new sap.ui.model.Filter("activity_service_team", sap.ui.model.FilterOperator.EQ, region);
			}

			var that = this;
			//this.getView().byId("table-mcs-cctmonitor").setBusy(true);

			var model2 = this.getModel("agsDashboardService");
			var oFilter = [];

			if (finalRegion === "EMEA" || finalRegion === "APJ" || finalRegion === "NA" || finalRegion === "LA") {
				var rFilter = new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, finalRegion);
				oFilter.push(rFilter);
			}

			dbModel.read("/FioriovpDynamicListCards", {
				filters: oFilter,
				success: function (oResult1) {
					var oResult = oResult1;
					var arr = oResult.results;
					for (var i = 0; i < arr.length; i++) {
						var sUrl = arr[i].URL;
						var sFilter;
						var sEntity;
						if (sUrl.indexOf("CaseList/$count") !== -1) {
							sFilter = sUrl.slice(24);
							sEntity = "/CaseList/$count";
						} else if (sUrl.indexOf("ActivityList?$filter") !== -1) {
							sFilter = sUrl.slice(21);
							sEntity = "/ActivityList";
						} else {
							sFilter = sUrl.slice(28);
							sEntity = "/ActivityList/$count";
						}
						sFilter = sFilter.replace(/%27/gi, "'");
						sFilter = sFilter.replace(/%20/gi, " ");

						model2.read(sEntity, {
							urlParameters: {
								$filter: sFilter
							},
							success: that.validate(i, oModel, arr)
						});
					}

					var oTable = that.getView().byId("table-mcs-cctmonitor");
					oTable.setModel(oModel);
					this.setCardProperty("/customHeader/additionalCardTitle", " (" + oResult.results.length + ")");
					oTable.bindItems("/rows", function (index, context) {
						var scroll = that.getView().byId("s1");
						if (oResult.results.length > 9) {
							scroll.setHeight("31rem");
						}
						var obj = context.getObject();
						var row = new sap.m.ColumnListItem();
						row.addCell(new sap.m.Link({
							text: obj.name,
							href: obj.link,
							tooltip: obj.name,
							target: "_blank"
						}));
						row.addCell(new sap.m.Text({
							text: obj.count
						}));
						return row;
					});

					this.setCardSuccessState();
				}.bind(this),
				error: function (oError) {
					this.setCardErrorState();
				}.bind(this)

			});
		},*/

		//Method responsible for handling normal entries in the CCT monitor table and adding them to the JSON model
		/*validate: function (index, oModel, arr, oResult1) {
			return function (data) {
				var temp = oModel.getProperty("/rows");
				var entry = {
					name: arr[index].Title,
					count: data,
					link: arr[index].Link
				};
				temp.push(entry);
				oModel.setProperty("/rows", temp);
			};
		},*/

		onSelectionFinish: function (oEvent) {
			var aSelectedItems = oEvent.getParameter("selectedItems");
			var oTable = this.byId("table-mcs-cctmonitor");
			var aSticky = aSelectedItems.map(function (oItem) {
				return oItem.getKey();
			});
			oTable.setSticky(aSticky);
		},

		/*onToggleInfoToolbar: function (oEvent) {
			var oTable = this.byId("table-mcs-cctmonitor");
			oTable.getInfoToolbar().setVisible(!oEvent.getParameter("pressed"));
		},*/

		// Method responsible for refreshing the view every given time interval. this method gets called from the modelServices method
		// _updateCardEventBus: function (sChanel, oEvent, oData) {
		// 	var sRegion = oData.region;
		// 	this.setCardProperty("/rows", []);
		// 	this.setCardProperty("/region", sRegion);
		// 	this.setCardUpdateStartState();

		// 	this._getCardData(oData.region);
		// },

		_getCardData: function () {
			var sRegion = this.getCoreModel("workplaceModel").getProperty("/selectedProfileInstance/FilterValues/Region");
			var oDynamicValuesPromise = this._getDynamiceListCards(sRegion);

			oDynamicValuesPromise.then(function (aData) {
				this.setCardProperty("/rows", []);
				this.setCardProperty("/customHeader/additionalCardTitle", "(" + aData.length + ")");
				var aPromises = [];
				for (var i = 0; i < aData.length; i++) {
					var oPromise = this._getTableEntry(aData[i]);
					aPromises.push(oPromise);

					var aRows = this.getCardProperty("/rows");
					var entry = {
						name: aData[i].Title,
						link: aData[i].Link
					};
					aRows.push(entry);
					this.setCardProperty("/rows", aRows);
				}

				var scroll = this.getView().byId("s1");
				if (aData.length > 9) {
					scroll.setHeight("31rem");
				} else {
					scroll.setHeight("auto");
				}

				Promise.all(aPromises).then(function (oData) {
					this.setCardSuccessState();
				}.bind(this));
				//for loop use card model
			}.bind(this)).catch(function (oError) {
				this.setCardErrorState();
			}.bind(this));
		},

		_getDynamiceListCards: function (sRegion) {
			var dbModel = this.getModel("mccDataManagerService");
			var oFilter = [];
			if (sRegion === "EMEA" || sRegion === "APJ" || sRegion === "NA" || sRegion === "LA" || sRegion === "World") {
				var rFilter = new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.EQ, sRegion);
				oFilter.push(rFilter);
			}

			return new Promise(function (resolve, reject) {
				dbModel.read("/FioriovpDynamicListCards", {
					filters: oFilter,
					success: function (oResult) {
						resolve(oResult.results);
					}.bind(this),
					error: function (oError) {
						reject(oError);
					}.bind(this)

				});
			}.bind(this));

		},

		_getTableEntry: function (oEntry) {

			var oAgsDashBoardServiceModel = this.getModel("agsDashboardService");
			var sUrl = oEntry.URL;
			var sFilter;
			var sEntity;
			if (sUrl.indexOf("CaseList/$count") !== -1) {
				sFilter = sUrl.slice(24);
				sEntity = "/CaseList/$count";
			} else if (sUrl.indexOf("ActivityList?$filter") !== -1) {
				sFilter = sUrl.slice(21);
				sEntity = "/ActivityList";
			} else {
				sFilter = sUrl.slice(28);
				sEntity = "/ActivityList/$count";
			}
			sFilter = sFilter.replace(/%27/gi, "'");
			sFilter = sFilter.replace(/%20/gi, " ");

			var oPromise = new Promise(function (resolve, reject) {
				oAgsDashBoardServiceModel.read(sEntity, {
					urlParameters: {
						$filter: sFilter
					},
					success: function (data) {
						//	that.validate(i, oModel, array)
						resolve(data);
					},
					error: function (err) {
						reject(err);
					}

				});
			});

			oPromise.then(function (oData) {
				var aRows = this.getCardProperty("/rows");
				var oObject = this.findObjectByKey(aRows, "name", oEntry.Title);
				/*var entry = {
					name: oEntry.Title,
					count: oData,
					link: oEntry.Link
				};*/

				oObject.count = oData;
				//aRows.push(entry);
				this.setCardProperty("/rows", aRows);

			}.bind(this));

			return oPromise;

		},

		//Method responsible for navigation to the MDR dashboards on clicking on an entry in the CCT monitor table
		onSelectionChange: function (oEvent) {
			debugger;
			var oSelectedItem = oEvent.getParameter("listItem");
			var activityId = oSelectedItem.getBindingContext("Information").getObject().activity_id;
			var currentUrl = window.location.href;
			var relativeUrl =
				"/sap(bD1lbiZjPTAwMSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?saprole=ZSU_DEFAULT&crm-object-type=BT126_APPT&crm-object-action=B&crm-object-keyname=OBJECT_ID&crm-object-value=" +
				activityId;
			var urlICP = this.getView().getModel("i18n").getResourceBundle().getText("urlICPSAP");
			var urlICT = this.getView().getModel("i18n").getResourceBundle().getText("urlICTSAP");
			var url = urlICP + relativeUrl;
			if (currentUrl.includes("a44f228ad.dispatcher.hana.ondemand.com")) {
				//we are in test environment
				url = urlICT + relativeUrl;
			}
			var win = window.open(url, "_blank");
			win.focus();
		}
	});
});