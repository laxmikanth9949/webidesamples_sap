sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseCardController, Filter, FilterOperator) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.MyActivities.MyActivities", {
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			//register AttachChange event for binding change to update the card title when for example a column filter is applied		
			this.getView().byId("myActivitiesTable").getBinding("rows").attachChange(this.updateCardTitle.bind(this, "activities"));

			this.onUpdateCard();
			// this.setCardAutoRefresh(300000); // Autorefresh in ms - if card needs to be autorefreshed, set the time in ms

			/* YOUR CODE HERE */
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			
			var oPromise = this._getActivities(); 

			oPromise.then(function (aActivities) {
				if (aActivities && aActivities.length > 0) {
					/* YOUR CODE HERE */
					this.setCardProperty("/activities", aActivities);

					var aPromises = [];
					aActivities.forEach(function (oActivity) {
						var oActivityPromise = this._getCaseByActivity(oActivity.ActivityID);
						aPromises.push(oActivityPromise);
					}.bind(this));

					Promise.all(aPromises).then(function (oData) {
						this.setCardSuccessState();
					}.bind(this)).catch(function (oError) {
						console.log("[Card: My Activities] - Error: " + oError);
						this.setCardErrorState(oError);
					}.bind(this));

				} else {
					this.setCardProperty("/activities", []);
				    this.setCardNoDataState();
					this.setCardProperty("/customHeader/additionalCardTitle", "");
				}
			}.bind(this)).catch(function (oError) {
				this.setCardErrorState(oError);
			}.bind(this));

		},

		_getActivities: function () {
			var oAppDepModel = this.getModel("appDepModel");
			var sUserId = sap.ui.getCore().getModel("UserInfo").getProperty("/name");

			var aFilter = []; //filter=EmployeeResponsible%20eq%20%27D057452%27%20and%20(StatusID%20eq%20%27E0010%27%20or%20StatusID%20eq%20%27E0011%27%20or%20StatusID%20eq%20%27E0019%27)
			var oResponsibleFilter = new Filter("EmployeeResponsible", FilterOperator.EQ, sUserId);
			var oStatusFilter = new Filter({
				filters: [
					new Filter("StatusID", FilterOperator.EQ, "E0010"),
					new Filter("StatusID", FilterOperator.EQ, "E0011"),
					new Filter("StatusID", FilterOperator.EQ, "E0019")
				],
				and: false
			});
			aFilter.push(oResponsibleFilter);
			aFilter.push(oStatusFilter);

			return new Promise(function (resolve, reject) {
				oAppDepModel.read("/ActivitySet", {
					filters: aFilter,
					success: function (oData) {
						resolve(oData.results);
					},
					error: function (oError) {
						console.log(oError);
						reject(oError);
					}.bind(this)
				});
			}.bind(this));

		},

		_getCaseByActivity: function (iActivityId) {
			var oWorkbenchModel = this.getModel("workbenchModel");
			var oFilter = new Filter("ActivityID", FilterOperator.EQ, iActivityId);

			var oWorkbenchPromise = new Promise(function (resolve, reject) {
				oWorkbenchModel.read("/Issues", {
					filters: [oFilter],
					success: function (oData) {
						resolve(oData);
					}.bind(this),
					error: function (oError) {
						reject(oError);
					}

				});
			}.bind(this));

			oWorkbenchPromise.then(function (oData) {
				if (oData.results && oData.results.length > 0) {
					var aActivities = this.getCardProperty("/activities");
					var sActivityID = oData.results[0].ActivityID + "";
					var oActivity = this.findObjectByKey(aActivities, "ActivityID", sActivityID);
					oActivity.CaseID = oData.results[0].CaseID;
				}
			}.bind(this));

			return oWorkbenchPromise;

		},

		onLinkPress: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCaseId = this.getCardProperty(sBindingContextPath).CaseID;
			var sActivityId = oEvent.getSource().getText();
			if (sCaseId) {
				this.navToApp(
					this.getResourceBundle().getText("mccWorkbenchActivityTest", [sCaseId, sActivityId]),
					this.getResourceBundle().getText("mccWorkbenchActivityProd", [sCaseId, sActivityId]), {}, false);
			} else {

				this.navToApp(
					this.getResourceBundle().getText("ActivitySearchTest", [sActivityId]),
					this.getResourceBundle().getText("ActivitySearch", [sActivityId]), {}, false);
			}
		},

		onCaseIdPressed: function (oEvent) {

			this.navToApp(
				this.getResourceBundle().getText("mccWorkbenchTest", [oEvent.getSource().getText()]),
				this.getResourceBundle().getText("mccWorkbenchProd", [oEvent.getSource().getText()]), {}, false);
		}
	});
});