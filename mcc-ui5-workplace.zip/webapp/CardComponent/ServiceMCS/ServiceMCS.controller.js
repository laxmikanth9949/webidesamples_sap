sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel"
], function (BaseCardController, JSONModel) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.ServiceMCS.ServiceMCS", {

		// Initialize the view and make a call to the refresh method
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */
			this.onUpdateCard();
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function (regionFilter, finalRegion) { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count
			

			var oAppDepModel = this.getModel("appDepModel");
			
			var aFilters = [];
			var oFilterServiceTeam = new sap.ui.model.Filter("MainServiceTeam", sap.ui.model.FilterOperator.EQ, "0029029183");
			var oFilterStatusId = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter('StatusID', sap.ui.model.FilterOperator.EQ, "E0010"),
					new sap.ui.model.Filter('StatusID', sap.ui.model.FilterOperator.EQ, "E0011"),
					new sap.ui.model.Filter('StatusID', sap.ui.model.FilterOperator.EQ, "E0018"),
					new sap.ui.model.Filter('StatusID', sap.ui.model.FilterOperator.EQ, "E0019"),
					new sap.ui.model.Filter('StatusID', sap.ui.model.FilterOperator.EQ, "E0020"),
					new sap.ui.model.Filter('StatusID', sap.ui.model.FilterOperator.EQ, "E0021"),
					new sap.ui.model.Filter('StatusID', sap.ui.model.FilterOperator.EQ, "E0022"),
					new sap.ui.model.Filter('StatusID', sap.ui.model.FilterOperator.EQ, "E0023"),
					new sap.ui.model.Filter('StatusID', sap.ui.model.FilterOperator.EQ, "E0024"),
					new sap.ui.model.Filter('StatusID', sap.ui.model.FilterOperator.EQ, "E0025"),
				],
				and: false
			});
			
			aFilters.push(oFilterServiceTeam);
			aFilters.push(oFilterStatusId);
			oAppDepModel.read("/ActivitySet", {
				filters: aFilters,
				success: function(oData){
					this.setCardProperty("/data", oData.results);
					this.setCardProperty("/customHeader/additionalCardTitle", " (" + oData.results.length + ")");

					
					var scroll = this.getView().byId("s1");
					if (oData.results.length > 9) {
						scroll.setHeight("31rem");
					} else {
						scroll.setHeight("auto");
					}
					
					this.setCardSuccessState();
				}.bind(this),
				error: function(err){
					this.setCardErrorState();
				}.bind(this)
			}); 

			//set the filters according to the given region and set the json model to the view
			//param(finalRegion) region of which data should be loaded
			/*	if (finalRegion === "EMEA" || finalRegion === "APJ" || finalRegion === "NA" || finalRegion === "LA") {
					var region;
					switch (finalRegion) {
					case "EMEA":
						region = "0003584574";
						break;
					case "APJ":
						region = "0003612380";
						break;
					case "NA":
						region = "0003612382";
						break;
					case "LA":
						region = "0009804549";
						break;
					}
					regionFilter = new sap.ui.model.Filter("activity_service_team", sap.ui.model.FilterOperator.EQ, region);
				}
				regionFilter = new sap.ui.model.Filter("activity_service_team", sap.ui.model.FilterOperator.EQ, "29029183");
				$.sap.globalRegion = finalRegion;
				var oFilter = [];
				var model = this.getModel("agsDashboardService");
				var f1 = new sap.ui.model.Filter("activity_process_type", sap.ui.model.FilterOperator.EQ, "ZS31");*/
			//var st = new sap.ui.model.Filter("activity_service_team", sap.ui.model.FilterOperator.EQ, '0003584574');
			/*var fOpen1 = new sap.ui.model.Filter("activity_status", sap.ui.model.FilterOperator.EQ, "E0010");
			var fOpen2 = new sap.ui.model.Filter("activity_status", sap.ui.model.FilterOperator.EQ, "E0011");
			var fOpen = new sap.ui.model.Filter({
				filters: [fOpen1, fOpen2],
				and: false
			});
			oFilter.push(fOpen);
			oFilter.push(f1);
			if (regionFilter) {
				oFilter.push(regionFilter);
			}
			var oModel = new JSONModel();
			model.read("/ActivityList/", {
				filters: oFilter,
				$expand: "ActivityCases",
				success: function (oData) {
					var oResult = this.bubbleSort(oData);
					oModel.setData(oResult);
					this.getView().setModel(oModel, "Information");
					this.setCardProperty("/customHeader/additionalCardTitle", " (" + oData.results.length + ")");
					var scroll = this.getView().byId("s1");
					if (oData.results.length > 9) {
						scroll.setHeight("31rem");
					} else {
						scroll.setHeight("auto");
					}

					this.setCardSuccessState();
				}.bind(this),
				error: function (oError) {
					this.setCardErrorState();
				}.bind(this)
			});*/
		},

		//On selecting an activity in the table, navigate to the activity link in the CRM
		onSelectionChange: function (oEvent) {
			var sPath = oEvent.getParameters().rowBindingContext.sPath;
			var activityId = this.getModel("cardModel").getProperty(sPath).ActivityID;
			
			//var oSelectedItem = oEvent.getParameter("listItem");
			//var activityId = oSelectedItem.getBindingContext("cardModel").getObject().ActivityID;
			var currentUrl = window.location.href;
			var relativeUrl =
				"/sap(bD1lbiZjPTAwMSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?saprole=ZSU_DEFAULT&crm-object-type=BT126_APPT&crm-object-action=B&crm-object-keyname=OBJECT_ID&crm-object-value=" +
				activityId;
			var urlICP = this.getView().getModel("i18n").getResourceBundle().getText("urlICPSAP");
			var urlICT = this.getView().getModel("i18n").getResourceBundle().getText("urlICTSAP");
			var url = urlICP + relativeUrl;
			if (currentUrl.includes("a44f228ad.dispatcher.hana.ondemand.com")) {
				//we are in test environment
				url = urlICT + relativeUrl;
			}
			var win = window.open(url, "_blank");
			win.focus();
		},

		//Method for sorting activities by date
		bubbleSort: function (oResult) {
			var that = this;
			var n = oResult.results.length;
			for (var i = 0; i < n - 1; i++) {
				for (var j = 0; j < n - i - 1; j++) {
					if ((oResult.results[j].activity_create_date) > (oResult.results[j + 1].activity_create_date)) {
						var temp = oResult.results[j];
						oResult.results[j] = oResult.results[j + 1];
						oResult.results[j + 1] = temp;
					}
				}
			}
			return oResult.results;
		},

		onCustomerPressed: function (oEvent) {
			//var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			//var sCustomerId = this.getCardModel().getProperty(sBindingContextPath).CustomerR3No;
				
			var sPath = oEvent.getParameters().rowBindingContext.sPath;
			var sCustomerId = this.getModel("cardModel").getProperty(sPath).CustomerR3No;
			
			this.navToApp(
				this.getResourceBundle().getText("mccOneDashboardTest", [sCustomerId]),
				this.getResourceBundle().getText("mccOneDashboardProd", [sCustomerId]), {}, false);

		}
	});
});