sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"com/sap/mcc/workplace/CardComponent/CardFormatter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Icon"
], function (BaseCardController, CardFormatter, JSONModel, Icon) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.OpenEscRequests.OpenEscRequests", {

		CardFormatter: CardFormatter,

		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "search", this.onUpdateCard, this);

			//register AttachChange event for binding change to update the card title when for example a column filter is applied		
			this.getView().byId("table-mcs-openEscalationRequests").getBinding("rows").attachChange(this.updateCardTitle.bind(this, "data"));

		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			var finalRegion = this.getCoreModel("workplaceModel").getProperty("/selectedProfileInstance/FilterValues/Region");
			var oRegionFilter;
			if (finalRegion === "EMEA" || finalRegion === "APJ" || finalRegion === "NA" || finalRegion === "LA") {
				var region;
				switch (finalRegion) {
				case "EMEA":
					region = "0003584574";
					break;
				case "APJ":
					region = "0003612380";
					break;
				case "NA":
					region = "0003612382";
					break;
				case "LA":
					region = "0009804549";
					break;
				}
				oRegionFilter = new sap.ui.model.Filter("MainServiceTeam", sap.ui.model.FilterOperator.EQ, region);
			}
			var that = this;
			var oFilter = [];
			var fOpen1 = new sap.ui.model.Filter("StatusID", sap.ui.model.FilterOperator.EQ, "E0010");
			var fOpen2 = new sap.ui.model.Filter("StatusID", sap.ui.model.FilterOperator.EQ, "E0011");
			var fOpen3 = new sap.ui.model.Filter("ActivityType", sap.ui.model.FilterOperator.EQ, "ZS31");
			var oStatusFilter = new sap.ui.model.Filter({
				filters: [fOpen1, fOpen2],
				and: false
			});
			oFilter.push(fOpen3);
			oFilter.push(oStatusFilter);
			if (oRegionFilter) {
				oFilter.push(oRegionFilter);
			}

			this.setCardProperty("/busy", true);

			var sText1 = this.getView().getModel("i18n").getResourceBundle().getText("openEscaInProg");
			this.getModel("appDepModel").read("/ActivitySet", {
				filters: oFilter,
				urlParameters: {
					"$orderby": "ChangedAt desc"
				},
				success: function (oResult1) {
					var oResult = that.bubbleSort(oResult1);
					that.setCardProperty("/data", oResult.results);
					that.setCardProperty("/customHeader/additionalCardTitle", sText1 + " (" + oResult.results.length + ")");

					if (oResult.length === 0) {
						this.setCardNoDataState();
					} else {
						this.setCardSuccessState();
					}
				}.bind(this),
				error: function () {
					this.setCardErrorState();
				}.bind(this)
			});
		},

		bubbleSort: function (oResult) {
			var n = oResult.results.length;
			for (var i = 0; i < n - 1; i++) {
				for (var j = 0; j < n - i - 1; j++) {
					if ((oResult.results[j].activity_create_date) > (oResult.results[j + 1].activity_create_date)) {
						var temp = oResult.results[j];
						oResult.results[j] = oResult.results[j + 1];
						oResult.results[j + 1] = temp;
					}
				}
			}
			return oResult;
		},

		onAfterRendering: function () {
			var that = this;
			var oBinding = this.getView().byId("table-mcs-openEscalationRequests").getBinding("items");
			var sText1 = this.getView().getModel("i18n").getResourceBundle().getText("openEscaRequestsReg");
			if (oBinding) {
				oBinding.attachChange(function (sReason) {
					that.getView().byId("header").setText(sText1 + " (" + oBinding.getLength() + ")");
					var scroll = that.getView().byId("s1");
					if (oBinding.getLength() > 9) {
						scroll.setHeight("31rem");
					}
				});
			}
		},

		/*onSelectionFinish: function (oEvent) {
			var aSelectedItems = oEvent.getParameter("selectedItems");
			var oTable = this.byId("table-mcs-openEscalationRequests");
			var aSticky = aSelectedItems.map(function (oItem) {
				return oItem.getKey();
			});
			oTable.setSticky(aSticky);
		},*/

	/*	onLinkPress: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCaseId = this.getCardProperty(sBindingContextPath).CaseID;
			var sActivityId = oEvent.getSource().getText();
			if (sCaseId) {
				this.navToApp(
					this.getResourceBundle().getText("mccWorkbenchActivityTest", [sCaseId, sActivityId]),
					this.getResourceBundle().getText("mccWorkbenchActivityProd", [sCaseId, sActivityId]), {}, false);
			} else {

				this.navToApp(
					this.getResourceBundle().getText("ActivitySearchTest") + sActivityId,
					this.getResourceBundle().getText("ActivitySearch") + sActivityId, {}, false);
			}
		}, */
		
		onCustomerPressed: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCustomerId = this.getCardModel().getProperty(sBindingContextPath).CustomerR3No;
			
				this.navToApp(
					this.getResourceBundle().getText("mccOneDashboardTest", [sCustomerId]),
					this.getResourceBundle().getText("mccOneDashboardProd", [sCustomerId]), {}, false);
		},

		onSelectionChange: function (oEvent) {
			var sBindingContextPath = oEvent.getParameter("rowBindingContext").getPath();
			var sActivityId = this.getCardModel().getProperty(sBindingContextPath).ActivityID;
			
			this.navToApp(
					this.getResourceBundle().getText("ActivitySearchTest", [sActivityId]),
					this.getResourceBundle().getText("ActivitySearch", [sActivityId]), {}, false);
			
			
		}
	});
});