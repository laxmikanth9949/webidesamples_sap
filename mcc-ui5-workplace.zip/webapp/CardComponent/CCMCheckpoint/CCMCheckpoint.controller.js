sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	'sap/ui/export/Spreadsheet',
	'sap/ui/export/library',
	"com/sap/mcc/workplace/CardComponent/CardFormatter",
	"sap/ui/core/Fragment"
], function (BaseCardController, JSONModel, Filter, FilterOperator, Spreadsheet, exportLibrary, Formatter, Fragment) {
	"use strict";

	var EdmType = exportLibrary.EdmType;

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.CCMCheckpoint.CCMCheckpoint", {

		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header

			this.setCardProperty("/customHeader/action/right", [
				new sap.ui.core.Icon({
					visible: "{= !${/busy}}",
					src: "sap-icon://email",
					tooltip: "CCM Checkpoint Report Mail",
					press: [this.openMailTemplateFragement, this],
					color: "#FFFFFF"
				})
			]);

			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			this.setCardProperty("/visibleCQI", false);
			this.setCardProperty("/bQGateSelected", false);
			this.setCardProperty("/bNewQGate", true);

			this.setRequestAttachedFaild();

			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			this.setCardProperty("/busy", false);

			this.onUpdateCard();

			//register AttachChange event for binding change to update the card title when for example a column filter is applied		
			this.getView().byId("ccmtable").getBinding("rows").attachChange(this.updateCardTitle.bind(this, "data"));

			this._getMailTemplates();

			sap.ui.getCore().getEventBus().subscribe("FilterBar", "dataLoaded", this.onUpdateCard, this);
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "search", this.setCardUpdateStartState, this);
		},

		onSendEmailClick: function (oEvent) {
			var aSelectedItems = [];
			var oTable = this.byId("ccmtable");
			var aSelectedIndices = oTable.getSelectedIndices();

			var sSelectedTemplate = this.byId("template-selection").getSelectedButton().getText();

			//check if some rows are selected
			if (aSelectedIndices.length > 0) {
				aSelectedIndices.forEach(index => {
					var sPath = oTable.getContextByIndex(index).sPath;
					aSelectedItems.push(this.getModel("cardModel").getProperty(sPath));
				});

				var aMailTemplates = this.getModel("EmailTemplates").getProperty("/templates");
				if (sSelectedTemplate === "CCM Checkpoint Summary Mail") this.generateEmail("CCM_Checkpoint_Summary.msg", aSelectedItems,
					aMailTemplates);
				else if (sSelectedTemplate === "CCM Checkpoint Invitation Mail") this.generateEmail("CCM_Checkpoint_Planning.msg", aSelectedItems,
					aMailTemplates);

			} else {
				sap.m.MessageToast.show(this.getResourceBundle().getText("noSelectedRow"));
			}
		},

		_getMailTemplates: function () {
			var oWorkbenchModel = this.getModel("workbenchModel");
			var oFilter = new Filter("profile", FilterOperator.EQ, "mcc-ccm-checker");
			var oMailTemplatePromise = new Promise(function (resolve, reject) {
				oWorkbenchModel.read("/MailTemplates", {
					filters: [oFilter],
					urlParameters: {
						"$expand": "MailRoles"
					},
					success: function (oData) {
						resolve(oData.results);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			}.bind(this));

			oMailTemplatePromise.then(function (aMailTemplates) {
				var oMailTemplateModel = new JSONModel({
					templates: aMailTemplates
				});
				this.getView().setModel(oMailTemplateModel, "EmailTemplates");
			}.bind(this)).catch(function (oError) {
				console.log("Error loading Mail Templates: " + oError);
			});

		},

		getCCMCheckerTable(aSelectedCases, sTemplateName) {

			var style =
				"<style type='text/css'>.myTable { border-collapse:collapse;font-size: 14.5; width:100% } .myTable th { background-color:#0C7ECF;color:white; } .myTable td, .myTable th { padding:5px;border:1px solid #000; } </style>";
			var table = style + "<table class='myTable' style='font-family:Arial'><tr>";
			table += "<th>Case ID</th>";
			table += "<th>Case Title</th>";
			table += "<th>Customer Name</th>";
			table += "<th>Responsible Person</th>";
			table += "<th>No. QGates</th>";
			table += "<th>Service Team</th>";
			table += "<th>Region</th>";
			table += "<th>Top Issues (Open / Close)</th>";
			table += "<th>Issues (Open / Close) </th>";
			table += "<th>Open For</th>";
			table += "<th>Go Live</th>";
			table += "<th>Product Lines</th>";
			if (sTemplateName === "CCM_Checkpoint_Summary.msg") {
				table += "<th>No. QGates</th>";
				table += "<th>Last QGate</th>";
				table += "<th>QGate Note</th>";
				table += "<th>Next QGate</th>";
			}
			//	table += "<th>Further Links</th>"; //Further Links
			table += "</tr>";

			for (var i = 0; i < aSelectedCases.length; i++) {

				var currentCase = aSelectedCases[i];
				var sGoLive = " - ";
				var sLastQGateDate = "";
				var sNextQGateDate = "";
				var sNotes = "";
				var sNoQGates = "";
				if (currentCase.GoLive) {
					sGoLive = this.formatDateMail(currentCase.GoLive)
				};
				if (currentCase.lastQGateDate) {
					sLastQGateDate = this.formatDateMail(currentCase.lastQGateDate);
				};
				if (currentCase.nextQGateDate) {
					sNextQGateDate = this.formatDateMail(currentCase.nextQGateDate);
				};
				if (currentCase.MeetingNotes) {
					sNotes = currentCase.MeetingNotes;
				};
				if (currentCase.NoQGates) {
					sNoQGates = currentCase.NoQGates;
				};

				if (i % 2 === 1) {
					table += "<tr style='background: #eee'>";
				} else {
					table += "<tr>";
				}

				var sCaseURL = this.getCaseLink(currentCase.CaseID);
				var sWorkbenchURL = this.getWorkbenchLink(currentCase.CaseID);

				table += "<p><td><a href=" + sCaseURL + ">" + currentCase.CaseID + "</a> (<a href=" + sWorkbenchURL + ">WB</a>) </p></td>"

				table += "<td>" + currentCase.CaseTitle + "</td>"
				table += "<td>" + currentCase.CustomerName + "</td>"
				table += "<td>" + currentCase.ResponsiblePerson + "</td>"
				table += "<td>" + currentCase.NoQGates + "</td>"
				table += "<td>" + currentCase.ServiceTeamName + "</td>"
				table += "<td>" + currentCase.Region + "</td>"
				table += "<td>" + (currentCase.TopIssuesOpenClosed ? currentCase.TopIssuesOpenClosed : "") + "</td>"
				table += "<td>" + (currentCase.ActivitiesOpenClosed ? currentCase.ActivitiesOpenClosed : "") + "</td>"
				table += "<td>" + Formatter.getDaysSince(currentCase.CreateTime) + "</td>"
				table += "<td>" + sGoLive + "</td>"
				table += "<td>" + (currentCase.ProductLinesMerged ? currentCase.ProductLinesMerged : "") + "</td>"
				if (sTemplateName === "CCM_Checkpoint_Summary.msg") {
					table += "<td>" + sNoQGates + "</td>";
					table += "<td>" + sLastQGateDate + "</td>";
					table += "<td>" + sNotes + "</td>";
					table += "<td>" + sNextQGateDate + "</td>";
				}
				table += "</tr>"
			}

			table += "</table>";
			table = table.replace(/null/g, "");

			return new Promise((resolve, reject) => {
				if (aSelectedCases.length > 0) resolve(table);
				else reject("ERROR")
			});
		},

		getCCMCheckpointTemplate: function (aSelectedCases, oRecipients, sTemplateName) {
			return new Promise((resolve, reject) => {
				var oUserInfo = sap.ui.getCore().getModel("UserInfo");
				var sUserName = oUserInfo.getProperty("/firstName") + " " + oUserInfo.getProperty("/lastName");

				var pCCMCheckerTable = this.getCCMCheckerTable(aSelectedCases, sTemplateName);
				pCCMCheckerTable.then((sCCMCheckerTable) => {
					var body = {
						"variable replacement": [{
							"variable": "&lt;count_selected_ccm_cases&gt;",
							"replaceWith": "" + aSelectedCases.length
						}, {
							"variable": "&lt;table_selected_ccm_cases&gt;",
							"replaceWith": sCCMCheckerTable
						}, {
							"variable": "&lt;user_name&gt;",
							"replaceWith": sUserName
						}],
						"recipients": {
							"to": oRecipients.to,
							"cc": oRecipients.cc
						}
					}

					resolve(JSON.stringify(body));
				});
			});
		},

		generateEmail: function (sTemplateName, aSelectedItems, aMailTemplates) {
			this.getView().setBusy(true);

			var oTemplate;
			var aRecipientsSet = new Set();
			aMailTemplates.forEach(template => {
				if (template.TemplateName === sTemplateName) oTemplate = template;
			})

			var aSetRegions = new Set();
			aSelectedItems.forEach(function (oCase) {
				if (!(!oCase.ResponsibleMail || oCase.ResponsibleMail === "")) {
					//extract recipients from mail to put them to the recipients list (to)
					aRecipientsSet.add(oCase.ResponsibleMail);
				}
				if (oCase.Region) {
					aSetRegions.add(oCase.Region);
				}
			});

			var aMailRoles = oTemplate.MailRoles.results.filter(roles => roles.RoleType === "G");

			aSetRegions.forEach(function (sRegion) {
				aMailRoles = aMailRoles.concat(oTemplate.MailRoles.results.filter(roles => roles.region === sRegion && roles.RoleType === "R"));
			});

			var oRecipients = {
				"to": "",
				"cc": ""
			};

			// add case responsiblemail to mail recipient (to)
			aRecipientsSet.forEach(function (oCaseRecipient) {
				oRecipients.to = oRecipients.to + oCaseRecipient + "; ";
			});
			aMailRoles.forEach(function (MailRole) {
				if (MailRole.ToOrCC === "CC") {
					oRecipients.cc = oRecipients.cc + MailRole.Recipients + "; ";
				} else if (MailRole.ToOrCC === "To") {
					oRecipients.to = oRecipients.to + MailRole.Recipients + "; ";
				}

			});

			var getBody,
				sTemplatePath = "/dbmanager/getMailTemplate?filename=MCCWorkplace/";

			getBody = this.getCCMCheckpointTemplate(aSelectedItems, oRecipients, sTemplateName);
			sTemplatePath += sTemplateName;

			var that = this;
			getBody.then(function (body) {
				var templatePath = sTemplatePath; //MCCWorkbench%2Fmcc-cpc%2FEngagement_Closure.msg"; //MCCWorkplace/MCS_Business_Down_Report.msg

				var req = new XMLHttpRequest();

				req.open("POST", templatePath, true);
				req.setRequestHeader("Content-type", "application/json; charset=utf-8");
				req.responseType = "blob";
				req.onload = function (event) {
					if (req.status === 200) {
						var blob = req.response;
						var fileName = "";
						if (req.getResponseHeader("content-disposition")) {
							fileName = req.getResponseHeader("content-disposition").split("filename=")[1]; //req.getResponseHeader("filename");
						}
						if (window.navigator.msSaveOrOpenBlob) {
							window.navigator.msSaveOrOpenBlob(blob, fileName);
						} else {
							var link = document.createElement('a');
							link.href = window.URL.createObjectURL(blob);
							link.download = fileName;
							link.click();
						}
					} else {
						sap.m.MessageBox.error(
							"An error occured while generating the mail template.", {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Mail Generation Failed",
								onClose: function () {}
							}
						);
					}
					that.oView.setBusy(false);
				};

				req.send(body);
			});
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			// this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			//var aCases = this._getCardSpecificCases("CriticalCustomerMgmt");

			var oCasesLoaded = this._loadCases();

			oCasesLoaded.then(function (aData) {

				var aPromises = [];
				if (aData.length > 0) {
					var aPromises = [];
					this.getCQIScore("data", "mcs-ccm-global-manager");

					//do single expand requests due to performance improvements
					var oPromiseQGate = this._getCaseDetailsAppDepSrv("toQGate");
					aPromises.push(oPromiseQGate);
					var oPromiseActivity = this._getCaseDetailsAppDepSrv("toActivity");
					aPromises.push(oPromiseActivity);
					var oPromiseTopIssues = this._getCaseDetailsAppDepSrv("toTopIssue");
					aPromises.push(oPromiseTopIssues);
					var oPromiseCustomSet = this._getCaseDetailsAppDepSrv("toCustomSet");
					aPromises.push(oPromiseCustomSet);
					var oPromiseAffectedProduct = this._getCaseDetailsAppDepSrv("toAffectedProduct");
					aPromises.push(oPromiseAffectedProduct);

					//set success state when all requests have finished
					Promise.all(aPromises).then(function (oData) {
							this.setCardSuccessState();
						}.bind(this))
						.catch(function (oError) {
							// when any odata requests failed
							this.setCardErrorState();
						}.bind(this));

				}
			}.bind(this)).catch(function (oError) {
				console.log("[Open CCM Cases]: Request Failed " + oError);
			});

		},

		_loadCases: function () {
			var oZSAppDepModel = this.getModel("appDepModel");

			var aFilterBar = this.getFilterBarValues("CCMCheckpoint");
			var aFilters = [];
			aFilters = aFilters.concat(aFilterBar);
			var oFilterCaseType = new Filter('CaseType', FilterOperator.EQ, "ZS02");
			var oFilterCustomerType = new Filter("CustomerTypeID", FilterOperator.EQ, "ZSCUSTYP05");
			var oReasonFilter = new Filter("ReasonId", FilterOperator.EQ, "ENGA");

			var oStatusFilter = new Filter({
				filters: [
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 71
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 80
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 81
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 99
					})
				],
				and: false
			});

			//push filter to array
			aFilters.push(oReasonFilter);
			aFilters.push(oFilterCustomerType);
			aFilters.push(oFilterCaseType);
			aFilters.push(oStatusFilter);

			return new Promise(function (resolve, reject) {
				oZSAppDepModel.read("/CaseSet", {
					filters: aFilters,
					urlParameters: {
						"$expand": "toQGate"
					},
					success: function (oData) {
						if (oData.results && oData.results.length > 0) {
							oData.results.forEach(function (oCase) {
								oCase.Region = this._getRegion(oCase.ServiceOrg);
								oCase.CustomerType = this._getCustomerType(oCase.CustomerTypeID);
							}.bind(this));
							this.setCardProperty("/data", oData.results);

							//resolve promise to request additional information from ZS APP DEP SRV (CustomerTypeID)
							resolve(oData.results);
						} else {

							this.setCardNoDataState();
							// resolve promise with empty array --> no additinal data (CustomerTypeID) from ZS APP DEP SRV is requested
							resolve([]);
						}
					}.bind(this),
					error: function (oError) {
						this.setCardProperty("/customHeader/additionalCardTitle", "");
						this.setCardErrorState(oError);
						resolve(oError);
					}.bind(this)
				});
			}.bind(this));

		},

		_getCaseDetailsAppDepSrv: function (sExpandProperty) {
			var oZSAppDepModel = this.getModel("appDepModel");
			var aFilters = [];
			var oFilterCaseType = new Filter('CaseType', FilterOperator.EQ, "ZS02");
			var oFilterCustomerType = new Filter("CustomerTypeID", FilterOperator.EQ, "ZSCUSTYP05");

			var oStatusFilter = new Filter({
				filters: [
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 71
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 80
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 81
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 99
					})
				],
				and: false
			});
			aFilters.push(oFilterCaseType);
			aFilters.push(oFilterCustomerType);
			aFilters.push(oStatusFilter);

			var oUrlParameter = {};
			if (sExpandProperty) {
				oUrlParameter = {
					"$expand": sExpandProperty
				};
			}

			return new Promise(function (resolve, reject) {
				oZSAppDepModel.read("/CaseSet", {
					filters: aFilters,
					urlParameters: oUrlParameter,
					success: function (oData) {
						this._updateModel(oData.results);
						resolve(oData.results);
					}.bind(this),
					error: function (oError) {
						resolve(oError);
					}.bind(this)
				});
			}.bind(this));
		},

		_refreshQGateByCase: function (CaseId, CaseType, CaseObject) {
			var oZSAppDepModel = this.getModel("appDepModel");
			var sUrlPath = "/CaseSet(CaseID='" + CaseId + "',CaseType='" + CaseType + "',CaseObject='" + CaseObject + "')/toQGate"
			var sCaseId = CaseId;

			var oPromise = new Promise(function (resolve, reject) {
				oZSAppDepModel.read(sUrlPath, {
					success: function (oData) {
						resolve(oData);
					}.bind(this),
					error: function (oError) {
						reject(oError);
					}.bind(this)
				});
			}.bind(this));

			oPromise.then(function (oData) {
				var aData = this.getModel("cardModel").getProperty("/data");
				var oObject = this.findObjectByKey(aData, "CaseID", sCaseId);
				oObject.toQGate = oData;

				if (oData.results) {
					var iQGates = 0;

					if (oData.results.length > 0) {
						var aQGates = oData.results;
						iQGates = aQGates.length;
						// filter array for Status created
						var aNextQGates = aQGates.filter(oQGate => oQGate.Status === "I1700");
						// sort array by Qnumber and reverse it to get the latest value at fist place
						aNextQGates = aNextQGates.sort(function (a, b) {
							return parseInt(a.Qnumber) - parseInt(b.Qnumber);
						}).reverse();
						if (aNextQGates.length > 0) {
							oObject.nextQGateDate = aNextQGates[0].StartDate;
						}
						var aLastQGates = aQGates.filter(oQGate => oQGate.Status === "I1702");
						// sort array by qgate number
						aLastQGates = aLastQGates.sort(function (a, b) {
							return parseInt(a.Qnumber) - parseInt(b.Qnumber);
						}).reverse();
						if (aLastQGates.length > 0) {
							oObject.lastQGateDate = aLastQGates[0].FinishDate;
							oObject.SeverityTextColor = Formatter.formatLastQGateTextColor(aLastQGates[0].SeverityText);
							oObject.MeetingNotes = aLastQGates[0].Text;
						}
					}

					oObject.NoQGates = iQGates;
				}

				this.getModel("cardModel").refresh(true);

				// only close if Dialog will stay open				
				if (!this.getCardProperty("/bClose")) this.sortTable();

				sap.ui.core.BusyIndicator.hide();

				// if Save and Exit was pressed
				if (this.getCardProperty("/bClose")) {
					this.setCardProperty("/bClose", false);
					this.onCancelAddQGatesPressed();
				}
			}.bind(this))
		},

		// update the card model depending on which associated entity is expanded from root entity case 
		_updateModel: function (aResults) {
			var aData = this.getModel("cardModel").getProperty("/data");
			aResults.forEach(function (oCase) {
				var oObject = this.findObjectByKey(aData, "CaseID", oCase.CaseID);
				if (oObject) {
					// count 
					if (oCase.toQGate.results) {
						var iQGates = 0;

						if (oCase.toQGate.results.length > 0) {
							var aQGates = oCase.toQGate.results;
							iQGates = aQGates.length;
							// filter array for Status created
							var aNextQGates = aQGates.filter(oQGate => oQGate.Status === "I1700");
							// sort array by Qnumber and reverse it to get the latest value at fist place
							aNextQGates = aNextQGates.sort(function (a, b) {
								return parseInt(a.Qnumber) - parseInt(b.Qnumber);
							}).reverse();
							if (aNextQGates.length > 0) {
								oObject.nextQGateDate = aNextQGates[0].StartDate;
							}
							var aLastQGates = aQGates.filter(oQGate => oQGate.Status === "I1702");
							// sort array by qgate number
							aLastQGates = aLastQGates.sort(function (a, b) {
								return parseInt(a.Qnumber) - parseInt(b.Qnumber);
							}).reverse();
							if (aLastQGates.length > 0) {
								oObject.lastQGateDate = aLastQGates[0].FinishDate;
								oObject.SeverityTextColor = Formatter.formatLastQGateTextColor(aLastQGates[0].SeverityText);
								oObject.MeetingNotes = aLastQGates[0].Text;
							}
						}

						oObject.NoQGates = iQGates;
					}

					//count open / closed activities
					if (oCase.toActivity.results && oCase.toActivity.results.length > 0) {
						var iOpenActivities = 0;
						var iClosedActivities = 0;
						oCase.toActivity.results.forEach(function (oActivity) {
							//skip this --> Status = OBSOLETE
							if ((oActivity.CategoryID === 'ZYP' || oActivity.CategoryID === 'ZYO') && oActivity.StatusID !== "E0020") {

								if (oActivity.StatusID === "E0013" || oActivity.StatusID === "E0014") {
									iClosedActivities++;
								} else {
									iOpenActivities++;
								}
							}
						});
						oObject.ActivitiesOpenClosed = iOpenActivities + " / " + iClosedActivities;
					}

					if (oCase.toTopIssue.results && oCase.toTopIssue.results.length > 0) {
						var iOpenTopIssues = 0;
						var iClosedTopIssues = 0;
						oCase.toTopIssue.results.forEach(function (oTopIssue) {
							if (oTopIssue.StatusID === "E0012") {
								//skip this --> Status = Rejected
							} else if (oTopIssue.StatusID === "E0013") {
								iClosedTopIssues++;
							} else {
								iOpenTopIssues++;
							}
						});
						oObject.TopIssuesOpenClosed = iOpenTopIssues + " / " + iClosedTopIssues;
					}

					//merge all Products (AffectedProductText attributes into one single property "ProductLinesMerged" of case )
					if (oCase.toAffectedProduct.results && oCase.toAffectedProduct.results.length > 0) {
						var aProducts = oCase.toAffectedProduct.results;
						var aProductLines = [];
						var sIsMainProduct = "";
						aProducts.forEach(function (oProduct) {
							if (oProduct.IsMainProduct) {
								sIsMainProduct = oProduct.AffectedProductText;
							} else {
								aProductLines.push(oProduct.AffectedProductText);
							}
						});
						aProductLines = sIsMainProduct ? [sIsMainProduct].concat(aProductLines) : aProductLines;

						aProductLines = [...new Set(aProductLines)];
						//split all values with ", " and prevent the last value having a comma at the end
						if (aProductLines.length > 1) {
							oObject.ProductLinesMerged = aProductLines.slice(0, -1).join(', ') + ", " + aProductLines.slice(-1);
							if (aProductLines.length > 2) {
								oObject.ProductLinesMergedFormatted = "<p><strong>" + aProductLines.slice(0, 1) + ", </strong>" + aProductLines.slice(1, -1)
									.join(
										', ') + ", " + aProductLines.slice(-1) + "</p>";
							} else {
								oObject.ProductLinesMergedFormatted = "<p><strong>" + aProductLines.slice(0, 1) + ", </strong>" + aProductLines.slice(1, -1)
									.join(
										', ') + aProductLines.slice(-1) + "</p>";
							}
						} else if (sIsMainProduct) {
							oObject.ProductLinesMerged = aProductLines.toString();
							oObject.ProductLinesMergedFormatted = "<p><strong>" + aProductLines.toString() + "</strong></p>";
						} else {
							oObject.ProductLinesMerged = aProductLines.toString();
							oObject.ProductLinesMergedFormatted = "<p>" + aProductLines.toString() + "</p>";
						}
					}

					if (oCase.toCustomSet.results && oCase.toCustomSet.results.length > 0) {
						if (oCase.toCustomSet.results[0].Golive) {
							oObject.GoLive = oCase.toCustomSet.results[0].Golive;
						}
					}
				}
			}.bind(this));

			this.getModel("cardModel").refresh(true);
		},

		_getCustomerType: function (sCaseTypeID) {
			var sCasetype = "";
			switch (sCaseTypeID) {
			case 'ZSCUSTYP01':
				sCasetype = "PES Active";
				break;
			case 'ZSCUSTYP02':
				sCasetype = "PES Complete";
				break;
			case 'ZSCUSTYP03':
				sCasetype = " VIP";
				break;
			case 'ZSCUSTYP04':
				sCasetype = "CPC";
				break;
			case 'ZSCUSTYP05':
				sCasetype = "CCM";
				break;
			default:
				sCasetype = "";
				break;
			}

			return sCasetype;
		},

		_getRegion: function (sServiceOrg) {
			var sRegion = "";
			switch (sServiceOrg) {
			case "O 50008010":
				sRegion = "EMEA";
				break;
			case "O 50008134":
				sRegion = "APJ";
				break;
			case "O 50008167":
				sRegion = "NA";
				break;
			case "O 50008174":
				sRegion = "LA";
				break;
			}
			return sRegion;
		},

		//https://fiorilaunchpad.sap.com/sites#mcconedashboard-Display&/Customer/20088468
		onCustomerPressed: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCustomerId = this.getCardModel().getProperty(sBindingContextPath).CustomerR3No;

			this.navToApp(
				this.getResourceBundle().getText("mccOneDashboardTest", [sCustomerId]),
				this.getResourceBundle().getText("mccOneDashboardProd", [sCustomerId]), {}, false);

		},

		//https://fiorilaunchpad.sap.com/sites#mcconedashboard-Display&/Case/20088468
		onLinkPress: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCaseId = this.getCardModel().getProperty(sBindingContextPath).CaseID;

			this.navToApp(
				this.getResourceBundle().getText("mccOneDashboardTestCase", [sCaseId]),
				this.getResourceBundle().getText("mccOneDashboardProdCase", [sCaseId]), {}, false);
		},

		//https://fiorilaunchpad.sap.com/sites#mccworkbench-Display&/20081242
		//https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites#mccissuetracking-Display&/20088566
		onWorkbenchLinkPress: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCaseId = this.getCardModel().getProperty(sBindingContextPath).CaseID;

			this.navToApp(
				this.getResourceBundle().getText("mccWorkbenchTest", [sCaseId]),
				this.getResourceBundle().getText("mccWorkbenchProd", [sCaseId]), {}, false);
		},

		getWorkbenchLink: function (sCaseId) {
			var sHostname = window.location.hostname;
			var sURL = null;

			// SAP IT Cloud T - https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites
			if (sHostname.lastIndexOf("sapitcloudt") > -1 || sHostname.lastIndexOf("a44f228ad") > -1) {
				sURL = this.getResourceBundle().getText("mccWorkbenchTest", [sCaseId]);
			} else if (sHostname === "fiorilaunchpad.sap.com" || sHostname.lastIndexOf("a87daa223") > -1) {
				sURL = this.getResourceBundle().getText("mccWorkbenchProd", [sCaseId]);
			}

			return sURL;
		},

		getCaseLink: function (sCaseId) {
			var sHostname = window.location.hostname;
			var sURL = null;

			// SAP IT Cloud T - https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites
			if (sHostname.lastIndexOf("sapitcloudt") > -1 || sHostname.lastIndexOf("a44f228ad") > -1) {
				sURL = this.getResourceBundle().getText("mccOneDashboardTestCase", [sCaseId]);
			} else if (sHostname === "fiorilaunchpad.sap.com" || sHostname.lastIndexOf("a87daa223") > -1) {
				sURL = this.getResourceBundle().getText("mccOneDashboardProdCase", [sCaseId]);
			}

			return sURL;
		},

		onApplyQGatesPressed: function (oEvent) {
			if (this.validateInput()) {
				sap.ui.core.BusyIndicator.show();
				var sName = sap.ui.getCore().byId("qGateName-input").getValue();
				var dDate = sap.ui.getCore().byId("qGateDate-datePicker").getValue();
				var sStatus = sap.ui.getCore().byId("qGateStatus-select").getSelectedKey();
				var sRating = sap.ui.getCore().byId("qGateRating-select").getSelectedKey();
				var sText = sap.ui.getCore().byId("qGateText-input").getValue();

				// selected item table
				var table = sap.ui.getCore().byId("qGate-table");
				var sPath = table.getSelectedContextPaths()[0];
				var oQGate = oEvent.getSource().getModel("cardModel").getProperty(sPath);

				var sPathCase = oEvent.getSource().getParent().getParent().getElementBinding("cardModel").sPath;
				var oCase = oEvent.getSource().getParent().getParent().getModel("cardModel").getProperty(sPathCase);

				var newQGate = {
					Name: sName,
					Severity: sRating,
					FinishDate: dDate + "T00:00:00",
					StartDate: dDate + "T00:00:00",
					Status: sStatus,
					Text: sText
				};
				this._updateQGate(oQGate.RecordId, oQGate.ParentId, newQGate, oCase);
			}
		},

		onCancelAddQGatesPressed: function (oEvent) {
			this.setCardProperty("/bNewQGate", true);
			this.setCardProperty("/bQGateSelected", false);
			var oDialog = sap.ui.getCore().byId("qGate-dialog");
			oDialog.destroy();
		},

		onPressSave: function (oEvent) {
			var isNew = this.getCardProperty("/bNewQGate");
			var isSelected = this.getCardProperty("/bQGateSelected");

			// indicator to close dialog
			this.setCardProperty("/bClose", false);

			if (isNew) {
				this.onAddQGatePress(oEvent)
			} else if (isSelected) {
				this.onApplyQGatesPressed(oEvent)
			} else {
				// print error message here
			}
		},

		onPressSaveExit: function (oEvent) {
			// devide if Update or Add
			var isNew = this.getCardProperty("/bNewQGate");
			var isSelected = this.getCardProperty("/bQGateSelected");

			// indicator to close dialog
			this.setCardProperty("/bClose", true);

			if (isNew) {
				this.onAddQGatePress(oEvent)
			} else if (isSelected) {
				this.onApplyQGatesPressed(oEvent)
			} else {
				// print error message here
			}

			// close dialog
			this.onCancelAddQGatesPressed(oEvent);

		},

		onUnDoPress: function (oEvent) {
			// get the previous QGate
			var previousQGate = this.getCardProperty("/previousQGate");

			// here replace all field with the original data
			sap.ui.getCore().byId("qGateName-input").setValue(previousQGate.Name);
			sap.ui.getCore().byId("qGateDate-datePicker").setValue(this.formatDate(previousQGate.StartDate));

			if (previousQGate.Status === "I1700" || previousQGate.Status === "I1702") {
				sap.ui.getCore().byId("qGateStatus-select").setSelectedKey(previousQGate.Status);
			} else {
				sap.ui.getCore().byId("qGateStatus-select").setValue(previousQGate.StatusText);
			}

			if (previousQGate.Severity === "00100" || previousQGate.Severity === "00300" || previousQGate.Severity === "00001" ||
				previousQGate.Severity === "00050" || previousQGate.Severity === "00200") {
				sap.ui.getCore().byId("qGateRating-select").setSelectedKey(previousQGate.Severity);
			} else {
				sap.ui.getCore().byId("qGateRating-select").setValue(previousQGate.SeverityText);
			}
			sap.ui.getCore().byId("qGateText-input").setValue(previousQGate.Text);

		},

		uuidv4: function () {
			return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
				var r = Math.random() * 16 | 0,
					v = c == 'x' ? r : (r & 0x3 | 0x8);
				return v.toString(16);
			});
		},

		onNewQGatePress: function (oEvent) {
			// here clear all input fields
			this.clearFormular();
			// set status to Created
			var oStatusSelect = sap.ui.getCore().byId("qGateStatus-select");
			oStatusSelect.setSelectedKey("I1700");
			//set new qGate Property true 
			this.setCardProperty("/bNewQGate", true);
		},

		sortTable: function () {
			var table = sap.ui.getCore().byId("qGate-table");
			var aSorters = [];
			var oBinding = table.getBinding("items");
			aSorters.push(new sap.ui.model.Sorter("StartDate", false))

			oBinding.sort(aSorters);
		},

		onUpdateFinished: function (oEvent) {
			var item = oEvent.getSource().getAggregation("items")[0];
			oEvent.getSource().setSelectedItem(item, true, true);
		},

		onAddQGatePress: function (oEvent) {
			if (this.validateInput()) {
				sap.ui.core.BusyIndicator.show();

				// get parent id
				var sPathCase = oEvent.getSource().getParent().getParent().getElementBinding("cardModel").sPath;
				var oCase = oEvent.getSource().getParent().getParent().getModel("cardModel").getProperty(sPathCase);
				var sParentId = oCase.CaseGuid;
				var sCaseId = oCase.CaseID;

				// get Existing qGates
				var aQGates = oCase.toQGate.results;

				// determine QGate Number
				var QGateNumber = 0;
				if (aQGates && aQGates.length === 0) QGateNumber = 0;
				else {
					aQGates.forEach(function (object) {
						if (QGateNumber < parseInt(object.Qnumber)) QGateNumber = parseInt(object.Qnumber);
					});
					QGateNumber = QGateNumber + 1;
				}

				// check if number of existing QGate is below 5 
				if (aQGates.length < 5) {
					// get all the data

					// user id / status id / region
					var sName = sap.ui.getCore().byId("qGateName-input").getValue();
					var dDate = sap.ui.getCore().byId("qGateDate-datePicker").getValue();
					var sStatus = sap.ui.getCore().byId("qGateStatus-select").getSelectedKey();
					var sRating = sap.ui.getCore().byId("qGateRating-select").getSelectedKey();
					var sText = sap.ui.getCore().byId("qGateText-input").getValue();

					// build object
					var oQGate = {
						ParentId: sParentId,
						RecordId: this.uuidv4(),
						RefDocID: sCaseId,
						RefDocObject: "C",
						RefDocType: "ZS02",
						Qnumber: "" + QGateNumber,
						Status: sStatus,
						Name: sName,
						StartDate: dDate + "T00:00:00",
						FinishDate: dDate + "T00:00:00",
						Severity: sRating,
						Text: sText
					}

					// call function to create new qgate in service	
					this._createQGate(oQGate.RecordId, oQGate.ParentId, oQGate, oCase);

				} else {
					// exit
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show(this.getResourceBundle().getText("maxQGates"));
					console.log("Only 5 QGates allowed!")
				}
			}
		},

		onQGateSelectionChange: function (oEvent) {
			console.log("STOP HERE");
			var sPath = oEvent.getSource()._aSelectedPaths[0];
			var qGate = oEvent.getSource().getModel("cardModel").getProperty(sPath);
			//var qGateModel = new JSONModel();

			// to undo changes setCardProperty ----------------------------------
			// do a deep copy with Spread

			var previousQGate = {
				ParentId: qGate.ParentId,
				RecordId: qGate.RecordId,
				RefDocID: qGate.RefDocID,
				RefDocObject: qGate.RefDocObject,
				RefDocType: qGate.RefDocType,
				Qnumber: qGate.Qnumber,
				Status: qGate.Status,
				StatusText: qGate.StatusText,
				Name: qGate.Name,
				StartDate: qGate.StartDate,
				FinishDate: qGate.FinishDate,
				Severity: qGate.Severity,
				SeverityText: qGate.SeverityText,
				Text: qGate.Text
			}

			this.setCardProperty("/previousQGate", previousQGate);
			// ------------------------------------------------------------------

			//qGateModel.setData(qGate);
			//oEvent.getSource().getParent().setModel(qGateModel,"qGateModel");

			sap.ui.getCore().byId("qGateName-input").setValue(qGate.Name);
			sap.ui.getCore().byId("qGateDate-datePicker").setValue(this.formatDate(qGate.StartDate));

			if (qGate.Status === "I1700" || qGate.Status === "I1702") {
				sap.ui.getCore().byId("qGateStatus-select").setSelectedKey(qGate.Status);
			} else {
				sap.ui.getCore().byId("qGateStatus-select").setValue(qGate.StatusText);
			}

			if (qGate.Severity === "00100" || qGate.Severity === "00300" || qGate.Severity === "00001" || qGate.Severity === "00050" ||
				qGate.Severity === "00200") {
				sap.ui.getCore().byId("qGateRating-select").setSelectedKey(qGate.Severity);
			} else {
				sap.ui.getCore().byId("qGateRating-select").setValue(qGate.SeverityText);
			}
			sap.ui.getCore().byId("qGateText-input").setValue(qGate.Text);

			//here set all input fields

			this.setCardProperty("/bNewQGate", false);
			this.setCardProperty("/bQGateSelected", true);
		},

		_createQGate: function (RecordId, ParentId, oQGate, oCase) {
			var oZSAppDepModel = this.getModel("appDepModel");
			var sPath = "/QGateSet";
			var oCaseCopy = oCase;
			var oPromise = new Promise(function (resolve, reject) {
				oZSAppDepModel.create(sPath, oQGate, {
					success: function (oCreateQGate) {
						resolve(oCreateQGate);
					}.bind(this),
					error: function (oError) {
						reject(oError);
					}
				})
			}.bind(this));

			this.setCardProperty("/busy", true);
			oPromise.then(function (aDate) {
				sap.m.MessageToast.show(this.getResourceBundle().getText("saveSuccessfulQGate"));
				this.setCardProperty("/busy", false);
				this.setCardProperty("/bNewQGate", false);
				this._refreshQGateByCase(oCaseCopy.CaseID, oCaseCopy.CaseType, oCaseCopy.CaseObject);
			}.bind(this)).catch(function (oError) {
				this.setCardProperty("/busy", false);
				sap.ui.core.BusyIndicator.hide();
				this.setCardProperty("/error", false);
			}.bind(this));
		},

		_updateQGate: function (RecordId, ParentId, oQGate, oCase) {
			sap.ui.core.BusyIndicator.show();
			var oZSAppDepModel = this.getModel("appDepModel");
			var sPath = "/QGateSet(RecordId=guid'" + RecordId + "',ParentId=guid'" + ParentId + "')";
			var oCaseCopy = oCase;

			var oPromise = new Promise(function (resolve, reject) {
				oZSAppDepModel.update(sPath, oQGate, {
					success: function (oUpdateRecommendation) {
						resolve(oUpdateRecommendation);
					}.bind(this),
					error: function (oError) {
						reject(oError);
					}
				})
			}.bind(this));

			this.setCardProperty("/busy", true);
			oPromise.then(function (aData) {
				sap.m.MessageToast.show(this.getResourceBundle().getText("saveSuccessfulQGate"));
				this.setCardProperty("/busy", false);
				this._refreshQGateByCase(oCaseCopy.CaseID, oCaseCopy.CaseType, oCaseCopy.CaseObject);
			}.bind(this)).catch(function (oError) {
				this.setCardProperty("/busy", false);
				sap.m.MessageToast.show(this.getResourceBundle().getText("saveErrorQGate"));
				console.log(oError)
				this.setCardProperty("/error", false);
				sap.ui.core.BusyIndicator.hide();
			}.bind(this));
		},

		onDeleteQGate: function (oEvent) {

			var table = sap.ui.getCore().byId("qGate-table");
			var sPath = table.getSelectedContextPaths()[0];
			// TODO check if something is selected

			// get selected item
			var oSelectedQGate = this.getModel("cardModel").getProperty(sPath);

			// check if a qgate is selected
			if (oSelectedQGate) {
				sap.ui.core.BusyIndicator.show();
				// get RecordId and Parent Id
				var sRecordId = oSelectedQGate.RecordId;
				var sParentId = oSelectedQGate.ParentId;

				// generate path
				var sUrlPath = "/QGateSet(RecordId=guid'" + sRecordId + "',ParentId=guid'" + sParentId + "')";

				// get ZS APP DEP MODEL
				var oZSAppDepModel = this.getModel("appDepModel");

				// collect all CaseInformation
				var oCurrentCase = oEvent.getSource().getModel("cardModel").getProperty(oEvent.getSource().getBindingContext("cardModel").sPath);
				var oCaseInformation = {
					CaseID: oCurrentCase.CaseID,
					CaseType: oCurrentCase.CaseType,
					CaseObject: oCurrentCase.CaseObject
				};

				// delete qgate
				var oPromise = new Promise(function (resolve, reject) {
					oZSAppDepModel.remove(sUrlPath, {
						success: function () {
							resolve(oCaseInformation);
						}.bind(this),
						error: function (oError) {
							reject(oError);
						}
					})
				}.bind(this));

				this.setCardProperty("/busy", true);
				oPromise.then(function (oCase) {
					sap.m.MessageToast.show(this.getResourceBundle().getText("deleteSuccessfulQGate"));
					this.setCardProperty("/busy", false);
					this._refreshQGateByCase(oCase.CaseID, oCase.CaseType, oCase.CaseObject);
					oZSAppDepModel.refresh(true);
				}.bind(this)).catch(function (oError) {
					this.setCardProperty("/busy", false);
					sap.m.MessageToast.show(this.getResourceBundle().getText("deleteErrorQGate"));
					this.setCardProperty("/error", false);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this));

				// clear fomular
				this.clearFormular();
			} else {
				sap.m.MessageToast.show(this.getResourceBundle().getText("noSelectedRow"));
			}
		},

		clearFormular: function () {
			sap.ui.getCore().byId("qGateName-input").setValue("");
			sap.ui.getCore().byId("qGateDate-datePicker").setValue("");;
			sap.ui.getCore().byId("qGateStatus-select").setSelectedKey("");
			sap.ui.getCore().byId("qGateRating-select").setSelectedKey("");
			sap.ui.getCore().byId("qGateText-input").setValue("");
		},

		updateQGate: function (oEvent) {
			var oBindingPath = oEvent.getSource().getBindingContext("cardModel").getPath()
			var oSource = oEvent.getSource();
			Fragment.load({
				type: "XML",
				name: "com.sap.mcc.workplace.view.fragments.CCMCheckerTemplate",
				controller: this
			}).then(function (oDialog) {
				oDialog.setModel(this.getView().getModel("i18n"), "i18n");
				//oDialog.setBindingContext(oSource.getBindingContext("cardModel"), "cardModel");
				oDialog.bindElement({
					path: oBindingPath,
					model: "cardModel"
				});
				this.getView().addDependent(oDialog);

				oDialog.setTitle("Edit Q. Gates for Element: " + this.getCardProperty(oBindingPath).CaseID);

				oDialog.open();

				var table = sap.ui.getCore().byId("qGate-table")
				this.sortTable();
				var oFirstItem = table.getAggregation("items")[0];
				table.setSelectedItem(oFirstItem, true, true);

			}.bind(this))
		},

		formatDate: function (dDate) {
			var iMonth = dDate.getMonth() + 1;
			var date = dDate.getFullYear() + "-" + iMonth + "-" + dDate.getDate();
			return date;
		},

		formatDateMail: function (dDate) {
			var aUTCString = dDate.toUTCString().split(" ");
			var sFormattedDate = "" + aUTCString[2] + " " + aUTCString[1] + ", " + aUTCString[3];
			return sFormattedDate;
		},

		setRequestAttachedFaild: function () {
			var that = this;
			this.getModel("appDepModel").attachRequestFailed(function (oEvent) {
				var method = oEvent.getParameter("method");
				var err = oEvent.getParameter("response");
				var request = oEvent.getParameter("url");
				var DB = "CRM (APP DEP Service)";
				var service = "ZS_APP_DEP_SRV";
				if (method && request ) {
					var Set = request.split("(")[0];
					Set = Set.split("?")[0];
					if (method === "GET") {
						that.showErrorMsgRead(err, DB, Set, request, service, method);
					} else if (method === "POST") {
						that.showErrorMsgCreate(err, DB, Set, request, service, method);
					} else if (method === "DELETE") {
						that.showErrorMsgDelete(err, DB, Set, request, service, method);
					} else if (method === "MERGE") {
						that.showErrorMsgMerge(err, DB, Set, request, service, method);
					}
				}
			});
		},

		showErrorMsgRead: function (err, DB, Set, request, service, method) {
			var that = this;
			try {
				var Msg = JSON.parse(err.responseText).error.message.value;
			} catch (e) {
				try {
					var Msg = JSON.parse(err.responseText).error.message;
				} catch (e) {
					var Msg = $(err.responseText).find('message').first().text();
				}
			}

			var text = "An error occured while reading an entry from " + Set + " on " + DB + ". \n\n" + Msg;
			var error = {
				Method: method,
				RequestURL: request,
				CaseID: "",
				oDataService: service,
				ErrorMessage: Msg,
				ErrorStatusCode: err.statusCode.toString()
			};

			var addText = "";

			that.createDialog("Error during Read", text, addText);
		},

		showErrorMsgCreate: function (err, DB, Set, request, service, method) {
			try {
				var Msg = JSON.parse(err.responseText).error.message.value;
			} catch (e) {
				var Msg = $(err.responseText).find('message').first().text();
			}
			var that = this;

			var text = "An error occured while creating an entry on " + Set + " on " + DB + ".\n\n" + Msg;

			var error = {
				Method: method,
				RequestURL: request,
				CaseID: "",
				oDataService: service,
				ErrorMessage: Msg,
				ErrorStatusCode: err.statusCode.toString()
			};

			var addText = "";

			that.createDialog("Error during Create", text, addText);
		},

		showErrorMsgDelete: function (err, DB, Set, request, service, method) {
			try {
				var Msg = JSON.parse(err.responseText).error.message.value;
			} catch (e) {
				var Msg = $(err.responseText).find('message').first().text();
			}
			var that = this;

			var text = "An error occured while deleting an entry on " + Set + " on " + DB + ".\n\n" + Msg;

			var error = {
				Method: method,
				RequestURL: request,
				CaseID: "",
				oDataService: service,
				ErrorMessage: Msg,
				ErrorStatusCode: err.statusCode.toString()
			};

			var addText = "";

			that.createDialog("Error during Delete", text, addText);
		},

		showErrorMsgMerge: function (err, DB, Set, request, service, method) {
			try {
				var Msg = JSON.parse(err.responseText).error.message.value;
			} catch (e) {
				var Msg = $(err.responseText).find('message').first().text();
			}
			var that = this;

			var text = "An error occured while Updating an entry on " + Set + " on " + DB + ".\n\n" + Msg;

			var error = {
				Method: method,
				RequestURL: request,
				CaseID: "",
				oDataService: service,
				ErrorMessage: Msg,
				ErrorStatusCode: err.statusCode.toString()
			};

			var addText = "";

			that.createDialog("Error during Update", text, addText);
		},

		createDialog: function (title, text, addText) {
			var bAddText = true;
			if (addText === "") {
				bAddText = false;
			}

			var dialog = new sap.m.Dialog({
				title: title,
				icon: "sap-icon://error",
				state: "Error",
				titleAlignment: "Center",
				contentWidth: "600px",
				content: new sap.m.VBox({
					items: [
						new sap.m.Text({
							text: text
						}).addStyleClass("sapUiSmallMarginBeginEnd sapUiSmallMarginTop"),
						new sap.m.Button({
							text: "More Details",
							type: "Transparent",
							visible: bAddText,
							press: function (oEvent) {
								oEvent.getSource().getParent().getItems()[2].setVisible(true);
							}
						}).addStyleClass("sapUiTinyMargin"),
						new sap.m.Text({
							text: addText,
							visible: false,
							wrapping: true
						}).addStyleClass("sapUiSmallMarginBeginEnd sapUiSmallMarginBottom")
					]
				}),
				endButton: new sap.m.Button({
					text: "Close",
					press: function (oEvent) {
						oEvent.getSource().getParent().close();
						oEvent.getSource().getParent().destroy();
					}
				})
			});

			this.getView().addDependent(dialog);
			dialog.open();
		},

		validateInput: function () {
			var sName = sap.ui.getCore().byId("qGateName-input").getValue();
			var dDate = sap.ui.getCore().byId("qGateDate-datePicker").getValue();
			var sStatus = sap.ui.getCore().byId("qGateStatus-select").getSelectedKey();

			var bError = false;

			if (sName === "" || !sName) {
				sap.ui.getCore().byId("qGateName-input").setValueState(sap.ui.core.ValueState.Error);
				bError = true;
			} else {
				sap.ui.getCore().byId("qGateName-input").setValueState(sap.ui.core.ValueState.None);
			}
			if (dDate === "" || !dDate) {
				sap.ui.getCore().byId("qGateDate-datePicker").setValueState(sap.ui.core.ValueState.Error);
				bError = true;
			} else {
				sap.ui.getCore().byId("qGateDate-datePicker").setValueState(sap.ui.core.ValueState.None);
			}
			if (sStatus === "" || !sStatus) {
				sap.ui.getCore().byId("qGateStatus-select").setValueState(sap.ui.core.ValueState.Error);
				bError = true;
			} else {
				sap.ui.getCore().byId("qGateStatus-select").setValueState(sap.ui.core.ValueState.None);
			}

			return !bError;
		},

		openMailTemplateFragement: function (oEvent) {
			if (!this.oMailTemplateSelectionCCM) {
				Fragment.load({
					id: this.getView().getId(),
					name: "com.sap.mcc.workplace.view.fragments.MailTemplateSelectionCCMCheckpoint",
					controller: this
				}).then(function (oMailTemplateSelectionCCM) {
					this.oMailTemplateSelectionCCM = oMailTemplateSelectionCCM;

					this.getView().addDependent(this.oMailTemplateSelectionCCM);

					this.oMailTemplateSelectionCCM.open();
				}.bind(this));
			} else {
				this.oMailTemplateSelectionCCM.open();
			}

		},

		generateMailTemplate: function (oEvent) {
			this.onSendEmailClick(oEvent);
		}

	});
});