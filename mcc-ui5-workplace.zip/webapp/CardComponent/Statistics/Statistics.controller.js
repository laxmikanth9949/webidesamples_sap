sap.ui.define([
		"sap/m/MessageToast",
		"com/sap/mcc/workplace/CardComponent/BaseCardController"
	],
	function (MessageToast, BaseCardController) {
		"use strict";

		return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.Statistics.Statistics", {
			//Open MCS Dashboard when pressing on any of the statistics tiles
			press: function (oEvent) {
				var url = this.getView().getModel("i18n").getResourceBundle().getText("mcsDashboardURL");
				var win = window.open(url, "_blank");
				win.focus();
				MessageToast.show("The GenericTile is pressed.");
			},

			//Subscribe to the event bus for changes in the filter criteria, Initialize the view and make a call to the refresh method
			onInit: function (evt) {
				/* BEGIN: CARD INITIALIZATION */
				// add custom control to header
				this.setCardProperty("/customHeader/action/right", []);
				this.setCardProperty("/customHeader/action/left", []);
				this.setCardProperty("/customHeader/additionalCardTitle", []);
				// Initialize view and CardHeader
				BaseCardController.prototype.onInit.apply(this, arguments);
				/* END: CARD INITIALIZATION */

				/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

				sap.ui.getCore().getEventBus().subscribe("FilterBar", "search", this.onUpdateCard, this);
			
			},

			/**
			 * onUpdateCard is triggered for refreshing the data.
			 * IMPORTANT: the onUpdateCard method name cannot be modified
			 */
			onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
				// this.setCardUpdateStartState();
				this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

				var regionFilter, regionFilterCritSitDashboard;
				var finalRegion = this.getCoreModel("workplaceModel").getProperty("/selectedProfileInstance/FilterValues/Region");

				var model = this.getModel("mcsDashboardService");
				//var model2 = this.getModel("agsDashboardService");
				var oCritSitModel = this.getModel("critSitDBModel");
				if (finalRegion === "EMEA" || finalRegion === "APJ" || finalRegion === "NA" || finalRegion === "LA") {
					var region;
					var regionC;
					switch (finalRegion) {
					case "EMEA":
						region = "0003584574";
						regionC = "O 50008010";
						break;
					case "APJ":
						region = "0003612380";
						regionC = "O 50008134";
						break;
					case "NA":
						region = "0003612382";
						regionC = "O 50008167";
						break;
					case "LA":
						region = "0009804549";
						regionC = "O 50008174";
						break;
					}
					regionFilter = new sap.ui.model.Filter("activity_service_team", sap.ui.model.FilterOperator.EQ, region);
					regionFilterCritSitDashboard = new sap.ui.model.Filter("ServiceTeam", sap.ui.model.FilterOperator.EQ, region);
					var regionFilterC = new sap.ui.model.Filter("service_org", sap.ui.model.FilterOperator.EQ, regionC);
				}
				var that = this;
				// get first day and last day of current and previous year dynamically
				var cy = new Date();
				var dc = new Date(new Date().getFullYear(), 0, 1);
				var py = new Date();
				py.setDate(cy.getDate() - 365);
				var dp = new Date(py.getFullYear(), 0, 1);
				var tDate1 = new Date(py.getFullYear() - 1, 11, 31);
				var tDate = new Date(py.getFullYear(), 11, 31);
				//create local model	
				var oModel = new sap.ui.model.json.JSONModel();
				//filter setup
				var oFilter1 = [];
				var filterc = new sap.ui.model.Filter("case_type", sap.ui.model.FilterOperator.EQ, "ZS01");
				var filter = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
					that.printDate(dc), that.printDate(new Date()));
				var f1 = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP01");
				var f11 = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP06");
				var fS1 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "20");
				var fS2 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "30");
				var fS3 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "40");
				var fS4 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "60");
				var fOr = new sap.ui.model.Filter({
					filters: [fS1, fS2, fS3],
					and: false
				});
				var fOr1 = new sap.ui.model.Filter({
					filters: [fS1, fS2, fS3, fS4],
					and: false
				});
				var f12 = new sap.ui.model.Filter({
					filters: [f1, f11],
					and: false
				});
				oFilter1.push(filter);
				oFilter1.push(f12);
				if (regionFilterC) {
					oFilter1.push(regionFilterC);
				}
				oFilter1.push(fOr);
				var d1 = $.Deferred();
				var d2 = $.Deferred();
				var d22 = $.Deferred();
				var d3 = $.Deferred();
				var d4 = $.Deferred();
				var d44 = $.Deferred();
				var d5 = $.Deferred();
				var d6 = $.Deferred();
				var d66 = $.Deferred();
				var d7 = $.Deferred();
				var d8 = $.Deferred();
				var d9 = $.Deferred();
				var d10 = $.Deferred();
				var d11 = $.Deferred();
				var d12 = $.Deferred();
				var d122 = $.Deferred();

				/*	//set all generic tiles to busy 
					//global escalations
					var oGenericTileGE = this.getView().byId("genericTileGE");
					if (oGenericTileGE) {
						oGenericTileGE.setBusy(true);
					}
					
					//business downs
					var oGenericTileBD = this.getView().byId("genericTileBD");
					if (oGenericTileBD) {
						oGenericTileBD.setBusy(true);
					}
					//escalation requests
					var oGenericTileER = this.getView().byId("genericTileER");
					if (oGenericTileER) {
						oGenericTileER.setBusy(true);
					}
					//global escalations
					var oGenericTileGET = this.getView().byId("genericTileGET");
					if (oGenericTileGET) {
						oGenericTileGET.setBusy(true);
					}*/

				// perform the read
				model.read("/MCSDashboardSet/$count", {
					filters: oFilter1,
					success: function (oResult1) {
						d1.resolve(Number(oResult1));
					},
					error: function (oError) {
						d1.reject(oError);
					}
				});
				var oFilter2 = [];
				var date = new Date();
				var lastYear = new Date();
				lastYear.setDate(date.getDate() - 365);
				var filter2 = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
					that.printDate(dp), that.printDate(lastYear));
				oFilter2.push(filter2);
				oFilter2.push(f12);
				if (regionFilterC) {
					oFilter2.push(regionFilterC);
				}
				oFilter2.push(fOr);
				model.read("/MCSDashboardSet/$count", {
					filters: oFilter2,
					success: function (oResult) {
						d2.resolve(Number(oResult));
					},
					error: function (oError) {
						d2.reject(oError);
					}
				});
				var totalTime = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
					that.printDate(dp), that.printDate(tDate));
				var oFilter22 = [];
				oFilter22.push(totalTime);
				oFilter22.push(f12);
				if (regionFilterC) {
					oFilter22.push(regionFilterC);
				}
				oFilter22.push(fOr);
				model.read("/MCSDashboardSet/$count", {
					filters: oFilter22,
					success: function (oResult) {
						d22.resolve(Number(oResult));
					},
					error: function (oError) {
						d22.reject(oError);
					}
				});
				var sText1 = this.getView().getModel("i18n").getResourceBundle().getText("thisYear");
				var sText2 = this.getView().getModel("i18n").getResourceBundle().getText("lastYear");
				var sText3 = this.getView().getModel("i18n").getResourceBundle().getText("lastYearTotal");
				$.when(d1, d2, d22).done(function (v1, v2, v3) {
					var data = {
						"Data": [{
							"Title": sText1,
							"Last_Year": v1,
							"color": "Good"
						}, {
							"Title": sText2,
							"Last_Year": v2,
							"color": "Error"
						}, {
							"Title": sText3,
							"Last_Year": v3,
							"color": "Neutral"
						}]
					};
					// feed the information to the local model
					oModel.setData(data);
					// attach the model to the view
					that.getView().setModel(oModel, "Information");
					that.getView().byId("genericTileGE").setBusy(false);
				}).catch(function (oErrors) {
					this._setErrorMessageForTile("genericTileGE", oErrors);
				}.bind(this));
				// create local model 
				var oModel2 = new sap.ui.model.json.JSONModel();
				var oFilter3 = [];
				// filter setup
				var filter3 = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
					that.printDate(dc), that.printDate(new Date()));
				var f3 = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP02");
				var f31 = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP03");
				var f32 = new sap.ui.model.Filter({
					filters: [f3, f31],
					and: false
				});
				oFilter3.push(filter3);
				oFilter3.push(f32);
				oFilter3.push(fOr1);
				// perform the read
				model.read("/MCSDashboardSet/$count", {
					filters: oFilter3,
					success: function (oResult1) {
						d3.resolve(Number(oResult1));
					},
					error: function (oError) {
						d3.reject(oError);
					}
				});
				var oFilter4 = [];
				var date = new Date();
				var lastYear = new Date();
				lastYear.setDate(date.getDate() - 365);
				var filter4 = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
					that.printDate(dp), that.printDate(lastYear));
				oFilter4.push(filter4);
				oFilter4.push(f32);
				oFilter4.push(fOr1);
				model.read("/MCSDashboardSet/$count", {
					filters: oFilter4,
					success: function (oResult) {
						d4.resolve(Number(oResult));
					},
					error: function (oError) {
						d4.reject(oError);
					}
				});
				var oFilter44 = [];
				var filter44 = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
					that.printDate(dp), that.printDate(tDate));
				oFilter44.push(filter44);
				oFilter44.push(f32);
				oFilter44.push(fOr1);
				model.read("/MCSDashboardSet/$count", {
					filters: oFilter44,
					success: function (oResult) {
						d44.resolve(Number(oResult));
					},
					error: function (oError) {
						d44.reject(oError);
					}
				});
				var sText1 = this.getView().getModel("i18n").getResourceBundle().getText("thisYear");
				var sText2 = this.getView().getModel("i18n").getResourceBundle().getText("lastYear");
				var sText3 = this.getView().getModel("i18n").getResourceBundle().getText("lastYearTotal");
				$.when(d3, d4, d44).done(function (v1, v2, v3) {
					var data = {
						"Data": [{
							"Title": sText1,
							"Last_Year": v1,
							"color": "Good"
						}, {
							"Title": sText2,
							"Last_Year": v2,
							"color": "Error"
						}, {
							"Title": sText3,
							"Last_Year": v3,
							"color": "Neutral"
						}]
					};
					// feed the information to the local model
					oModel2.setData(data);
					// attach the model to the view
					that.getView().setModel(oModel2, "Information2");
					that.getView().byId("genericTileBD").setBusy(false);
				}).catch(function (oErrors) {
					this._setErrorMessageForTile("genericTileBD", oErrors);
				}.bind(this));

				// create local model 
				var oModel3 = new sap.ui.model.json.JSONModel();
				var oFilter5 = [];
				// filter setup
				var filter5 = new sap.ui.model.Filter("activity_create_date", sap.ui.model.FilterOperator.BT,
					that.createDate(that.printDate(dc)), new Date());
				var f5 = new sap.ui.model.Filter("activity_process_type", sap.ui.model.FilterOperator.EQ, "ZS31");
				if (regionFilter) {
					oFilter5.push(regionFilter);
				}
				oFilter5.push(filter5);
				oFilter5.push(f5);
				// perform the read
				/*model2.read("/ActivityList/$count", {
					filters: oFilter5,
					success: function (oResult1) {
						d5.resolve(Number(oResult1));
					}
				});*/

				var aFilterCurrentYear = [new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.BT, that.createDate(that.printDate(dc)),
					new Date())];
				if (regionFilterCritSitDashboard) {
					aFilterCurrentYear.push(regionFilterCritSitDashboard);
				}

				oCritSitModel.read("/GlobalEscalationRequestSet/$count", {
					filters: aFilterCurrentYear,
					success: function (oResult1) {
						d5.resolve(Number(oResult1));
					},
					error: function (err) {
						d5.reject(err);
					}
				});
				var oFilter6 = [];
				var date = new Date();
				var lastYear = new Date();
				lastYear.setDate(date.getDate() - 365);
				var filter6 = new sap.ui.model.Filter("activity_create_date", sap.ui.model.FilterOperator.BT,
					that.createDate(that.printDate(dp)), lastYear);
				if (regionFilter) {
					oFilter6.push(regionFilter);
				}
				/*oFilter6.push(filter6);
				oFilter6.push(f5);
				model2.read("/ActivityList/$count", {
					filters: oFilter6,
					success: function (oResult) {
						d6.resolve(Number(oResult));
					}
				});*/

				var aFilterCompareLastYear = [new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.BT, that.createDate(that.printDate(
					dp)), lastYear)];
				if (regionFilterCritSitDashboard) {
					aFilterCompareLastYear.push(regionFilterCritSitDashboard);
				}
				oCritSitModel.read("/GlobalEscalationRequestSet/$count", {
					filters: aFilterCompareLastYear,
					success: function (oResult1) {
						d6.resolve(Number(oResult1));
					},
					error: function (err) {
						d6.reject(err);
					}
				});
				var oFilter66 = [];
				var filter66 = new sap.ui.model.Filter("activity_create_date", sap.ui.model.FilterOperator.BT,
					that.createDate(that.printDate(dp)), tDate);
				oFilter66.push(filter66);
				oFilter66.push(f5);
				if (regionFilter) {
					oFilter66.push(regionFilter);
				}
				/*	model2.read("/ActivityList/$count", {
						filters: oFilter66,
						success: function (oResult) {
							d66.resolve(Number(oResult));
						}
					});*/

				var aFilterTotalLastYear = [new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.BT, that.createDate(that.printDate(
					dp)), tDate)];
				if (regionFilterCritSitDashboard) {
					aFilterTotalLastYear.push(regionFilterCritSitDashboard);
				}
				oCritSitModel.read("/GlobalEscalationRequestSet/$count", {
					filters: aFilterTotalLastYear,
					success: function (oResult1) {
						d66.resolve(Number(oResult1));
					},
					error: function (err) {
						d66.reject(err);
					}
				});
				var sText1 = this.getView().getModel("i18n").getResourceBundle().getText("thisYear");
				var sText2 = this.getView().getModel("i18n").getResourceBundle().getText("lastYear");
				var sText3 = this.getView().getModel("i18n").getResourceBundle().getText("lastYearTotal");
				$.when(d5, d6, d66).done(function (v1, v2, v3) {
					var data = {
						"Data": [{
							"Title": sText1,
							"Last_Year": v1,
							"color": "Good"
						}, {
							"Title": sText2,
							"Last_Year": v2,
							"color": "Error"
						}, {
							"Title": sText3,
							"Last_Year": v3,
							"color": "Neutral"
						}]
					};
					// feed the information to the local model
					oModel3.setData(data);
					// attach the model to the view
					that.getView().setModel(oModel3, "Information3");
					that.getView().byId("genericTileER").setBusy(false);
				}).catch(function (oErrors) {
					this._setErrorMessageForTile("genericTileER", oErrors);
				}.bind(this));
				// create local model		
				var oModel4 = new sap.ui.model.json.JSONModel();
				var oFilter1n = [];
				var filtern = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
					that.printDate(dc), that.printDate(new Date()));
				// filter setup	
				var filter1n = new sap.ui.model.Filter("closing_time", sap.ui.model.FilterOperator.BT,
					that.printDate(dc), that.printDate(new Date()));
				var fOpen1 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "20");
				var fOpen2 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "30");
				var fOpen = new sap.ui.model.Filter({
					filters: [fOpen1, fOpen2],
					and: false
				});
				var fOpenClosed = new sap.ui.model.Filter({
					filters: [fOpen, filter1n],
					and: false
				});
				var fOpenClosedCreated = new sap.ui.model.Filter({
					filters: [fOpenClosed, filtern],
					and: false
				});
				var thisYear = 0;
				var lastYear1 = 0;
				var f1n = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP01");
				var f11n = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP06");
				//var f2n = new sap.ui.model.Filter("service_org", sap.ui.model.FilterOperator.EQ, 'O 50008010');
				var f12n = new sap.ui.model.Filter({
					filters: [f1n, f11n],
					and: false
				});
				if (regionFilterC) {
					oFilter1n.push(regionFilterC);
				}
				oFilter1n.push(f12n);
				var closed = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "40");
				var creationTime = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
					that.printDate(dc), that.printDate(new Date()));
				oFilter1n.push(creationTime);
				model.read("/MCSDashboardSet/$count", {
					filters: oFilter1n,
					success: function (oResult1) {
						thisYear = thisYear + Number(oResult1);
						d7.resolve();
					},
					error: function (oError) {
						d7.reject(oError);
					}
				});
				oFilter1n = [];
				oFilter1n.push(f12n);
				if (regionFilterC) {
					oFilter1n.push(regionFilterC);
				}
				oFilter1n.push(closed);
				var creationTime1 = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
					"20120101000000", that.printDate(tDate));
				var closedTime = new sap.ui.model.Filter("closing_time", sap.ui.model.FilterOperator.BT,
					that.printDate(dc), that.printDate(new Date()));
				oFilter1n.push(creationTime1);
				oFilter1n.push(closedTime);
				model.read("/MCSDashboardSet/$count", {
					filters: oFilter1n,
					success: function (oResult1) {
						thisYear = thisYear + Number(oResult1);
						d8.resolve();
					},
					error: function (oError) {
						d8.reject(oError);
					}
				});
				var creationTime2 = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
					"20120101000000", that.printDate(tDate));
				oFilter1n = [];
				oFilter1n.push(creationTime2);
				oFilter1n.push(f12n);
				if (regionFilterC) {
					oFilter1n.push(regionFilterC);
				}
				oFilter1n.push(fOpen);
				model.read("/MCSDashboardSet/$count", {
					filters: oFilter1n,
					success: function (oResult1) {
						thisYear = thisYear + Number(oResult1);
						d9.resolve();
					},
					error: function (oError) {
						d9.reject(oError);
					}
				});
				oFilter1n = [];
				oFilter1n.push(f12n);
				if (regionFilterC) {
					oFilter1n.push(regionFilterC);
				}
				var closedO = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "40");
				var creationTimeO = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
					that.printDate(dp), that.printDate(py));
				oFilter1n.push(creationTimeO);
				var lastYear2 = 0;
				model.read("/MCSDashboardSet/$count", {
					filters: oFilter1n,
					success: function (oResult1) {
						lastYear1 = lastYear1 + Number(oResult1);
						d10.resolve();
					},
					error: function (oError) {
						d10.reject(oError);
					}
				});
				oFilter1n = [];
				oFilter1n.push(f12n);
				if (regionFilterC) {
					oFilter1n.push(regionFilterC);
				}
				var creationTimeOT = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
					that.printDate(dp), that.printDate(tDate));
				oFilter1n.push(creationTimeOT);
				model.read("/MCSDashboardSet/$count", {
					filters: oFilter1n,
					success: function (oResult1) {
						lastYear2 = lastYear2 + Number(oResult1);
						d122.resolve();
					},
					error: function (oError) {
						d122.reject(oError);
					}
				});
				oFilter1n = [];
				var creationTimeOld = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
					"20120101000000", that.printDate(tDate1));
				var closedTimeOld = new sap.ui.model.Filter("closing_time", sap.ui.model.FilterOperator.BT,
					that.printDate(dp), that.printDate(new Date()));
				oFilter1n.push(f12n);
				if (regionFilterC) {
					oFilter1n.push(regionFilterC);
				}
				oFilter1n.push(creationTimeOld);
				oFilter1n.push(closedTimeOld);
				model.read("/MCSDashboardSet/$count", {
					filters: oFilter1n,
					success: function (oResult1) {
						lastYear1 = lastYear1 + Number(oResult1);
						lastYear2 = lastYear2 + Number(oResult1);
						d11.resolve();
					},
					error: function (oError) {
						d11.reject(oError);
					}
				});
				oFilter1n = [];
				oFilter1n.push(f12n);
				if (regionFilterC) {
					oFilter1n.push(regionFilterC);
				}
				var creationTimeOld1 = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
					"20120101000000", that.printDate(tDate1));
				oFilter1n.push(fOpen);
				oFilter1n.push(creationTimeOld1);
				model.read("/MCSDashboardSet/$count", {
					filters: oFilter1n,
					success: function (oResult1) {
						lastYear1 = lastYear1 + Number(oResult1);
						lastYear2 = lastYear2 + Number(oResult1);
						d12.resolve();
					},
					error: function (oError) {
						d12.reject(oError);
					}
				});
				var sText1 = this.getView().getModel("i18n").getResourceBundle().getText("thisYear");
				var sText2 = this.getView().getModel("i18n").getResourceBundle().getText("lastYear");
				var sText3 = this.getView().getModel("i18n").getResourceBundle().getText("lastYearTotal");
				$.when(d7, d8, d9, d10, d11, d12).done(function () {
					var data = {
						"Data": [{
							"Title": sText1,
							"Last_Year": thisYear,
							"color": "Good"
						}, {
							"Title": sText2,
							"Last_Year": lastYear1,
							"color": "Error"
						}, {
							"Title": sText3,
							"Last_Year": lastYear2,
							"color": "Neutral"
						}]
					};
					// feed the information to the local model
					oModel4.setData(data);
					// attach the model to the view
					that.getView().setModel(oModel4, "Information4");
					that.getView().byId("genericTileGET").setBusy(false);
				}).catch(function (oErrors) {
					this._setErrorMessageForTile("genericTileGET", oErrors);
				}.bind(this));
			},

			_setErrorMessageForTile: function (sTileId, oError) {
				var oGenericTile = this.getView().byId(sTileId);
				var sErrorText = "Error - OData Request Failed";

				switch (oError.statusCode) {
				case '403':
					sErrorText = "No Authorization";
					break;
				case '404':
					sErrorText = "HTTP Error 404 - Ressource not Found";
					break;
				case '500':
					sErrorText = "HTTP Error 500 - Internal Server Error";
					break;
				}

				oGenericTile.setFailedText(sErrorText);
				oGenericTile.setState("Failed");
			},

			padStr: function (i) {
				return (i < 10) ? "0" + i : "" + i;
			},

			//Get the date in date format.
			//@returns a date in string format.
			printDate: function (temp) {
				var temp1 = new Date(temp);
				var dateStr = this.padStr(temp.getFullYear()) +
					this.padStr(1 + temp.getMonth()) +
					this.padStr(temp.getDate()) +
					this.padStr(temp.getHours()) +
					this.padStr(temp.getMinutes()) +
					this.padStr(temp.getSeconds());
				return (dateStr);
			},
			createDate: function (temp) {
				var year = temp.substring(0, 4);
				var month = temp.substring(4, 6);
				var day = temp.substring(6, 8);
				var hour = temp.substring(8, 10);
				var minute = temp.substring(10, 12);
				var seconds = temp.substring(12, 14);
				return new Date(year, month - 1, day, hour, minute, seconds);
			},

			// Destroy the timer on exiting the view
			onExit: function () {
				// You should stop the interval on exit. 
				// You should also stop the interval if you navigate out of your view and start it again when you navigate back. 
				if (this.intervalHandle) {
					clearInterval(this.intervalHandle);
				}
			},

			//@Method responsible for removing duplicates from an array
			arrayUnique: function (array) {
				var a = array.concat();
				for (var i = 0; i < a.length; ++i) {
					for (var j = i + 1; j < a.length; ++j) {
						if (a[i].case_id === a[j].case_id) {
							a.splice(j--, 1);
						}
					}
				}
				return a;
			},

			onCustomActionPress: function (oEvent) {
				var sText = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("globalFilterMessageToast");
				MessageToast.show(sText);
			},

			onGlobalViewIconPress: function (oEvent) {
				var sText = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("globalViewMessageToast");
				MessageToast.show(sText);
			}
		});
	});