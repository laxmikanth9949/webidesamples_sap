sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/ValueState",
	"sapit/controls/EmployeeSearchDialog",
	"sap/m/MessageBox",
	"sap/m/Token",
	"sap/m/MultiInput"
], function (BaseCardController, Filter, FilterOperator, Fragment, JSONModel, ValueState, EmployeeSearchDialog,
	MessageBox, Token, MultiInput) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.MyRecommendations.MyRecommendations", {

		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			//register AttachChange event for binding change to update the card title when for example a column filter is applied
			this._oTable = this.getView().byId("tableRecommendations");
			this._oTable.getBinding("rows").attachChange(this.updateCardTitle.bind(this, "recommendations"));

			this.onUpdateCard();
			// this.setCardAutoRefresh(300000); // Autorefresh in ms - if card needs to be autorefreshed, set the time in ms

			this._loadRecommendationDropdownValues().then(function (oValueHelp) {

				var oJSONModel = new JSONModel(oValueHelp);
				this.setModel(oJSONModel, "RecommendationModel");
			}.bind(this));

		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			var oPromiseRecommendations = this._getRecommendations();
			// this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			oPromiseRecommendations.then(function (aRecommendations) {
				// convert CaseID + RemcommendationID (CF OData Service - Integer value) to String to enhance column filtering (contains)				
				aRecommendations.forEach(function (oRecommendation) {
					oRecommendation.CaseID = oRecommendation.CaseID + "";
					oRecommendation.RecommendationsGiven = oRecommendation.RecommendationsGiven + "";
				});
				this.setCardProperty("/recommendations", aRecommendations);
				this.setCardSuccessState();

				var aPromises = [];
				aRecommendations.forEach(function (oRecommendation) {
					var oCaseDetailsPromise = this._getCaseDetails(oRecommendation.CaseID);
					aPromises.push(oCaseDetailsPromise);
				}.bind(this));

				//set success state when all requests have finished
				Promise.all(aPromises).then(function (oData) {
						this.setCardSuccessState();
						this.getCardModel().refresh(true);
					}.bind(this))
					.catch(function (oError) {
						// when any odata requests failed
						this.setCardErrorState();
					}.bind(this));

			}.bind(this)).catch(function (oError) {
				console.log("[My Recommendations]: Request Failed " + oError);
			});
		},

		_getRecommendations: function (aCustomFilter) {
			var aFilter = [];
			if (aCustomFilter) {
				aFilter = aCustomFilter;
			}
			var oWorkbenchModel = this.getModel("workbenchModel");
			var oFilter;
			return new Promise(function (resolve, reject) {
				var oPromise = this._getUserInfo();
				oPromise.then(function (oData) {
					var oUser = oData["name"];
					//var oFilter = new Filter("Status", FilterOperator.NE, "Completed");
				
					var oStatusFilter = new Filter({
								path: "Status",
								operator: FilterOperator.NE,
								value1: "Removed by Author"
							});
					var oFilter = new Filter({
						filters: [
							new Filter({
								path: "Responsible",
								operator: FilterOperator.EQ,
								value1: oUser
							}),
							new Filter({
								path: "createdBy",
								operator: FilterOperator.EQ,
								value1: oUser
							})
						],
						and: false
					});
					aFilter.push(oStatusFilter);
					aFilter.push(oFilter);
					
					oWorkbenchModel.read("/Recommendations", {
						filters: aFilter,
						success: function (oData, oResp) {
							resolve(oData.results);
						}.bind(this),
						error: function (oError) {
							this.setCardProperty("/customHeader/additionalCardTitle", "");
							this.setCardNoDataState();
							reject(oError);
						}.bind(this)
					});
				}.bind(this));
			}.bind(this));
		},

		_getCaseDetails: function (iCaseId) {
			var oAppDepModel = this.getModel("appDepModel");
			var oFilter = new Filter("CaseID", FilterOperator.EQ, "" + iCaseId); //CaseSet?$filter=%20CaseID%20eq%20%2720079821%27

			var oCaseDetails = new Promise(function (resolve, reject) {
				oAppDepModel.read("/CaseSet", {
					filters: [oFilter],
					urlParameters: {
						"$expand": "toAffectedProduct"
					},
					success: function (oData) {
						resolve(oData.results[0]);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			}.bind(this));

			oCaseDetails.then(function (oCase) {
				if (oCase) {
					var aData = this.getCardProperty("/recommendations");

					var aObjects = aData.filter(ele => ele.CaseID === iCaseId); //this.findObjectByKey(aData, "CaseID", iCaseId);
					aObjects.forEach(function (oObject) {

						oObject.CaseTitle = oCase.CaseTitle;
						oObject.ServiceOrgName = oCase.ServiceOrgName;
						oObject.ServiceTeamName = oCase.ServiceTeamName;
						oObject.StatusText = oCase.StatusText;
						oObject.CustomerName = oCase.CustomerName;
						oObject.CustomerR3No = oCase.CustomerR3No;
						if (oCase.toAffectedProduct && oCase.toAffectedProduct.results.length > 0) {
							var aProducts = oCase.toAffectedProduct.results;
							var aProductLines = [];
							var sIsMainProduct = "";
							aProducts.forEach(function (oProduct) {
								if (oProduct.IsMainProduct) {
									sIsMainProduct = oProduct.AffectedProductText;
								} else {
									aProductLines.push(oProduct.AffectedProductText);
								}
							});
							aProductLines = sIsMainProduct ? [sIsMainProduct].concat(aProductLines) : aProductLines;

							aProductLines = [...new Set(aProductLines)];
							//split all values with ", " and prevent the last value having a comma at the end
							if (aProductLines.length > 1) {
								oObject.ProductLinesMerged = aProductLines.slice(0, -1).join(', ') + ", " + aProductLines.slice(-1);
								if (aProductLines.length > 2) {
									oObject.ProductLinesMergedFormatted = "<p><strong>" + aProductLines.slice(0, 1) + ", </strong>" + aProductLines.slice(1, -
											1)
										.join(
											', ') + ", " + aProductLines.slice(-1) + "</p>";
								} else {
									oObject.ProductLinesMergedFormatted = "<p><strong>" + aProductLines.slice(0, 1) + ", </strong>" + aProductLines.slice(1, -
											1)
										.join(
											', ') + aProductLines.slice(-1) + "</p>";
								}
							} else if (sIsMainProduct) {
								oObject.ProductLinesMerged = aProductLines.toString();
								oObject.ProductLinesMergedFormatted = "<p><strong>" + aProductLines.toString() + "</strong></p>";
							} else {
								oObject.ProductLinesMerged = aProductLines.toString();
								oObject.ProductLinesMergedFormatted = "<p>" + aProductLines.toString() + "</p>";
							}
						}
					}.bind(this));
				}
			}.bind(this));

			return oCaseDetails;
		},

		updateRecommendation: function (oEvent) {
			var sBindingPath = oEvent.getSource().getBindingContext("cardModel").getPath()
			var oRecommendationObject = this.getCardProperty(sBindingPath);
			//format Tags to display them as items in the dialog
			//if Tags property is empty, just skip the creation
			if (oRecommendationObject.Tags && !Array.isArray(oRecommendationObject.Tags)) {
				var aRecommendationTokens = [];
				oRecommendationObject.Tags.split(",").forEach(function (item) {
					var oItem = {
						text: item
					};
					aRecommendationTokens.push(oItem);
				});
				this.getCardModel().getProperty(sBindingPath).TagsToken = aRecommendationTokens;
			}

			//property needed in order to distinguish if value has changed or change event is fired after initial loading
			this.setCardProperty("/dialogOpenInitialLoading", true);

			// use the sap it library to request the user name an display it at the recommendation dialog - modifiedBy 
			var sModifiedBy = this.getCardModel().getProperty(sBindingPath).modifiedBy;
			if (sModifiedBy) {
				this.getUserInfo(sModifiedBy).then(function (oData) {
					this.setCardProperty(sBindingPath + "/modifiedByName", oData);
				}.bind(this)).catch(function (oData) {
					//this.setCardProperty(sBindingPath).modifiedByName = "";
				}.bind(this));
			}

			// "Fragment" required from module "sap/ui/core/Fragment"
			var sFragmentId = this.getView().createId("addRecommendationDialog");
			Fragment.load({
				id: sFragmentId,
				type: "XML",
				name: "com.sap.mcc.workplace.view.fragments.Recommendation",
				controller: this
			}).then(function (oDialog) {
				this.oRecommendationDialog = oDialog;
				oDialog.setModel(this.getView().getModel("i18n"), "i18n");
				oDialog.setModel(this.getView().getModel("RecommendationModel"), "RecommendationModel");
				//	oDialog.setBindingContext(oEvent.getSource().getBindingContext("cardModel"), "cardModel");
				oDialog.bindElement({
					path: sBindingPath,
					model: "cardModel"
				});
				this.getView().addDependent(oDialog);
				this.createValidatorForMultiInput(sFragmentId, "tags");
				//manually fire the change event, such that the dependent dropdown refreshs itselfs after initial loading
				var oSelectedItem = Fragment.byId(sFragmentId, "type").getSelectedItem();
				if (oSelectedItem) {
					Fragment.byId(sFragmentId, "type").fireChange(oSelectedItem);
				}

				//set dialog title this.
				var sTitle = this.getResourceBundle().getText("editCaseRecommendationsTitle");
				if (this.getCardProperty(sBindingPath).ActivityID) {
					sTitle = this.getResourceBundle().getText("editIssueRecommendationsTitle");
				}
				oDialog.setTitle(sTitle);
				oDialog.open();

			}.bind(this));

			/*var sFragmentId = this.getView().createId(sProfileAlias + "FilterBarFragment");
						Fragment.load({
							id: sFragmentId,
							name: "com.sap.mcc.workplace.view.fragments.FilterBar",
							controller: this
						}).then(function (oFilterBar) {
							oScrollContainer.addContent(oFilterBar); // connect Fragment to ScrollContainer
							oScrollContainer.addContent(oGridContainer);
							oScrollContainer.addContent(oNoCardsFlexBox);
						});*/
		},

		/** 
		 * Create validators to create new multiInput Tokens.
		 * @private
		 * @param {string} sFragmentId fragment Id.
		 * @param {string} sControlId control Id.
		 * @returns {void}
		 */
		createValidatorForMultiInput: function (sFragmentId, sControlId) {
			var oMultiInput = Fragment.byId(sFragmentId, sControlId);
			if (oMultiInput) {
				var fValidator = function (args) {
					return new Token({
						text: args.text
					});

				};
				oMultiInput.addValidator(fValidator);
			}
		},

		onSaveRecommendationPressed: function (oEvent) {
			var oDialog = oEvent.getSource().getParent();
			var sBindingPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var oRecommendation = this.getCardProperty(sBindingPath);
			var sUserId = sap.ui.getCore().getModel("UserInfo").getProperty("/name");
			var oDateNow = new Date();
			var bValidation = true;
			var oUpdateEntry = {
				UID: oRecommendation.UID,
				modifiedAt: oDateNow,
				modifiedBy: sUserId,
			};
			/*if (oRecommendation.ActivityID) {
				oUpdateEntry.ActivityID = oRecommendation.ActivityID;
			}*/
			if (oRecommendation.TagsToken) {
				var tags = [];
				oRecommendation.TagsToken.forEach(function (item) {
					tags.push(item.text);
				});
				oUpdateEntry.Tags = tags.join(",");
				oRecommendation.Tags = tags.join(",");
			}
			if (oRecommendation.RecommendationType) {
				oUpdateEntry.RecommendationType = oRecommendation.RecommendationType;
			} else {
				bValidation = false;
			}
			if (oRecommendation.TargetResult) {
				oUpdateEntry.TargetResult = oRecommendation.TargetResult;
			} else if (!oRecommendation.TargetResult) {
				bValidation = false;
			}
			if (oRecommendation.ImprovementPotential) {
				oUpdateEntry.ImprovementPotential = oRecommendation.ImprovementPotential;
			} else {
				bValidation = false;
			}
			if (oRecommendation.ProposedMeasure) {
				oUpdateEntry.ProposedMeasure = oRecommendation.ProposedMeasure;
			} else {
				bValidation = false;
			}
			if (oRecommendation.Status) {
				oUpdateEntry.Status = oRecommendation.Status;
				//Prevent saving a due date when status is an end-value
				//When Recommendation status is set to either of end-values (e.g. Completed/ Discarded / Accepted / Rejected), the Due Date has to be reseted (set to empty)
				if (oRecommendation.Status.indexOf("In Process") === -1) {
					oUpdateEntry.DueDate = null;
					oRecommendation.DueDate = null;
				}
			} else {
				bValidation = false;
			}

			if (!oRecommendation.StatusReason && (oRecommendation.Status === "Discarded by Regional Owner" || oRecommendation.Status ===
					"Rejected by Global Owner")) {
				bValidation = false;
			} else if (oRecommendation.StatusReason && (oRecommendation.Status === "Discarded by Regional Owner" || oRecommendation.Status ===
					"Rejected by Global Owner")) {
				oUpdateEntry.StatusReason = oRecommendation.StatusReason;
			} else {
				oUpdateEntry.StatusReason = "";
			}

			if (oRecommendation.Responsible) {
				oUpdateEntry.Responsible = oRecommendation.Responsible;
			} else {
				oUpdateEntry.Responsible = "";
			}

			if (oRecommendation.ResponsibleName) {
				oUpdateEntry.ResponsibleName = oRecommendation.ResponsibleName;
			} else {
				oUpdateEntry.ResponsibleName = "";
			}

			if (oRecommendation.DueDate) {
				oUpdateEntry.DueDate = oRecommendation.DueDate;
			} else {
				oUpdateEntry.DueDate = null;
			}

			if (!oRecommendation.ResultDocumentation && oRecommendation.Status.indexOf("In Process") === -1) {
				bValidation = false;
			} else if (oRecommendation.Status.indexOf("In Process") === -1) {
				oUpdateEntry.ResultDocumentation = oRecommendation.ResultDocumentation;
			} else {
				oUpdateEntry.ResultDocumentation = "";
			}

			if (oRecommendation.Comments) {
				oUpdateEntry.Comments = oRecommendation.Comments;
			} else {
				oUpdateEntry.Comments = "";
			}

			//If validation fails, prevent from saving or creating
			if (!bValidation) {
				sap.m.MessageBox.error(
					this.getView().getModel("i18n").getResourceBundle().getText("MandatoryFields"), {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error"
					}
				);
				return;
			} else {
				var oWorkbenchModel = this.getModel("workbenchModel");
				var oPromise = new Promise(function (resolve, reject) {
					oWorkbenchModel.update("/Recommendations(guid'" + oRecommendation.UID + "')", oUpdateEntry, {
						success: function (oUpdateRecommendation, oStatus) {
							resolve({});
						}.bind(this),
						error: function (oError) {
							reject(oError);
						}
					});
				}.bind(this));

				oPromise.then(function (oData) {
					sap.m.MessageToast.show(this.getResourceBundle().getText("saveSuccessful"));
					oDialog.destroy();
					//this.getCardModel().refresh();
					this.onUpdateCard();
					//update Recommendation in table
					oRecommendation.modifiedAt = oDateNow;
					oRecommendation.modifiedBy = sUserId;

				}.bind(this)).catch(function (oError) {
					console.log("Error: Update Recommendation " + oError);
				}.bind(this));
			}

		},

		onCancelAddRecommendationPressed: function (oEvent) {
			var oDialog = this.oRecommendationDialog;//oEvent.getSource().getParent();
			var sBindingPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var oRecommendation = this.getCardProperty(sBindingPath);
			var sUID = oRecommendation.UID;
			var oFilter = new Filter("UID", FilterOperator.EQ, sUID);
			this._getRecommendations([oFilter]).then(function (oData) {
				var oObject = this.getCardProperty(sBindingPath);
				oObject.Tags = oData[0].Tags;
				delete oObject.TagsToken;
				oObject.RecommendationType = oData[0].RecommendationType;
				oObject.TargetResult = oData[0].TargetResult;
				oObject.Status = oData[0].Status;
				oObject.StatusReason = oData[0].StatusReason;
				oObject.ImprovementPotential = oData[0].ImprovementPotential;
				oObject.ProposedMeasure = oData[0].ProposedMeasure;
				oObject.Responsible = oData[0].Responsible;
				oObject.ResponsibleName = oData[0].ResponsibleName;
				oObject.DueDate = oData[0].DueDate;
				oObject.ResultDocumentation = oData[0].ResultDocumentation;
				oObject.Comments = oData[0].Comments;

				this.setCardProperty(sBindingPath, oObject);

			}.bind(this)).catch(function (oErr) {
				this.onUpdateCard();
			}.bind(this)).finally(function () {

				oDialog.destroy();
			}.bind(this));
		},

		onStatusChange: function (oEvent) {
			var sBindingPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var oRecommendation = this.getCardProperty(sBindingPath);
			//When Recommendation status is set to either of end-values (e.g. Completed/ Discarded / Accepted / Rejected), the Due Date has to be reseted (set to empty)
			if (oRecommendation.Status.indexOf("In Process") === -1) {

				oRecommendation.DueDate = null;
			}
		},

		onLinkPress: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCustomerId = this.getCardModel().getProperty(sBindingContextPath).CaseID;
			this.navToApp(
				this.getResourceBundle().getText("mccWorkbenchTest", [sCustomerId]),
				this.getResourceBundle().getText("mccWorkbenchProd", [sCustomerId]), {}, false);
		},

		/**
		 * Called from RecommendationBuilder
		 * Loads dropdown values for recommendation dialog
		 * @memberOf com.sap.mcc.IssueTracking.mccissuetracking.util.LoadData
		 * @param {object} that
		 * @param {object} oFilter The filter object for the request
		 * @returns {promise} The promise of the read request
		 */
		_loadRecommendationDropdownValues: function () {
			return new Promise(function (resolve, reject) {
				var aFilter = [new Filter({
					filters: [
						new Filter("DropdownName", FilterOperator.StartsWith, "Recommendation-Dropdown"),
						new Filter("DropdownName", FilterOperator.NotEndsWith, "-Inactive"),
					],
					and: true
				})]
				this.getModel("workbenchModel").read("/DropdownValues", {
					filters: aFilter,
					success: function (oData) {
						var aStatusDropDown = [];
						var aTypeDropDown = [];
						var aStatusReasonDropDown = [];
						//var aTargetResultDropDown = [];
						//var aOrganizationDropdown = [];
						oData.results.forEach(function (oEntry) {
							if (oEntry.DropdownName.indexOf("Type") > 0) {
								aTypeDropDown.push(oEntry);
							} else if (oEntry.DropdownName.indexOf("StatusReason") > 0) {
								aStatusReasonDropDown.push(oEntry);
							} else if (oEntry.DropdownName.indexOf("Status") > 0) {
								aStatusDropDown.push(oEntry);
								// } else if (oEntry.DropdownName.indexOf("TargetResult") > 0) {
								// 	aTargetResultDropDown.push(oEntry);
							}

							/*else if (oEntry.DropdownName.indexOf("Organization") > 0) {
								aOrganizationDropdown.push(oEntry);
							}*/
						});
						var oObject = {};
						oObject.ValueHelpStatus = aStatusDropDown;
						oObject.ValueHelpType = aTypeDropDown;
						aTypeDropDown.reverse();
						oObject.ValueHelpStatusReason = aStatusReasonDropDown;
						//oObject.ValueHelpTargetResult = aTargetResultDropDown;
						//oObject.ValueHelpOrganization = aOrganizationDropdown;
						resolve(oObject);
					}.bind(this),
					error: function (err) {
						reject();
					}
				});
			}.bind(this));
		},

		onValueListHelper: function (oEvent) {
			//If the Type value get changes, the value of the Status field should be reset to “In Process by Regional Owner”
			var bDialogOpenInitialLoading = this.getCardProperty("/dialogOpenInitialLoading");
			var sBindingPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var oBindingObject = this.getCardProperty(sBindingPath);
			if (!bDialogOpenInitialLoading) {
				oBindingObject.Status = "In Process by Regional Owner";
				oBindingObject.TargetResult = "";
			}
			this.setCardProperty("/dialogOpenInitialLoading", false);

			var selectedKey = oEvent.getSource().mProperties.selectedKey;

			var aFilter = [new Filter({
				filters: [
					new Filter("DropdownName", FilterOperator.StartsWith, "Recommendation-Dropdown"),
					new Filter("DropdownName", FilterOperator.NotEndsWith, "-Inactive"),
				],
				and: true
			})];

			this.getModel("workbenchModel").read("/DropdownValues", {
				filters: aFilter,
				success: function (oData) {
					var aTargetResultDropDown = [];
					oData.results.forEach(function (oEntry) {
						if ((oEntry.DropdownName.indexOf("TargetResult") >= 0) && (oEntry.DropdownValue.indexOf(selectedKey) >= 0)) {
							aTargetResultDropDown.push(oEntry);
						}
					});
					this.getView().getModel("RecommendationModel").setProperty("/ValueHelpTargetResult", aTargetResultDropDown);
				}.bind(this),
				error: function (err) {}
			});
		},

		formatRecomTargetResult: function (text) {
			if (text !== null) {
				var formatted = text.substring(text.indexOf("-") + 2, text.length);
				return formatted;
			} else {
				return "";
			}
		},

		/**
		 * Fired by information buttons in the recommendation dialog
		 * Opens popover with correct information text
		 * @memberOf com.sap.mcc.IssueTracking.mccissuetracking.util.RecommendationBuilder
		 * @param {object} oEvent
		 */
		onOpenRecommendationPopover: function (oEvent, sText) {
			var oButton = oEvent.getSource();
			var sText;
			if (oButton.getId().indexOf("tagsPopoverButton") > -1) {
				sText = "{i18n>TagsInfoText}";
			} else if (oButton.getId().indexOf("typePopoverButton") > -1) {
				sText = "{i18n>RecomTypeInfoText}";
			} else if (oButton.getId().indexOf("targetPopoverButton") > -1) {
				sText = "{i18n>targetResultInfoText}";
			} else if (oButton.getId().indexOf("improvementPopoverButton") > -1) {
				sText = "{i18n>ImprovementInfoText}";
			} else if (oButton.getId().indexOf("measurePopoverButton") > -1) {
				sText = "{i18n>MeasureInfoText}";
			} else if (oButton.getId().indexOf("statusPopoverButton") > -1) {
				sText = "{i18n>StatusInfoText}";
			} else if (oButton.getId().indexOf("resultdocPopoverButton") > -1) {
				sText = "{i18n>ResultDocInfoText}";
			} else if (oButton.getId().indexOf("respReasonPopoverButton") > -1) {
				sText = "{i18n>ResponsibleInfoText}";
			} else if (oButton.getId().indexOf("ReasonPopoverButton") > -1) {
				sText = "{i18n>ReasonInfoText}";
			} else if (oButton.getId().indexOf("commentPopoverButton") > -1) {
				sText = "{i18n>CommentInfoText}";
			} else if (oButton.getId().indexOf("dueDatePopoverButton") > -1) {
				sText = "{i18n>DueDateInfoText}";
			}

			// create popover
			this._oPopover = new sap.m.Popover({
				showHeader: false,
				placement: "HorizontalPreferredRight",
				content: [new sap.m.Text({
					text: sText,
					width: "20rem"
				}).addStyleClass("padding1rem")]
			})
			this.getView().addDependent(this._oPopover);
			this._oPopover.openBy(oButton);
		},

		onRecTokenUpdate: function (oEvent) {
			var sType = oEvent.getParameter("type");
			var aAddedTokens = oEvent.getParameter("addedTokens");
			var aRemovedTokens = oEvent.getParameter("removedTokens");
			var sBindingPath = oEvent.getSource().getBindingContext("cardModel").getPath()
			var aContexts = this.getCardProperty(sBindingPath).TagsToken;
			if (!aContexts) {
				aContexts = [];
			}
			console.log(aContexts);
			switch (sType) {
				// add new context to the data of the model, when new token is being added
			case "added":
				aAddedTokens.forEach(function (oToken) {
					aContexts.push({
						text: oToken.getText()
					});
				});
				break;
				// remove contexts from the data of the model, when tokens are being removed
			case "removed":
				aRemovedTokens.forEach(function (oToken) {
					aContexts = aContexts.filter(function (oContext) {
						return oContext.text !== oToken.getText();
					});
				});
				break;
			default:
				break;
			}
			this.getCardProperty(sBindingPath).TagsToken = aContexts;
		},

		handleDatePickerChange: function (oEvent) {
			var sBindingPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var oRecommendation = this.getCardProperty(sBindingPath);

			var oDP = oEvent.getSource(),
				bValid = oEvent.getParameter("valid");

			if (bValid) {
				oDP.setValueState(ValueState.None);
				var oDateValue = oDP.getDateValue();
				var sMonth = oDateValue.getMonth() + 1;
				sMonth = ("0" + sMonth).slice(-2);
				var sDate = ("0" + oDateValue.getDate()).slice(-2);
				var sDateString = oDateValue.getFullYear() + "-" + sMonth + "-" + sDate + "T00:00:00.0000000Z";
				oRecommendation.DueDate = new Date(sDateString);
			} else {
				delete oRecommendation.DueDate;
				oDP.setValueState(ValueState.Error);
			}
		},

		onEmployeeSelected: function (oEvent) {
			var sBindingContextPath = this.getView().byId(this.getView().createId("addRecommendationDialog--addRecommendationDialog")).getBindingContext(
				"cardModel").getPath();
			var oBindingObject = this.getCardProperty(sBindingContextPath);
			var oUserValues = oEvent.getParameter("value");
			var sUserId = oUserValues.id;
			var sUserName = oUserValues.firstName + " " + oUserValues.lastName;
			oBindingObject.Responsible = sUserId;
			oBindingObject.ResponsibleName = sUserName;
			this.setCardProperty(sBindingContextPath, oBindingObject);
		},

		onEmployeeSearch: function (oEvent) {
			var sHostname = window.location.hostname;
			if (sHostname.lastIndexOf("sapitcloudt") > -1 || sHostname.lastIndexOf("fiorilaunchpad.sap.com") > -1) {
				var oDialog = new EmployeeSearchDialog({liveSearch: false});
				oDialog.attachConfirm(this.onEmployeeSelected.bind(this));
				oDialog.open();
			} else {
				MessageBox.warning("Please open the MCC Workplace in the SAP Fiorilaunchpad.", {
					actions: ["[FLP] MCC Workplace", MessageBox.Action.OK],
					emphasizedAction: "[FLP] MCC Workplace",
					onClose: this._openFlpMCCWorkplace.bind(this)
				});
			}

		},

		resetEmployee: function (oEvent) {
			var sBindingContextPath = this.getView().byId(this.getView().createId("addRecommendationDialog--addRecommendationDialog")).getBindingContext(
				"cardModel").getPath();
			var oBindingObject = this.getCardProperty(sBindingContextPath);
			oBindingObject.Responsible = "";
			oBindingObject.ResponsibleName = "";
		},

		/**
		 * Fired by column sort menu of role type
		 * Sort function for role type column
		 * @memberOf mcc.workbench.admin.WorkbenchCRUD.view.List
		 * @public
		 * @param {object} oEvent The oEvent that comes with pressing the menu button
		 */
		onSort: function (oEvent) {
			var bIsDesc = oEvent.getSource().getIcon().indexOf("desc") > -1;
			oEvent.getSource().getParent().getParent().setSorted(true);
			this._oTable.getBinding("rows").sort(new sap.ui.model.Sorter("ResponsibleName", bIsDesc));
			this._oTable.getBinding("rows").refresh(true);
		},

		/**
		 * Fired by column filter menu of ResponsibleName or Responsible
		 * Filter function for responsible column (ResponsibleName or Responsible property)
		 * @memberOf mcc.workbench.admin.WorkbenchCRUD.view.List
		 * @public
		 * @param {object} oEvent The oEvent that comes with entering the search term
		 */
		onCustomFilter: function (oEvent) {
			var sValue = oEvent.getParameter("item").getProperty("value");
			//var oValueHelp = this.getView().getModel("oValueHelp").getData()["RoleTypes"];
			var aTableFilters = this._oTable.getBinding("rows").aFilters;
			var aClearedTableFilters = [];
			var aFilter = [];
			var aNewFilter = [];

			for (var j = 0; j < aTableFilters.length; j++) {
				if (aTableFilters[j].sPath && aTableFilters[j].sPath !== "ResponsibleName" && aTableFilters[j].sPath !== "Responsible") {
					aClearedTableFilters.push(aTableFilters[j]);
				}
			}

			if (sValue.trim() === "") {
				oEvent.getSource().getParent().getParent().setFiltered(false);
				aNewFilter = aClearedTableFilters;
			} else {
				oEvent.getSource().getParent().getParent().setFiltered(true);
				var oFilter = new Filter({
					filters: [
						new Filter({
							path: 'ResponsibleName',
							operator: FilterOperator.Contains,
							value1: sValue
						}),
						new Filter({
							path: 'Responsible',
							operator: FilterOperator.Contains,
							value1: sValue
						})
					],
					and: false
				})
				aFilter.push(oFilter);

				aNewFilter = aClearedTableFilters.concat(aFilter);
			}

			this._oTable.getBinding("rows").filter(aNewFilter);
			this._oTable.getBinding("rows").refresh(true);
		},

		_openFlpMCCWorkplace: function (sAction) {
			if (sAction === "[FLP] MCC Workplace") {
				var sHostname = window.location.hostname;
				var oRessourceBundle = this.getResourceBundle();
				var sFLPUrl = oRessourceBundle.getText("mccWorkplaceProd");
				if (sHostname.lastIndexOf("a44f228ad") > -1) {
					sFLPUrl = oRessourceBundle.getText("mccWorkplaceFlpTest");
				}
				sap.m.URLHelper.redirect(sFLPUrl);
			}
		},

		onCustomerPressed: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCustomerId = this.getModel("cardModel").getProperty(sBindingContextPath).CustomerR3No;

			this.navToApp(
				this.getResourceBundle().getText("mccOneDashboardTest", [sCustomerId]),
				this.getResourceBundle().getText("mccOneDashboardProd", [sCustomerId]), {}, false);

		},

		// *****************************************************************************************
		// *****************************************************************************************
		// **			BEGIN: CODE REUSE Workbench
		// **			https://github.wdf.sap.corp/mcc/mcc-ui5-workbench
		// **			AddRecommendation.framgment.xml, F4ValueHelp.fragment.xml
		// *****************************************************************************************
		// *****************************************************************************************

		_onValueHelpRequested: function (oEvent) {
			this._oValueHelpDialog = sap.ui.xmlfragment("com.sap.mcc.workplace.view.fragments.F4ValueHelp",
				this);
			this._oTargetResultInput = oEvent.getSource();
			this._oValueHelpDialog.setTitle("Target Result");
			this._oValueHelpDialog.setKey("DropdownValue");
			this.oView.addDependent(this._oValueHelpDialog);
			this._oValueHelpDialog.getTableAsync().then(function (oTable) {
				oTable.setModel(this.getView().getModel("RecommendationModel"));
				oTable.bindAggregation("rows", "/ValueHelpTargetResult");
				oTable.addColumn(new sap.ui.table.Column({
					width: "12rem",
					label: new sap.m.Label({
						text: "Target Result"
					}),
					template: new sap.m.Text({
						text: {
							path: "DropdownValue",
							formatter: this.formatRecomTargetResult.bind(this)
						}
					})
				}));
				oTable.addColumn(new sap.ui.table.Column({
					label: new sap.m.Label({
						text: "Description"
					}),
					template: new sap.m.Text({
						text: "{Description}",
						wrapping: true
					})
				}));
				var sBindingPath = this.getView().byId(this.getView().createId("addRecommendationDialog--addRecommendationDialog")).getBindingContext(
					"cardModel").getPath();
				var sFilterProperty = this.getCardModel().getProperty(sBindingPath + "/RecommendationType");

				var oSorter = new sap.ui.model.Sorter("position");

				var oFilter = new Filter("DropdownValue", FilterOperator.Contains, sFilterProperty);

				oTable.getBinding("rows").sort(oSorter);
				oTable.getBinding("rows").filter(oFilter);

				this._oValueHelpDialog.update();
			}.bind(this));
			if (this._oTargetResultInput.getSelectedKey() !== "") {
				var oToken = new sap.m.Token();
				oToken.setKey(this._oTargetResultInput.getSelectedKey());
				oToken.setText(this._oTargetResultInput.getSelectedKey());
				this._oValueHelpDialog.setTokens([oToken]);
			}
			this._oValueHelpDialog.open();
		},
		onValueHelpOkPress: function (oEvent) {
			this.bRecommendationChanged = true;
			var aTokens = oEvent.getParameter("tokens");
			var text = this.formatRecomTargetResult(aTokens[0].getKey());
			var sBindingPath = this.getView().byId(this.getView().createId("addRecommendationDialog--addRecommendationDialog")).getBindingContext(
				"cardModel").getPath();
			this.setCardProperty(sBindingPath + "/TargetResult", text);
			this._oValueHelpDialog.close();
		},

		onValueHelpCancelPress: function () {
			this._oValueHelpDialog.close();
		},

		onValueHelpAfterClose: function () {
			this._oValueHelpDialog.destroy();
		}

		// *****************************************************************************************
		// *****************************************************************************************
		// **			END: CODE REUSE Workbench
		// **			https://github.wdf.sap.corp/mcc/mcc-ui5-workbench
		// **			AddRecommendation.framgment.xml, F4ValueHelp.fragment.xml
		// *****************************************************************************************
		// *****************************************************************************************
	});
});