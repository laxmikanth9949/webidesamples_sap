sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"./formatter"
], function (BaseCardController, JSONModel, formatter) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.WorklistQD.WorklistQD", {
		formatter: formatter,

		// Initialize the view and make a call to the refresh method
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */
			this.onUpdateCard();
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			var aFilter = [];
			var model = this.getModel("sc2_critsit_dashboard_srv");
			var oFilter = new sap.ui.model.Filter({
				filters: [new sap.ui.model.Filter({
						filters: [
							new sap.ui.model.Filter("MccStatus", sap.ui.model.FilterOperator.EQ, "1"),
							new sap.ui.model.Filter("MccStatus", sap.ui.model.FilterOperator.EQ, "2")
						],
						and: false
					}),
					new sap.ui.model.Filter("QdJudgement", sap.ui.model.FilterOperator.EQ, "1"),
					new sap.ui.model.Filter("StatOpen", sap.ui.model.FilterOperator.EQ, "X")
				],
				and: true
			});
			aFilter.push(oFilter);
			model.read("/Critical_IncidentsSet", {
				filters: aFilter,
				success: function (oResult1) {
					var oResult = this.bubbleSort(oResult1);
					this.setCardProperty("/data", oResult.results);
					this.setCardProperty("/customHeader/additionalCardTitle", " (" + oResult.results.length + ")");

					this.setCardSuccessState();
				}.bind(this),
				error: function (oError) {
					this.setCardErrorState();
				}.bind(this)
			});
		},

		//method for sorting the activites by create date
		bubbleSort: function (oResult) {
			var n = oResult.results.length;
			for (var i = 0; i < n - 1; i++) {
				for (var j = 0; j < n - i - 1; j++) {
					if ((oResult.results[j].CreatedAt) > (oResult.results[j + 1].CreatedAt)) {
						var temp = oResult.results[j];
						oResult.results[j] = oResult.results[j + 1];
						oResult.results[j + 1] = temp;
					}
				}
			}
			return oResult;
		},

		// Keep count of number of entries in the table
		onAfterRendering: function () {
			/*var that = this;
			var oBinding = this.getView().byId("table-mcs-worklistQD").getBinding("items");
			if (oBinding) {
				oBinding.attachChange(function (sReason) {
					that.getView().byId("header").setText(that.getView().byId("header").getText() + " (" + oBinding.getLength() + ")");
					var scroll = that.getView().byId("s1");
					if (oBinding.getLength() > 9) {
						scroll.setHeight("31rem");
					}
				});
			}*/
		},

		onPopinLayoutChanged: function () {
			var oTable = this.byId("table-mcs-worklistQD");
			var oComboBox = this.byId("idPopinLayout");
			var sPopinLayout = oComboBox.getSelectedKey();
			switch (sPopinLayout) {
			case "Block":
				oTable.setPopinLayout(sap.m.PopinLayout.Block);
				break;
			case "GridLarge":
				oTable.setPopinLayout(sap.m.PopinLayout.GridLarge);
				break;
			case "GridSmall":
				oTable.setPopinLayout(sap.m.PopinLayout.GridSmall);
				break;
			default:
				oTable.setPopinLayout(sap.m.PopinLayout.Block);
				break;
			}
		},

		//On selecting an activity in the table, navigate to the activity link in the CRM
		onSelectionChange: function (oEvent) {
			var sPath = oEvent.getParameters().rowBindingContext.sPath;
			var incidentId = this.getModel("cardModel").getProperty(sPath).IncidentId;
			
			this.navToApp(
				this.getResourceBundle().getText("qdAssistantWorklistQDTest", [incidentId]),
				this.getResourceBundle().getText("qdAssistantWorklistQD", [incidentId]), {}, false);
		},

		//returns a date in form days and hours
		//param(information) date in string format
		getDays: function (information) {
			if (information) {
				// get total seconds between the times
				var delta = Math.abs(new Date() - (information)) / 1000;

				// calculate (and subtract) whole days
				var days = Math.floor(delta / 86400);
				delta -= days * 86400;

				// calculate (and subtract) whole hours
				var hours = Math.floor(delta / 3600) % 24;
				delta -= hours * 3600;

				// calculate (and subtract) whole minutes
				var minutes = Math.floor(delta / 60) % 60;
				delta -= minutes * 60;

				// what's left is seconds
				var seconds = delta % 60;
				var text = days + " d " + hours + " h ";
				if ((days === 0) && hours === 0) {
					return "< 1 hour";
				}
				return text;
			}
		},

		//returns a date in date format
		//param(temp) date in string format
		createDate: function (temp) {
			if (temp) {
				var year = temp.substring(0, 4);
				var month = temp.substring(4, 6);
				var day = temp.substring(6, 8);
				var hour = temp.substring(8, 10);
				var minute = temp.substring(10, 12);
				var seconds = temp.substring(12, 14);
				return new Date(year, month - 1, day, hour, minute, seconds);
			}
		},

		//Convert date format to month day year ex: "February 2, 2019"
		getmDate: function (date) {
			if (date) {
				var month = ["January", "February", "March", "April", "May", "June",
					"July", "August", "September", "October", "November", "December"
				][date.getMonth()];
				var str = month + " " + date.getDate() + " " + date.getFullYear();
				return str;
			}
		},

		//returns mcc status in text format
		//param(sStatus) in numerical format
		formatMccStatus: function (sStatus) {
			switch (sStatus) {
			case "1":
				return "New";
			case "2":
				return "In Process";
			case "3":
				return "Closed";
			default:
				return "";
			}
		},

		onCustomerPressed: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCustomerId = this.getModel("cardModel").getProperty(sBindingContextPath).ErpCustNo;

			this.navToApp(
				this.getResourceBundle().getText("mccOneDashboardTest", [sCustomerId]),
				this.getResourceBundle().getText("mccOneDashboardProd", [sCustomerId]), {}, false);

		}
	});
});