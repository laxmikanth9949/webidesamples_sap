sap.ui.define([
	"sap/ui/base/Object"
], function (UI5Object) {
	"use strict";

	return UI5Object.extend("com.sap.mcc.workplace.CardComponent.CardErrorHandler", {

		/**
		 * Handles application errors by automatically attaching to the model events and displaying errors when needed.
		 * @class
		 * @param {sap.ui.core.UIComponent} oComponent reference to the app's component
		 * @public
		 * @alias com.sap.mcc.workplace.CardComponent.CardErrorHandler
		 */
		constructor: function (oComponent, sModelName) {
			this._oResourceBundle = oComponent.getModel("i18n").getResourceBundle();
			this._oComponent = oComponent;
			this._oModel = sModelName ? oComponent.getModel(sModelName) : oComponent.getModel();

			this._oModel.attachMetadataFailed(function (oEvent) {
				this._oComponent.getModel("cardModel").setProperty("/error", true);
				this._oComponent.getModel("cardModel").setProperty("/noData", false);
				this._oComponent.getModel("cardModel").setProperty("/busy", false);

				if (oEvent.getParameter("statusCode") === 403) {
					this._oComponent.getModel("cardModel").setProperty("/metadataError", true);
					this._oComponent.getModel("cardModel").setProperty("/metadataErrorStatusCode", 403);
					this._oComponent.getModel("cardModel").setProperty("/errorMessage", "Missing Authorization");
				}
			}, this);

			// triggered when Request has to be cancelled
			this._oModel.attachRequestFailed(function (oEvent) {
				if (oEvent.getParameter("statusCode") !== "(Aborted)") {
					this._oComponent.getModel("cardModel").setProperty("/metadataError", false);
					this._oComponent.getModel("cardModel").setProperty("/error", true);
					this._oComponent.getModel("cardModel").setProperty("/noData", false);
					this._oComponent.getModel("cardModel").setProperty("/busy", false);
				}

			}, this);
		}

	});

});