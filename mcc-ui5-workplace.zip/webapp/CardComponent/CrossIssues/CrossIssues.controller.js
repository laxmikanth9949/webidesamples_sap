sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/ValueState",
	"sapit/controls/EmployeeSearchDialog",
	"sap/m/MessageBox",
	"sap/m/Token",
	"sap/m/MultiInput",
	"sap/ui/export/Spreadsheet",
	"sap/ui/export/library",
], function (BaseCardController, Filter, FilterOperator, Fragment, JSONModel, ValueState, EmployeeSearchDialog, MessageBox, Token,
	MultiInput, Spreadsheet, exportLibrary) {
	"use strict";

	var EdmType = exportLibrary.EdmType;

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.CrossIssues.CrossIssues", {

		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
		this.setCardProperty("/customHeader/action/right", [
				new sap.ui.core.Icon({
					visible: "{= !(${/busy})}",
					src: "sap-icon://download",
					tooltip: "Download",
					press: [this.openConfidentialDialog, this],
					color: "#FFFFFF"
				}).addStyleClass("sapUiSmallMarginBeginEnd"),
				new sap.ui.core.Icon({
					src: "sap-icon://create-form",
					tooltip: "New Cross Issues",
					press: [this.createCrossIssue, this],
					color: "#FFFFFF"
				})
			]);

			this.setCardProperty("/editMode", false);

			this.setCardProperty("/dropdownValues", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			//register AttachChange event for binding change to update the card title when for example a column filter is applied
			this._oTable = this.getView().byId("tableCrossIssues");
			this._oTable.getBinding("rows").attachChange(this.updateCardTitle.bind(this, "crossIssues"));

			this.setRequestAttachedFaild();
			
			this._loadBusinessScenarioDropdowns();
			this.onUpdateCard();
			// this.setCardAutoRefresh(300000); // Autorefresh in ms - if card needs to be autorefreshed, set the time in ms
			this._loadProductLine();

			this._getMailTemplates();
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			var oFilter = new Filter({
				filters: [new Filter("TopIssueType", FilterOperator.EQ, "ZS38"),
					new Filter("SoldToPartyID", FilterOperator.EQ, "0020672944")
				],
				and: true
			});
			
			//temporarily removed status filter
			/*new Filter({
						filters: [new Filter("StatusID", FilterOperator.EQ, "E0010"),
							new Filter("StatusID", FilterOperator.EQ, "E0011"),
							new Filter("StatusID", FilterOperator.EQ, "E0014"),
							new Filter("StatusID", FilterOperator.EQ, "E0016"),
							new Filter("StatusID", FilterOperator.EQ, "E0017")
						],
						and: false
					})*/

			var oCrossIssuePromise = this._getCrossIssues([oFilter]);
			// this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			oCrossIssuePromise.then(function (aCrossIssues) {

				this.setCardProperty("/crossIssues", aCrossIssues);
				var aPromises = [];
				aCrossIssues.forEach(function (oCrossIssue) {
					var oPromise = this._getCrossIssueDetails(oCrossIssue.TopIssueID, oCrossIssue.TopIssueType);
					aPromises.push(oPromise);
				}.bind(this));

				Promise.all(aPromises).finally(function (oData) {
					this.setCardSuccessState();
					// load cross issues from hana db
					this._getCrossIssuesHana();
				}.bind(this));

				//this.setCardSuccessState();

			}.bind(this)).catch(function (oError) {
				console.log("[Recommendations]: Request Failed " + oError);
				this.setCardErrorState();
			}.bind(this));
		},
		
		_getCrossIssuesHana: function() {
			return new Promise(function(resolve,reject) {
				var oModel = this.getModel("workbenchModel");
				oModel.read("/CrossIssues", {
					success: function (oData) {
						var aCrossIssuesHana = oData.results;
						var aCrossIssues = this.getCardProperty("/crossIssues");
						var aCombined = [];
						
						for(var i = 0; i < aCrossIssues.length; i++) {
							var oCrossIssue = aCrossIssues[i];
							
							var oFound = aCrossIssuesHana.find(function(oCrossIssueHana) {
								return (oCrossIssueHana.TopIssueID === oCrossIssue.TopIssueID);
							});
							
							if(typeof(oFound) !== "undefined" && typeof(oFound.BusinessScenario) !== "undefined" && oFound.BusinessScenario) aCrossIssues[i].BusinessScenario = this.formatBusinesScenario(oFound.BusinessScenario);
							
						}
						
						this.setCardProperty("/crossIssues",aCrossIssues)
						resolve()
					}.bind(this),
					error: function (err) {
						reject(err);
					}
				});	
			}.bind(this))
		},

		_getCrossIssues: function (aCustomFilter) {
			var aFilter = [];
			if (aCustomFilter) {
				aFilter = aCustomFilter;
			}
			var oZSAppDepModel = this.getModel("appDepModel");
			//var oFilter = new Filter("Status", FilterOperator.NE, "Completed");

			return new Promise(function (resolve, reject) {
				oZSAppDepModel.read("/TopIssueSet", {
					filters: aFilter,

					success: function (oData, oResp) {
						resolve(oData.results);
					}.bind(this),
					error: function (oError) {
						this.setCardProperty("/customHeader/additionalCardTitle", "");
						this.setCardNoDataState();
						reject(oError);
					}.bind(this)
				});
			}.bind(this));

		},

		_getCrossIssueDetails: function (iCrossIssueID, sCrossIssueType) {
			var oAppDepModel = this.getModel("appDepModel");
			var oTopIssueIDFilter = new Filter("TopIssueID", FilterOperator.EQ, "" + iCrossIssueID); //CaseSet?$filter= CaseID eq '20079821'
			var oTopIssueTypeFilter = new Filter("TopIssueType", FilterOperator.EQ, "" + sCrossIssueType);
			var oTopIssueDetails = new Promise(function (resolve, reject) {
				oAppDepModel.read("/TopIssueSet", {
					filters: [oTopIssueIDFilter, oTopIssueTypeFilter],
					urlParameters: {
						"$expand": "toAffectedProduct"
					},
					success: function (oData) {
						resolve(oData.results[0]);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			}.bind(this));

			oTopIssueDetails.then(function (oTopIssue) {
				if (oTopIssue) {
					var aData = this.getCardProperty("/crossIssues");

					var aObjects = aData.filter(ele => ele.TopIssueID === iCrossIssueID); //this.findObjectByKey(aData, "CaseID", iCaseId);
					aObjects.forEach(function (oObject) {

						if (oTopIssue.toAffectedProduct && oTopIssue.toAffectedProduct.results.length > 0) {
							var aProducts = oTopIssue.toAffectedProduct.results;
							var aProductLines = [];
							var sIsMainProduct = "";
							aProducts.forEach(function (oProduct) {
								if (oProduct.IsMainProduct) {
									sIsMainProduct = oProduct.AffectedProductText;
								} else {
									aProductLines.push(oProduct.AffectedProductText);
								}
							});

							aProductLines = sIsMainProduct ? [sIsMainProduct].concat(aProductLines) : aProductLines;

							aProductLines = [...new Set(aProductLines)];
							//split all values with ", " and prevent the last value having a comma at the end
							if (aProductLines.length > 1) {
								oObject.Products = aProductLines.slice(0, -1).join(', ') + ", " + aProductLines.slice(-1);
								if (aProductLines.length > 2) {
									oObject.ProductLinesMergedFormatted = "<p><strong>" + aProductLines.slice(0, 1) + ", </strong>" + aProductLines.slice(1, -1)
										.join(', ') + ", " + aProductLines.slice(-1) + "</p>";
								} else {
									oObject.ProductLinesMergedFormatted = "<p><strong>" + aProductLines.slice(0, 1) + ", </strong>" + aProductLines.slice(1, -1)
										.join(', ') + aProductLines.slice(-1) + "</p>";
								}
							} else if (sIsMainProduct) {
								oObject.Products = aProductLines.toString();
								oObject.ProductLinesMergedFormatted = "<p><strong>" + aProductLines.toString() + "</strong></p>";
							} else {
								oObject.Products = aProductLines.toString();
								oObject.ProductLinesMergedFormatted = "<p>" + aProductLines.toString() + "</p>";
							}
							this.getView().byId("tableCrossIssues").getBinding("rows").refresh()
						}
					}.bind(this));
				}
			}.bind(this));

			return oTopIssueDetails;
		},

		onLinkPress: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCustomerId = this.getCardModel().getProperty(sBindingContextPath).CaseId;
			this.navToApp(
				this.getResourceBundle().getText("mccWorkbenchTest", [oEvent.getSource().getText()]),
				this.getResourceBundle().getText("mccWorkbenchProd", [oEvent.getSource().getText()]), {}, false);
		},

		/**
		 * Fired by column sort menu of role type
		 * Sort function for role type column
		 * @memberOf mcc.workbench.admin.WorkbenchCRUD.view.List
		 * @public
		 * @param {object} oEvent The oEvent that comes with pressing the menu button
		 */
		onSort: function (oEvent) {
			var bIsDesc = oEvent.getSource().getIcon().indexOf("desc") > -1;
			oEvent.getSource().getParent().getParent().setSorted(true);
			this._oTable.getBinding("rows").sort(new sap.ui.model.Sorter("ResponsibleName", bIsDesc));
			this._oTable.getBinding("rows").refresh(true);
		},

		createCrossIssue: function (oEvent) {
			// close confidential popover
			//oEvent.getSource().getParent().close();
			// open new popover
			var sFragmentId = this.getView().createId("crossIssueFragment");
			Fragment.load({
				id: sFragmentId,
				type: "XML",
				name: "com.sap.mcc.workplace.view.fragments.CreateNewCrossIssue",
				controller: this
			}).then(function (oDialog) {
				var oAppDepModel = this.getView().getModel("appDepModel");
				oDialog.setModel(oAppDepModel, "appDepModel");
				this.getView().addDependent(oDialog);
				this.createValidatorForMultiInput(sFragmentId, "tags");

				var oCrossIssueModel = new JSONModel({});
				this.getView().setModel(oCrossIssueModel, "crossIssueModel");
				oDialog.setModel(oCrossIssueModel, "crossIssueModel");

				// initialize model
				var oModelData = {

					A001: "", // Description
					ZSCA: "", // Engagemment Reason
					ZS05: "", // Exit Criteria

					Description: "",
					RespPersonName: "",
					RespPersonNo: "",
					TopIssueType: "ZS38",
					SoldToPartyID: "0020672944",
					StatusID: "E0010",
					CustomerTags: [],
					expandedProducts: false,
					expandedLinkedObjects: false,
					AffectedProducts: [],
					LinkedObjects: [],
					linkedObjectDescription: "",
					linkedObjectObjectsID: "",
					linkedObjectObjectsType: "",
					linkedObjectURL: "",
					objectTypes: [],
					selectedObjectType: "1",
					customer: []
				}

				oCrossIssueModel.setData(oModelData);
				this._loadObjectTypeDropdowns();
				oDialog.open();
				this.setCardProperty("/editMode", true);
			}.bind(this))
		},
		
		_loadBusinessScenarioDropdowns: function() {
			var oModel = this.getView().getModel("workbenchModel");
			var oFilter = new Filter("DropdownName",FilterOperator.EQ,'Case-BusinessScenario-Dropdown');
			
			oModel.read("/DropdownValues", {
				filters: [oFilter],
				success: function(oData) {
					this.setCardProperty("/dropdownValues/0",oData.results);
				}.bind(this),
				error: function(err) {
					console.log(err);
				}
			})
		},

		_loadObjectTypeDropdowns: function () {
			var workbenchModel = this.getView().getModel("workbenchModel");
			var crossIssueModel = this.getView().getModel("crossIssueModel");
			var aFilter = [new Filter(
				"DropdownName", FilterOperator.StartsWith, 'LinkedObjects-ObjectType-Dropdown')];
			workbenchModel.read("/DropdownValues", {
				filters: aFilter,
				success: function (oData) {
					crossIssueModel.setProperty("/objectTypes", oData.results);
				},
				error: function (oErr) {}
			});
		},

		formatDropdownKey: function (sKey) {
			var aDropdownValues = this.getView().getModel("crossIssueModel").getData().objectTypes;
			if (aDropdownValues) {
				for (var i = 0; i < aDropdownValues.length; i++) {
					if (sKey === aDropdownValues[i].DropdownKey) {
						return aDropdownValues[i].DropdownValue;
					}
				}

				return sKey;
			} else {
				return
			}
		},

		_addLinkedObject: function (oEvent) {
			var oCrossIssueModel = this.getView().getModel("crossIssueModel").getData();
			var oLinkedObject = {
				linkedObjectObjectsType: oCrossIssueModel.selectedObjectType,
				linkedObjectObjectsID: oCrossIssueModel.linkedObjectObjectsID,
				linkedObjectDescription: oCrossIssueModel.linkedObjectDescription,
				linkedObjectURL: oCrossIssueModel.linkedObjectURL
			}
			oCrossIssueModel.LinkedObjects.push(oLinkedObject);
			this.getView().getModel("crossIssueModel").refresh(true);

			var oDialog = oEvent.getSource().getParent();
			oDialog.close();
			oDialog.destroy();
		},

		_saveAffectedProducts: function (RefDocID, RefDocType, RefDocObject) {
			var aAffectedProducts = this.getView().getModel("crossIssueModel").getData().AffectedProducts;
			return new Promise(function (resolveAll, rejectAll) {
				var promises = [];

				for (var i = 0; i < aAffectedProducts.length; i++) {
					var oAffectedProduct = aAffectedProducts[i];
					var payload = {
						RefDocID: RefDocID,
						RefDocType: RefDocType,
						RefDocObject: RefDocObject,
						AffectedProductID: oAffectedProduct.AffectedProductID,
						IsMainProduct: oAffectedProduct.IsMainProduct
					}

					var promise = new Promise(function (resolve, reject) {
						var oAppDepModel = this.getView().getModel("appDepModel");
						var sPath = "/AffectedProductSet";

						oAppDepModel.create(sPath, payload, {
							success: function (oData) {
								resolve(oData);
							},
							error: function (err) {
								reject(err);
							}
						})
					}.bind(this));

					promises.push(promise);
				}

				Promise.all(promises).then(function () {
					resolveAll();
				}).catch(function (err) {
					err.entitySet = "/AffectedProductSet";
					rejectAll(err);
				})
			}.bind(this));
		},

		_saveLinkedObjects: function (sTopIssueId) {
			var workbenchModel = this.getView().getModel("workbenchModel");
			var crossIssueModel = this.getView().getModel("crossIssueModel");

			return new Promise(function (resolveAll, rejectAll) {
				var aPromises = [];
				var aLinkedObjects = crossIssueModel.getData().LinkedObjects;

				aLinkedObjects.forEach(function (oLinkedObject) {
					var oPayload = {
						Description: oLinkedObject.linkedObjectDescription,
						ObjectID: oLinkedObject.linkedObjectObjectsID,
						ObjectType: oLinkedObject.linkedObjectObjectsType,
						TopIssueID: sTopIssueId,
						URL: oLinkedObject.linkedObjectURL
					}

					var oPromise = new Promise(function (resolve, reject) {
						workbenchModel.create("/LinkedObjects", oPayload, {
							success: function () {
								resolve();
							},
							error: function (err) {
								err.entitySet = "/LinkedObjects"
								reject(err);
							}
						})
					});
					aPromises.push(oPromise);
				});
				Promise.all(aPromises).then(function () {
					resolveAll();
				}).catch(function (err) {
					rejectAll(err);
				})
			});
		},

		_saveTopIssue: function (oTopIssue) {
			return new Promise(function (resolve, reject) {
				var oAppDepModel = this.getView().getModel("appDepModel");
				var sPath = "/TopIssueSet";

				oAppDepModel.create(sPath, oTopIssue, {
					success: function (oData) {
						resolve(oData);
					},
					error: function (err) {
						reject(err);
					}
				})
			}.bind(this));
		},

		_saveAffectedCustomers: function (aData, RefDocID, RefDocType, RefDocObject) {
			return new Promise(function (resolveAll, rejectAll) {
				var promises = [];

				for (var i = 0; i < aData.length; i++) {
					var oCustomer = aData[i];
					var payload = {
						RefDocID: RefDocID,
						RefDocType: RefDocType,
						RefDocObject: RefDocObject,
						PartnerId: oCustomer.key,
						PartnerFct: "ZSAFFCUS"
					}

					var promise = new Promise(function (resolve, reject) {
						var oAppDepModel = this.getView().getModel("appDepModel");
						var sPath = "/PartiesInvolvedSet";

						oAppDepModel.create(sPath, payload, {
							success: function (oData) {
								resolve(oData);
							},
							error: function (err) {
								err.entitySet = "/PartiesInvolvedSet";
								reject(err);
							}
						})
					}.bind(this));

					promises.push(promise);
				}

				Promise.all(promises).then(function () {
					resolveAll();
				}).catch(function (err) {
					rejectAll(err);
				})
			}.bind(this));
		},

		_saveNotes: function (oData, RefDocID, RefDocType, RefDocObject) {
			return new Promise(function (resolveAll, rejectAll) {
				var aNotes = [{
					NotesType: "A001",
					Text: oData.A001
				}, {
					NotesType: "ZSCA",
					Text: oData.ZSCA
				}, {
					NotesType: "ZS05",
					Text: oData.ZS05
				}];
				var promises = [];

				for (var i = 0; i < aNotes.length; i++) {
					var oNote = aNotes[i];
					if (oNote.Text && oNote.Text !== "") {
						var payload = {
							RefDocID: RefDocID,
							RefDocType: RefDocType,
							RefDocObject: RefDocObject,
							NoteType: oNote.NotesType,
							Text: oNote.Text
						}

						var promise = new Promise(function (resolve, reject) {
							var oAppDepModel = this.getView().getModel("appDepModel");
							var sPath = "/NoteSet";

							oAppDepModel.create(sPath, payload, {
								success: function (oData) {
									resolve(oData);
								},
								error: function (err) {
									err.entitySet = "/NoteSet";
									reject(err);
								}
							})
						}.bind(this));

						promises.push(promise);
					}
				}

				Promise.all(promises).then(function () {
					resolveAll();
				}).catch(function (err) {
					rejectAll(err);
				})
			}.bind(this));
		},

		onSaveCrossIssue: function (oEvent) {
			// first create new top Issue
			var oCrossIssueModel = this.getView().getModel("crossIssueModel").getData();
			var oTopIssue = {
				Description: oCrossIssueModel.Description,
				RespPersonNo: oCrossIssueModel.RespPersonNo,
				TopIssueType: oCrossIssueModel.TopIssueType,
				SoldToPartyID: oCrossIssueModel.SoldToPartyID,
				StatusID: oCrossIssueModel.StatusID
			}

			var oNotes = {
				A001: oCrossIssueModel.A001,
				ZSCA: oCrossIssueModel.ZSCA,
				ZS05: oCrossIssueModel.ZS05
			}

			var oDialog = oEvent.getSource().getParent();

			sap.ui.core.BusyIndicator.show();
			this._saveTopIssue(oTopIssue).then(function (oIssue) {

				this.generateEmail(oIssue, oNotes);

				var aError = []

				// and here do notes saving

				this._saveNotes(oNotes, oIssue.TopIssueID, oIssue.TopIssueType, oIssue.TopIssueObject).catch(function (err) {
					aError.push(err);
				}.bind(this)).finally(function () {

					this._saveAffectedCustomers(oCrossIssueModel.CustomerTags, oIssue.TopIssueID, oIssue.TopIssueType,
						oIssue.TopIssueObject).catch(function (err) {
						aError.push(err);
					}.bind(this)).finally(function () {
						this._saveLinkedObjects(oIssue.TopIssueID).catch(function (err) {
							aError.push(err);
						}.bind(this)).finally(function () {
							this._saveAffectedProducts(oIssue.TopIssueID, oIssue.TopIssueType, oIssue.TopIssueObject).catch(function (err) {
								aError.push(err);
							}.bind(this)).finally(function () {
								if (aError.length > 0) {
									oDialog.close();
									oDialog.destroy();
									this._handleCrossIssueErrors(true, aError, oIssue.TopIssueID);
									this.onUpdateCard();
									sap.ui.core.BusyIndicator.hide();
								} else {
									oDialog.close();
									oDialog.destroy();
									sap.m.MessageToast.show("Cross Issue saved");
									this.onUpdateCard();
									sap.ui.core.BusyIndicator.hide();
								}
							}.bind(this));
						}.bind(this));
					}.bind(this));
				}.bind(this));

			}.bind(this)).catch(function (err) {
				sap.ui.core.BusyIndicator.hide();
				this._handleCrossIssueErrors(false, err);
				// todo: do some error handling here	
			}.bind(this));
		},

		closeDialogCrossIssue: function (oEvent) {
			var oDialog = oEvent.getSource().getParent();
			this.setCardProperty("/editMode", false);
			oDialog.close();
			oDialog.destroy();
		},

		closeProductDialog: function (oEvent) {
			var oDialog = oEvent.getSource().getParent().getParent();
			oDialog.close();
			oDialog.destroy();

		},

		/** 
		 * Create validators to create new multiInput Tokens.
		 * @private
		 * @param {string} sFragmentId fragment Id.
		 * @param {string} sControlId control Id.
		 * @returns {void}
		 */
		createValidatorForMultiInput: function (sFragmentId, sControlId) {
			var oMultiInput = Fragment.byId(sFragmentId, sControlId);
			if (oMultiInput) {
				var fValidator = function (args) {
					return new Token({
						text: args.text
					});

				};
				oMultiInput.addValidator(fValidator);
			}
		},

		onCustomerTags: function (oEvent) {
			var sType = oEvent.getParameter("type");
			var aAddedTokens = oEvent.getParameter("addedTokens");
			var aRemovedTokens = oEvent.getParameter("removedTokens");
			//var sBindingPath = oEvent.getSource().getBindingContext("crossIssueModel").getPath()
			var oCrossIssueModel = this.getModel("crossIssueModel");
			var aContexts = oCrossIssueModel.getProperty("/CustomerTags");
			if (!aContexts) {
				aContexts = [];
			}
			switch (sType) {
				// add new context to the data of the model, when new token is being added
			case "added":
				aAddedTokens.forEach(function (oToken) {
					aContexts.push({
						text: oToken.getText(),
						key: oToken.getKey()
					});
				});
				break;
				// remove contexts from the data of the model, when tokens are being removed
			case "removed":
				aRemovedTokens.forEach(function (oToken) {
					aContexts = aContexts.filter(function (oContext) {
						return oContext.getKey !== oToken.getKey();
					});
				});
				break;
			default:
				break;
			}
			oCrossIssueModel.setProperty("/CustomerTags", aContexts);
		},

		_openFlpMCCWorkplace: function (sAction) {
			if (sAction === "[FLP] MCC Workplace") {
				var sHostname = window.location.hostname;
				var oRessourceBundle = this.getResourceBundle();
				var sFLPUrl = oRessourceBundle.getText("mccWorkplaceProd");
				if (sHostname.lastIndexOf("a44f228ad") > -1) {
					sFLPUrl = oRessourceBundle.getText("mccWorkplaceFlpTest");
				}
				sap.m.URLHelper.redirect(sFLPUrl);
			}
		},

		onExpandProducts: function (oEvent) {
			this.getModel("crossIssueModel").setProperty("/expandedProducts", oEvent.getSource().getExpanded());
		},

		onExpandLinkedObjects: function (oEvent) {
			this.getModel("crossIssueModel").setProperty("/expandedLinkedObjects", oEvent.getSource().getExpanded());
		},

		openProductDialog: function (oEvent) {
			var sProductDialogId = this.getView().createId("ProductDialog");
			Fragment.load({
				id: sProductDialogId,
				type: "XML",
				name: "com.sap.mcc.workplace.view.fragments.AffectedProductDialog",
				controller: this
			}).then(function (oDialog) {
				var oAppDepModel = this.getModel("appDepModel");
				oDialog.setModel(oAppDepModel, "appDepModel");
				var oProductLinesModel = this.getModel("ProductLines");
				oDialog.setModel(oProductLinesModel, "ProductLines")
				this.getView().addDependent(oDialog);

				oDialog.open();
			}.bind(this))
		},

		openLinkedObjectsDialog: function (oEvent) {
			var sLinkedObjectsDialog = this.getView().createId("LinkedObjectsDialog");
			Fragment.load({
				id: sLinkedObjectsDialog,
				type: "XML",
				name: "com.sap.mcc.workplace.view.fragments.createLinkedObject",
				controller: this
			}).then(function (oDialog) {
				var oAppDepModel = this.getModel("appDepModel");
				oDialog.setModel(oAppDepModel, "appDepModel");

				var oCrossIssueModel = this.getModel("crossIssueModel");
				oDialog.setModel(oCrossIssueModel, "crossIssueModel");

				this.getView().addDependent(oDialog);
				oDialog.open();
			}.bind(this))
		},

		_loadProductLine: function () {
			var oModel = this.getModel("appDepModel");
			return new Promise(function (resolve, reject) {
				oModel.read("/ProductLineSet", {
					urlParameters: {
						"$top": 9999
					},
					success: function (oData) {
						oData.results = oData.results.sort(function (a, b) {
							if (a.LineName < b.LineName) {
								return -1;
							}
							if (b.LineName < a.LineName) {
								return 1;
							}
							return 0;
						});
						var oProductLineModel = new JSONModel();
						oProductLineModel.setData(oData.results);
						this.getView().setModel(oProductLineModel, "ProductLines");
						resolve();
					}.bind(this),
					error: function (err) {
						this.getView().setModel(new JSONModel([]), "ProductLines");
						resolve();
					}.bind(this)
				});
			}.bind(this));
		},

		loadProducts: function (index) {
			return new Promise(function (resolve, reject) {
				var lineId = this.getModel("ProductLines").getData()[index].LineID;
				var oModel = this.getModel("appDepModel");
				if (!lineId) {
					this.setModel(new JSONModel([]), "Products");
					resolve();
					return;
				}
				oModel.read("/ProductLineSet('" + lineId + "')/toProduct", {
					success: function (oData) {
						oData.results = oData.results.sort(function (a, b) {
							if (a.ProductName < b.ProductName) {
								return -1;
							}
							if (b.ProductName < a.ProductName) {
								return 1;
							}
							return 0;
						});
						this.setModel(new JSONModel(oData.results), "Products");
						resolve();
					}.bind(this),
					error: function (err) {
						this.setModel(new JSONModel([]), "Products");
						resolve();
					}.bind(this)
				});
			}.bind(this));
		},

		loadAllProducts: function () {
			return new Promise(function (resolve, reject) {
				var oModel = this.getModel("appDepModel");
				oModel.read("/ProductSet", {
					urlParameters: {
						"$top": 20000
					},
					success: function (oData) {
						oData.results = oData.results.sort(function (a, b) {
							if (a.ProductName < b.ProductName) {
								return -1;
							}
							if (b.ProductName < a.ProductName) {
								return 1;
							}
							return 0;
						});
						this.setModel(new JSONModel(oData.results), "Products");
						resolve();
					}.bind(this),
					error: function (err) {
						this.setModel(new JSONModel(oData.results), "Products");
						resolve();
					}.bind(this)
				});
			}.bind(this));
		},

		loadProductVersions: function (index) {
			return new Promise(function (resolve, reject) {
				var lineId = this.getModel("Products").getData()[index].LineID;
				var productNr = this.getModel("Products").getData()[index].ProductNR;
				var oModel = this.getModel("appDepModel");
				if (!productNr || !lineId) {
					this.setModel(new JSONModel([]), "ProductVersions");
					resolve();
					return;
				}
				oModel.read("/ProductSet(ProductNR='" + productNr + "',LineID='" + lineId + "')/toProductVersion", {
					success: function (oData) {
						oData.results = oData.results.sort(function (a, b) {
							if (a.Version > b.Version) {
								return -1;
							}
							if (b.Version > a.Version) {
								return 1;
							}
							return 0;
						});
						this.setModel(new JSONModel(oData.results), "ProductVersions");
						resolve();
					}.bind(this),
					error: function (err) {
						this.setModel(new JSONModel([]), "ProductVersions");
						resolve();
					}.bind(this)
				});
			}.bind(this));
		},

		loadAllProductVersions: function () {
			return new Promise(function (resolve, reject) {
				var oModel = this.getModel("appDepModel");
				var sortVersion = new sap.ui.model.Sorter("Version", false);
				oModel.read("/ProductVersionSet", {
					urlParameters: {
						"$top": 20000
					},
					sorters: [sortVersion],
					success: function (oData) {
						this.setModel(new JSONModel(oData.results), "ProductVersions");
						resolve();
					}.bind(this),
					error: function (err) {
						this.setModel(new JSONModel([]), "ProductVersions");
						resolve();
					}.bind(this)
				});
			}.bind(this));
		},

		onSearchLine: function (oEvent) {
			// add filter for search
			var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("LineName", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}

			// update list binding
			var oList = Fragment.byId(this.getView().createId("ProductDialog"), "listProductLines");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},

		onSearchProduct: function (oEvent) {
			// add filter for search
			var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("ProductName", FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}

			// update list binding
			var oList = Fragment.byId(this.getView().createId("ProductDialog"), "listProducts");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},

		onSearchVersion: function (oEvent) {
			// add filter for search
			var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("Version", FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}

			// update list binding
			var oList = Fragment.byId(this.getView().createId("ProductDialog"), "listProductVersions");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},

		onSearchVersion: function (oEvent) {
			// add filter for search
			var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("Version", FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}

			// update list binding
			var oList = Fragment.byId(this.getView().createId("ProductDialog"), "listProductVersions");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},

		handleNavNext: function (oEvent) {
			var oDialog = Fragment.byId(this.getView().createId("ProductDialog"), "ProductDialog");
			oDialog.setBusy(true);

			var navCon = Fragment.byId(this.getView().createId("ProductDialog"), "navContainer");
			var listItemIndex = oEvent.getSource().getBindingContextPath().substring(1);
			if (navCon.getCurrentPage().getId().indexOf("selectProductLine") > -1) {
				this.loadProducts(listItemIndex).then(function () {
					oDialog.setBusy(false);
					navCon.to(Fragment.byId(this.getView().createId("ProductDialog"), "selectProduct"), "slide");
				}.bind(this));
			} else if (navCon.getCurrentPage().getId().indexOf("selectProduct") > -1) {
				this.loadProductVersions(listItemIndex).then(function () {
					oDialog.setBusy(false);
					navCon.to(Fragment.byId(this.getView().createId("ProductDialog"), "selectProductVersion"), "slide");
					Fragment.byId(this.getView().createId("ProductDialog"), "buttonAdd").setEnabled(true);
				}.bind(this));
			}
		},

		handleNavBack: function (oEvent) {
			var navCon = Fragment.byId(this.getView().createId("ProductDialog"), "navContainer");
			if (navCon.getCurrentPage().getId() !== "selectProductVersion") {
				Fragment.byId(this.getView().createId("ProductDialog"), "buttonAdd").setEnabled(false);
			}
			navCon.back();
		},

		onTabBarSelected: function (oEvent) {
			var navCon = Fragment.byId(this.getView().createId("ProductDialog"), "navContainer");
			var oDialog = Fragment.byId(this.getView().createId("ProductDialog"), "ProductDialog");
			oDialog.setBusy(true);
			if (oEvent.getParameter("selectedKey") === "line") {
				Fragment.byId(this.getView().createId("ProductDialog"), "buttonAdd").setEnabled(false);
				navCon.to(Fragment.byId(this.getView().createId("ProductDialog"), "selectProductLine"), "slide");
				oDialog.setBusy(false);
			} else if (oEvent.getParameter("selectedKey") === "product") {
				Fragment.byId(this.getView().createId("ProductDialog"), "buttonAdd").setEnabled(false);
				this.loadAllProducts().then(function () {
					oDialog.setBusy(false);
					navCon.to(Fragment.byId(this.getView().createId("ProductDialog"), "selectProduct"), "slide");
				}.bind(this));
			} else if (oEvent.getParameter("selectedKey") === "version") {
				var load = this.loadAllProductVersions().then(function () {
					oDialog.setBusy(false);
					navCon.to(Fragment.byId(this.getView().createId("ProductDialog"), "selectProductVersion"), "slide");
					Fragment.byId(this.getView().createId("ProductDialog"), "buttonAdd").setEnabled(true);
				}.bind(this));
			}

			if (oEvent.getSource().getId().indexOf("line") > -1) {
				oEvent.getSource().setSelectedKey("line");
			} else if (oEvent.getSource().getId().indexOf("product") > -1) {
				oEvent.getSource().setSelectedKey("product");
			} else if (oEvent.getSource().getId().indexOf("version") > -1) {
				oEvent.getSource().setSelectedKey("version");
			}
		},

		addSolution: function () {
			//event tracking
			//	sap.git.usage.Reporting.addEvent(this.Main.getOwnerComponent(), "Add affected solution");
			var oDialog = Fragment.byId(this.getView().createId("ProductDialog"), "ProductDialog")
			oDialog.setBusy(true);
			var that = this;
			if (Fragment.byId(this.getView().createId("ProductDialog"), "listProductVersions").getSelectedContextPaths().length > 0) {
				var index = Fragment.byId(this.getView().createId("ProductDialog"), "listProductVersions").getSelectedContextPaths()[0].substring(
					1);
				var id = this.getModel("ProductVersions").getData()[index].ProductID;

				var versionText = this.getModel("ProductVersions").getData()[index].Version;
				if (this.checkProductID(id) === false) {
					var aProducts = this.getModel("crossIssueModel").getProperty("/AffectedProducts"),
						bMainSelected = true;
					if (aProducts.length > 0) {
						for (var i = 0; i < aProducts.length; i++) {
							if (aProducts[i].IsMainProduct === true) {
								bMainSelected = false;
							}
						}
					}
					var newRow = {
						//RefDocID: this.Main.oCaseID,
						AffectedProductText: versionText,
						AffectedProductID: id,
						IsMainProduct: bMainSelected,
						RefDocObject: "1"
					};

					aProducts.push(newRow);
					this.getModel("crossIssueModel").refresh(true)
					oDialog.setBusy(false);
					oDialog.close();
					oDialog.destroy();

					/*var save = SaveData.createAffectedProduct(this, newRow);
					save.then(function (newProduct) {
						if (newProduct !== undefined) {
							var aProducts = that.oView.getModel("affectedProducts").getData();
							aProducts.push(newProduct);
							that.oView.getModel("affectedProducts").setData(aProducts);
							that.oView.getModel("affectedProducts").refresh();
							that.newProductAdded = true;
						}
						that.oSolutionDialog.setBusy(false);
						that.oSolutionDialog.close();
					});*/
				} else {
					oDialog.setBusy(false);

					sap.m.MessageBox.error(
						"This product is already added as an affected product.", {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error"
						}
					);
				}
			} else {
				oDialog.setBusy(false);
				sap.m.MessageBox.error(
					"Please select a product version first.", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error"
					}
				);
			}
		},

		checkProductID: function (id) {
			var aProducts = this.getModel("crossIssueModel").getProperty("/AffectedProducts");
			var bSaved = false;
			for (var i = 0; i < aProducts.length; i++) {
				if (aProducts[i].AffectedProductID === id) {
					bSaved = true;
					break;
				}
			}
			return bSaved;
		},

		onDeleteProduct: function (oEvent) {
			var sBindingPath = oEvent.getSource().getBindingContext("crossIssueModel").getPath();
			// get Index of selected item; pop returns the last element of the array
			var iIndex = sBindingPath.split("/").pop();
			this.getModel("crossIssueModel").getProperty("/AffectedProducts").splice(iIndex, 1);
			this.getModel("crossIssueModel").refresh();

		},

		onDeleteLinkedObject: function (oEvent) {
			var sBindingPath = oEvent.getSource().getBindingContext("crossIssueModel").getPath();
			var iIndex = sBindingPath.split("/").pop();
			this.getModel("crossIssueModel").getProperty("/LinkedObjects").splice(iIndex, 1);
			this.getModel("crossIssueModel").refresh();
		},

		onToggleMainProduct: function (oEvent) {
			var sBindingPath = oEvent.getSource().getBindingContext("crossIssueModel").getPath();
			var aProducts = this.getModel("crossIssueModel").getProperty("/AffectedProducts");
			aProducts.forEach(function (oProduct) {
				oProduct.IsMainProduct = false;
			});
			this.getModel("crossIssueModel").setProperty(sBindingPath + "/IsMainProduct", true);
			this.getModel("crossIssueModel").refresh();

		},

		openPPMSPopover: function (oEvent) {
			var sProductDialogId = this.getView().createId("AddPpmsIdDialog");
			Fragment.load({
				id: sProductDialogId,
				type: "XML",
				name: "com.sap.mcc.workplace.view.fragments.AddPpmsIdDialog",
				controller: this
			}).then(function (oPpmsDialog) {
				var oAppDepModel = this.getModel("appDepModel");
				oPpmsDialog.setModel(oAppDepModel, "appDepModel");
				this.getView().addDependent(oPpmsDialog);

				oPpmsDialog.open();
			}.bind(this))
		},

		searchPpms: function (oEvent) {
			var oValue = Fragment.byId(this.getView().createId("AddPpmsIdDialog"), "inputPpms").getValue();
			var oFilter = new Filter("PpmsID", FilterOperator.EQ, oValue);
			this.loadProductVersionByPpmsID(oFilter).then(function (oData) {
				if (oData.length > 0) {
					Fragment.byId(this.getView().createId("AddPpmsIdDialog"), "textPpms").setText(oData[0].Version);
					Fragment.byId(this.getView().createId("AddPpmsIdDialog"), "idPpms").setText(oData[0].ProductID);
					Fragment.byId(this.getView().createId("AddPpmsIdDialog"), "productVersion").setVisible(true);
					Fragment.byId(this.getView().createId("AddPpmsIdDialog"), "inputPpms").setValueState("None");
					Fragment.byId(this.getView().createId("AddPpmsIdDialog"), "buttonAddPpms").setEnabled(true);
				} else {
					Fragment.byId(this.getView().createId("AddPpmsIdDialog"), "inputPpms").setValueState("Error");
					Fragment.byId(this.getView().createId("AddPpmsIdDialog"), "inputPpms").setValueStateText("Incorrect PPMS-ID");
					Fragment.byId(this.getView().createId("AddPpmsIdDialog"), "buttonAddPpms").setEnabled(false);
					Fragment.byId(this.getView().createId("AddPpmsIdDialog"), "productVersion").setVisible(false);
				}
			}.bind(this));
		},

		loadProductVersionByPpmsID: function (oFilter) {
			return new Promise(function (resolve, reject) {
				var oModel = this.getModel("appDepModel");
				oModel.read("/ProductVersionSet", {
					filters: [oFilter],
					success: function (oData) {
						resolve(oData.results);
					},
					error: function (err) {
						resolve([]);
					}
				});
			}.bind(this));
		},

		cancelPpms: function (oEvent) {
			oEvent.getSource().getParent().close();
			oEvent.getSource().getParent().destroy();
		},

		uuidv4: function () {
			return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
				var r = Math.random() * 16 | 0,
					v = c == 'x' ? r : (r & 0x3 | 0x8);
				return v.toString(16);
			});
		},

		addSolutionByPpms: function (oEvent) {
			var oDialog = oEvent.getSource().getParent()
			oDialog.setBusy(true);
			var sProductId = Fragment.byId(this.getView().createId("AddPpmsIdDialog"), "idPpms").getText()
			if (this.checkProductID(sProductId) === false) {
				var that = this;
				var sProductVersion = Fragment.byId(this.getView().createId("AddPpmsIdDialog"), "textPpms").getText();
				var Products = this.getModel("crossIssueModel").getProperty("/AffectedProducts"),
					bMainSelected = true;
				if (Products.length > 0) {
					for (var i = 0; i < Products.length; i++) {
						if (Products[i].IsMainProduct === true) {
							bMainSelected = false;
						}
					}
				}

				var newRow = {
					AffectedProductText: sProductVersion,
					AffectedProductID: sProductId,
					IsMainProduct: bMainSelected,
					RefDocObject: "1"
				};

				this.getModel("crossIssueModel").getProperty("/AffectedProducts").push(newRow);
				this.getModel("crossIssueModel").refresh(true);
				oDialog.setBusy(false);
				oDialog.close();
				oDialog.destroy();

			} else {
				oDialog.setBusy(false);
				sap.m.MessageBox.error(
					"This product is already added as an affected product.", {
						icon: sap.m.MessageBox.Icon.ERROR,
						title: "Error"
					}
				);
			}
		},

		setRequestAttachedFaild: function () {
			var that = this;
			this.getModel("appDepModel").attachRequestFailed(function (oEvent) {
				if (!this.getCardProperty("/editMode")) {
					var method = oEvent.getParameter("method");
					var err = oEvent.getParameter("response");
					var request = oEvent.getParameter("url");
					var DB = "CRM (APP DEP Service)";
					var service = "ZS_APP_DEP_SRV";
					var Set = request.split("(")[0];
					Set = Set.split("?")[0];
					if (method === "GET") {
						that.showErrorMsgRead(err, DB, Set, request, service, method);
					} else if (method === "POST") {
						that.showErrorMsgCreate(err, DB, Set, request, service, method);
					} else if (method === "DELETE") {
						that.showErrorMsgDelete(err, DB, Set, request, service, method);
					} else if (method === "MERGE") {
						that.showErrorMsgMerge(err, DB, Set, request, service, method);
					}
				}
			}.bind(this));
		},

		showErrorMsgRead: function (err, DB, Set, request, service, method) {
			var that = this;
			try {
				var Msg = JSON.parse(err.responseText).error.message.value;
			} catch (e) {
				try {
					var Msg = JSON.parse(err.responseText).error.message;
				} catch (e) {
					var Msg = $(err.responseText).find('message').first().text();
				}
			}

			var text = "An error occured while reading an entry from " + Set + " on " + DB + ". \n\n" + Msg;
			var error = {
				Method: method,
				RequestURL: request,
				CaseID: "",
				oDataService: service,
				ErrorMessage: Msg,
				ErrorStatusCode: err.statusCode.toString()
			};

			var addText = "";

			that.createDialog("Error during Read", text, addText);
		},

		showErrorMsgCreate: function (err, DB, Set, request, service, method) {
			try {
				var Msg = JSON.parse(err.responseText).error.message.value;
			} catch (e) {
				var Msg = $(err.responseText).find('message').first().text();
			}
			var that = this;

			var text = "An error occured while creating an entry on " + Set + " on " + DB + ".\n\n" + Msg;

			var error = {
				Method: method,
				RequestURL: request,
				CaseID: "",
				oDataService: service,
				ErrorMessage: Msg,
				ErrorStatusCode: err.statusCode.toString()
			};

			var addText = "";

			that.createDialog("Error during Create", text, addText);
		},

		showErrorMsgDelete: function (err, DB, Set, request, service, method) {
			try {
				var Msg = JSON.parse(err.responseText).error.message.value;
			} catch (e) {
				var Msg = $(err.responseText).find('message').first().text();
			}
			var that = this;

			var text = "An error occured while deleting an entry on " + Set + " on " + DB + ".\n\n" + Msg;

			var error = {
				Method: method,
				RequestURL: request,
				CaseID: "",
				oDataService: service,
				ErrorMessage: Msg,
				ErrorStatusCode: err.statusCode.toString()
			};

			var addText = "";

			that.createDialog("Error during Delete", text, addText);
		},

		showErrorMsgMerge: function (err, DB, Set, request, service, method) {
			try {
				var Msg = JSON.parse(err.responseText).error.message.value;
			} catch (e) {
				var Msg = $(err.responseText).find('message').first().text();
			}
			var that = this;

			var text = "An error occured while Updating an entry on " + Set + " on " + DB + ".\n\n" + Msg;

			var error = {
				Method: method,
				RequestURL: request,
				CaseID: "",
				oDataService: service,
				ErrorMessage: Msg,
				ErrorStatusCode: err.statusCode.toString()
			};

			var addText = "";

			that.createDialog("Error during Update", text, addText);
		},

		createDialog: function (title, text, addText) {
			var bAddText = true;
			if (addText === "") {
				bAddText = false;
			}

			var dialog = new sap.m.Dialog({
				title: title,
				icon: "sap-icon://error",
				state: "Error",
				titleAlignment: "Center",
				contentWidth: "600px",
				content: new sap.m.VBox({
					items: [
						new sap.m.Text({
							text: text
						}).addStyleClass("sapUiSmallMarginBeginEnd sapUiSmallMarginTop"),
						new sap.m.Button({
							text: "More Details",
							type: "Transparent",
							visible: bAddText,
							press: function (oEvent) {
								oEvent.getSource().getParent().getItems()[2].setVisible(true);
							}
						}).addStyleClass("sapUiTinyMargin"),
						new sap.m.Text({
							text: addText,
							visible: false,
							wrapping: true
						}).addStyleClass("sapUiSmallMarginBeginEnd sapUiSmallMarginBottom")
					]
				}),
				endButton: new sap.m.Button({
					text: "Close",
					press: function (oEvent) {
						oEvent.getSource().getParent().close();
						oEvent.getSource().getParent().destroy();
					}
				})
			});

			this.getView().addDependent(dialog);
			dialog.open();
		},

		_handleCrossIssueErrors: function (bTopIssue, aError, sTopIssueID = false) {
			var aMessages = [];

			if (bTopIssue) {
				aMessages.push({
					type: 'Success',
					title: "Cross Issue (" + sTopIssueID + ") saved with Error",
					description: 'Please see other error messages for more details.',
					subtitle: 'Please see other error messages for more details.',
					counter: 1
				})
			} else {
				var oResponseText = JSON.parse(aError.responseText);
				aMessages.push({
					type: 'Error',
					title: 'Save Cross Issue Faild',
					description: oResponseText.error.message.value,
					subtitle: oResponseText.error.message.value,
					counter: 1
				})
			}

			var aAffectedProduct = [];
			var oAffectedProductErr = {};
			var aPartiesInvolved = [];
			var oPartiesInvolvedErr = {};
			var aLinkedObjects = [];
			var oLinkedObjectsErr = {};

			if (aError.length) {
				var oModelData = this.getView().getModel("crossIssueModel").getData();

				aLinkedObjects = oModelData.LinkedObjects;

				for (var i = 0; i < aError.length; i++) {
					switch (aError[i].entitySet) {
					case "/AffectedProductSet":
						oAffectedProductErr = aError[i];
						aAffectedProduct = oModelData.AffectedProducts;
						break;
					case "/PartiesInvolvedSet":
						oPartiesInvolvedErr = aError[i];
						aPartiesInvolved = oModelData.CustomerTags;
						break;
					case "/LinkedObjects":
						oLinkedObjectsErr = aError[i];
						aLinkedObjects = oModelData.LinkedObjects;
						break;
					}
				}

				aAffectedProduct.forEach(function (element) {
					var oResponseText = JSON.parse(oAffectedProductErr.responseText);
					aMessages.push({
						type: 'Error',
						title: "Could not save Affected Product (" + element.AffectedProductID + ")",
						description: oResponseText.error.message.value,
						subtitle: oResponseText.error.message.value
					})
				});

				aPartiesInvolved.forEach(function (element) {
					var oResponseText = JSON.parse(oPartiesInvolvedErr.responseText);
					aMessages.push({
						type: 'Error',
						title: "Could not save Affected Customer " + element.text,
						description: oResponseText.error.message.value,
						subtitle: oResponseText.error.message.value
					})
				});

				aLinkedObjects.forEach(function (element) {
					var oResponseText = JSON.parse(oLinkedObjectsErr.responseText);
					aMessages.push({
						type: 'Error',
						title: "Could not save Linked Object (" + element.Description + ")",
						description: oResponseText.error.message.value,
						subtitle: oResponseText.error.message.value
					})
				});
			}

			this.openErrorMessageView(aMessages);
		},

		// *****************************************************************************************
		// *****************************************************************************************
		// **			BEGIN: CODE REUSE MCC One Dashboard
		// **			https://github.wdf.sap.corp/customerexperience/mcconedashboard/
		// **			SubscriptionSettings.controller.js
		// *****************************************************************************************
		// *****************************************************************************************

		onSuggest: function (oEvent) {
			this.getModel("crossIssueModel").setProperty("/customer", []);
			var oMultiInput = oEvent.getSource();
			var oModel = this.getModel("critSitModel");
			var sValue = oEvent.getParameter("suggestValue");
			var aFilter = new Array(
				new Filter([
						new Filter("Name1", sap.ui.model.FilterOperator.Contains, sValue),
						new Filter("ErpCustNo", sap.ui.model.FilterOperator.EQ, sValue),
						new Filter("Partner", sap.ui.model.FilterOperator.EQ, sValue)
					],
					false
				)
			);

			//set busy indicator
			oMultiInput.setBusy(true);
			oMultiInput.setBusyIndicatorDelay(0);
			var iacValues = ["1", "8", "3", "T", "U", "O", "P"];
			oModel.read("/CustomerSet", {
				urlParameters: {
					"$top": 999,
					"$select": "Partner,Name1,ErpCustNo,Iac,CountryT,GuErpNo,IsGlobalUltimate"
				},
				filters: aFilter,
				success: function (data, response) {
					oMultiInput.setBusy(false);
					//var aCustomers = data.results;

					var aCustomerData = [];
					//push data to array
					data.results.forEach(function (customer) {

						aCustomerData.push({
							text: customer.Name1,
							key: customer.Partner,
							filterProp: customer.IsGlobalUltimate === "X" ? "Global Ultimate" : "Customer",
							iac: iacValues.indexOf(customer.Iac) > -1 ? customer.Iac : "ZZZZZ",
							description: " - " + customer.CountryT //"(" + customer.CountryT + ")"
						});

					}.bind(this));

					iacValues.push("ZZZZZ");

					//sort array by filterProp and iac
					aCustomerData = aCustomerData.sort(function (a, b) {
						if (iacValues.indexOf(a.iac) < iacValues.indexOf(b.iac)) {
							return -1;
						} else if (iacValues.indexOf(a.iac) > iacValues.indexOf(b.iac)) {
							return 1;
						} else if (b.filterProp < a.filterProp) {
							return -1;
						} else if (b.filterProp > a.filterProp) {
							return 1;
						} else if (b.text > a.text) {
							return -1;
						} else if (b.text < a.text) {
							return 1;
						} else if (b.description > a.description) {
							return -1;
						} else if (b.description < a.description) {
							return 1;
						}
						return 0;
					}.bind(this));

					for (var i = 0; i < aCustomerData.length; i++) {
						if (i === 0) {
							aCustomerData[i].isTopMatch = true;
						} else if ((i === 1 || i === 2) && aCustomerData[i].iac !== "ZZZZZ") {
							aCustomerData[i].isTopMatch = true;
						} else if (i > 2 && i < 5 && aCustomerData[i].iac !== "ZZZZZ" && aCustomerData[i].iac === aCustomerData[(i - 1)].iac) {
							aCustomerData[i].isTopMatch = true;
						} else {
							aCustomerData[i].isTopMatch = false;
						}
					}

					this.getModel("crossIssueModel").setProperty("/customer", aCustomerData);
					this.getModel("crossIssueModel").refresh(true);
				}.bind(this),
				error: function (oErr) {}.bind(this)

			})
		},

		// *****************************************************************************************
		// *****************************************************************************************
		// **			END: CODE REUSE MCC One Dashboard
		// **			https://github.wdf.sap.corp/customerexperience/mcconedashboard/
		// **			SubscriptionSettings.controller.js
		// *****************************************************************************************
		// *****************************************************************************************

		generateEmail: function (oCrossIssue, oNotes) {

			var oTemplate;
			var aRecipients = [];
			var aMailTemplates = this.getModel("EmailTemplates").getProperty("/templates");
			if (aMailTemplates && aMailTemplates.length > 0) {
				var oMailTemplate = aMailTemplates[0];
				var sTemplateName = oMailTemplate.TemplateName;
				var aMailRoles = oMailTemplate.MailRoles.results;

				if (aMailRoles && aMailRoles.length > 0) {
					//add creator of Cross issue as recipient
					var oUserInfoModel = sap.ui.getCore().getModel("UserInfo");
					var sMailAdress = oUserInfoModel.getProperty("/email");
					
					var oRecipients = {
						"to": "",
						"cc": ""
					};
					
					oRecipients.cc = sMailAdress + ";";
					var aMailRoles = aMailRoles.filter(roles => roles.RoleType === "G"); 

					aMailRoles.forEach(function (MailRole) {
						if (MailRole.ToOrCC === "CC") {
							oRecipients.cc = oRecipients.cc + MailRole.Recipients + "; ";
						} else if (MailRole.ToOrCC === "To") {
							oRecipients.to = oRecipients.to + MailRole.Recipients + "; ";
						}

					});

					var body = {
						"variable replacement": [{
							"variable": "crossissue_id",
							"replaceWith": oCrossIssue.TopIssueID
						}, {
							"variable": "cross_issue_title",
							"replaceWith": oCrossIssue.Description
						}, {
							"variable": "cross_issue_problem",
							"replaceWith": oNotes.A001
						}, {
							"variable": "cross_issue_business_impact",
							"replaceWith": oNotes.ZSCA
						}, {
							"variable": "username",
							"replaceWith": oCrossIssue.CreatedByName
						}],
						"recipients": oRecipients
					};

					body = JSON.stringify(body);

					var that = this;

					var templatePath = "/dbmanager/getMailTemplate?filename=MCCWorkplace/" + sTemplateName + "&sendMail=true";

					var req = new XMLHttpRequest();

					req.open("POST", templatePath, true);
					req.setRequestHeader("Content-type", "application/json; charset=utf-8");
					req.responseType = "blob";
					req.onload = function (event) {
						if (req.status === 201) {
							/*	var blob = req.response;
								var fileName = "";
								if (req.getResponseHeader("content-disposition")) {
									fileName = req.getResponseHeader("content-disposition").split("filename=")[1]; //req.getResponseHeader("filename");
								}
								if (window.navigator.msSaveOrOpenBlob) {
									window.navigator.msSaveOrOpenBlob(blob, fileName);
								} else {
									var link = document.createElement('a');
									link.href = window.URL.createObjectURL(blob);
									link.download = fileName;
									link.click();
								}*/
						} else {
							sap.m.MessageBox.error(
								"An error occured while generating the mail template.", {
									icon: sap.m.MessageBox.Icon.ERROR,
									title: "Mail Generation Failed",
									onClose: function () {}
								}
							);
						}
					};

					req.send(body);
				}
			}

		},

		_generateCrossIssueLink: function (sCrossIssueId) {
			var sHostname = window.location.hostname;
			var sURL = null;

			// SAP IT Cloud T - https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites
			if (sHostname.lastIndexOf("sapitcloudt") > -1 || sHostname.lastIndexOf("a44f228ad") > -1) {
				sURL = this.getResourceBundle().getText("mccWorkbenchTest", sCrossIssueId);
			} else if (sHostname === "fiorilaunchpad.sap.com" || sHostname.lastIndexOf("a87daa223") > -1) {
				sURL = this.getResourceBundle().getText("mccWorkbenchProd", sCrossIssueId);
			}
			return sURL;
		},

		_getMailTemplates: function () {
			var oWorkbenchModel = this.getModel("workbenchModel");
			var oFilter = new Filter("profile", FilterOperator.EQ, "mcc-workplace-crossIssue");
			var oMailTemplatePromise = new Promise(function (resolve, reject) {
				oWorkbenchModel.read("/MailTemplates", {
					filters: [oFilter],
					urlParameters: {
						"$expand": "MailRoles"
					},
					success: function (oData) {
						resolve(oData.results);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			}.bind(this));

			oMailTemplatePromise.then(function (aMailTemplates) {
				var oMailTemplateModel = new JSONModel({
					templates: aMailTemplates
				});
				this.getView().setModel(oMailTemplateModel, "EmailTemplates");
			}.bind(this)).catch(function (oError) {
				console.log("Error loading Mail Templates: " + oError);
			});

		},
		
		onDataExport: function (oEvent) {
			this.oConfidentialFragment.close()

			var aCols, aExportingData, oSettings, oSheet;

			aCols = this._createColumnConfig();
			aExportingData = this._addMCCWorkplaceUrlForSpreadsheet(this.getModel("cardModel").getProperty('/crossIssues'));

			oSettings = {
				workbook: {
					columns: aCols,
					context: {
						sheetName: "Cross Issues"
					}
				},
				dataSource: aExportingData,
				fileName: "CrossIssues.xlsx",
				showProgress: false
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build()
				.finally(function () {
					//ToDo oSheet.destroy();
				});
		},

		_createColumnConfig: function () {
			return [{
				label: 'Cross Issue ID',
				property: 'TopIssueID',
				type: EdmType.String,
			}, {
				label: 'Rating',
				property: 'RatingText',
				type: EdmType.String
			}, {
				label: 'Title',
				property: 'Description',
				type: EdmType.String,
			}, {
				label: 'Status',
				property: 'StatusText',
				type: EdmType.String,
			}, {
				label: 'Business Scenario',
				property: 'BusinessScenario',
				type: EdmType.String,
			}, {
				label: 'Open For',
				property: 'CreatedAt',
				type: EdmType.DateTime,
			}, {
				label: 'Product Version',
				property: 'Products',
				type: EdmType.String,
			}, {
				label: 'Cross Issue ID (Link)',
				property: 'workplaceURL',
				type: EdmType.String,
			}];
		},
		
		_addMCCWorkplaceUrlForSpreadsheet: function (aArray) {
			var sHostname = window.location.hostname;
			var sURL = null;

			aArray.forEach(function (oItem, iIndex, aArray) {
				// SAP IT Cloud T - https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites
				if (sHostname.lastIndexOf("sapitcloudt") > -1 || sHostname.lastIndexOf("a44f228ad") > -1) {
					sURL = this.getResourceBundle().getText("mccWorkbenchTest", [oItem.TopIssueID]);
				} else if (sHostname === "fiorilaunchpad.sap.com" || sHostname.lastIndexOf("a87daa223") > -1) {
					sURL = this.getResourceBundle().getText("mccWorkbenchProd", [oItem.TopIssueID]);
				}

				aArray[iIndex].workplaceURL = sURL;
			}.bind(this));

			return aArray;

		},
		
		formatBusinesScenario: function(sValue) {
			var aDropdownValues = this.getCardProperty("/dropdownValues/0");
			if( typeof(aDropdownValues) !== "undefined" && aDropdownValues.length > 0) {
				var oFound = aDropdownValues.find(function(oDropdown) {
					return (oDropdown.DropdownKey === sValue);
				})
				
				if(typeof(oFound) !== "undefined") return oFound.DropdownValue;
				else return sValue;
			} else {
				return sValue;
			}
		}

	});
});