sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel"
], function (BaseCardController, JSONModel) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.MCCInbox.MCCInbox", {

		// Initialize the view and make a call to the refresh method
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			this.onUpdateCard();
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			var oFilter = [];
			// load the model from models file
			var model = this.getModel("agsDashboardService");
			// set the filters
			var f1 = new sap.ui.model.Filter("activity_cat", sap.ui.model.FilterOperator.EQ, "Z91"); //CategoryID
			var f2 = new sap.ui.model.Filter("activity_cat", sap.ui.model.FilterOperator.EQ, "ZB2");
			var f3 = new sap.ui.model.Filter("activity_cat", sap.ui.model.FilterOperator.EQ, "Z89");
			var f4 = new sap.ui.model.Filter("activity_result_desc", sap.ui.model.FilterOperator.EQ, "Z2ZS460001"); //ResultID 
			var f5 = new sap.ui.model.Filter("activity_result_desc", sap.ui.model.FilterOperator.EQ, "Z2ZS460002");
			var f6 = new sap.ui.model.Filter("activity_result_desc", sap.ui.model.FilterOperator.EQ, "Z2ZS460003");
			var f7 = new sap.ui.model.Filter("activity_result_desc", sap.ui.model.FilterOperator.EQ, "Z2ZS460004");
			var f8 = new sap.ui.model.Filter("activity_result_desc", sap.ui.model.FilterOperator.EQ, "Z2ZS460040");
			var prio = new sap.ui.model.Filter("activity_priority", sap.ui.model.FilterOperator.EQ, "1");
			var st = new sap.ui.model.Filter("activity_service_team", sap.ui.model.FilterOperator.EQ, "0026670166");// MainServiceTeam
			var fOpen1 = new sap.ui.model.Filter("activity_status_desc", sap.ui.model.FilterOperator.EQ, "In Process");//PriorityID would be better currently PriorityDesc
			var fOpen2 = new sap.ui.model.Filter("activity_status_desc", sap.ui.model.FilterOperator.EQ, "New");
			var fOpen = new sap.ui.model.Filter({
				filters: [fOpen1, fOpen2],
				and: false
			});
			var fCat = new sap.ui.model.Filter({
				filters: [f1, f2, f3],
				and: false
			});
			var resultDes = new sap.ui.model.Filter({
				filters: [f4, f5, f6, f7, f8],
				and: false
			});
			oFilter.push(fOpen);
			oFilter.push(fCat);
			oFilter.push(st);
			oFilter.push(resultDes);
			oFilter.push(prio);
			
			var sText1 = this.getView().getModel("i18n").getResourceBundle().getText("mccInboxGlobal");
			model.read("/ActivityList/", {
				filters: oFilter,
				success: function (oResult1) {
					// sort the results by date, set the model to the view, keep a count of the number of entries, and set the height accordingly
					var oResult = this.bubbleSort(oResult1);

					this.setCardProperty("/data", oResult);

					this.setCardProperty("/customHeader/additionalCardTitle", sText1 + " (" + oResult.length + ")");
					var scroll = this.getView().byId("s1");
					if (oResult.length > 9) {
						scroll.setHeight("31rem");
					}
					this.setCardSuccessState();
				}.bind(this),
				error: function () {
					this.setCardErrorState();
				}.bind(this)
			});
		},

		//method for sorting the activites by create date
		bubbleSort: function (oResult) {
			var n = oResult.results.length;
			for (var i = 0; i < n - 1; i++) {
				for (var j = 0; j < n - i - 1; j++) {
					if ((oResult.results[j].activity_create_date) > (oResult.results[j + 1].activity_create_date)) {
						var temp = oResult.results[j];
						oResult.results[j] = oResult.results[j + 1];
						oResult.results[j + 1] = temp;
					}
				}
			}
			return oResult.results;
		},

		//On selecting an activity in the table, navigate to the activity link in the CRM
		onSelectionChange: function (oEvent) {
			var sPath = oEvent.getParameters().rowBindingContext.sPath;
			var activityId = this.getModel("cardModel").getProperty(sPath).activity_id;
			
			var currentUrl = window.location.href;
			var relativeUrl =
				"/sap/bc/bsp/sap/crm_ui_start/default.htm?saprole=ZSU_DEFAULT&crm-object-type=BT126_APPT&crm-object-action=B&crm-object-keyname=OBJECT_ID&crm-object-value=" +
				activityId;
			var urlICP = this.getView().getModel("i18n").getResourceBundle().getText("urlICPSAP");
			var urlICT = this.getView().getModel("i18n").getResourceBundle().getText("urlICTSAP");
			var url = urlICP + relativeUrl;
			if (currentUrl.includes("a44f228ad.dispatcher.hana.ondemand.com")) {
				//we are in test environment
				url = urlICT + relativeUrl;
			}
			var win = window.open(url, "_blank");
			win.focus();
		},

		//Convert date format to month day year ex: "February 2, 2019"
		getmDate: function (date) {
			var month = ["January", "February", "March", "April", "May", "June",
				"July", "August", "September", "October", "November", "December"
			][date.getMonth()];
			var str = month + " " + date.getDate() + " " + date.getFullYear();
			return str;
		},

		openActivity: function (oEvent) {
			var oActivity = oEvent.getSource().getBindingContext("cardModel").getObject();
			var sTestURL = this.getView().getModel("i18n").getResourceBundle().getText("ActivitySearchTest", [oActivity.activity_id])  ;
			var sProdURL = this.getView().getModel("i18n").getResourceBundle().getText("ActivitySearch", [oActivity.activity_id]) ;
			this.navToApp(sTestURL, sProdURL, {}, false);
		}
	});
});