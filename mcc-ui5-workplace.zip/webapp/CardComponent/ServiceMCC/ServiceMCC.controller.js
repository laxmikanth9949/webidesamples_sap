sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/FilterType"
], function (BaseCardController, JSONModel, Filter, FilterOperator, Filtertype) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.ServiceMCC.ServiceMCC", {

		// Initialize the view and make a call to the refresh method
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */
			this.onUpdateCard();
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			var oModel = this.getView().getModel("agsDashboardService");
			var fTableFilter = new Filter({
				filters: [
					new Filter("activity_service_team", FilterOperator.EQ, "20672944"),
					new Filter({
						filters: [
							new Filter("activity_status", FilterOperator.EQ, "E0010"),
							new Filter("activity_status", FilterOperator.EQ, "E0011"),
							new Filter("activity_status", FilterOperator.EQ, "E0018"),
							new Filter("activity_status", FilterOperator.EQ, "E0019"),
							new Filter("activity_status", FilterOperator.EQ, "E0020"),
							new Filter("activity_status", FilterOperator.EQ, "E0021"),
							new Filter("activity_status", FilterOperator.EQ, "E0022"),
							new Filter("activity_status", FilterOperator.EQ, "E0023"),
							new Filter("activity_status", FilterOperator.EQ, "E0024"),
							new Filter("activity_status", FilterOperator.EQ, "E0025")
						],
						and: false
					})
				],
				and: true
			});
			

			oModel.read("/ActivityList", {
				filters: [fTableFilter],
				$expand: "ActivityCases",
				success: function (oData) {
					this.setCardProperty("/data", oData.results);
					this.setCardProperty("/customHeader/additionalCardTitle", " (" + oData.results.length + ")");
					
					this.setCardSuccessState();
				}.bind(this),
				error: function (oError) {
					this.setCardErrorState();
				}.bind(this)
			});
		},

		// reload: function () {
		// 	this.initializeView();
		// },

		//On selecting an activity in the table, navigate to the activity link in the CRM
		onSelectionChange: function (oEvent) {
			var sPath = oEvent.getParameters().rowBindingContext.sPath;
			var activityId = this.getModel("cardModel").getProperty(sPath).activity_id
			var currentUrl = window.location.href;
			var relativeUrl =
				"/sap(bD1lbiZjPTAwMSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?saprole=ZSU_DEFAULT&crm-object-type=BT126_APPT&crm-object-action=B&crm-object-keyname=OBJECT_ID&crm-object-value=" +
				activityId;
			var urlICP = this.getView().getModel("i18n").getResourceBundle().getText("urlICPSAP");
			var urlICT = this.getView().getModel("i18n").getResourceBundle().getText("urlICTSAP");
			var url = urlICP + relativeUrl;
			if (currentUrl.includes("a44f228ad.dispatcher.hana.ondemand.com")) {
				//we are in test environment
				url = urlICT + relativeUrl;
			}
			var win = window.open(url, "_blank");
			win.focus();
		},

		formatURL: function (sCustNumber) {
			var currentUrl = window.location.href;
			var sMccCriticalSitUrl = this.getView().getModel("i18n").getResourceBundle().getText("mccOneDashboardProd", [sCustNumber]);
			var url = sMccCriticalSitUrl;
			var mccCritSitCustomerURL2 = this.getView().getModel("i18n").getResourceBundle().getText("mccOneDashboardTest", [sCustNumber]);
			if (currentUrl.includes("a44f228ad.dispatcher.hana.ondemand.com")) {
				//we are in test envrionment
				url = mccCritSitCustomerURL2 ;
			}
			return url;
		}
	});
});