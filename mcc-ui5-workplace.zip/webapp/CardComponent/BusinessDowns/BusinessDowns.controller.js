sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"com/sap/mcc/workplace/CardComponent/CardFormatter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"./formatter",
	"sap/ui/core/Icon",
	"sap/ui/core/Fragment"
], function (BaseCardController, CardFormatter, JSONModel, Filter, FilterOperator, formatter, Icon, Fragment) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.BusinessDowns.BusinessDowns", {
		//	formatter: CardFormatter,

		// Initialize the view and make a call to the refresh method
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", [
				new sap.ui.core.Icon({
					visible: "{= !${/busy}}",
					src: "sap-icon://email",
					tooltip: "Business Down Report Mail",
					press: [this.openMailTemplateFragement, this],
					color: "#FFFFFF"
				})
			]);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			this.onUpdateCard();
			sap.ui.getCore().getEventBus().subscribe("mcs.emea.esca.overview", "reload", this.onUpdateCard, this);
			
			this._getMailTemplates();
		
			//register AttachChange event for binding change to update the card title when for example a column filter is applied		
			this.getView().byId("table-mcs-openBusinessDowns").getBinding("rows").attachChange(this.updateCardTitle.bind(this, "results"));
		},
					

		// Check if the card has not been removed from the view, set the filters and set the json model to the view
		onUpdateCard: function () {
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count
			var that = this;

			var aFilter = [];
			var oStatusFilter = new Filter({
				filters: [
					new Filter("StatusID", FilterOperator.EQ, "20"),
					new Filter("StatusID", FilterOperator.EQ, "30"),
					new Filter("StatusID", FilterOperator.EQ, "40")
				],
				and: false
			});
			var oProcessTypeFilter = new Filter({
				filters: [
						 new Filter("ProcessTypeId", FilterOperator.EQ, "ZSPRCTYP02"),
						 new Filter("ProcessTypeId", FilterOperator.EQ, "ZSPRCTYP04"),
					],
					and: false
			});
			aFilter.push(oStatusFilter);
			aFilter.push(oProcessTypeFilter);

			this._loadCases(aFilter, {}).then(function (aCases) {
				aCases.forEach(function(oCase){
					if(oCase.ProcessTypeId === "ZSPRCTYP02"){
						oCase.Type = "BDM";
					} else if (oCase.ProcessTypeId === "ZSPRCTYP04"){
						oCase.Type = "WatchList";
					}
				});
				this.setCardProperty("/results", aCases);
				that.setCardProperty("/customHeader/additionalCardTitle", " (" + aCases.length + ")");
				
				this.setCardSuccessState();
			}.bind(this)).catch(function (oError) {
				this.setCardErrorState();
			});
		},

		//method for sorting the activites by create date
		bubbleSort: function (oResult) {
			var that = this;
			var n = oResult.results.length;
			for (var i = 0; i < n - 1; i++) {
				for (var j = 0; j < n - i - 1; j++) {
					if (that.createDate(oResult.results[j].create_time) > that.createDate(oResult.results[j + 1].create_time)) {
						var temp = oResult.results[j];
						oResult.results[j] = oResult.results[j + 1];
						oResult.results[j + 1] = temp;
					}
				}
			}
			return oResult;
		},

		onPopinLayoutChanged: function () {
			var oTable = this.byId("table-mcs-openBusinessDowns");
			var oComboBox = this.byId("idPopinLayout");
			var sPopinLayout = oComboBox.getSelectedKey();
			switch (sPopinLayout) {
			case "Block":
				oTable.setPopinLayout(sap.m.PopinLayout.Block);
				break;
			case "GridLarge":
				oTable.setPopinLayout(sap.m.PopinLayout.GridLarge);
				break;
			case "GridSmall":
				oTable.setPopinLayout(sap.m.PopinLayout.GridSmall);
				break;
			default:
				oTable.setPopinLayout(sap.m.PopinLayout.Block);
				break;
			}
		},

		onSelectionFinish: function (oEvent) {
			var aSelectedItems = oEvent.getParameter("selectedItems");
			var oTable = this.byId("table-mcs-openBusinessDowns");
			var aSticky = aSelectedItems.map(function (oItem) {
				return oItem.getKey();
			});
			oTable.setSticky(aSticky);
		},

		//On selecting an case in the table, navigate to the case link in the CRM
		onSelectionChange: function (oEvent) {
			
			var sPath = oEvent.getParameters().rowBindingContext.sPath; //Dec 23, 2020 Fix Marvin - click on table row did not work
			var caseId = this.getModel("cardModel").getProperty(sPath).CaseID;
			
			var currentUrl = window.location.href;
			var relativeUrl =
				"/sap/bc/bsp/sap/crm_ui_start/default.htm?sap-language=EN&saprole=ZSU_DEFAULT&crm-object-type=CRM_CMG&crm-object-action=B&crm-object-keyname=EXT_KEY&crm-object-value=" +
				caseId;
			var urlICP = this.getView().getModel("i18n").getResourceBundle().getText("urlICPSAP");
			var urlICT = this.getView().getModel("i18n").getResourceBundle().getText("urlICTSAP");
			var url = urlICP + relativeUrl;
			if (currentUrl.includes("a44f228ad.dispatcher.hana.ondemand.com")) {
				//we are in test environment
				url = urlICT + relativeUrl;
			}
			var win = window.open(url, "_blank");
			win.focus();
			if (currentUrl.includes("a44f228ad.dispatcher.hana.ondemand.com")) {
				//we are in test environment
				url = urlICT + relativeUrl;
			}
			win.focus();
		},

		//returns a date in form days and hours
		//param(information) date in string format
		getDays: function (information) {
			// get total seconds between the times
			var delta = Math.abs(new Date() - this.createDate(information)) / 1000;

			// calculate (and subtract) whole days
			var days = Math.floor(delta / 86400);
			delta -= days * 86400;

			// calculate (and subtract) whole hours
			var hours = Math.floor(delta / 3600) % 24;
			delta -= hours * 3600;

			// calculate (and subtract) whole minutes
			var minutes = Math.floor(delta / 60) % 60;
			delta -= minutes * 60;

			// what's left is seconds
			var seconds = delta % 60;
			var text = days + " d " + hours + " h ";
			if ((days === 0) && hours === 0) {
				return "< 1 hour";
			}
			return text;
		},

		//returns a date in date format
		//param(temp) date in string format
		createDate: function (temp) {
			if (temp) {
				var year = temp.substring(0, 4);
				var month = temp.substring(4, 6);
				var day = temp.substring(6, 8);
				var hour = temp.substring(8, 10);
				var minute = temp.substring(10, 12);
				var seconds = temp.substring(12, 14);

				return new Date(year, month - 1, day, hour, minute, seconds);
			}
		},

		//Convert date format to month day year ex: "February 2, 2019"
		//param(date1) date in date format
		getmDate: function (date1) {
			if (date1) {
				var date = this.createDate(date1);
				var oDateFormatter = new sap.ui.model.type.Date({
					style: "medium"
				});
				return oDateFormatter.formatValue(date, "sap.ui.model.type.Date");
			}
			return "";
		},

		_getMailTemplates: function () {
			var oWorkbenchModel = this.getModel("workbenchModel");
			var oFilter = new Filter("profile", FilterOperator.EQ, "mcc-workplace-bd");
			var oMailTemplatePromise = new Promise(function (resolve, reject) {
				oWorkbenchModel.read("/MailTemplates", {
					filters: [oFilter],
					urlParameters: {
						"$expand": "MailRoles"
					},
					success: function (oData) {
						resolve(oData.results);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			}.bind(this));

			oMailTemplatePromise.then(function (aMailTemplates) {
				var oMailTemplateModel = new JSONModel({
					templates: aMailTemplates
				});
				this.getView().setModel(oMailTemplateModel, "EmailTemplates");
			}.bind(this)).catch(function (oError) {
				console.log("Error loading Mail Templates: " + oError);
			});

		},

		openMailTemplateFragement: function (oEvent) {
			if (!this.oMailTemplateSelection) {
				Fragment.load({
					id: this.getView().getId(),
					name: "com.sap.mcc.workplace.view.fragments.MailTemplateSelection",
					controller: this
				}).then(function (oMailTemplateSelection) {
					oMailTemplateSelection.setModel(this.getView().getModel("EmailTemplates"), "EmailTemplates");
					this.oMailTemplateSelection = oMailTemplateSelection;
					//	this._oInformationDialog.setTitle(oCard.CardName + " - Card Information");
					this.getView().addDependent(this.oMailTemplateSelection);
					this.oMailTemplateSelection.open();
				}.bind(this));
			} else {
				this.oMailTemplateSelection.open();
			}

		},

		generateMailTemplate: function (oEvent) {
			var oWorkbenchModel = sap.ui.getCore().getModel("workplaceModel")
			var sMailTemplateBindingPath = this.getView().byId("mailTemplate").getSelectedButton().getBindingContext("EmailTemplates").getPath();
			var oMailTemplate = this.getModel("EmailTemplates").getProperty(sMailTemplateBindingPath);

			var sRegion = this.getView().byId("region").getSelectedButton().getText();
			var bRegionGlobal = sRegion === "Global" ? true : false;
			sRegion = sRegion === "Global" ? "" : sRegion;
			//using the expanded entity (Mailroels) of the selected mail template
		
			
			//always get the default/ global recipients  (RoleType property is set to G)
			var aMailRoles = oMailTemplate.MailRoles.results.filter(roles => roles.RoleType === "G");
			//add region specific addtional recipients (region !== Global)
			if(sRegion !== ""){
				var sFilterRegion = sRegion === "Americas" ? "NA" : sRegion;
				aMailRoles = aMailRoles.concat(oMailTemplate.MailRoles.results.filter(roles => roles.region === sFilterRegion && roles.RoleType === "R"));
			}

			// add additional Mail distribution list when region is set to global and MCS Business down report is selected
			// this behaviour can't be maintained via the Admin app
			if (oMailTemplate.TemplateName === "MCS_Business_Down_Report.msg" && bRegionGlobal) {

				var oGlobalToDistributionList = {
					"ToOrCC": "To",
					"Recipients": "DL PE CSI MCC BUSINESS DOWN REPORTING EXECUTIVES <DL_5C9B69601C0C750283163A91@global.corp.sap>"
				};
				aMailRoles.push(oGlobalToDistributionList);

				var oGlobalToDistributionListAmericas = {
					"ToOrCC": "CC",
					"Recipients": "DL PE CSI MCC BUSINESS DOWN REPORTING AMERICAS <DL_521532F6DF15DB27DF0108B7@global.corp.sap>"
				};
				aMailRoles.push(oGlobalToDistributionListAmericas);
				
				var oGlobalToDistributionListEMEA = {
					"ToOrCC": "CC",
					"Recipients": "DL PE CSI MCC BUSINESS DOWN REPORTING EMEA <DL_5CA45D101C0C750283163F39@global.corp.sap>"
				};
				aMailRoles.push(oGlobalToDistributionListEMEA);
				
				var oGlobalToDistributionListAPJ = {
					"ToOrCC": "CC",
					"Recipients": "DL PE CSI MCC BUSINESS DOWN REPORTING APJ <DL_5C9B641B1C0C750283163A8C@global.corp.sap>"
				};
				aMailRoles.push(oGlobalToDistributionListAPJ);

			}

			this.generateEmail(oMailTemplate.TemplateName, aMailRoles, sRegion);

			//clode Fragment
			oEvent.getSource().getParent().close();
		},

		generateEmail: function (sTemplateName, aRecipients, sRegion) {
			this.getView().setBusy(true);

			var oRecipients = {
				"to": "",
				"cc": ""
			};

			aRecipients.forEach(function (MailRole) {
				if (MailRole.ToOrCC === "CC") {
					oRecipients.cc = oRecipients.cc + MailRole.Recipients + "; ";
				} else if (MailRole.ToOrCC === "To") {
					oRecipients.to = oRecipients.to + MailRole.Recipients +"; ";
				}

			});

			var getBody,
				sTemplatePath = "/dbmanager/getMailTemplate?filename=MCCWorkplace/";
			//distinguitsch between templates
			if (sTemplateName === "MCS_Business_Down_Report.msg") {
				getBody = this.getBusinessDownMailBody(oRecipients, sRegion);
				sTemplatePath += "MCS_Business_Down_Report.msg";
			} else if (sTemplateName === "MCS_Duty_Manager_Handover_Report.msg") {
				getBody = this.getHandoverMailBody(oRecipients);
				sTemplatePath += "MCS_Duty_Manager_Handover_Report.msg";
			}
			var that = this;
			getBody.then(function (body) {
				var templatePath = sTemplatePath; //MCCWorkbench%2Fmcc-cpc%2FEngagement_Closure.msg"; //MCCWorkplace/MCS_Business_Down_Report.msg

				var req = new XMLHttpRequest();

				req.open("POST", templatePath, true);
				req.setRequestHeader("Content-type", "application/json; charset=utf-8");
				req.responseType = "blob";
				req.onload = function (event) {
					if (req.status === 200) {
						var blob = req.response;
						var fileName = "";
						if (req.getResponseHeader("content-disposition")) {
							fileName = req.getResponseHeader("content-disposition").split("filename=")[1]; //req.getResponseHeader("filename");
						}
						if (window.navigator.msSaveOrOpenBlob) {
							window.navigator.msSaveOrOpenBlob(blob, fileName);
						} else {
							var link = document.createElement('a');
							link.href = window.URL.createObjectURL(blob);
							link.download = fileName;
							link.click();
						}
					} else {
						sap.m.MessageBox.error(
							"An error occured while generating the mail template.", {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Mail Generation Failed",
								onClose: function () {}
							}
						);
					}
					that.oView.setBusy(false);
				};

				req.send(body);
			});
		},

		// Generate Mail template body for MCS_Business_Down_Report.msg
		// 1. load template specific cases (see filter Values)
		// 2. generate mail body json string
		getBusinessDownMailBody: function (oRecipients, sRegion) {
			return new Promise(function (resolve, reject) {
				var oUserInfo = sap.ui.getCore().getModel("UserInfo");
				var sName = oUserInfo.getProperty("/firstName") + " " + oUserInfo.getProperty("/lastName");
				var aFilter = [];
				var oStatusFilter = new Filter({
					filters: [
						new Filter("StatusID", FilterOperator.EQ, "30"),
						new Filter("StatusID", FilterOperator.EQ, "40")
					],
					and: false
				});
				var oProcessTypeFilter = new Filter("ProcessTypeId", FilterOperator.EQ, "ZSPRCTYP02");
				aFilter.push(oStatusFilter);
				aFilter.push(oProcessTypeFilter);

				var oCasePromise = this._loadCases(aFilter, {
					"$expand": "toActivity,toNote,toPartiesInvolved"
				});
				var oDate = new Date();
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MMMM d, yyyy"
				});
				var sCurrentDate = oDateFormat.format(oDate);
				//var sCurrentDate = oDate.getDate() + "." + oDate.getMonth() + "." + oDate.getFullYear();
				//ToDo 

				oCasePromise.then(function (aData) {

					var oBusinessDowns = this._generateBDList(aData);

					var body = {
						"variable replacement": [{
							"variable": "&lt;current_date&gt;",
							"replaceWith": sCurrentDate
						}, {
							"variable": "&lt;count_bdm_ongoing&gt;",
							"replaceWith": oBusinessDowns.ongoingBDcount.toString()
						}, {
							"variable": "&lt;count_bdm_closed&gt;",
							"replaceWith": oBusinessDowns.closedBDcount.toString()
						}, {
							"variable": "&lt;list_bdm_ongoing&gt;",
							"replaceWith": oBusinessDowns.ongoingBD //"<ul style='list-style-type:none; padding: 0; margin: 0 '> <li> <p align='justify'> <u> Customer:</u> Test Customer <br> <u>Delivery Unit:</u> OnPremise <br> <u>Engagement:</u> Enterprise Support <br> <u>CRM Case:</u> 000010022997 / <u>Incident No.:</u> 708817 2020 <br> <u>Since (UTC):</u> 22.10.2020 <br> <u>Issue/Impact:</u><br> The customer Bharat Electronics Limited reports that their SAP Supplier Relationship Management (SRM) production system is not accessible. The customer reports that due to an secure socket layer (SSL) certificate issue, the critical HTTPS integration between the portal and the backend SAP SRM system is failing. As a result, the customer states the entire supplier relationship operations (shopping cart and procurement) for around 4,000 users is affected. <br> <u>Status:</u><br> The issue is not resolved. SAP expert has requested customer to send screenshots of they SSL warnings and any errors seen. Also the customer was requested to attach step by step guide on how to reproduce the issue and to perform HTTP Watch trace during issue reproduction. <br> <u>Next Steps:</u><br> Customer to provide the requested information. SAP to continue investigation. </p><br> </li> <li> <p align='justify'> <u> Customer:</u> Test Customer <br> <u>Delivery Unit:</u> OnPremise <br> <u>Engagement:</u> Enterprise Support <br> <u>CRM Case:</u> 000010022997 / <u>Incident No.:</u> 708817 2020 <br> <u>Since (UTC):</u> 22.10.2020 <br> <u>Issue/Impact:</u><br> The customer Bharat Electronics Limited reports that their SAP Supplier Relationship Management (SRM) production system is not accessible. The customer reports that due to an secure socket layer (SSL) certificate issue, the critical HTTPS integration between the portal and the backend SAP SRM system is failing. As a result, the customer states the entire supplier relationship operations (shopping cart and procurement) for around 4,000 users is affected. <br> <u>Status:</u><br> The issue is not resolved. SAP expert has requested customer to send screenshots of they SSL warnings and any errors seen. Also the customer was requested to attach step by step guide on how to reproduce the issue and to perform HTTP Watch trace during issue reproduction. <br> <u>Next Steps:</u><br> Customer to provide the requested information. SAP to continue investigation. </p></li> </ul>"
						}, {
							"variable": "&lt;list_bdm_closed&gt;",
							"replaceWith": oBusinessDowns.closedBD
						}, {
							"variable": "&lt;current_user&gt;",
							"replaceWith": sName
						}, {
							"variable": "&lt;region&gt;",
							"replaceWith": sRegion
						}],
						"recipients": {
							"to": oRecipients.to,
							"cc": oRecipients.cc
						}
					};
					resolve(JSON.stringify(body));

				}.bind(this)).catch(function (oError) {
					console.log("Mail Generation Error: " + oError);
					this.getView().setBusy(false);
				}.bind(this));

			}.bind(this));
		},

		_loadCases: function (aFilter, oUrlParameters) {
			var oAppDepModel = this.getModel("appDepModel");
			return new Promise(function (resolve, reject) {

				oAppDepModel.read("/CaseSet", {
					filters: aFilter,
					urlParameters: oUrlParameters,
					success: function (oData) {
						resolve(oData.results);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			}.bind(this));
		},

		_generateBDList: function (aBusinessDowns) {
			var oBusinessDownsList = {
				ongoingBD: "",
				ongoingBDcount: 0,
				closedBD: "",
				closedBDcount: 0
			};
			//generateList Items
			aBusinessDowns.forEach(function (oBusinessDown) {

				var oNotesValues = this._getNoteValuesForMail(oBusinessDown.toNote.results);
				var oCreateDate = new Date(oBusinessDown.CreateTime);
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "MMMM d, yyyy"
				});
				var sSinceDate = oDateFormat.format(oCreateDate, true);
				//var sDeliveryUnit = oBusinessDown.DeliveryUnitName ? oBusinessDown.DeliveryUnitName : "On Premise";
				//Dec 23, 2020 Fix Marvin: START
				//iterated through all parties involved to identify the delivery unit, if not found set to "On Premise", otherwise apply following logic:
				//use Firstname if available and if not a number, otherwise use Lastname. If Lastname is also not available use PartnerId.
				
				var sDeliveryUnit = "On Premise";
				if (oBusinessDown.toPartiesInvolved.results && oBusinessDown.toPartiesInvolved.results.length > 0) {
					
					for(var ix = 0; ix < oBusinessDown.toPartiesInvolved.results.length; ix++) {
					    var obj = oBusinessDown.toPartiesInvolved.results[ix];
					
					    if ("ZSDELUNI" === obj.PartnerFct) {
					    	//we found the delivery unit parties involved entry
					    	
					    	if (obj.Firstname != "" && isNaN(obj.Firstname) ) {
					    		sDeliveryUnit = obj.Firstname;
					    	} else if (obj.Lastname != "" && isNaN(obj.Lastname) ) {
					    		sDeliveryUnit = obj.Lastname;
					    	} else {
					    		sDeliveryUnit = obj.PartnerId
							}
					    	
					    } 
					}	// for end

				}
				//Dec 23, 2020 Fix Marvin: END

				var sHostname = window.location.hostname;
				var sURL = null;
				var iCustomerTicketID = "";
				if (oBusinessDown.toActivity.results && oBusinessDown.toActivity.results.length > 0) {
					if (sHostname.lastIndexOf("sapitcloudt") > -1 || sHostname.lastIndexOf("a44f228ad") > -1) {
						sURL = this.getResourceBundle().getText("qaSupportTicket", [oBusinessDown.toActivity.results[0].CustomerTicketID]);
					} else if (sHostname === "fiorilaunchpad.sap.com" || sHostname.lastIndexOf("a87daa223") > -1) {
						sURL = this.getResourceBundle().getText("supportTicket", [oBusinessDown.toActivity.results[0].CustomerTicketID]);
					}
					iCustomerTicketID = this.formatIncidentId(oBusinessDown.toActivity.results[0].CustomerTicketID);
				}

				//var sSinceDate = oCreateDate.getUTCDate() + "." + oCreateDate.getUTCMonth() + 1 + "." + oCreateDate.getUTCFullYear();
				var sText = "<li><p align='justify'><u>Customer:</u> <b>" + oBusinessDown.CustomerName + " / "+ oBusinessDown.CustomerCountry +"</b><br>";
				sText += "<u>Delivery Unit:</u> <b>" + sDeliveryUnit + "</b><br>";
				sText += "<u>Engagement:</u> " + oBusinessDown.CategoryText + "<br>";
				sText += "<u>CRM Case:</u> " + oBusinessDown.CaseID + " / <u>Incident No.:</u> <a href='" + sURL + "'>" + iCustomerTicketID +
					"</a> <br>";
				sText += "<u>Since (UTC):</u> " + sSinceDate + "<br>";
				sText += "<u>Issue/Impact:</u><br>" + oNotesValues.issue + "<br>";
				sText += "<u>Status: </u><br>" + oNotesValues.impact + "<br>";
				sText += "<u>Next Steps: </u><br>" + oNotesValues.nextSteps + "<br>";

				if (oBusinessDown.StatusID === "30") {
					oBusinessDownsList.ongoingBD += sText + "<br>";
					oBusinessDownsList.ongoingBDcount += 1;
				} else if (oBusinessDown.StatusID === "40") {
					oBusinessDownsList.closedBD += sText + "<br>";
					oBusinessDownsList.closedBDcount += 1;
				}
			}.bind(this));

			var sHtmlListBegin = "<ul style='list-style-type:none; padding: 0; margin: 0 '>";
			var sHtmlListEnd = "</ul>";

			if (oBusinessDownsList.ongoingBD) {
				oBusinessDownsList.ongoingBD = sHtmlListBegin + oBusinessDownsList.ongoingBD + sHtmlListEnd;
			}
			if (oBusinessDownsList.closedBD) {
				oBusinessDownsList.closedBD = sHtmlListBegin + oBusinessDownsList.closedBD + sHtmlListEnd;
			}

			return oBusinessDownsList;
		},

		//generate HTML table which shows the neccessary information per case (row)
		_generateCaseTable: function (aCases) {
			return new Promise(function (resolve, reject) {

				if (aCases.length > 0) {

					var sHostname = window.location.hostname;
					var sCaseURL = null;

					var style =
						"<style type='text/css'>.myTable { border-collapse:collapse;font-size: 14.5; width:100% } .myTable th { background-color:#0C7ECF;color:white; } .myTable td, .myTable th { padding:5px;border:1px solid #000; } </style>";
					var table = style + "<table class='myTable' style='font-family:Arial'><tr>";
					table += "<th>Case ID</th>";
					table += "<th>Customer Name</th>";
					table += "<th>Type</th>";
					table += "<th>Title</th>";
					table += "<th>Activity</th>";
					table += "<th>Incident No</th>";
					//	table += "<th>Further Links</th>"; //Further Links
					table += "</tr>";
					for (var i = 0; i < aCases.length; i++) {

						var sCaseURL = null;
						var sBackofficeAssistantURL = null;
						var sBCPIncidentURL = null;
						if (sHostname.lastIndexOf("sapitcloudt") > -1 || sHostname.lastIndexOf("a44f228ad") > -1) {
							sCaseURL = this.getResourceBundle().getText("CaseSearchTest", [aCases[i].CaseID]);
							if (aCases[i].toActivity.results && aCases[i].toActivity.results.length > 0) {
								sBackofficeAssistantURL = this.getResourceBundle().getText("backofficeAssistantTest", [aCases[i].toActivity.results[0].ActivityID]);
								sBCPIncidentURL = this.getResourceBundle().getText("qaSupportTicket", [aCases[i].toActivity.results[0].CustomerTicketID]);
							}
						} else if (sHostname === "fiorilaunchpad.sap.com" || sHostname.lastIndexOf("a87daa223") > -1) {
							sCaseURL = this.getResourceBundle().getText("CaseSearch", [aCases[i].CaseID]);
							if (aCases[i].toActivity.results && aCases[i].toActivity.results.length > 0) {
								sBackofficeAssistantURL = this.getResourceBundle().getText("backofficeAssistant", [aCases[i].toActivity.results[0].ActivityID]);
								sBCPIncidentURL = this.getResourceBundle().getText("supportTicket", [aCases[i].toActivity.results[0].CustomerTicketID]);
							}
						}
						
						var sBCPIncident = "";
						var sActivityID = "";
						
						//fix Jan 4 cannot read property customerticketID of undefined
						if (aCases[i].toActivity.results && aCases[i].toActivity.results.length > 0) {
							sBCPIncident = aCases[i].toActivity.results[0].CustomerTicketID ? this.formatIncidentId(aCases[i].toActivity.results[0].CustomerTicketID) : ""; 
							sActivityID = aCases[i].toActivity.results[0].ActivityID ? aCases[i].toActivity.results[0].ActivityID : "";
						} 
						
						if (i % 2 === 1) {
							table += "<tr style='background: #eee'>";
						} else {
							table += "<tr>";
						}
						table += "<td><a href=" + sCaseURL + ">" + aCases[i].CaseID + "</a></td>";
						table += "<td>" + aCases[i].CustomerName + "</td>";
						table += "<td>" + aCases[i].Type + "</td>";
						table += "<td>" + aCases[i].CaseTitle + "</td>";
						table += "<td><a href=" + sBackofficeAssistantURL + ">" + sActivityID + "</a></td>";
						table += "<td><a href=" + sBCPIncidentURL + ">" + sBCPIncident + "</a></td>";

						//		table += "<td>" + oTicketInfo.url + "</td>";
						table += "</tr>";

					}
					table += "</table>";
					table = table.replace(/null/g, "");
				} else {
					var table = "";
				}
				resolve(table);
			}.bind(this));
		},

		// Generate Mail template body for MCS_Duty_Manager_Handover_Report.msg
		// 1. load template specific cases (see filter Values)
		// 2. generate mail body json string
		getHandoverMailBody: function (oRecipients) {
			return new Promise(function (resolve, reject) {
				var aFilter = [];
				var oStatusFilter = new Filter({
					filters: [
						new Filter("StatusID", FilterOperator.EQ, "30")
					],
					and: false
				});
				var oProcessTypeFilter = new Filter({
					filters: [
						new Filter("ProcessTypeId", FilterOperator.EQ, "ZSPRCTYP02"),
						new Filter("ProcessTypeId", FilterOperator.EQ, "ZSPRCTYP04")
					],
					and: false
				});
				aFilter.push(oStatusFilter);
				aFilter.push(oProcessTypeFilter);

				var oCasePromise = this._loadCases(aFilter, {
					"$expand": "toActivity"
				});

				oCasePromise.then(function (aCases) {
					var oCurrentDate = new Date();
					var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
						pattern: "MMMM d, yyyy"
					});
					var sCurrentDate = oDateFormat.format(oCurrentDate);
					var oUserInfo = sap.ui.getCore().getModel("UserInfo");
					var sName = oUserInfo.getProperty("/firstName") + " " + oUserInfo.getProperty("/lastName");

					var iBDMCount = 0;
					var iWatchListCount = 0;

					//transform Process Type ID to either BDM or Watchlist
					aCases.forEach(function (oCase) {
						if (oCase.ProcessTypeId === "ZSPRCTYP02") {
							iBDMCount++;
							oCase.Type = "BDM";
						} else if (oCase.ProcessTypeId === "ZSPRCTYP04") {
							iWatchListCount++;
							oCase.Type = "Watchlist";
						}
					}.bind(this));

					this._generateCaseTable(aCases).then(function (oTemplate) {

						var body = {
							"variable replacement": [{
								"variable": "&lt;current_date&gt;",
								"replaceWith": sCurrentDate
							}, {
								"variable": "&lt;count_bdm_ongoing&gt;",
								"replaceWith": iBDMCount.toString()
							}, {
								"variable": "&lt;count_watchlist_ongoing&gt;",
								"replaceWith": iWatchListCount.toString()
							}, {
								"variable": "&lt;table_bdm_handover_cases&gt;",
								"replaceWith": oTemplate
							}, {
								"variable": "&lt;user_name&gt;",
								"replaceWith": sName
							}],
							"recipients": {
								"to": oRecipients.to,
								"cc": oRecipients.cc
							}
						};

						resolve(JSON.stringify(body));

					}.bind(this)).catch(function (oError) {
						reject(oError);
					});
				}.bind(this)).catch(function (oErr) {
					reject(oErr);
				});
			}.bind(this));

		},

		_getNoteValuesForMail: function (aNotes) {
			var oNoteTexts = {
				issue: "",
				impact: "",
				nextSteps: ""
			};
			aNotes.forEach(function (oNote) {
				if (oNote.NoteType === "ZS16") {
					oNoteTexts.issue = oNote.Text;
				}
				if (oNote.NoteType === "ZS17") {
					oNoteTexts.impact = oNote.Text;
				}
				if (oNote.NoteType === "ZS18") {
					oNoteTexts.nextSteps = oNote.Text;
				}
			});
			return oNoteTexts;
		},

		formatIncidentId: function (id) {
			if (id) {
				var year = id.substring(id.length - 4);
				var ID = parseInt(id.substring(10, id.length - 4));
				return ID + "/" + year;
			} else {
				return "";
			}
		}
	});
});