sap.ui.define([
	"jquery.sap.global",
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"sap/viz/ui5/data/FlattenedDataset",
	"sap/viz/ui5/controls/common/feeds/FeedItem",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/viz/ui5/api/env/Format",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Text"
], function (jQuery, BaseCardController, JSONModel, FlattenedDataset, FeedItem, ChartFormatter, Format, Dialog, Button,
	Text) {
	"use strict";
	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.BDTimeline.BDTimeline", {
		_constants: {
			name: "Business Downs Timeline",
			chartContainerId: "idChartContainer",
			vizFrame: {
				id: "idVizFrame",
				dataset: {
					dimensions: [{
						name: "Date",
						value: "{view1>Date}",
						dataType: "date"
					}],
					measures: [{
						name: "Business Downs",
						value: "{view1>Global Escalations}"
					}],
					data: {
						path: "view1>/Data"
					}
				},
				type: "timeseries_line",
				feedItems: [{
					"uid": "valueAxis",
					"type": "Measure",
					"values": ["Business Downs"]
				}, {
					"uid": "timeAxis",
					"type": "Dimension",
					"values": ["Date"]
				}],
				vizProperties: {
					plotArea: {
						window: {
							start: "firstDataPoint",
							end: "lastDataPoint"
						},
						dataLabel: {
							formatString: ChartFormatter.DefaultPattern.SHORTFLOAT_MFD2,
							visible: false
						}
					},
					valueAxis: {
						visible: true,
						label: {
							formatString: ChartFormatter.DefaultPattern.SHORTFLOAT
						},
						title: {
							visible: false
						}
					},
					timeAxis: {
						title: {
							visible: false
						},
						interval: {
							unit: ""
						}
					},
					title: {
						text: "Business Downs Timeline",
						visible: true
					},
					interaction: {
						syncValueAxis: false
					}
				}
			}
		},

		// Initialize the view and make a call to the refresh method
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "search", this.reload, this);
			$.sap.globalDate2 = new Date();

			this.onUpdateCard();
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			var oCurrentDate = new Date();
			var oFirstDayOfTheYear = new Date(new Date().getFullYear(), 0, 1);
			$.sap.globalDate1 = oFirstDayOfTheYear;
			this.populateView(oFirstDayOfTheYear, oCurrentDate);
		},

		// destroy the viz frame
		_destroyVizFrame: function () {
			var vizFrame = this.oVizFrame = this.getView().byId(this._constants.vizFrame.id);
			vizFrame.destroyFeeds();
			vizFrame.destroyDataset();
		},

		//Whenever a change is done to the view we need to reconstruct the vizframe and set the dataset
		//param (oData) data which should be displayed in the view
		_updateVizFrame: function (oData) {
			var vizFrame = this.oVizFrame = this.getView().byId(this._constants.vizFrame.id);
			var oVizFrame = this._constants.vizFrame;
			var oDataset = new FlattenedDataset(this._constants.vizFrame.dataset);
			var oModel = new JSONModel(oData);
			vizFrame.setDataset(oDataset);
			vizFrame.setModel(oModel, "view1");
			this._addFeedItems(vizFrame, oVizFrame.feedItems);
			vizFrame.setVizType(oVizFrame.type);
			vizFrame.setVizProperties(oVizFrame.vizProperties);
		},

		// Adds the passed feed items to the passed Viz Frame.
		// @param {sap.viz.ui5.controls.VizFrame} vizFrame Viz Frame to add feed items to
		// @param {Object[]} feedItems Feed items to add
		_addFeedItems: function (vizFrame, feedItems) {
			for (var i = 0; i < feedItems.length; i++) {
				vizFrame.addFeed(new FeedItem(feedItems[i]));
			}
		},

		onPressCustomCard: function (oEvent) {},
		//Given a date, compute the week number of that date
		//param(d) date
		getWeekNumber: function (d) {
			// Copy date so don't modify original
			d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
			// Set to nearest Thursday: current date + 4 - current day number
			// Make Sunday's day number 7
			d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
			// Get first day of year
			var yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
			// Calculate full weeks to nearest Thursday
			var weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
			// Return array of year and week number
			return [d.getUTCFullYear(), weekNo];
			//return weekNo;
		},

		// returns the date of the monday last week
		getPreviousMonday: function () {
			var date = new Date();
			var day = date.getDay();
			var prevMonday;
			if (date.getDay() === 0) {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate() - 6);
			} else {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate() - day - 6);
			}
			return prevMonday;
		},

		//returns the date of the monday this week
		getThisMonday: function () {
			var date = new Date();
			var day = date.getDay();
			var prevMonday;
			if (date.getDay() === 0) {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate());
			} else {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate() - day + 1);
			}
			return prevMonday;
		},
		padStr: function (i) {
			return (i < 10) ? "0" + i : "" + i;
		},

		//returns the date in string format
		//param(temp) date in date format
		printDate: function (temp) {
			var temp1 = new Date(temp);
			var dateStr = this.padStr(temp.getFullYear()) +
				this.padStr(1 + temp.getMonth()) +
				this.padStr(temp.getDate()) +
				this.padStr(temp.getHours()) +
				this.padStr(temp.getMinutes()) +
				this.padStr(temp.getSeconds());
			return (dateStr);
		},

		// returns the date of a monday given week and year
		// param (w), param(y) week and year
		getDateOfWeek: function (w, y) {
			var date = new Date();
			var tdate = new Date(date.getFullYear(), 0, 1);
			var day = tdate.getDay();
			var d;
			switch (day) {
			case 0:
				d = (-5 + (w - 1) * 7);
				break;
			case 1:
				d = (1 + (w - 1) * 7);
				break;
			case 2:
				d = (0 + (w - 1) * 7);
				break;
			case 3:
				d = (-1 + (w - 1) * 7);
				break;
			case 4:
				d = (-2 + (w - 1) * 7);
				break;
			case 5:
				d = (-3 + (w - 1) * 7);
				break;
			case 6:
				d = (-4 + (w - 1) * 7);
				break;
			}
			// 1st of January + 7 days for each week
			return new Date(y, 0, d);
		},

		//returns a date in date format
		//param(temp) date in string format
		createDate: function (temp) {
			var year = temp.substring(0, 4);
			var month = temp.substring(4, 6);
			var day = temp.substring(6, 8);
			var hour = temp.substring(8, 10);
			var minute = temp.substring(10, 12);
			var seconds = temp.substring(12, 14);
			return new Date(year, month - 1, day, hour, minute, seconds);
		},

		//returns the number of days from the beginning of the year up to a certain date in the same year
		//param (now) a date
		getDay: function (now) {
			var start = new Date(now.getFullYear(), 0, 0);
			var diff = now - start;
			var oneDay = 1000 * 60 * 60 * 24;
			var day = Math.floor(diff / oneDay);
			return day;
		},

		//method responsible for changing the data passed to the view after a change in the filter critiera
		//param(sChanel) event bus channel, param(oEvent) event that caused the change, param(oData) the values of region and date that did actually change in the global filter
		reload: function (sChanel, oEvent, oData) {
			this._flushCard();
			var finalDate1;
			var finalDate2;
			if ((oData.date1) && (oData.date2)) {
				finalDate1 = oData.date1;
				finalDate2 = oData.date2;
			} else {
				finalDate1 = $.sap.globalDate1;
				finalDate2 = $.sap.globalDate2;
			}
			this.populateView(finalDate1, finalDate2);
		},

		//method responsible for refreshing the view after a change in the filter critiera
		//param(sChanel) event bus channel, param(oEvent) event that caused the change, param(oData) the values of region and date that did actually change in the global filter
		populateView: function (date1, date2) {
			var regionFilter;
			var finalRegion = this.getCoreModel("workplaceModel").getProperty("/selectedProfileInstance/FilterValues/Region");
			if (finalRegion === "EMEA" || finalRegion === "APJ" || finalRegion === "NA" || finalRegion === "LA") {
				var region;
				switch (finalRegion) {
				case "EMEA":
					region = "O 50008010";
					break;
				case "APJ":
					region = "O 50008134";
					break;
				case "NA":
					region = "O 50008167";
					break;
				case "LA":
					region = "O 50008174";
					break;
				}
				regionFilter = new sap.ui.model.Filter("service_org", sap.ui.model.FilterOperator.EQ, region);
			}
			$.sap.globalDate1 = date1;
			$.sap.globalDate2 = date2;
			var that = this;
			var cy = new Date();
			var dc = new Date(new Date().getFullYear(), 0, 1);
			var lastDay = new Date(cy.getFullYear(), 11, 31);
			Format.numericFormatter(ChartFormatter.getInstance());
			// set explored app's demo model on this sample
			var oModel = new JSONModel(this.settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel, "view");
			var oFilter = [];
			var oFilter1 = [];
			var f1 = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP02");
			var f11 = new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ, "ZSPRCTYP03");
			//var f2 = new sap.ui.model.Filter("service_org",sap.ui.model.FilterOperator.EQ,'O 50008010');
			var fOpen1 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "20");
			var fOpen2 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "30");
			var closed1 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "40");
			var fOpen = new sap.ui.model.Filter({
				filters: [fOpen1, fOpen2],
				and: false
			});
			var f12 = new sap.ui.model.Filter({
				filters: [f1, f11],
				and: false
			});
			//console.log(this.getPreviousMonday());
			//	console.log(this.printDate(this.getPreviousMonday()));
			var fCreatedDate = new sap.ui.model.Filter("create_time", sap.ui.model.FilterOperator.BT,
				that.printDate(date1), that.printDate(date2));
			var fClosedDate = new sap.ui.model.Filter("closing_time", sap.ui.model.FilterOperator.BT,
				that.printDate(date1), that.printDate(date2));
			var fClosed = new sap.ui.model.Filter({
				filters: [closed1, fClosedDate],
				and: true
			});
			var last = new sap.ui.model.Filter({
				filters: [fCreatedDate, fClosed],
				and: false
			});
			var all = new sap.ui.model.Filter({
				filters: [f12, fOpen],
				and: true
			});
			var all1 = new sap.ui.model.Filter({
				filters: [f12, fClosedDate],
				and: true
			});
			var countT;
			oFilter.push(all);
			oFilter1.push(all1);
			if (regionFilter) {
				oFilter.push(regionFilter);
				oFilter1.push(regionFilter);
			}
			var model = this.getModel("mcsDashboardService");
			model.read("/MCSDashboardSet/", {
				filters: oFilter1,
				success: function (oResult1) {
					var closedArr = oResult1.results;
					model.read("/MCSDashboardSet", {
						filters: oFilter,
						success: function (oResult) {
							var merged = oResult.results.concat(closedArr);
							var data = {
								"Data": []
							};
							var filterT;
							var filterR;
							var temporary = [];
							var temporary1 = [];
							var currentWeek = that.getWeekNumber(new Date())[1];
							var t1;
							if (date1.getFullYear() !== date2.getFullYear()) {
								var diff = date2.getFullYear() - date1.getFullYear();
								for (var i = that.getDay(date1); i <= 365; i++) {
									countT = 0;
									filterT = merged;
									filterR = filterT.filter(function (item) {
										temporary1 = that.getWeekNumber(that.createDate(item.create_time));
										var cond1 = (item.status === "20" || item.status === "30");
										var ts = date1;
										var testDate = new Date(ts.getFullYear(), 0, i + 1);
										var cond2 = that.createDate(item.create_time) <= testDate;
										var dt = date1;
										var date = new Date(dt.getFullYear(), 0, i);
										var condN = date < new Date();
										temporary = that.getWeekNumber(that.createDate(item.closing_time));
										var condition = that.getDateOfWeek(i, new Date().getFullYear()) <= that.createDate(item.closing_time);
										var cond3 = that.createDate(item.closing_time) >= date;
										var cond4 = that.createDate(item.closing_time) > that.createDate(that.printDate(date1));
										return ((cond1 && cond2 && condN) || (cond3 && cond4 && cond2));
									});
									countT = filterR.length;
									filterR = [];
									var dt = new Date();
									var date = new Date(date1.getFullYear(), 0, i);
									data.Data.push({
										"Global Escalations": countT,
										"Date": date
									});
								}
								if (diff > 1) {
									for (var k = 1; k < diff; k++) {
										var dDate = new Date(date1.getFullYear() + k, 0, 1);
										var endDate1 = new Date(date1.getFullYear() + k + 1, 0, 0);
										for (i = that.getDay(dDate); i <= 365; i++) {
											countT = 0;
											filterT = merged;
											filterR = filterT.filter(function (item) {
												temporary1 = that.getWeekNumber(that.createDate(item.create_time));
												var cond1 = (item.status === "20" || item.status === "30");
												var ts = dDate;
												var testDate = new Date(ts.getFullYear(), 0, i + 1);
												var cond2 = that.createDate(item.create_time) <= testDate;
												var dt = dDate;
												var date = new Date(dt.getFullYear(), 0, i);
												var condN = date < new Date();
												temporary = that.getWeekNumber(that.createDate(item.closing_time));
												var condition = that.getDateOfWeek(i, new Date().getFullYear()) <= that.createDate(item.closing_time);
												//var cond3 = temporary[1]>=i;
												var cond3 = that.createDate(item.closing_time) >= date;
												var cond4 = that.createDate(item.closing_time) > that.createDate(that.printDate(dDate));
												return ((cond1 && cond2 && condN) || (cond3 && cond4 && cond2));
											});
											countT = filterR.length;
											filterR = [];
											var dt = new Date();
											date = new Date(dDate.getFullYear(), 0, i);
											data.Data.push({
												"Global Escalations": countT,
												"Date": date
											});
										}
									}
								}
								for (i = 1; i <= that.getDay(date2); i++) {
									countT = 0;
									filterT = merged;
									filterR = filterT.filter(function (item) {
										temporary1 = that.getWeekNumber(that.createDate(item.create_time));
										var cond1 = (item.status === "20" || item.status === "30");
										var ts = date2;
										var testDate = new Date(ts.getFullYear(), 0, i + 1);
										var cond2 = that.createDate(item.create_time) <= testDate;
										dt = date2;
										date = new Date(dt.getFullYear(), 0, i);
										var condN = date < new Date();
										temporary = that.getWeekNumber(that.createDate(item.closing_time));
										var condition = that.getDateOfWeek(i, new Date().getFullYear()) <= that.createDate(item.closing_time);
										var cond3 = that.createDate(item.closing_time) >= date;
										var cond4 = that.createDate(item.closing_time) > that.createDate(that.printDate(date1));
										return ((cond1 && cond2 && condN) || (cond3 && cond4 && cond2));
									});
									countT = filterR.length;
									filterR = [];
									var dt = new Date();
									date = new Date(date2.getFullYear(), 0, i);
									data.Data.push({
										"Global Escalations": countT,
										"Date": date
									});
								}
							} else {
								for (i = that.getDay(date1); i <= that.getDay(date2); i++) {
									countT = 0;
									filterT = merged;
									filterR = filterT.filter(function (item) {
										temporary1 = that.getWeekNumber(that.createDate(item.create_time));
										var cond1 = (item.status === "20" || item.status === "30");
										var ts = date2;
										var testDate = new Date(ts.getFullYear(), 0, i + 1);
										var cond2 = that.createDate(item.create_time) <= testDate;
										var dt = date2;
										var date = new Date(dt.getFullYear(), 0, i);
										var condN = date < new Date();
										temporary = that.getWeekNumber(that.createDate(item.closing_time));
										var condition = that.getDateOfWeek(i, new Date().getFullYear()) <= that.createDate(item.closing_time);
										var cond3 = that.createDate(item.closing_time) >= date;
										var cond4 = that.createDate(item.closing_time) > that.createDate(that.printDate(date1));
										return ((cond1 && cond2 && condN) || (cond3 && cond4 && cond2));
									});
									countT = filterR.length;
									filterR = [];
									var dt = new Date();
									var date = new Date(date1.getFullYear(), 0, i);
									data.Data.push({
										"Global Escalations": countT,
										"Date": date
									});
								}
							}
							that._destroyVizFrame();
							that._updateVizFrame(data);
							this.setCardSuccessState();
						}.bind(this),
						error: function (oError) {
							this.setCardErrorState();
						}.bind(this)
					});
				}.bind(this),
				error: function (oError) {
					this.setCardErrorState();
				}.bind(this)
			});
		}
	});
});