sap.ui.define([
	"jquery.sap.global",
	"com/sap/mcc/workplace/CardComponent/BaseCardController"
], function (jQuery, BaseCardController) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.QuickAccess.QuickAccess", {
		// set the root path of the folder and load the image from the correct path
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */
			var aOptions = [{
					"Key": "xSearch",
					"Name": "xSearch"
				}, {
					"Key": "Case",
					"Name": "Case"
				}, {
					"Key": "Activity",
					"Name": "Activity"
				}, {
					"Key": "KBA",
					"Name": "KBA"
				}, {
					"Key": "SNOW",
					"Name": "ServiceNow"
				}, {
					"Key": "Corporate",
					"Name": "Corporate Search"
				}, {
					"Key": "Ariba",
					"Name": "Ariba Service Request"
				}];

			if (!this.getCoreModel("workplaceModel").getProperty("/disclaimerVisible")) {
				aOptions.push({
					"Key": "Incident",
					"Name": "Incident"
				});
			}

			this.setCardProperty("/Options", aOptions);
			this.setCardProperty("/placeholderText", "Search Query");
			this.setCardProperty("/placeholder", "Search Query");
			this.setCardProperty("/searchQuery", "");
			
		},

		onAfterRendering: function () {
			var sSelectedItemText = this.getView().byId("typeSelect").getSelectedItem().getText();
			this._setPlaceholderForInputQuery(sSelectedItemText);
		},

		onSelectChange: function (oEvent) {
			var sSelectedItemText = oEvent.getSource().getSelectedItem().getText();
			this._setPlaceholderForInputQuery(sSelectedItemText);
		},

		_setPlaceholderForInputQuery: function (sType) {
			var sPlaceholerText = this.getCardProperty("/placeholderText");
			this.setCardProperty("/placeholder", sType + " " + sPlaceholerText);
		},

		onSearchPress: function (oEvent) {
			var bTestEnvironment = this.getCoreModel("workplaceModel").getProperty("/disclaimerVisible");
			var sSearchQuery = this.getCardProperty("/searchQuery");
			var sSelectedKey = this.getView().byId("typeSelect").getSelectedKey();
			var sUrl;

			switch (sSelectedKey) {
			case 'Activity':
				sUrl = this.getResourceBundle().getText("ActivitySearch", [sSearchQuery]);
				if (bTestEnvironment) {
					sUrl = this.getResourceBundle().getText("ActivitySearchTest", [sSearchQuery]);
				}
				break;
			case 'Ariba':
				sUrl = this.getResourceBundle().getText("AribaSearch") + sSearchQuery;
				break;
			case 'Case':
				sUrl = this.getResourceBundle().getText("CaseSearch", [sSearchQuery]);
				if (bTestEnvironment) {
					sUrl = this.getResourceBundle().getText("CaseSearchTest", [sSearchQuery]);
				}
				break;
			case 'KBA':
				sUrl = this.getResourceBundle().getText("KBASearch") + sSearchQuery;
				break;
			case 'Incident':
				sUrl = this.getResourceBundle().getText("BCPIncidentSearch") + sSearchQuery;
				break;
			case 'xSearch':
				sUrl = this.getResourceBundle().getText("XSearch") + sSearchQuery;
				break;
			case 'SNOW':
				sUrl = this.getResourceBundle().getText("SNOW") + sSearchQuery;
				if (bTestEnvironment) {
					sUrl = this.getResourceBundle().getText("SNOWTEST") + sSearchQuery;
				}
				break;
			case 'Corporate':
				sUrl = this.getResourceBundle().getText("CorporateSearch") + sSearchQuery;
				break;

			default:
				sUrl = this.getResourceBundle().getText("CorporateSearch") + sSearchQuery;
				break;
			}

			sap.m.URLHelper.redirect(sUrl, true);
		}
	});
});