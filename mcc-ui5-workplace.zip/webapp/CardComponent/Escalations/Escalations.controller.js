sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function (Controller, JSONModel, MessageToast) {
	"use strict";

	var TableController = sap.ui.controller("com.sap.mcc.workplace.CardComponent.Escalations.Escalations", {
		onInit: function () {
			sap.ui.getCore().getEventBus().subscribe("Filter1", "reload", this.reload, this);
			$.sap.globalDate2 = new Date();
			this.initializeView(null, $.sap.globalRegion);
			this.modelServices(300000);
		},
		
		initializeView: function (regionFilter, finalRegion) {
			if (finalRegion === "EMEA" || finalRegion === "APJ" || finalRegion === "NA" || finalRegion === "LA") {
				var region;
				switch (finalRegion) {
				case "EMEA":
					region = "0003584574";
					break;
				case "APJ":
					region = "0003612380";
					break;
				case "NA":
					region = "0003612382";
					break;
				case "LA":
					region = "0009804549";
					break;
				}
				regionFilter = new sap.ui.model.Filter("activity_service_team", sap.ui.model.FilterOperator.EQ, region);
			}
			$.sap.globalRegion = finalRegion;
			var that = this;
			var oFilter = [];
			var model = this.getModel("mainService");
			var f1 = new sap.ui.model.Filter("activity_process_type", sap.ui.model.FilterOperator.EQ, "ZS31");
			var fOpen1 = new sap.ui.model.Filter("activity_status", sap.ui.model.FilterOperator.EQ, "E0010");
			var fOpen2 = new sap.ui.model.Filter("activity_status", sap.ui.model.FilterOperator.EQ, "E0011");
			var fOpen = new sap.ui.model.Filter({
				filters: [fOpen1, fOpen2],
				and: false
			});
			oFilter.push(fOpen);
			oFilter.push(f1);
			if (regionFilter) {
				oFilter.push(regionFilter);
			}
			var oModel = new JSONModel();
			var sText1 = this.getView().getModel("i18n").getResourceBundle().getText("openEscaInProg");
			//set Busy Indicator of Table
			this.getView().byId("chart-mcs-globalEscalations").setBusy(true);
			model.read("/ActivityList/", {
				filters: oFilter,
				success: function (oResult1) {
					
					var oResult = that.bubbleSort(oResult1);
					oModel.setData(oResult);
					that.getView().setModel(oModel, "Information");
					that.getView().byId("header").setText(sText1 + " (" + oResult.results.length + ")");
					var scroll = that.getView().byId("s1");
					if (oResult.results.length > 9) {
						scroll.setHeight("31rem");
					} else {
						scroll.setHeight("auto");
					}

					//disable Busy Indicator of table
					that.getView().byId("chart-mcs-globalEscalations").setBusy(false);
				},
				error: function () {
					//disable Busy Indicator of table
					that.getView().byId("chart-mcs-globalEscalations").setBusy(false);
				}
			});
		},
		
		bubbleSort: function (oResult) {
			var that = this;
			var n = oResult.results.length;
			for (var i = 0; i < n - 1; i++) {
				for (var j = 0; j < n - i - 1; j++) {
					if ((oResult.results[j].activity_create_date) > (oResult.results[j + 1].activity_create_date)) {
						var temp = oResult.results[j];
						oResult.results[j] = oResult.results[j + 1];
						oResult.results[j + 1] = temp;
					}
				}
			}
			return oResult;
		},
		
		//Check if the card has not been removed from the view, set the filters and set the json model to the view
			//param(sChanel) eventbus channel, param(oEvent) event responsible for the change, param(oData) contains the current region value
			reload: function (sChanel, oEvent, oData) {
				//reload card specific data only if the card is visible at the ui
				var finalRegion;
				var finalDate1;
				var finalDate2;
				var regionFilter;
				var region;
				var regionC;
				if (oData.region) {
					switch (oData.region) {
					case "EMEA":
						region = "0003584574";
						regionC = "O 50008010";
						finalRegion = "EMEA";
						break;
					case "APJ":
						region = "0003612380";
						regionC = "O 50008134";
						finalRegion = "APJ";
						break;
					case "NA":
						region = "0003612382";
						regionC = "O 50008167";
						finalRegion = "NA";
						break;
					case "LA":
						region = "0009804549";
						regionC = "O 50008174";
						finalRegion = "LA";
						break;
					}
					if (region) {
						regionFilter = new sap.ui.model.Filter("service_org", sap.ui.model.FilterOperator.EQ, region);
					}
				} else {
					finalRegion = $.sap.globalRegion;
				}
				if ((oData.date1) && (oData.date2)) {
					finalDate1 = oData.date1;
					finalDate2 = oData.date2;
				} else {
					finalDate1 = $.sap.globalDate1;
					finalDate2 = $.sap.globalDate2;
				}
				this.initializeView(regionFilter, finalRegion);
			},
		
		onAfterRendering: function () {
			var that = this;
			var oBinding = this.getView().byId("chart-mcs-globalEscalations").getBinding("items");
			var sCardName = this.getView().getModel("i18n").getResourceBundle().getText("openEscaRequestsReg");
			if (oBinding) {
				oBinding.attachChange(function (sReason) {
					that.getView().byId("header").setText(sCardName + " (" + oBinding.getLength() + ")");
					var scroll = that.getView().byId("s1");
					if (oBinding.getLength() > 9) {
						scroll.setHeight("31rem");
					}
				});
			}
		},
		
		onPopinLayoutChanged: function () {
			var oTable = this.byId("chart-mcs-globalEscalations");
			var oComboBox = this.byId("idPopinLayout");
			var sPopinLayout = oComboBox.getSelectedKey();
			switch (sPopinLayout) {
			case "Block":
				oTable.setPopinLayout(sap.m.PopinLayout.Block);
				break;
			case "GridLarge":
				oTable.setPopinLayout(sap.m.PopinLayout.GridLarge);
				break;
			case "GridSmall":
				oTable.setPopinLayout(sap.m.PopinLayout.GridSmall);
				break;
			default:
				oTable.setPopinLayout(sap.m.PopinLayout.Block);
				break;
			}
		},

		onSelectionFinish: function (oEvent) {
			var aSelectedItems = oEvent.getParameter("selectedItems");
			var oTable = this.byId("chart-mcs-globalEscalations");
			var aSticky = aSelectedItems.map(function (oItem) {
				return oItem.getKey();
			});
			oTable.setSticky(aSticky);
		},
		
		onSearch: function () {
			var aFilters = this.getView().byId("smartFilterBar").getFilters();
			this.getView().byId("chart-mcs-globalEscalations").getBinding("items").filter(aFilters);
			this.modelServices();
		},

		onToggleInfoToolbar: function (oEvent) {
			var oTable = this.byId("chart-mcs-globalEscalations");
			oTable.getInfoToolbar().setVisible(!oEvent.getParameter("pressed"));
		},
		
		//@method responsible for refreshing the view
			modelServices: function (time) {
				var that = this;
				this.intervalHandle = setInterval(function () {
					that.initializeView(null, $.sap.globalRegion);
				}, 300000);
			},
		
		onExit: function () {
			// You should stop the interval on exit. 
			// You should also stop the interval if you navigate out of your view and start it again when you navigate back. 
			if (this.intervalHandle){
				clearInterval(this.intervalHandle);
			}
		},
		
		onSelectionChange: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			var activityId = oSelectedItem.getBindingContext("Information").getObject().activity_id;
			var currentUrl = window.location.href;
			var relativeUrl =
				"/sap(bD1lbiZjPTAwMSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?saprole=ZSU_DEFAULT&crm-object-type=BT126_APPT&crm-object-action=B&crm-object-keyname=OBJECT_ID&crm-object-value=" +
				activityId;
			var urlICP = this.getView().getModel("i18n").getResourceBundle().getText("urlICPSAP");
			var urlICT = this.getView().getModel("i18n").getResourceBundle().getText("urlICTSAP");
			var url = urlICP + relativeUrl;
			if (currentUrl.includes("a44f228ad.dispatcher.hana.ondemand.com")) {
				//we are in test environment
				url = urlICT + relativeUrl;
			}
			var win = window.open(url, "_blank");
			win.focus();

		},
		getDays: function (date, time) {
				//respect date and time 
				//create a new date object
				var myDate = new Date(date);
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyy-MM-dd"
				});
				var sDateTmp = dateFormat.format(myDate);
				var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					pattern: "HH:mm:ss",
					UTC: true
				});
				var TZOffsetMs = myDate.getTimezoneOffset() * 60 * 1000;
				var timeStr = timeFormat.format(new Date(time.ms -  TZOffsetMs));
				var sDate = sDateTmp + "T" + timeStr;
				var oDateTime = new Date(sDate);
				
				// get total seconds between the times
				var delta = Math.abs(new Date() - (oDateTime)) / 1000;

				// calculate (and subtract) whole days
				var days = Math.floor(delta / 86400);
				delta -= days * 86400;

				// calculate (and subtract) whole hours
				var hours = Math.floor(delta / 3600) % 24;
				delta -= hours * 3600;

				// calculate (and subtract) whole minutes
				var minutes = Math.floor(delta / 60) % 60;
				delta -= minutes * 60;

				// what's left is seconds
				var seconds = delta % 60;
				var text = days + " d " + hours + " h ";
				if ((days === 0) && hours === 0) {
					return "< 1 hour";
				}
				return text;
		},
		
		getmDate: function (date) {
			if (date) {
				var month = ["January", "February", "March", "April", "May", "June",
					"July", "August", "September", "October", "November", "December"
				][date.getMonth()];
				var str = month + " " + date.getDate() + " " + date.getFullYear();
				return str;
			}
		},
		
		onCustomActionPress: function (oEvent) {
			var sText = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("globalFilterMessageToast");
			MessageToast.show(sText);
		},

		formatURL: function (sCustNumber) {
			var currentUrl = window.location.href;
			var sMccCriticalSitUrl = this.getView().getModel("i18n").getResourceBundle().getText("mccCritSitCustomerURL");
			var url = sMccCriticalSitUrl + sCustNumber;
			if (currentUrl.includes("a44f228ad.dispatcher.hana.ondemand.com")) {
				//we are in test envrionment
				url = "https://flpnwc-sapitcloudt.dispatcher.hana.ondemand.com/sites#mcccriticalsituation-Display&/Customer/" + sCustNumber;
			}
			return url;
		}
	});
	return TableController;
});