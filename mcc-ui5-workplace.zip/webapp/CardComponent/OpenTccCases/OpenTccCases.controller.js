sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseCardController, JSONModel, Filter, FilterOperator) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.OpenTccCases.OpenTccCases", {
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			//register AttachChange event for binding change to update the card title when for example a column filter is applied		
			this.getView().byId("tableTccCases").getBinding("rows").attachChange(this.updateCardTitle.bind(this, "data"));

			this.onUpdateCard();
			// this.setCardAutoRefresh(300000); // Autorefresh in ms - if card needs to be autorefreshed, set the time in ms

			/* YOUR CODE HERE */
			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "dataLoaded", this.onUpdateCard, this);
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "search", this.setCardUpdateStartState, this);
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();

			var oCasesLoaded = this._loadCases();

			oCasesLoaded.then(function (aData) {
				//this._getCQIScore();
				var aPromises = [];
				var oCQIPromise = this.getCQIScore("data", "mcs-ccm-global-manager");
				

				/*oCQIPromise.then(function(odata){
				}.bind(this));*/

				if (aData.length > 0) {
					var aPromises = [];
					/*		for (var i = 0; i < aData.length; i++) {*/
					var CasecheckerPromise = this._getCaseDetailsAppDepSrv();
					aPromises.push(CasecheckerPromise);
					/*		}*/

					//set success state when all requests have finished
					Promise.all(aPromises).then(function (oData) {
							this.setCardSuccessState();
						}.bind(this))
						.catch(function (oError) {
							// when any odata requests failed
							this.setCardErrorState();
						}.bind(this));

				}
			}.bind(this)).catch(function (oError) {
				console.log("[Open CCM Cases]: Request Failed " + oError);
			});
		},

		_loadCases: function () {
			var oZSAppDepModel = this.getModel("appDepModel");
			var aFilterBar = this.getFilterBarValues("OpenTccCases");

			//default filter
			var oFilterCustomerType = new Filter({
				filters: [
					new Filter("ServiceTeam", FilterOperator.EQ, "0029907917"),
					new Filter("ServiceTeam", FilterOperator.EQ, "0029907919"),
					new Filter("ServiceTeam", FilterOperator.EQ, "0029907921"),
					new Filter("ServiceTeam", FilterOperator.EQ, "0029907920")
				],
				and: false
			});

			//inner join filterbar values with default filters
			// make sure only tcc service teams are used in odata requests
			if (aFilterBar.length) {
				var aFilterHelper = [];
				for (var i = 0; i < aFilterBar.length; i++) {
					var oFilter = aFilterBar[i];
					if (oFilter && oFilter.aFilters[0] && oFilter.aFilters[0].sPath === "ServiceTeam") {
						var aSelectedFilterbarFilters = oFilter.aFilters;

						aSelectedFilterbarFilters.forEach(function (oFilter) {
							var sValue = oFilter.oValue1;
							if (sValue.indexOf("29907917") != -1  || sValue.indexOf("29907919") != -1 || sValue.indexOf("29907921") != -1 || sValue.indexOf("29907920") != -1) {
								var oFilter = new Filter("ServiceTeam", FilterOperator.EQ, sValue);
								aFilterHelper.push(oFilter);
							}
						}.bind(this));
						break;
					}
				}
				if (aFilterHelper.length) {
					//overwrite default values
					oFilterCustomerType = new Filter({
						filters: aFilterHelper,
						and: false
					});
				}
			}

			var aFilters = [];
			//merge array when filters are set in filter bar
		//	aFilters = aFilters.concat(aFilterBar);
			var oFilterCaseType = new Filter('CaseType', FilterOperator.EQ, "ZS02");
			//filter service team: 29907917 or 29907919 or 29907921 or 29907920

			var oStatusFilter = new Filter({
				filters: [
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 71
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 80
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 81
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 99
					})
				],
				and: false
			});

			//push filter to array
			aFilters.push(oFilterCustomerType);
			aFilters.push(oFilterCaseType);
			aFilters.push(oStatusFilter);

			return new Promise(function (resolve, reject) {
				oZSAppDepModel.read("/CaseSet", {
					filters: aFilters,
					success: function (oData) {
						if (oData.results && oData.results.length > 0) {
							oData.results.forEach(function (oCase) {
								oCase.Region = this._getRegion(oCase.ServiceOrg);
								oCase.CustomerType = this._getCustomerType(oCase.CustomerTypeID);
							}.bind(this));
							this.setCardProperty("/data", oData.results);

							//resolve promise to request additional information from ZS APP DEP SRV (CustomerTypeID)
							resolve(oData.results);
						} else {

							this.setCardNoDataState();
							// resolve promise with empty array --> no additinal data (CustomerTypeID) from ZS APP DEP SRV is requested
							resolve([]);
						}
					}.bind(this),
					error: function (oError) {
						this.setCardProperty("/customHeader/additionalCardTitle", "");
						this.setCardErrorState(oError);
						resolve(oError);
					}.bind(this)
				});
			}.bind(this));

		},

		_getCaseDetailsAppDepSrv: function () {
			var oZSAppDepModel = this.getModel("appDepModel");
			var aFilters = [];
			var oFilterCaseType = new Filter('CaseType', FilterOperator.EQ, "ZS02");
			//filter service team: 29907917 or 29907919 or 29907921 or 29907920
			var oFilterCustomerType = new Filter({
				filters: [
					new Filter("ServiceTeam", FilterOperator.EQ, "0029907917"),
					new Filter("ServiceTeam", FilterOperator.EQ, "0029907919"),
					new Filter("ServiceTeam", FilterOperator.EQ, "0029907921"),
					new Filter("ServiceTeam", FilterOperator.EQ, "0029907920")
				],
				and: false
			});

			var oStatusFilter = new Filter({
				filters: [
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 71
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 80
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 81
					}),
					new Filter({
						path: 'StatusID',
						operator: FilterOperator.EQ,
						value1: 99
					})
				],
				and: false
			});

			//push filter to array
			aFilters.push(oFilterCustomerType);
			aFilters.push(oFilterCaseType);
			aFilters.push(oStatusFilter);

			var oCaseTypePromise = new Promise(function (resolve, reject) {
				oZSAppDepModel.read("/CaseSet", {
					filters: aFilters,
					urlParameters: {
						"$expand": "toActivity,toTopIssue,toCustomSet,toAffectedProduct"
					},
					success: function (oData) {
						//due to filter on case id only one entry gets returned
						resolve(oData.results);
					}.bind(this),
					error: function (oError) {
						resolve(oError);
					}.bind(this)
				});
			}.bind(this));

			oCaseTypePromise.then(function (aResults) {
				var aData = this.getModel("cardModel").getProperty("/data");

				aResults.forEach(function (oCase) {
					var oObject = this.findObjectByKey(aData, "CaseID", oCase.CaseID);
					//count open / closed activities
					if (oCase.toActivity && oCase.toActivity.results.length > 0) {
						var iOpenActivities = 0;
						var iClosedActivities = 0;
						oCase.toActivity.results.forEach(function (oActivity) {
							//skip this --> Status = OBSOLETE
							if ((oActivity.CategoryID === 'ZYP' || oActivity.CategoryID === 'ZYO') && oActivity.StatusID !== "E0020") {

								if (oActivity.StatusID === "E0013" || oActivity.StatusID === "E0014") {
									iClosedActivities++;
								} else {
									iOpenActivities++;
								}
							}
						});
						oObject.ActivitiesOpenClosed = iOpenActivities + " / " + iClosedActivities;
					}

					if (oCase.toTopIssue && oCase.toTopIssue.results.length > 0) {
						var iOpenTopIssues = 0;
						var iClosedTopIssues = 0;
						oCase.toTopIssue.results.forEach(function (oTopIssue) {
							if (oTopIssue.StatusID === "E0012") {
								//skip this --> Status = Rejected
							} else if (oTopIssue.StatusID === "E0013") {
								iClosedTopIssues++;
							} else {
								iOpenTopIssues++;
							}
						});
						oObject.TopIssuesOpenClosed = iOpenTopIssues + " / " + iClosedTopIssues;
					}

					//merge all Products (AffectedProductText attributes into one single property "ProductLinesMerged" of case )
					if (oCase.toAffectedProduct && oCase.toAffectedProduct.results.length > 0) {
						var aProducts = oCase.toAffectedProduct.results;
						var aProductLines = [];
						aProducts.forEach(function (oProduct) {
							aProductLines.push(oProduct.AffectedProductText);
						});

						aProductLines = [...new Set(aProductLines)];
						//split all values with ", " and prevent the last value having a comma at the end
						if (aProductLines.length > 1) {
							oObject.ProductLinesMerged = aProductLines.slice(0, -1).join(', ') + ", " + aProductLines.slice(-1);
						} else {
							oObject.ProductLinesMerged = aProductLines.toString();
						}
					}

					if (oCase.toCustomSet && oCase.toCustomSet.results.length > 0) {
						if (oCase.toCustomSet.results[0].Golive) {
							oObject.GoLive = oCase.toCustomSet.results[0].Golive;
						}
					}

				}.bind(this));

			}.bind(this)).catch(function () {

			});

			return oCaseTypePromise;

		},

		_getCustomerType: function (sCaseTypeID) {
			var sCasetype = "";
			switch (sCaseTypeID) {
			case 'ZSCUSTYP01':
				sCasetype = "PES Active";
				break;
			case 'ZSCUSTYP02':
				sCasetype = "PES Complete";
				break;
			case 'ZSCUSTYP03':
				sCasetype = " VIP";
				break;
			case 'ZSCUSTYP04':
				sCasetype = "CPC";
				break;
			case 'ZSCUSTYP05':
				sCasetype = "CCM";
				break;
			}

			return sCasetype;
		},

		_getRegion: function (sServiceOrg) {
			var sRegion = "";
			switch (sServiceOrg) {
			case "O 50008010":
				sRegion = "EMEA";
				break;
			case "O 50008134":
				sRegion = "APJ";
				break;
			case "O 50008167":
				sRegion = "NA";
				break;
			case "O 50008174":
				sRegion = "LA";
				break;
			}
			return sRegion;
		},

		onCustomerPressed: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCustomerId = this.getCardModel().getProperty(sBindingContextPath).CustomerR3No;

			this.navToApp(
				this.getResourceBundle().getText("mccOneDashboardTest", [sCustomerId]),
				this.getResourceBundle().getText("mccOneDashboardProd", [sCustomerId]), {}, false);

		},
		//https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites#mccissuetracking-Display&/20083313
		onLinkPress: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCustomerId = this.getCardModel().getProperty(sBindingContextPath).CaseId;
			this.navToApp(
				this.getResourceBundle().getText("mccWorkbenchTest", [oEvent.getSource().getText()]),
				this.getResourceBundle().getText("mccWorkbenchProd", [oEvent.getSource().getText()]), {}, false);
		},
	});
});