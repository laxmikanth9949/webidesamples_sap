sap.ui.define([
	"com/sap/mcc/workplace/controller/BaseController",
	"sap/base/Log",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/m/OverflowToolbar",
	"sap/m/Toolbar",
	"sap/m/Text",
	"sap/ui/core/Icon",
	"com/sap/mcc/workplace/CardComponent/CardFormatter",
	"sapit/controls/EmployeePopover",
	'sap/m/MessageItem',
	'sap/m/MessageView',
	'sap/m/Button',
	'sap/m/Dialog',
	'sap/m/Bar'
], function (BaseController, Log, JSONModel, Filter, FilterOperator, Fragment, OverflowToolbar, Toolbar, Text, Icon,
	CardFormatter, EmployeePopover, MessageItem, MessageView, Button, Dialog, Bar) {
	"use strict";

	return BaseController.extend("com.sap.mcc.workplace.CardComponent.BaseCardController", {

		formatter: CardFormatter,
		dateFilter: {
			active: false,
			columnID: ""
		},

		onInit: function () {
			if (this.getView().getParent().oContainer.getParent()) { // if View was loaded
				var oHeader;
				var sCardID = this.getView().getViewName().split(".").pop();
				var sProfileInstanceAlias = this.getCoreModel("workplaceModel").getProperty("/selectedProfileInstance/Alias");
				var oCard = this.getCoreModel("workplaceModel").getProperty("/_cardIntegration/" + sProfileInstanceAlias).find(function (oItem) {
					return oItem.cardId === sCardID;
				});

				this.getView().getParent().oContainer.getParent().getParent().setBusy(false); // Requires direct boolean. Tried using binding, but the .refresh() breaks the layoutData.
				this.setCardProperty("/CardInfo", Object.assign({}, oCard)); // Clone object before assigning it to cardModel
				if (oCard && oCard.ReloadInterval) {
					this.setCardAutoRefresh(oCard.ReloadInterval);
				}

				if (oCard) {
					// Depending on CardType, it will rendera different Header
					if (oCard.CardType === "Table") {
						oHeader = new sap.f.cards.Header({
							toolbar: new Toolbar({
								width: "100%",
								content: [
									new Icon({
										src: (this.getCardProperty("/CardInfo/FilterProperty")) ? "sap-icon://filter" : "sap-icon://clear-filter",
										tooltip: (this.getCardProperty("/CardInfo/FilterProperty")) ? "{i18n>card.tooltip.filterable}" : "{i18n>card.tooltip.nonfilterable}",
										color: "#FFFFFF",
										press: [this.openFilterBarInformation, this]
									}).addStyleClass("sapUiTinyMarginBegin"),
									new sap.m.FlexBox({
										items: this.getCardProperty("/customHeader/action/left")
									}),
									new Text({
										text: "{/CardInfo/CardName}"
									}),
									new Text({
										text: "{/customHeader/additionalCardTitle}"
									}),
									new sap.m.ToolbarSpacer(),
									new sap.m.FlexBox({
										items: this.getCardProperty("/customHeader/action/right")
									}),
									new sap.m.HBox({
										visible: "{= ${/busy} && !(${/metadataError})}",
										items: [
											new Icon({
												src: "sap-icon://synchronize",
												tooltip: "{i18n>card.tooltip.refresh}",
												color: "#FFFFFF"
											}).addStyleClass("mccWorkplaceRefreshCardAnimation sapUiTinyMarginBegin")
										]
									}),
									new sap.m.HBox({
										visible: "{= !(${/busy}) && !(${/metadataError})}",
										items: [
											// new sap.m.Text({
											// 	text: "{/lastRefreshText}"
											// })
											new Icon({
												visible: "{= !(${/autoRefreshTime})}",
												src: "sap-icon://refresh",
												tooltip: "{/lastRefreshText}",
												press: [this._flushCard, this],
												color: "#FFFFFF"
											}).addStyleClass("sapUiTinyMarginBegin"),
											new Icon({
												visible: "{= !!(${/autoRefreshTime})}",
												src: "sap-icon://future",
												tooltip: "{/autoRefreshText}",
												press: [this._flushCard, this],
												color: "#FFFFFF"
											}).addStyleClass("sapUiTinyMarginBegin")
										]
									}),
									new sap.m.HBox({
										items: [
											new Icon({
												src: "sap-icon://message-information",
												tooltip: "{i18n>card.tooltip.information}",
												color: "#FFFFFF",
												press: [this.openInformationDialog, this]
											}).addStyleClass("sapUiTinyMarginBeginEnd")
										]
									})
								]
							})
						}).addStyleClass("mccWorkplaceCardHeader").setModel(this.getCardModel());
						// Refresh "/lastRefreshText" and "/lastRefreshDateTime"
						(function refreshTime() {
							var dLastRefreshDateTime = this.getCardProperty("/lastRefreshDateTime");
							var sRelativeTime = sap.ui.core.format.DateFormat.getDateTimeInstance({
								pattern: "h:mm a",
								relative: true,
								relativeScale: "auto"
							});
							if (dLastRefreshDateTime) {
								this.setCardProperty("/lastRefreshText", "Click to Refresh. Refreshed: " + sRelativeTime.format(new Date(dLastRefreshDateTime)));
							}
							setTimeout(refreshTime.bind(this), 1000);
						}.bind(this))();
					} else if (oCard.CardType === "Action") {
						oHeader = new sap.f.cards.Header({
							toolbar: new Toolbar({
								width: "100%",
								content: [
									new sap.m.FlexBox({
										items: this.getCardProperty("/customHeader/action/left")
									}),
									new Text({
										text: this.getCardModel().getProperty("/CardInfo/CardName")
									}),
									new Text({
										text: "{/customHeader/additionalCardTitle}"
									}),
									new sap.m.ToolbarSpacer(),
									new sap.m.HBox({
										items: [
											new sap.m.FlexBox({
												items: this.getCardProperty("/customHeader/action/right")
											}),
											new Icon({
												src: "sap-icon://message-information",
												tooltip: "{i18n>card.tooltip.information}",
												color: "#FFFFFF",
												press: [this.openInformationDialog, this]
											}).addStyleClass("sapUiTinyMarginBeginEnd")
										]
									})
								]
							})
						}).addStyleClass("mccWorkplaceCardHeader").setModel(this.getCardModel());
					} else if (oCard.CardType === "Chart") {
						oHeader = new sap.f.cards.Header({
							toolbar: new Toolbar({
								width: "100%",
								content: [
									new Icon({
										src: (this.getCardProperty("/CardInfo/FilterProperty")) ? "sap-icon://filter" : "sap-icon://clear-filter",
										tooltip: (this.getCardProperty("/CardInfo/FilterProperty")) ? "{i18n>card.tooltip.filterable}" : "{i18n>card.tooltip.nonfilterable}",
										color: "#FFFFFF",
										press: [this.openFilterBarInformation, this],
									}).addStyleClass("sapUiTinyMarginBegin"),
									new sap.m.FlexBox({
										items: this.getCardProperty("/customHeader/action/left")
									}),
									new Text({
										text: "{/CardInfo/CardName}"
									}),
									new Text({
										text: "{/customHeader/additionalCardTitle}"
									}),
									new sap.m.ToolbarSpacer(),
									new sap.m.FlexBox({
										visible: "{= !(${/busy})}",
										items: this.getCardProperty("/customHeader/action/right")
									}),
									new sap.m.HBox({
										visible: "{= ${/busy}  && !(${/metadataError})}",
										items: [
											new Icon({
												src: "sap-icon://synchronize",
												tooltip: "{i18n>card.tooltip.refresh}",
												color: "#FFFFFF"
											}).addStyleClass("mccWorkplaceRefreshCardAnimation sapUiTinyMarginBegin")
										]
									}),
									new sap.m.HBox({
										visible: "{= !(${/busy}) && !(${/metadataError})}",
										items: [
											new Icon({
												visible: "{= !(${/autoRefreshTime})}",
												src: "sap-icon://refresh",
												tooltip: "{/lastRefreshText}",
												press: [this._flushCard, this],
												color: "#FFFFFF"
											}).addStyleClass("sapUiTinyMarginBegin"),
											new Icon({
												visible: "{= !!(${/autoRefreshTime})}",
												src: "sap-icon://future",
												tooltip: "{/autoRefreshText}",
												press: [this._flushCard, this],
												color: "#FFFFFF"
											}).addStyleClass("sapUiTinyMarginBegin")
										]
									}),
									new sap.m.HBox({
										items: [
											new Icon({
												src: "sap-icon://message-information",
												tooltip: "{i18n>card.tooltip.information}",
												color: "#FFFFFF",
												press: [this.openInformationDialog, this]
											}).addStyleClass("sapUiTinyMarginBeginEnd")
										]
									})
								]
							})
						}).addStyleClass("mccWorkplaceCardHeader").setModel(this.getCardModel());
					} else if (oCard.CardType === "KPI") {
						oHeader = new sap.f.cards.Header({
							toolbar: new Toolbar({
								width: "100%",
								content: [
									new Icon({
										src: (this.getCardProperty("/CardInfo/FilterProperty")) ? "sap-icon://filter" : "sap-icon://clear-filter",
										tooltip: (this.getCardProperty("/CardInfo/FilterProperty")) ? "{i18n>card.tooltip.filterable}" : "{i18n>card.tooltip.nonfilterable}",
										color: "#FFFFFF",
										press: [this.openFilterBarInformation, this],
									}).addStyleClass("sapUiTinyMarginBegin"),
									new sap.m.FlexBox({
										items: this.getCardProperty("/customHeader/action/left")
									}),
									new Text({
										text: "{/CardInfo/CardName}"
									}),
									new Text({
										text: "{/customHeader/additionalCardTitle}"
									}),
									new sap.m.ToolbarSpacer(),
									new sap.m.FlexBox({
										visible: "{= !(${/busy})}",
										items: this.getCardProperty("/customHeader/action/right")
									}),
									new sap.m.HBox({
										visible: "{= ${/busy} && !(${/metadataError})}",
										items: [
											new Icon({
												src: "sap-icon://synchronize",
												tooltip: "{i18n>card.tooltip.refresh}",
												color: "#FFFFFF"
											}).addStyleClass("mccWorkplaceRefreshCardAnimation sapUiTinyMarginBegin")
										]
									}),
									new sap.m.HBox({
										visible: "{= !(${/busy}) && !(${/metadataError})}",
										items: [
											new Icon({
												visible: "{= !(${/autoRefreshTime})}",
												src: "sap-icon://refresh",
												tooltip: "{/lastRefreshText}",
												press: [this._flushCard, this],
												color: "#FFFFFF"
											}).addStyleClass("sapUiTinyMarginBegin"),
											new Icon({
												visible: "{= !!(${/autoRefreshTime})}",
												src: "sap-icon://future",
												tooltip: "{/autoRefreshText}",
												press: [this._flushCard, this],
												color: "#FFFFFF"
											}).addStyleClass("sapUiTinyMarginBegin")
										]
									}),
									new sap.m.HBox({
										items: [
											new Icon({
												src: "sap-icon://message-information",
												tooltip: "{i18n>card.tooltip.information}",
												color: "#FFFFFF",
												press: [this.openInformationDialog, this]
											}).addStyleClass("sapUiTinyMarginBeginEnd")
										]
									})
								]
							})
						}).addStyleClass("mccWorkplaceCardHeader").setModel(this.getCardModel());
						// Refresh "/lastRefreshText" and "/lastRefreshDateTime"
						(function refreshTime() {
							var dLastRefreshDateTime = this.getCardProperty("/lastRefreshDateTime");
							var sRelativeTime = sap.ui.core.format.DateFormat.getDateTimeInstance({
								pattern: "h:mm a",
								relative: true,
								relativeScale: "auto"
							});
							if (dLastRefreshDateTime) {
								this.setCardProperty("/lastRefreshText", "Click to Refresh. Refreshed: " + sRelativeTime.format(new Date(dLastRefreshDateTime)));
							}
							setTimeout(refreshTime.bind(this), 1000);
						}.bind(this))();
					} else if (oCard.CardType === "Text") {
						// TODO: implement Text card type
					} else {
						Log.error("ERROR - MCCWORKPLACE-202: missing card type property in the DB or invalid type.",
							"https://github.wdf.sap.corp/mcc/mcc-ui5-workplace/wiki/Error-Codes#MCCWORKPLACE-202", "BaseCardController.onInit (CardID: " +
							oCard.cardId + ", CardType: " + oCard.CardType + ")");
					}

					// set busy to false and set Header aggregation 
					this.getView().getParent().oContainer.getParent().getParent().setAggregation("_header", oHeader);
					// this.getView().getParent().oContainer.getParent().getParent().setBusy(false);

					// TODO: alerts are only available currently for cards that has ScrollContainer structure. Evaluate for other type of cards
					if (this.getView().getContent()[0] instanceof sap.m.ScrollContainer) {
						// Move card content to a VBox
						var aCurrContent = [this.getView().getContent()[0].getContent()];
						this.getView().getContent()[0].removeAllContent();
						// Create Error Message
						this.getView().getContent()[0].addContent(new sap.m.VBox(this.getView().createId("contentBox"), {
							visible: "{= (!(${cardModel>/metadataError}) && !(${cardModel>/error}) && !(${cardModel>/noData}))}",
							items: aCurrContent
						}));

						// Create Error Message
						var aAuthorizationRoleUrls = oCard.AuthorizationRole.map(function (aRole) {
							var aRoleParts = aRole.split(" ");
							return new sap.m.Link({
								"text": "Request Authorization: " + aRole,
								"href": "https://fiorilaunchpad.sap.com/sites#arm-Create&/createRequest/prefilled?system=" + aRoleParts[0] + "&mandant=" +
									aRoleParts[1] + "&role=" + aRoleParts[2],
								"target": "_blank"
							});
						});
						var aAuthorizationRoleUrls = new sap.m.VBox({
							items: aAuthorizationRoleUrls
						});

						this.getView().getContent()[0].addContent(new sap.m.VBox(this.getView().createId("errorBox"), {
							justifyContent: "Center",
							alignItems: "Center",
							visible: "{= (${cardModel>/metadataError} || ${cardModel>/error})}",
							items: [
								new sap.ui.core.Icon({
									src: "{= ${cardModel>/metadataError} ? 'sap-icon://private' : 'sap-icon://message-error'}"
								}),
								new sap.m.Label(this.getView().createId("errorBoxLabel"), {
									text: "{= (${cardModel>/errorMessage} || ${i18n>card.message.cardError}) }"
								}),
								new sap.m.VBox({
									items: aAuthorizationRoleUrls
								})
							]
						}).addStyleClass("sapUiMediumMarginTopBottom"));
						// // Create noData Message
						this.getView().getContent()[0].addContent(new sap.m.VBox(this.getView().createId("noDataBox"), {
							justifyContent: "Center",
							alignItems: "Center",
							visible: "{cardModel>/noData}",
							items: [
								new sap.ui.core.Icon({
									src: "sap-icon://document"
								}),
								new sap.m.Label(this.getView().createId("noDataBoxLabel"), {
									text: this.getResourceBundle().getText("card.message.cardNoData")
								})
							]
						}).addStyleClass("sapUiMediumMarginTopBottom"));
					}
				}
			}
		},

		onUpdateCard: function () {
			Log.error("ERROR - MCCWORKPLACE-201: onUpdateCard method was not found.",
				"https://github.wdf.sap.corp/mcc/mcc-ui5-workplace/wiki/Error-Codes#MCCWORKPLACE-201", "BaseCardController.onUpdateCard");
		},

		onDataExport: function () {
			Log.error("ERROR - MCCWORKPLACE-203: onDataExport method was not found.",
				"https://github.wdf.sap.corp/mcc/mcc-ui5-workplace/wiki/Error-Codes#MCCWORKPLACE-203", "BaseCardController.onDataExport");
		},

		setCardNeutralState: function () {
			this.setCardProperty("/error", false);
			this.setCardProperty("/noData", false);
		},

		setCardUpdateStartState: function () {
			this.setCardProperty("/noData", false);
			this.setCardProperty("/busy", true);
		},

		setCardSuccessState: function () {
			this.setCardProperty("/error", false);
			this.setCardProperty("/noData", false);
			this.setCardProperty("/busy", false);
			this.setCardProperty("/lastRefreshDateTime", new Date());
		},

		setCardErrorState: function (sCustomMessage) {
			this.setCardProperty("/error", true);
			this.setCardProperty("/noData", false);
			this.setCardProperty("/busy", false);
			this.setCardProperty("/lastRefreshDateTime", new Date());
			if (sCustomMessage) {
				this.getView().byId(this.getView().createId("errorBoxLabel")).setText(sCustomMessage);
			}
		},

		setCardNoDataState: function (sCustomMessage) {
			this.setCardProperty("/error", false);
			this.setCardProperty("/noData", true);
			this.setCardProperty("/busy", false);
			this.setCardProperty("/lastRefreshDateTime", new Date());
			if (sCustomMessage) {
				this.getView().byId(this.getView().createId("noDataBoxLabel")).setText(sCustomMessage);
			}
		},

		_flushCard: function () {
			this.setCardProperty("/busy", true);
			setTimeout(this.onUpdateCard.bind(this), 300);

			if (this.getCardProperty("/autoRefreshTime")) {
				this.setCardProperty("/autoRefreshCountdownTime", this.getCardProperty("/autoRefreshTime"));
			}
		},

		/**
		 * Set auto refesh function iRefreshTime in ms
		 */
		setCardAutoRefresh: function (iRefreshTime) {

			if (iRefreshTime && iRefreshTime > 0) {
				//refresh time in ms
				this.setCardProperty("/autoRefreshTime", iRefreshTime);

				// Refresh "/autoRefreshText" and "/autoRefreshTime"
				(function autoRefreshTime() {
					var iRefreshRate = 1000; // 1000ms = 1s
					var iAutoRefreshTime = this.getCardProperty("/autoRefreshTime");
					var iAutoRefreshCountdownTime = this.getCardProperty("/autoRefreshCountdownTime");

					if (!iAutoRefreshCountdownTime || iAutoRefreshCountdownTime < 0) {
						iAutoRefreshCountdownTime = iAutoRefreshTime;
						// TODO: check if Profile is visible
						this.onUpdateCard(); // auto refresh mechanism is called
					}

					this.setCardProperty("/autoRefreshText", "Click to Refresh. Auto Refresh in " + CardFormatter.millisToMinutesAndSeconds(
						iAutoRefreshCountdownTime));
					iAutoRefreshCountdownTime = iAutoRefreshCountdownTime - iRefreshRate;
					this.setCardProperty("/autoRefreshCountdownTime", iAutoRefreshCountdownTime);

					this._oAutoRefreshHandle = setTimeout(autoRefreshTime.bind(this), iRefreshRate);
				}.bind(this))();
			} else {
				this.onUpdateCard();
			}
		},

		/**
		 * Destroy autoRefresh
		 */
		onExit: function () {
			if (this._oAutoRefreshHandle) {
				clearTimeout(this._oAutoRefreshHandle);
			}
		},

		/**
		 * Update Card Title of Tables to display the correct amount of items / rows when binding changes
		 */
		updateCardTitle: function (sBindingPath, oEvent) {

			var iCases = oEvent.getSource().getLength();
			// if iCases = 0; no additional header to display
			var sCardTitle = iCases ? "(" + iCases + ")" : "";
			if (iCases && sBindingPath && this.getCardProperty("/" + sBindingPath)) {
				var iBindingCount = this.getCardProperty("/" + sBindingPath).length;
				sCardTitle = (iCases && iCases != iBindingCount) ? "(" + iCases + " of " + iBindingCount + ")" : "(" + iBindingCount + ")";
			}
			/*for(var i = 0; i < aColumns.length; i++){
				if(aColumns[i].getFiltered()){
					sCardTitle += " [filtered]";
					break;
				}
			}*/

			this.setCardProperty("/customHeader/additionalCardTitle", sCardTitle);
		},

		/**
		 * Convenience method for accessing the router in every controller of the application.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return this.getOwnerComponent().getRouter();
		},

		/**
		 * Convenience method for getting the Core model by name in every controller of the application.
		 * Note: cards are implemented in a multicomponent approach, so acess to the common Model is via sap.ui.getCore()
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getCoreModel: function (sName) {
			return sap.ui.getCore().getModel(sName);
		},

		/**
		 * Convenience method for getting the view model by name in every controller of the application.
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Convenience method for getting the view model by name in every controller of the application.
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getCardModel: function () {
			return this.getOwnerComponent().getModel("cardModel");
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setCardModel: function (oModel) {
			return this.getOwnerComponent().setModel(oModel, "cardModel");
		},

		/**
		 * Sets a new value for the given property sPath of the cardModel
		 * If doesn't exists yet, it will create an instance of cardModel
		 * @public
		 */
		setCardProperty: function (sPath, oValue, oContext, bAsyncUpdate) {
			return this.getCardModel().setProperty(sPath, oValue, oContext, bAsyncUpdate);
		},

		/**
		 * Returns the value for the property with the given sPath of the cardModel
		 * If doesn't exists yet, it will create an instance of cardModel
		 * @public
		 */
		getCardProperty: function (sPath) {
			return this.getCardModel().getProperty(sPath);
		},

		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		/**
		 * Navigates to external application
		 * mimics a Handlebar implementation for parameters
		 * @public
		 */
		navToApp: function (sTestUrl, sProdUrl, oParams, bCrossAppNavigation) {
			var sHostname = window.location.hostname;
			var sURL = null;

			// SAP IT Cloud T - https://fiorilaunchpad-sapitcloudt.dispatcher.hana.ondemand.com/sites
			if (sHostname.lastIndexOf("sapitcloudt") > -1 || sHostname.lastIndexOf("a44f228ad") > -1) {
				sURL = sTestUrl;
			} else if (sHostname === "fiorilaunchpad.sap.com" || sHostname.lastIndexOf("a87daa223") > -1) {
				sURL = sProdUrl;
			}

			// custom implementation of Handlebar
			if (Object.keys(oParams).length) {
				Object.keys(oParams).forEach(function (oKey) {
					sURL.replace("{" + oKey + "}", oParams[oKey]);
				});
			}

			if (bCrossAppNavigation) {
				// bCrossAppNavigation TODO: implement if crossAppNavigation is desired or open in new tb	
			} else {
				if (sURL) {
					sap.m.URLHelper.redirect(sURL, true);
				}
			}

		},

		_getCardSpecificCases: function (sCardId) {
			var oWorkplaceModel = this.getCoreModel("workplaceModel");
			var sSelectedProfileName = oWorkplaceModel.getProperty("/selectedProfileInstance/Name").replace(/\s+/g, '');
			if (sSelectedProfileName === "RegionalMCSManager/MCSGlobal") {
				sSelectedProfileName = "RegionalManager";
			}
			var aProfileCards = sap.ui.getCore().getModel("workplaceModel").getProperty("/_cardIntegration/" + sSelectedProfileName);
			var oFilterCases = oWorkplaceModel.getProperty("/FilterCases");
			var aFilterValues = [];

			if (aProfileCards) {
				for (var i = 0; i < aProfileCards.length; i++) {
					if (aProfileCards[i].cardId === sCardId) {
						aFilterValues = aProfileCards[i].FilterProperty.split(";");
						break;
					}
				}
			}

			if (aFilterValues && aFilterValues.length > 0) {
				//var aFilter = ["CaseId", "ResponsiblePerson"];
				var aHelper = [];

				aFilterValues.forEach(function (sFilter) {
					if (oFilterCases.hasOwnProperty(sFilter)) {
						aHelper = aHelper.concat(oFilterCases[sFilter]);
					}

				}.bind(this));

				return this._removeObjectDuplicatesInArray(aHelper);
			} else {
				return [];
			}
		},

		getFilterBarValues: function (sCardId) {
			var oWorkplaceModel = this.getCoreModel("workplaceModel");
			var aFilters = [];
			var sSelectedProfileName = oWorkplaceModel.getProperty("/selectedProfileInstance/Name").replace(/\s+/g, '');
			if (sSelectedProfileName === "RegionalMCSManager/MCSGlobal") {
				sSelectedProfileName = "RegionalManager";
			}
			var aProfileCards = sap.ui.getCore().getModel("workplaceModel").getProperty("/_cardIntegration/" + sSelectedProfileName);
			// filter for s card id
			// split filter values 
			// return filter in array
			try {
				var aSelectedcard = aProfileCards.filter(oCard => oCard.cardId === sCardId);
				var oFilterValues = oWorkplaceModel.getProperty("/FilterValues");
				if (aSelectedcard.length > 0) {
					//check if filtervalues > 0
					var sFilterProperty = aSelectedcard[0].FilterProperty;
					if (sFilterProperty.length > 0) {
						var aFilterProperties = sFilterProperty.split(";");
						aFilterProperties.forEach(function (sFilterName) {
							if (oFilterValues.hasOwnProperty(sFilterName)) {
								aFilters.push(oFilterValues[sFilterName]);
							}
						});
					}
				}

				return aFilters;
			} catch (e) {
				console.log(e);
				return [];
			}

		},

		getCQIScore: function (sPropertyName, sProfile) {
			var sPath = "/" + sPropertyName;
			var sUrl = "/executeRuleCheck?profile=" + sProfile;
			var CasecheckerPromise = new Promise(function (resolve, reject) {
				jQuery.ajax({
					type: "GET",
					contentType: "application/json",
					url: sUrl, //"/executeRuleCheck?profile=mcs-gem&object=CaseSet(CaseID=%27" + sCaseId +"%27,CaseType=%27ZS01%27,CaseObject=%27C%27)",
					dataType: "json",
					success: function (data, textStatus, jqXHR) {
						resolve(data);
					},
					error: function (err) {
						reject(err);
					}
				});
			});

			CasecheckerPromise.then(function (oData) {
				if (oData.Data && oData.Data.length > 0) {
					//set Column CQI visible
					this.setCardProperty("/visibleCQI", true);
					var aData = this.getCardProperty(sPath);
					oData.Data.forEach(function (oCaseCQI) {
						//	oCaseCQI.Identifier // CaseId
						var oObject = this.findObjectByKey(aData, "CaseID", oCaseCQI.Identifier);
						if (oObject) {
							oObject.CQI = oCaseCQI.CQI;
							oObject.CQIStatus = oCaseCQI.RuleCheckResult;
							if (oCaseCQI.Rules && oCaseCQI.Rules.length > 0) {
								oObject.Rules = oCaseCQI.Rules.filter((item) => item.RuleResult !== "Success");
							}
						}
					}.bind(this));
					//this.getCardModel().refresh();
				} else {
					this.setCardProperty("/visibleCQI", false);

				}

			}.bind(this)).catch(function (oError) {
				this.setCardProperty("/visibleCQI", false);
			}.bind(this));

			return CasecheckerPromise;
		},

		_getFilteredOptions: function (sCardId) {
			var oWorkplaceModel = this.getCoreModel("workplaceModel");

			oWorkplaceModel.getProperty("/FilterBar/Region");
		},

		_removeObjectDuplicatesInArray: function (aArray) {
			var unique = {};
			var aUnique = [];
			aArray.forEach(function (oObj, iIndex) {
				if (!unique[oObj.CaseID]) {
					unique[oObj.CaseID] = true;
					aUnique.push(oObj);
				}
			});
			return aUnique;
		},

		openConfidentialDialog: function (oEvent) {
			if (!this.oConfidentialFragment) {
				Fragment.load({
					name: "com.sap.mcc.workplace.view.fragments.Confidential",
					controller: this
				}).then(function (oConfidentialFragment) {
					this.oConfidentialFragment = oConfidentialFragment;
					//	this._oInformationDialog.setTitle(oCard.CardName + " - Card Information");
					this.oConfidentialFragment.open();
				}.bind(this));
			} else {
				this.oConfidentialFragment.open();
			}

		},

		closeDialog: function (oEvent) {
			oEvent.getSource().getParent().close();
		},

		openCQIPopover: function (oEvent) {
			var oCtx = oEvent.getSource().getBindingContext("cardModel"),
				oControl = oEvent.getSource();
			// create popover
			if (!this._oPopover) {
				Fragment.load({
					id: "CQIPopOver",
					name: "com.sap.mcc.workplace.view.fragments.CQIPopover",
					controller: this
				}).then(function (oPopover) {
					this._oPopover = oPopover;
					this.getView().addDependent(this._oPopover);
					this._oPopover.bindElement({
						path: oCtx.getPath(),
						model: "cardModel"
					});
					this._oPopover.openBy(oControl);
				}.bind(this));
			} else {
				this._oPopover.bindElement({
					path: oCtx.getPath(),
					model: "cardModel"
				});
				this._oPopover.openBy(oControl);
			}
		},

		getCaseRegion: function (aCases) {
			aCases.forEach(function (oCase) {
				switch (oCase.ServiceOrg) {
				case "O 50008010":
					oCase.Region = "EMEA";
					break;
				case "O 50008134":
					oCase.Region = "APJ";
					break;
				case "O 50008167":
					oCase.Region = "NA";
					break;
				case "O 50008174":
					oCase.Region = "LA";
					break;
				default:
					oCase.Region = "";
				}
			});

			return aCases;
		},

		openEmployeePopover: function (oEvent) {
			var sEmployeeId = "";
			if (oEvent.getSource().data("UserId")) {
				sEmployeeId = oEvent.getSource().data("UserId");
			}
			var oPopover = new EmployeePopover({
				employeeId: sEmployeeId
			});

			oPopover.openBy(oEvent.getSource());
		},

		onFilter: function (oEvent) {
			if (this.dateFilter.active) {
				this.dateFilter.column.setFiltered(false);
			}
		},

		onDateFilter: function (oEvent) {
			var sValue = oEvent.getParameter('item').getProperty('value');

			var sFilterProperty = "";
			var sTableID = "";
			var aClearedTableFilters = [];
			var aFilter = [];
			var aNewFilter = [];

			if (oEvent.getSource().data("Property") && oEvent.getSource().data('TableID')) {
				sFilterProperty = oEvent.getSource().data("Property");
				sTableID = oEvent.getSource().data('TableID');
			} else {
				//TODO: add further error handling here ...
				console.log("Error during date filter");
			}

			var oTable = this.byId(sTableID);
			var aTableFilters = oTable.getBinding().aFilters;

			for (var j = 0; j < aTableFilters.length; j++) {
				if (aTableFilters[j].sPath !== sFilterProperty) {
					aClearedTableFilters.push(aTableFilters[j]);
				}
			}

			if (sValue.trim() !== "" && Date.parse(sValue) > 0) {
				oEvent.getSource().getParent().getParent().setFiltered(true);
				var oStart = new Date(Date.parse(sValue));
				var oEnd = new Date(Date.parse(sValue));
				oEnd.setHours(23);
				oEnd.setMinutes(59);
				oEnd.setSeconds(59);
				if (aFilter.length === 0) {
					var filter = new sap.ui.model.Filter(sFilterProperty, sap.ui.model.FilterOperator.BT, oStart, oEnd);
					this.dateFilter = {
						active: true,
						column: oEvent.getSource().getParent().getParent()
					};
					aFilter.push(filter);
				}
				aNewFilter = aClearedTableFilters.concat(aFilter);
			} else {
				this.dateFilter = {
					active: false,
					column: ""
				};
				oEvent.getSource().getParent().getParent().setFiltered(false);
				aNewFilter = aClearedTableFilters;
			}

			oTable.getBinding().filter(aNewFilter);
			oTable.getBinding().refresh(true);
		},

		onSortDate: function (oEvent) {
			var oColumn = oEvent.getSource().getParent().getParent();
			var sColumnId = oEvent.getSource().getParent().getParent().sId;

			var sProperty = "";
			var sTableID = "";
			var bIsDesc = {};
			var sOpenFor = "";

			if (oEvent.getSource().data("Property")) sProperty = oEvent.getSource().data("Property")
			if (oEvent.getSource().data('TableID')) sTableID = oEvent.getSource().data('TableID');
			//
			if (oEvent.getSource().data('OpenFor')) sOpenFor = oEvent.getSource().data('OpenFor');
			if (oEvent.getSource().data('sort') === "asc") {
				bIsDesc = false;
				oColumn.setProperty("sortOrder", sap.ui.table.SortOrder.Ascending);
			} else if (oEvent.getSource().data('sort') === "dsc") {
				bIsDesc = true;
				oColumn.setProperty("sortOrder", sap.ui.table.SortOrder.Descending);
			} else {
				console.log("Error during sorting!")
			}

			//toggle the bIsDesc flag to show the correct column ordering in OpenFor columns 
			// date values are formatted --> ascending current date is last entry, but the open for = 0 days indidcates that the case / issue was just created
			// therefore the flag needs to be toggled
			if (sOpenFor === "true") {
				bIsDesc = !bIsDesc;
			}

			var oTable = this.byId(sTableID);

			//remove sorted icon on all other columns
			for (var i = 0; i < oColumn.getParent().getColumns().length; i++) {
				var currentColumn = oColumn.getParent().getColumns()[i];
				if (currentColumn.sId !== sColumnId) {
					currentColumn.setSorted(false);
				}
			}

			oColumn.setSorted(true);
			oTable.getBinding().sort(new sap.ui.model.Sorter(sProperty, bIsDesc));
			oTable.getBinding().refresh(true);
		},

		openErrorMessageView: function (aMessages) {
			var that = this;

			var oMessageTemplate = new MessageItem({
				type: '{type}',
				title: '{title}',
				description: '{description}',
				subtitle: '{subtitle}',
				counter: '{counter}',
				markupDescription: '{markupDescription}',
			});

			var oModel = new JSONModel();

			oModel.setData(aMessages);

			this.oMessageView = new MessageView({
				showDetailsPageHeader: false,
				itemSelect: function () {
					oBackButton.setVisible(true);
				},
				items: {
					path: "/",
					template: oMessageTemplate
				}
			});

			var oBackButton = new Button({
				icon: "sap-icon://nav-back",
				visible: false,
				press: function () {
					that.oMessageView.navigateBack();
					this.setVisible(false);
				}
			});

			this.oMessageView.setModel(oModel);

			this.oDialog = new Dialog({
				resizable: true,
				content: this.oMessageView,
				state: 'Error',
				beginButton: new Button({
					press: function () {
						this.getParent().close();
						this.getParent().destroy();
					},
					text: "Close"
				}),
				customHeader: new Bar({
					contentMiddle: [
						new Text({
							text: "Error"
						})
					],
					contentLeft: [oBackButton]
				}),
				contentHeight: "50%",
				contentWidth: "50%",
				verticalScrolling: false
			});

			this.oDialog.open();
			this.setCardSuccessState();
		},

		getUserInfo: function (sUserId) {
			return new Promise(function (resolve, reject) {
				jQuery.ajax({
					url: "/sap/ui5/1/resources/sapit/sapitapi/user-info/" + sUserId,
					async: false,
					method: "GET",
					dataType: 'json',
					success: function (oUserData) {
						resolve(oUserData.firstName + " " + oUserData.lastName);
						//return oUserData.firstName + " " + oUserData.lastName;
					},
					error: function (err) {
						reject(sUserId);
						//return userID;
					}
				});
			});

		}

	});
});