sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function (BaseCardController, JSONModel, MessageToast) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.CCTQueue.CCTQueue", {

		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */
			this.onUpdateCard();
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count
			
			var oFilter = [];
			var model = this.getModel("agsDashboardService");
			var f1 = new sap.ui.model.Filter("activity_service_team", sap.ui.model.FilterOperator.EQ, "14083268");
			var fOpen10 = new sap.ui.model.Filter("activity_status", sap.ui.model.FilterOperator.EQ, "E0010");
			var fOpen11 = new sap.ui.model.Filter("activity_status", sap.ui.model.FilterOperator.EQ, "E0011");
			var fOpen19 = new sap.ui.model.Filter("activity_status", sap.ui.model.FilterOperator.EQ, "E0019");
			var fOpen20 = new sap.ui.model.Filter("activity_status", sap.ui.model.FilterOperator.EQ, "E0020");
			var fOpen = new sap.ui.model.Filter({
				filters: [fOpen10, fOpen11, fOpen19, fOpen20],
				and: false
			});
			oFilter.push(fOpen);
			oFilter.push(f1);
			
			//set Busy Indicator of Table
			model.read("/ActivityList/", {
				filters: oFilter,
				success: function (oResult1) {
					var oResult = this.bubbleSort(oResult1);
					
					this.setCardProperty("/data", oResult.results);
					
					this.setCardProperty("/customHeader/additionalCardTitle", " (" + oResult.results.length + ")");
					var scroll = this.getView().byId("s1");
					if (oResult.results.length > 9) {
						scroll.setHeight("31rem");
					}
					
					
					this.setCardSuccessState();
				}.bind(this),
				error: function (oError) {
					this.setCardErrorState();
				}.bind(this)
			});
		},
		
		bubbleSort: function (oResult) {
			var that = this;
			var n = oResult.results.length;
			for (var i = 0; i < n - 1; i++) {
				for (var j = 0; j < n - i - 1; j++) {
					if ((oResult.results[j].activity_create_date) > (oResult.results[j + 1].activity_create_date)) {
						var temp = oResult.results[j];
						oResult.results[j] = oResult.results[j + 1];
						oResult.results[j + 1] = temp;
					}
				}
			}
			return oResult;
		},

		onAfterRendering: function () {

		},

		onSelectionChange: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			var activityId = oSelectedItem.getBindingContext("cardModel").getObject().activity_id;
			var currentUrl = window.location.href;
			var relativeUrl =
				"/sap(bD1lbiZjPTAwMSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?saprole=ZSU_DEFAULT&crm-object-type=BT126_APPT&crm-object-action=B&crm-object-keyname=OBJECT_ID&crm-object-value=" +
				activityId;
			var urlICP = this.getView().getModel("i18n").getResourceBundle().getText("urlICPSAP");
			var urlICT = this.getView().getModel("i18n").getResourceBundle().getText("urlICTSAP");
			var url = urlICP + relativeUrl;
			if (currentUrl.includes("a44f228ad.dispatcher.hana.ondemand.com")) {
				//we are in test envrionment
				url = urlICT + relativeUrl;
			}
			var win = window.open(url, "_blank");
			win.focus();

		},
		
		onGlobalViewIconPress: function (oEvent) {
			var sText = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("globalViewMessageToast");
			MessageToast.show(sText);
		},

		formatURL: function (sCustNumber) {
			var currentUrl = window.location.href;
			var sMccCriticalSitUrl = this.getView().getModel("i18n").getResourceBundle().getText("mccOneDashboardProd", [sCustNumber]);
			var url = sMccCriticalSitUrl;
			var mccCritSitCustomerURL2 = this.getView().getModel("i18n").getResourceBundle().getText("mccOneDashboardTest", [sCustNumber]); 
			if (currentUrl.includes("a44f228ad.dispatcher.hana.ondemand.com")) {
				//we are in test envrionment
				url = mccCritSitCustomerURL2 ;
			}
			return url;
		}
	});
});