sap.ui.define([
	"jquery.sap.global",
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (jQuery, BaseCardController, JSONModel, Filter, FilterOperator) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.ERAcceptancerate.ERAcceptanceRate", {
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			this.onUpdateCard();
			

			
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			// this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count
		
			var oModel = this.getModel("critsitDashboardService");
			
			//var oJSON = new JSONModel();
			
			//this.getView().setModel(oJSON, "feeder");
			
			//get the years
			var currentYear = new Date().getFullYear();
			var pastYear1 = currentYear-1;
			var pastYear2 = currentYear-2;
			var pastYear3 = currentYear-3;
			
			//definition of all filters used
			var oFilter = [];
			var filterA = new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "E0012"); //works
			var filterB = new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.GE, currentYear+"-01-01T00:00:00"); //current year
			var filterC = new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.BT, pastYear1+"-01-01T00:00:00", pastYear1+"-12-31T23:59:59"); // 1 year ago
			var filterD = new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.BT, pastYear2+"-01-01T00:00:00", pastYear2+"-12-31T23:59:59"); // 2 years ago
			var filterE = new sap.ui.model.Filter("CreationDate", sap.ui.model.FilterOperator.BT, pastYear3+"-01-01T00:00:00", pastYear3+"-12-31T23:59:59"); // 3 years ago
			
			
			//get total of escalation requests of the current year
			var totalCurrent = $.Deferred();
			oFilter.push(filterB);
			oModel.read("/GlobalEscalationRequestSet/$count", {
				filters: oFilter,
				success: function (oResult1) {
					totalCurrent.resolve(Number(oResult1));
				},
				error: function() {
				}
			});
			
			//get number of accepted escalation requests of the current year
			var acceptedCurrent = $.Deferred();
			oFilter = [];
			oFilter.push(filterA);
			oFilter.push(filterB);
			
			oModel.read("/GlobalEscalationRequestSet/$count", {
				filters: oFilter,
				success: function (oResult1) {
					acceptedCurrent.resolve(Number(oResult1));
				},
				error: function() {
				}
			});
			
			var past1total = $.Deferred();
			oFilter = [];
			oFilter.push(filterC);
			
			oModel.read("/GlobalEscalationRequestSet/$count", {
				filters: oFilter,
				success: function (oResult1) {
					past1total.resolve(Number(oResult1));
				},
				error: function() {
				}
			});
					
			var past1accepted = $.Deferred();
			oFilter = [];
			oFilter.push(filterC);
			oFilter.push(filterA);
			
			oModel.read("/GlobalEscalationRequestSet/$count", {
				filters: oFilter,
				success: function (oResult1) {
					past1accepted.resolve(Number(oResult1));
				},
				error: function() {
				}
			});
			
			var past2total = $.Deferred();
			oFilter = [];
			oFilter.push(filterD);
			
			oModel.read("/GlobalEscalationRequestSet/$count", {
				filters: oFilter,
				success: function (oResult1) {
					past2total.resolve(Number(oResult1));
				},
				error: function() {
				}
			});
					
			var past2accepted = $.Deferred();
			oFilter = [];
			oFilter.push(filterD);
			oFilter.push(filterA);
			
			oModel.read("/GlobalEscalationRequestSet/$count", {
				filters: oFilter,
				success: function (oResult1) {
					past2accepted.resolve(Number(oResult1));
				},
				error: function() {
				}
			});
			
			var past3total = $.Deferred();
			oFilter = [];
			oFilter.push(filterE);
			
			oModel.read("/GlobalEscalationRequestSet/$count", {
				filters: oFilter,
				success: function (oResult1) {
					past3total.resolve(Number(oResult1));
				},
				error: function() {
				}
			});
					
			var past3accepted = $.Deferred();
			oFilter = [];
			oFilter.push(filterE);
			oFilter.push(filterA);
			
			oModel.read("/GlobalEscalationRequestSet/$count", {
				filters: oFilter,
				success: function (oResult1) {
					past3accepted.resolve(Number(oResult1));
				},
				error: function() {
				}
			});
			
	
			$.when(totalCurrent,acceptedCurrent, past1total, past1accepted, past2total, past2accepted, past3total, past3accepted).done(function (v1,v2,v3,v4,v5,v6,v7,v8) {
				var p1 = this.getPercent(v2,v1);
				var p2 = this.getPercent(v4,v3);
				var p3 = this.getPercent(v6,v5);
				var p4 = this.getPercent(v8,v7);
				this.getView().byId("per1text").addStyleClass(this.getTextColorClass(p2));
				this.getView().byId("per2text").addStyleClass(this.getTextColorClass(p3));
				this.getView().byId("per3text").addStyleClass(this.getTextColorClass(p4));
				var data = {
					year: currentYear,
					total : v1,
					accepted : v2,
					percentage : p1,
					year1: pastYear1,
					total1: v3,
					accepted1: v4,
					per1: p2,
					year2: pastYear2,
					total2: v5,
					accepted2: v6,
					per2: p3,
					year3: pastYear3,
					total3: v7,
					accepted3: v8,
					per3: p4
				};
			// feed the information to the local model
			//	this.getModel("feeder").setData(data);
				this.setCardProperty("/data", data);
			//	this.getModel("feeder").refresh(true);
				this.setCardSuccessState();
			}.bind(this));		
		},
		
		getPercent: function(v1, v2) {
			return Math.round((v1/v2)*100);// + "%";
		},
		
		
		getTextColorClass: function (aValue) {
			var value = parseInt(aValue, 10);
			if (value <= 49) {
				return "mccWorkplaceTextGood";
			} else if (value < 80) {
				return "mccWorkplaceTextCritical";
			} else {
				return "mccWorkplaceTextError";
			}
		}
	});
});