sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController"
], function (BaseCardController) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.CCMCasesSAC.CCMCasesSAC", {
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */

			// set Card Succes State one the iframe got manually refreshed
			var oFrame = this.getView().byId("iframe1");
			oFrame.attachBrowserEvent("load", function (o) {
				this.setCardSuccessState();
			}.bind(this));
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified

			this.getView().byId("vBox").rerender();

		}
	});
});