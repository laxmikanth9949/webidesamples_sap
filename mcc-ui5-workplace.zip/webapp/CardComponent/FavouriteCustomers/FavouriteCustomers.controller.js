sap.ui.define([
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseCardController, Filter, FilterOperator) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.FavouriteCustomers.FavouriteCustomers", {
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */
			var oVizFrame = this.byId("idDonutChart");
			oVizFrame.setVizProperties({
				title: {
					visible: "true",
					text: "MCS Customer Interactions"
				},
				valueAxis: {
					title: {
						visible: false,
						text: "Amount"
					}
				},
				categoryAxis: {
					title: {
						visible: false,
						text: "Type"
					}
				},
				plotArea: {
					dataLabel: {
						visible: true
					}
				}
			});

			this.onUpdateCard();
			// this.setCardAutoRefresh(300000); // Autorefresh in ms - if card needs to be autorefreshed, set the time in ms

			/* YOUR CODE HERE */
		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			
			this._getFavouriteCustomers().then(function (aFavCustomer) {

				if (aFavCustomer && aFavCustomer.length > 0) {

					//this.getCardModel().refresh(true);
					var aAllPromise = [];
					for (var i = 0; i < aFavCustomer.length; i++) {
						aFavCustomer[i].chart = [];
						//4 requets to send 1. Very High messages 2. Business Downs 3. Critical Cases 4. Global Escalations
						//var CasecheckerPromise = this._readCaseCheckerDetails(aCases[i].CaseID, aCases[i].CustomerName);
						var oVeryHighMsgPromise = this._getVHMessages(aFavCustomer[i].ErpCustNo);
						aAllPromise.push(oVeryHighMsgPromise);
						var oGlobalEscPromise = this._getGlobalEscalations(aFavCustomer[i].ErpCustNo);
						aAllPromise.push(oGlobalEscPromise);
						//business Downs
						var oBusinessDown = this._getAmountBusinessDown(aFavCustomer[i].ErpCustNo);
						aAllPromise.push(oBusinessDown);
						//Critical Cases
						var oCriticalCasesPromise = this._getAmountCriticalCases(aFavCustomer[i].ErpCustNo, aFavCustomer[i].Partner);
						aAllPromise.push(oCriticalCasesPromise);
					}

					this.setCardProperty("/customers", aFavCustomer);

					Promise.all(aAllPromise).then(function (oData) {
							//disable loading indicator and error indicator
							this.setCardSuccessState();
						}.bind(this))
						.catch(function (oError) {
							// when any odata requests failed
							this.setCardErrorState();
						}.bind(this));

				} else {
					this.setCardNoDataState();
				}
			}.bind(this)).catch(function (oError) {
				this.setCardErrorState();
			}.bind(this));

			//if (aCases && aCases.length > 0) {
			/* YOUR CODE HERE */
			/*		this.setCardSuccessState();
				} else {
					this.setCardNoDataState();
				}*/
		},

		_getFavouriteCustomers: function () {
			var oFilter = new Filter("Attribute", FilterOperator.EQ, "FAVORITE_CUSTOMERS");
			var oModel = this.getModel("userProfile");
			return new Promise(function (resolveCustomer, rejectCustomer) {
				var oFavCustNoPromise = new Promise(function (resolve, reject) {
					oModel.read("/Entries", {
						filters: [oFilter],
						success: function (oData) {
							//this.setCardProperty("/favCustomers", oData.results);
							resolve(oData.results);
						}.bind(this),
						error: function (oError) {
							reject(oError);
						}
					});
				}.bind(this));

				oFavCustNoPromise.then(function (aCustomers) {
					var aPromise = [];
					//get Customer details (e.g. name, country etc.) for Each favorites entry
					aCustomers.forEach(function (oCustomer) {
						aPromise.push(this._getCustomerDetails(oCustomer.Value));
					}.bind(this));

					Promise.all(aPromise).then(function (aCustomerDetails) {

						resolveCustomer(aCustomerDetails);
					}.bind(this)).catch(function (oErr) {
						rejectCustomer(oErr);
					});
				}.bind(this));
			}.bind(this));

		},

		_getCustomerDetails: function (sErpCustNo) {
			var oCritSitDbModel = this.getModel("critsitDashboardService");

			var oFilterErpNo = new Filter("ErpCustNo", FilterOperator.EQ, sErpCustNo);

			return new Promise(function (resolve, reject) {
				oCritSitDbModel.read("/CustomerSet", {
					filters: [oFilterErpNo],
					success: function (oData) {
						var oCustomer = {};
						if (oData.results && oData.results.length > 0) {
							oCustomer = oData.results[0];
						}
						resolve(oCustomer);
					},
					error: function (oError) {
						reject(oError);
					}
				});
			}.bind(this));
		},

		_getVHMessages: function (sCustomerId) {

			var oSidModel = this.getModel("sidService");
			var oFilter = new Filter({
				filters: [
					new Filter("CustomerNo", FilterOperator.EQ, sCustomerId),
					new Filter("Priority", FilterOperator.EQ, "1")
					//Priority: very high = 1; high = 3
					/*new Filter({
						filters: [new Filter("Priority", FilterOperator.EQ, "1"), new Filter("Priority", FilterOperator.EQ, "3")],
						and: false
					})*/
				],
				and: true
			});

			var oMsgPromise = new Promise(function (resolve, reject) {

				oSidModel.read("/IncidentList", {
					urlParameters: {
						"$top": "5"
					},
					filters: [oFilter],
					success: function (oData) {
						resolve({
							CustomerId: sCustomerId,
							messages: oData.results
						});
					},
					error: function (err) {
						reject(err);
					}
				});

			});

			oMsgPromise.then(function (oData) {
				// add data to array

				if (oData.messages && oData.messages.length > 0) {
					var aCustomers = this.getCardProperty("/customers");
					var iIndex = this._findObjIndex(aCustomers, oData.CustomerId);

					if (typeof (iIndex) === "number" && iIndex >= 0) {
						aCustomers[iIndex].VeryHigh = oData.messages;
						this.setCardProperty("/customers", aCustomers);
						this.getCardModel().refresh(true);
					}
				}
			}.bind(this)).catch(function (oErr) {

			});

			return oMsgPromise;
		},

		_getGlobalEscalations: function (sCustomerId) {
			var aFilters = [];
			var oModel = this.getModel("critsitDashboardService");

			//ALL ongoing escalations
			//Rating =   ALL
			//Case Status = status eq '20' or status eq '30'
			//process_type  Global Escalations (ZSPRCTYP01)  -->  should be predefined in Backend
			var tileSpecificFilters = new sap.ui.model.Filter([ //LISSI
					//new sap.ui.model.Filter("process_type", sap.ui.model.FilterOperator.EQ,	"ZSPRCTYP01"),
					new sap.ui.model.Filter([new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "30"), new sap.ui.model.Filter(
						"Status", sap.ui.model.FilterOperator.EQ, "20")], false)
				],
				true
			);
			var oFilter = new sap.ui.model.Filter("CustomerErpNo", sap.ui.model.FilterOperator.EQ, sCustomerId);
			aFilters.push(oFilter);
			aFilters.push(tileSpecificFilters);

			var oGlobalEscPromise = new Promise(function (resolve, reject) {
				oModel.read("/GlobalEscalationsSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					success: function (data) {
						resolve({
							CustomerId: sCustomerId,
							GlobalEsc: data
						});
					},
					error: function (err) {
						reject(err);
					}
				});
			});

			oGlobalEscPromise.then(function (oData) {
				if (oData.GlobalEsc) {
					var aCustomers = this.getCardProperty("/customers");
					var iIndex = this._findObjIndex(aCustomers, oData.CustomerId);

					if (typeof (iIndex) === "number" && iIndex >= 0) {
						var oObj = {
							"Type": "Global Escalations",
							"Amount": oData.GlobalEsc
						};

						aCustomers[iIndex].chart.push(oObj);
						this.setCardProperty("/customers", aCustomers);
						this.getCardModel().refresh(true);
					}
				}
			}.bind(this)).catch(function (err) {

			});

			return oGlobalEscPromise;

		},

		_getAmountBusinessDown: function (sCustomerId) {
			var aFilters = [];

			var oBCModel = this.getModel("bcModel");

			//Escalation Status Flag:  15 - Business Down
			//User Status (Estatus):E0001(New), E0002 (In Process), E0004 (Customer Action)
			//TODO several status values must be provided from oData
			//TODO or BCP incident with ICP Service Request		
			var oFilter = new sap.ui.model.Filter([
					new sap.ui.model.Filter("ErpCustNo", sap.ui.model.FilterOperator.EQ, sCustomerId),
					new sap.ui.model.Filter("EscltnStatus", sap.ui.model.FilterOperator.EQ, "15"),
					new sap.ui.model.Filter("StatOpen", sap.ui.model.FilterOperator.EQ, "X")
					/*
										new sap.ui.model.Filter([new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0001"), new sap.ui.model.Filter(
												"Estatus", sap.ui.model.FilterOperator.EQ, "E0002"), new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ,
												"E0003"), new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0004"),
											new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0005"), new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator
												.EQ, "E0006"), new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0007"), new sap.ui.model.Filter("Estatus",
												sap.ui.model.FilterOperator.EQ, "E0015"),
											new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0016"), new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator
												.EQ, "E0017"),
											new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator.EQ, "E0018"), new sap.ui.model.Filter("Estatus", sap.ui.model.FilterOperator
												.EQ, "E0019")
										], false)*/
				],
				true
			);
			aFilters.push(oFilter);

			var oBusinessDownPromise = new Promise(function (resolve, reject) {
				oBCModel.read("/Critical_IncidentsSet/$count", {
					filters: [new sap.ui.model.Filter(aFilters, true)],
					success: function (data) {
						resolve({
							CustomerId: sCustomerId,
							BusinessDown: data
						});
					},
					error: function (err) {
						reject(err);
					}
				});
			});

			oBusinessDownPromise.then(function (oData) {
				if (oData.BusinessDown) {
					var aCustomers = this.getCardProperty("/customers");
					var iIndex = this._findObjIndex(aCustomers, oData.CustomerId);

					if (typeof (iIndex) === "number" && iIndex >= 0) {
						var oObj = {
							"Type": "Business Down",
							"Amount": oData.BusinessDown
						};

						aCustomers[iIndex].chart.push(oObj);
						this.setCardProperty("/customers", aCustomers);
						this.getCardModel().refresh(true);
					}
				}
			}.bind(this)).catch(function (err) {

			});

			return oBusinessDownPromise;
		},

		_getAmountCriticalCases: function (sCustomerId, sCustomerBpId) {
			var oAGSDashboardModel = this.getModel("agsDashboardService");

			//filter criteria
			// /CaseList?$filter=(status%20eq%20%2771%27%20or%20status%20eq%20%2780%27%20or%20status%20eq%20%2799%27)%20and%20(service_team%20eq%20%2725159208%27)%20and%20(case_type%20eq%20%27ZS02%27)%20and%20(customer_bp_id%20eq%20%270001188485%27)

			// ServiceTeam 25159208
			//status 71 80 99
			//CaseType ZS02
			//customer_bp_id  

			var oFilter = new Filter({
				filters: [
					new Filter("customer_bp_id", FilterOperator.EQ, sCustomerBpId),
					new Filter("service_team", FilterOperator.EQ, "25159208"),
					new Filter("case_type", FilterOperator.EQ, "ZS02"),
					new Filter({
						filters: [new Filter("status", FilterOperator.EQ, "71"), new Filter("status", FilterOperator.EQ, "80"), new Filter("status",
							FilterOperator.EQ, "99")],
						and: false
					})
				],
				and: true
			});

			//ZS AGS Dashboard SRV --> Service Team CaseType CustomerR3No
			var oCriticalCasesPromise = new Promise(function (resolve, reject) {
				oAGSDashboardModel.read("/CaseList/$count", {
					filters: [oFilter],
					success: function (data) {
						resolve({
							CustomerId: sCustomerId,
							CriticalCases: data
						});
					},
					error: function (err) {
						reject(err);
					}
				});
			});

			oCriticalCasesPromise.then(function (oData) {
				if (oData.CriticalCases) {
					var aCustomers = this.getCardProperty("/customers");
					var iIndex = this._findObjIndex(aCustomers, oData.CustomerId);

					if (typeof (iIndex) === "number" && iIndex >= 0) {
						var oObj = {
							"Type": "Critical Cases",
							"Amount": oData.CriticalCases
						};

						aCustomers[iIndex].chart.push(oObj);
						this.setCardProperty("/customers", aCustomers);
						this.getCardModel().refresh(true);
					}
				}
			}.bind(this)).catch(function () {

			});

			return oCriticalCasesPromise;
		},

		_findObjIndex: function (aArray, sCustomerId) {
			var iIndex;
			for (var i = 0; i < aArray.length; i++) {
				if (aArray[i].ErpCustNo === sCustomerId) {
					iIndex = i;
					break;
				}
			}
			return iIndex;
		},

		onTitlePressed: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCustomerId = this.getCardProperty(sBindingContextPath).ErpCustNo;

			this.navToApp(
				this.getResourceBundle().getText("mccOneDashboardTest", [sCustomerId]),
				this.getResourceBundle().getText("mccOneDashboardProd", [sCustomerId]), {}, false);
		},

		openVeryHighMessage: function (oEvent) {
			var sBindingContextPath = oEvent.getSource().getBindingContext("cardModel").getPath();
			var sCssObjectID = this.getCardProperty(sBindingContextPath).CssObjectID;

			this.navToApp(
				this.getResourceBundle().getText("veryHighMessagesBCT", [sCssObjectID]),
				this.getResourceBundle().getText("veryHighMessagesBCP", [sCssObjectID]), {}, false);
		}
	});
});