sap.ui.define([
	'jquery.sap.global',
	"com/sap/mcc/workplace/CardComponent/BaseCardController",
	'sap/ui/model/json/JSONModel',
	'sap/viz/ui5/data/FlattenedDataset',
	'sap/viz/ui5/controls/common/feeds/FeedItem',
	'sap/viz/ui5/format/ChartFormatter',
	'sap/viz/ui5/api/env/Format',
	'sap/m/Dialog',
	'sap/m/Button',
	'sap/m/MessageToast',
	'sap/m/Text'
], function (jQuery, BaseCardController, JSONModel, FlattenedDataset, FeedItem, ChartFormatter, Format, Dialog, Button, MessageToast,
	Text) {
	"use strict";

	return BaseCardController.extend("com.sap.mcc.workplace.CardComponent.ETimeline.ETimeline", {
		_constants: {
			name: "Escalation Requests Timeline",
			chartContainerId: "idChartContainer",
			vizFrame: {
				id: "idVizFrame",
				dataset: {
					dimensions: [{
						name: 'Date',
						value: "{view1>Date}",
						dataType: 'date'
					}],
					measures: [{
						name: "Escalation Requests",
						value: "{view1>Global Escalations}"
					}],
					data: {
						path: "view1>/Data"
					}
				},
				type: "timeseries_line",
				feedItems: [{
					"uid": "valueAxis",
					"type": "Measure",
					"values": ["Escalation Requests"]
				}, {
					"uid": "timeAxis",
					"type": "Dimension",
					"values": ["Date"]
				}],
				vizProperties: {
					plotArea: {
						window: {
							start: "firstDataPoint",
							end: "lastDataPoint"
						},
						dataLabel: {
							formatString: ChartFormatter.DefaultPattern.SHORTFLOAT_MFD2,
							visible: false
						}
					},
					valueAxis: {
						visible: true,
						label: {
							formatString: ChartFormatter.DefaultPattern.SHORTFLOAT
						},
						title: {
							visible: false
						}
					},
					timeAxis: {
						title: {
							visible: false
						},
						interval: {
							unit: ''
						}
					},
					title: {
						text: "Escalation Requests Timeline",
						visible: true
					},
					interaction: {
						syncValueAxis: false
					}
				}
			}
		},

		oVizFrame: null,
		chartTypeSelect: null,
		chart: null,
		onInit: function () {
			/* BEGIN: CARD INITIALIZATION */
			// add custom control to header
			this.setCardProperty("/customHeader/action/right", []);
			this.setCardProperty("/customHeader/action/left", []);
			this.setCardProperty("/customHeader/additionalCardTitle", []);
			// Initialize view and CardHeader
			BaseCardController.prototype.onInit.apply(this, arguments);
			/* END: CARD INITIALIZATION */

			/* CARD SPECIFIC IMPLEMENTATION STARTS BELLOW */
			sap.ui.getCore().getEventBus().subscribe("FilterBar", "search", this.onUpdateCard, this);

		},

		/**
		 * onUpdateCard is triggered for refreshing the data.
		 * IMPORTANT: the onUpdateCard method name cannot be modified
		 */
		onUpdateCard: function () { // IMPORTANT: the onUpdateCard method name cannot be modified
			this.setCardUpdateStartState();
			this.setCardProperty("/customHeader/additionalCardTitle", ""); // reset the additional Card Title e.g. total count

			var oCurrentDate = new Date();
			var oFirstDayOfTheYear = new Date(new Date().getFullYear(), 0, 1);
			this.populateView(oFirstDayOfTheYear, oCurrentDate);
		},

		_destroyVizFrame: function () {
			var vizFrame = this.oVizFrame = this.getView().byId(this._constants.vizFrame.id);
			vizFrame.destroyFeeds();
			vizFrame.destroyDataset();
		},

		_updateVizFrame: function (oData) {
			var vizFrame = this.oVizFrame = this.getView().byId(this._constants.vizFrame.id);
			var oVizFrame = this._constants.vizFrame;
			var oDataset = new FlattenedDataset(this._constants.vizFrame.dataset);
			var oModel = new JSONModel(oData);
			vizFrame.setDataset(oDataset);
			vizFrame.setModel(oModel, "view1");
			this._addFeedItems(vizFrame, oVizFrame.feedItems);
			vizFrame.setVizType(oVizFrame.type);
			vizFrame.setVizProperties(oVizFrame.vizProperties);
		},

		// Adds the passed feed items to the passed Viz Frame.
		// @param {sap.viz.ui5.controls.VizFrame} vizFrame Viz Frame to add feed items to
		// @param {Object[]} feedItems Feed items to add
		_addFeedItems: function (vizFrame, feedItems) {
			for (var i = 0; i < feedItems.length; i++) {
				vizFrame.addFeed(new FeedItem(feedItems[i]));
			}
		},

		
		getChartData: function () {
			var that = this;
			var cy = new Date();
			var dc = new Date(new Date().getFullYear(), 0, 1);
			var lastDay = new Date(cy.getFullYear(), 11, 31);
			Format.numericFormatter(ChartFormatter.getInstance());
			var oFilter = [];
			var filter5 = new sap.ui.model.Filter("activity_create_date", sap.ui.model.FilterOperator.BT,
				that.createDate(that.printDate(dc)), new Date());
			var f5 = new sap.ui.model.Filter("activity_process_type", sap.ui.model.FilterOperator.EQ, 'ZS31');
			var f6 = new sap.ui.model.Filter("activity_service_team", sap.ui.model.FilterOperator.EQ, '0003584574');
			var countT;
			var all = new sap.ui.model.Filter({
				filters: [filter5, f5, f6],
				and: true
			});
			oFilter.push(all);
			var model = this.getModel("agsDashboardService");
			model.read("/ActivityList", {
				filters: oFilter,
				success: function (oResult) {
					var merged = oResult.results;
					var data = {
						'Data': []
					};
					var filterT;
					var filterR;
					var temporary = [];
					var temporary1 = [];
					var currentWeek = that.getWeekNumber(new Date())[1];
					for (var i = 0; i < currentWeek; i++) {
						countT = 0;
						filterT = merged;
						filterR = filterT.filter(function (item) {
							var dt = new Date();
							var date = new Date(dt.getFullYear(), 0, i * 7);
							var date2 = new Date(dt.getFullYear(), 0, (i + 1) * 7);
							var cond1 = (item.activity_create_date) >= date;
							var cond2 = (item.activity_create_date) < date2;
							return cond1 && cond2;
						});
						countT = filterR.length;
						filterR = [];
						var dt = new Date();
						var date = new Date(dt.getFullYear(), 0, i * 7);
						data['Data'].push({
							"Global Escalations": countT,
							"Date": date
						});
					}
					that._updateVizFrame(data);
				}
			});
		},
		
		populateView: function (date1, date2) {
			var regionFilter;
			var finalRegion = this.getCoreModel("workplaceModel").getProperty("/selectedProfileInstance/FilterValues/Region");

			if (finalRegion === "EMEA" || finalRegion === "APJ" || finalRegion === "NA" || finalRegion === "LA") {
				var region;
				switch (finalRegion) {
				case "EMEA":
					region = "0003584574";
					break;
				case "APJ":
					region = "0003612380";
					break;
				case "NA":
					region = "0003612382";
					break;
				case "LA":
					region = "0009804549";
					break;
				}
				regionFilter = new sap.ui.model.Filter("activity_service_team", sap.ui.model.FilterOperator.EQ, region);
			}
			var that = this;
			var cy = new Date();
			var dc = new Date(new Date().getFullYear(), 0, 1);
			var lastDay = new Date(cy.getFullYear(), 11, 31);
			Format.numericFormatter(ChartFormatter.getInstance());
			// set explored app's demo model on this sample
			var oModel = new JSONModel(this.settingsModel);
			oModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
			this.getView().setModel(oModel, "view");
			var oFilter = [];
			var filter5 = new sap.ui.model.Filter("activity_create_date", sap.ui.model.FilterOperator.BT,
				date1, date2);
			var f5 = new sap.ui.model.Filter("activity_process_type", sap.ui.model.FilterOperator.EQ, 'ZS31');
			var countT;
			var all = new sap.ui.model.Filter({
				filters: [filter5, f5],
				and: true
			});
			oFilter.push(all);
			if (regionFilter) {
				oFilter.push(regionFilter);
			}
			var model = this.getModel("agsDashboardService");
			model.read("/ActivityList", {
				filters: oFilter,
				success: function (oResult) {
					var merged = oResult.results;
					var data = {
						'Data': []
					};
					var filterT;
					var filterR;
					var temporary = [];
					var temporary1 = [];
					var currentWeek = that.getWeekNumber(new Date())[1];
					var startWeek = that.getWeekNumber(date1)[1];
					if (date1.getFullYear() != date2.getFullYear()) {
						var diff = date2.getFullYear() - date1.getFullYear();
						for (var i = startWeek; i <= 52; i++) {
							countT = 0;
							filterT = merged;
							filterR = filterT.filter(function (item) {
								var dt = new Date();
								var date = new Date(date1.getFullYear(), 0, i * 7);
								var tdate2 = new Date(date1.getFullYear(), 0, (i + 1) * 7);
								var cond1 = (item.activity_create_date) >= date;
								var cond2 = (item.activity_create_date) < tdate2;
								return cond1 && cond2;
							});
							countT = filterR.length;
							filterR = [];
							var dt = new Date();
							var date = new Date(date1.getFullYear(), 0, i * 7);
							data['Data'].push({
								"Global Escalations": countT,
								"Date": date
							});
						}
						if (diff > 1) {
							for (var k = 1; k < diff; k++) {
								var dDate = new Date(date1.getFullYear() + k, 0, 1);
								var endDate1 = new Date(date1.getFullYear() + k + 1, 0, 0);
								var dWeek = that.getWeekNumber(dDate)[1];
								for (i = dWeek; i <= 52; i++) {
									countT = 0;
									filterT = merged;
									filterR = filterT.filter(function (item) {
										var dt = new Date();
										var date = new Date(dDate.getFullYear(), 0, i * 7);
										var tdate2 = new Date(dDate.getFullYear(), 0, (i + 1) * 7);
										var cond1 = (item.activity_create_date) >= date;
										var cond2 = (item.activity_create_date) < tdate2;
										return cond1 && cond2;
									});
									countT = filterR.length;
									filterR = [];
									var dt = new Date();
									date = new Date(dDate.getFullYear(), 0, i * 7);
									data['Data'].push({
										"Global Escalations": countT,
										"Date": date
									});
								}
							}
						}
						for (i = 0; i < that.getWeekNumber(date2)[1]; i++) {
							countT = 0;
							filterT = merged;
							filterR = filterT.filter(function (item) {
								var dt = new Date();
								var date = new Date(date2.getFullYear(), 0, i * 7);
								var tdate2 = new Date(date2.getFullYear(), 0, (i + 1) * 7);
								var cond1 = (item.activity_create_date) >= date;
								var cond2 = (item.activity_create_date) < tdate2;
								return cond1 && cond2;
							});
							countT = filterR.length;
							filterR = [];
							var dt = new Date();
							date = new Date(date2.getFullYear(), 0, i * 7);
							data['Data'].push({
								"Global Escalations": countT,
								"Date": date
							});
						}
					} else {
						for (i = that.getWeekNumber(date1)[1]; i < that.getWeekNumber(date2)[1]; i++) {
							countT = 0;
							filterT = merged;
							filterR = filterT.filter(function (item) {
								var dt = new Date();
								var date = new Date(date1.getFullYear(), 0, i * 7);
								var tdate2 = new Date(date1.getFullYear(), 0, (i + 1) * 7);
								var cond1 = (item.activity_create_date) >= date;
								var cond2 = (item.activity_create_date) < tdate2;
								return cond1 && cond2;
							});
							countT = filterR.length;
							filterR = [];
							var dt = new Date();
							date = new Date(date2.getFullYear(), 0, i * 7);
							data['Data'].push({
								"Global Escalations": countT,
								"Date": date
							});
						}
					}
					that._destroyVizFrame();
					that._updateVizFrame(data);
					this.setCardSuccessState();
				}.bind(this),
				error: function (oError) {
					this.setCardErrorState();
				}.bind(this)
			});
		},

		getWeekNumber: function (d) {
			// Copy date so don't modify original
			d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
			// Set to nearest Thursday: current date + 4 - current day number
			// Make Sunday's day number 7
			d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
			// Get first day of year
			var yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
			// Calculate full weeks to nearest Thursday
			var weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
			// Return array of year and week number
			return [d.getUTCFullYear(), weekNo];
			//return weekNo;
		},

		getPreviousMonday: function () {
			var date = new Date();
			var day = date.getDay();
			var prevMonday;
			if (date.getDay() == 0) {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate() - 6);
			} else {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate() - day - 6);
			}
			return prevMonday;
		},

		getThisMonday: function () {
			var date = new Date();
			var day = date.getDay();
			var prevMonday;
			if (date.getDay() == 0) {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate());
			} else {
				prevMonday = new Date();
				prevMonday.setDate(date.getDate() - day + 1);
			}
			return prevMonday;
		},

		padStr: function (i) {
			return (i < 10) ? "0" + i : "" + i;
		},

		printDate: function (temp) {
			var temp1 = new Date(temp);
			var dateStr = this.padStr(temp.getFullYear()) +
				this.padStr(1 + temp.getMonth()) +
				this.padStr(temp.getDate()) +
				this.padStr(temp.getHours()) +
				this.padStr(temp.getMinutes()) +
				this.padStr(temp.getSeconds());
			return (dateStr);
		},

		getDateOfWeek: function (w, y) {
			var date = new Date();
			var tdate = new Date(date.getFullYear(), 0, 1);
			var day = tdate.getDay();
			var d;
			switch (day) {
			case 0:
				d = (-5 + (w - 1) * 7);
				break;
			case 1:
				d = (1 + (w - 1) * 7);
				break;
			case 2:
				d = (0 + (w - 1) * 7);
				break;
			case 3:
				d = (-1 + (w - 1) * 7);
				break;
			case 4:
				d = (-2 + (w - 1) * 7);
				break;
			case 5:
				d = (-3 + (w - 1) * 7);
				break;
			case 6:
				d = (-4 + (w - 1) * 7);
				break;
			}
			// 1st of January + 7 days for each week
			return new Date(y, 0, d);
		},

		createDate: function (temp) {
			var year = temp.substring(0, 4);
			var month = temp.substring(4, 6);
			var day = temp.substring(6, 8);
			var hour = temp.substring(8, 10);
			var minute = temp.substring(10, 12);
			var seconds = temp.substring(12, 14);
			return new Date(year, month - 1, day, hour, minute, seconds);
		},

		getDay: function () {
			var now = new Date();
			var start = new Date(now.getFullYear(), 0, 0);
			var diff = now - start;
			var oneDay = 1000 * 60 * 60 * 24;
			var day = Math.floor(diff / oneDay);
			return day;
		},

		onAfterRendering: function () {
			this.chartTypeSelect = this.getView().byId('chartTypeSelect');
		}
	});
});