sap.ui.define([], function () {
	"use strict";

	return {
		breaklineFormatter: function (aValues) {
			if (aValues) {
				return aValues.join("\n");
			} else {
				return;
			}
		}
	};
});