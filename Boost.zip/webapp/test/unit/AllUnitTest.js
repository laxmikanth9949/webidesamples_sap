sap.ui.define([
	"sap/support/boost/test/unit/model/formatter",
	"sap/support/boost/test/unit/page/mainPage.controller",
	"sap/support/boost/test/unit/page/App.controller"
], function() {
	"use strict";
});