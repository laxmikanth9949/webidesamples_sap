function initModel() {
	var sUrl = "/NorthWind/V2/(S(nxqh3wdn51y2bvmgdyn4mys4))/OData/OData.svc/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}