sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"../model/formatter",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/HBox",
	"sap/m/VBox",
	"sap/m/Text",
	"sap/ui/core/format/NumberFormat",
	"sap/ui/core/format/DateFormat",
	"sap/m/MessageBox",
	"sap/m/Popover",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV"
], function (Controller, Filter, FilterOperator, formatter, Dialog, Button, HBox, VBox, Text, NumberFormat, DateFormat, MessageBox,
	Popover, Export, ExportTypeCSV) {
	"use strict";

	return Controller.extend("ZCrudOperation.ZCrudOperation.controller.View1", {
		formatter: formatter,
		onInit: function () {
			debugger;
			var oModel = this.getOwnerComponent().getModel();
			this.oDataModel = this.getOwnerComponent().getModel("ReadWriteModel");
			this.getView().byId("id_Table2").setModel(this.oDataModel);
			//	this.getView().byId("Table_Id").setModel(oModel);
			//sap.ui.core.BusyIndicator.show(2);
			//	this.getView().byId("Table_Id").setProperty("busy",true);
			oModel.read("/Employees", {
				success: function (req, res) {

					var oJson = new sap.ui.model.json.JSONModel();
					oJson.setSizeLimit(req.results.length);
					oJson.setData(req);
					this.getView().byId("Table_Id").setModel(oJson);
					this.getView().byId("idSearch").setModel(oJson);
					this.getView().byId("CountItems").setText("Total Items : " + req.results.length);
					//sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function (oError) {

				}
			});
		},
		onLiveChange: function (oEvent) {
			var sValue = oEvent.getSource().getValue();
			var aArray = [];
			var oTable = this.getView().byId("Table_Id");
			var oBindings = oTable.getBinding("items");
			if (sValue && sValue.length > 3) {
				// multiple columns we search
				var oFilter = new Filter([new sap.ui.model.Filter("FirstName", sap.ui.model.FilterOperator.Contains, sValue),
					new sap.ui.model.Filter("LastName", sap.ui.model.FilterOperator.Contains, sValue),
					new sap.ui.model.Filter("Title", sap.ui.model.FilterOperator.Contains, sValue),
					new sap.ui.model.Filter("City", sap.ui.model.FilterOperator.Contains, sValue),
					new sap.ui.model.Filter("Country", sap.ui.model.FilterOperator.Contains, sValue),
					new sap.ui.model.Filter("Region", sap.ui.model.FilterOperator.Contains, sValue)
				]);
				aArray.push(oFilter);
				// only one column we search // hided this
				/*	aArray.push(new sap.ui.model.Filter("FirstName", sap.ui.model.FilterOperator.Contains, sValue));*/
			}
			// only one column we search and apply filters to table
			oBindings.filter(aArray);
		},
		onUpdateFinished: function (oEvent) {
			this.getView().byId('CountItems').setText("Total Items: " + this.getView().byId('Table_Id').getBinding('items').getLength());
		},
		onSuggest: function (oEvent) {
			debugger;
			var value = oEvent.getParameter("suggestValue");
			var oTable = this.getView().byId("Table_Id");
			var filters = [];
			if (value) {
				filters = [
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("FirstName", function (sText) {
							return (sText || "").toUpperCase().indexOf(value.toUpperCase()) > -1;
						})
					], false)
				];
			}
			this.getView().byId("idSearch").getBinding("suggestionItems").filter(filters);
			this.getView().byId("idSearch").suggest();
			oTable.getBinding("items").filter(filters);
		},
		onSearchSuggest: function (oEvent) {
			var value = oEvent.getSource().getValue();
			var oTable = this.getView().byId("Table_Id");
			var filters = [];
			if (value) {
				filters = [
					new sap.ui.model.Filter([
						new sap.ui.model.Filter("FirstName", function (sText) {
							return (sText || "").toUpperCase().indexOf(value.toUpperCase()) > -1;
						})
					], false)
				];
			}
			this.getView().byId("idSearch").getBinding("suggestionItems").filter(filters);
			this.getView().byId("idSearch").suggest();
			oTable.getBinding("items").filter(filters);
		},
		itemPress: function (oEvent) {
			//var oModelData = this.getOwnerComponent().getModel();
			var oBindingObject = oEvent.getSource().getBindingContext().getObject();
			if (!this.oDialog) {
				this.oDialog = new sap.m.Dialog({
					title: "Selected-Data",
					id: "idDialog",
					draggable: true,
					resizable: true,
					content: [
						new sap.m.HBox({
							justifyContent: "SpaceBetween",
							items: [
								new sap.m.Label({
									text: "EmployeeId",
									design: "Bold"
								}),
								new sap.m.Text({
									text: "{EmployeeID}",
									textAlign: "Begin"
								})
							]
						}),
						new sap.m.HBox({
							justifyContent: "SpaceBetween",
							items: [
								new sap.m.Label({
									text: "FullName",
									design: "Bold"
								}),
								new sap.m.Text({
									text: "{TitleOfCourtesy} {LastName} {FirstName}",
									textAlign: "Begin"
								})
							]
						}),
						new sap.m.HBox({
							justifyContent: "SpaceBetween",
							items: [
								new sap.m.Label({
									text: "Title",
									design: "Bold"
								}),
								new sap.m.Text({
									text: "{Title}",
									textAlign: "Begin"
								})
							]
						}),
						new sap.m.HBox({
							justifyContent: "SpaceBetween",
							items: [
								new sap.m.Label({
									text: "DOB",
									design: "Bold"
								}),
								new sap.m.Text({
									text: {
										path: "BirthDate",
										formatter: formatter.formatDate
									},
									textAlign: "Begin"
								})
							]
						}),
						new sap.m.HBox({
							justifyContent: "SpaceBetween",
							items: [
								new sap.m.Label({
									text: "HireDate",
									design: "Bold"
								}),
								new sap.m.Text({
									text: {
										path: "HireDate",
										formatter: formatter.formatDate
									},
									textAlign: "Begin"
								})
							]
						}),
						new sap.m.HBox({
							justifyContent: "SpaceBetween",
							items: [
								new sap.m.Label({
									text: "City",
									design: "Bold"
								}),
								new sap.m.Text({
									text: "{City}",
									textAlign: "Begin"
								})
							]
						})
					],
					beginButton: new Button({
						text: "OK",
						press: function (oEve) {
							oEve.getSource().getParent().close();
						}
					}),
					endButton: new Button({
						text: "Close",
						press: function (oEve) {
							oEve.getSource().getParent().close();
						}
					})
				});
				this.getView().addDependent(this.oDialog);
			}
			this.oDialog.bindElement("/");
			var oJson = new sap.ui.model.json.JSONModel();
			oJson.setData(oBindingObject);
			sap.ui.getCore().byId("idDialog").setModel(oJson);
			this.oDialog.open();
		},
		handleCurrency: function (oEvent) {
			var oValue = oEvent.getSource().getValue().replace(/[. ,]/g, '');
			if (oValue > 0) {
				var oCurrency = new Intl.NumberFormat(navigator.language);
				var oFormatValue = oCurrency.format(oValue);
				this.getView().byId("price").setValue(oFormatValue);
				sap.ui.getCore().byId("priceDialog").setValue(oFormatValue);
			}
		},
		onSubmitData: function (oEvent) {
			debugger;
			var oBj = {};
			oBj.ID = Number(this.getView().byId("productId").getValue());
			oBj.Name = this.getView().byId("productName").getValue();
			oBj.ReleaseDate = this.getView().byId("date").getValue();
			oBj.DiscontinuedDate = this.getView().byId("Ddate").getValue();
			oBj.Rating = Number(this.getView().byId("rating").getValue());
			oBj.Description = this.getView().byId("descriptionId").getValue();
			oBj.Price = this.getView().byId("price").getValue();
			var that = this;
			this.oDataModel.create("/Products", oBj, {
				success: function (data) {
					sap.m.MessageBox.success("Successfully Added");
					that.onClearData();
				},
				error: function (oError) {
					sap.m.MessageBox.error(oError.responseText);
				}
			});
		},
		onReleaseDateChange: function (oEvent) {
			var oReleaseDate = this.getView().byId("date").getDateValue();
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd\'T\'HH:mm:ss"
			});
			if(oReleaseDate){
			var oFormatedReleaseDate = oDateFormat.format(oReleaseDate);
			this.getView().byId("date").setValue(oFormatedReleaseDate);
			}else{
				var oDialogDate = sap.ui.getCore().byId("dateDialog").getDateValue();
			var oDialogFortedRleaseDate = oDateFormat.format(oDialogDate);
			sap.ui.getCore().byId("dateDialog").setValue(oDialogFortedRleaseDate);
			}
		},
		onDiscontinueDateChange: function (oEvent) {
			var oDiscontinueDate = this.getView().byId("Ddate").getDateValue();
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd\'T\'HH:mm:ss"
			});
			if(oDiscontinueDate){
			var oformattedDiscontinueDate = oDateFormat.format(oDiscontinueDate);
			this.getView().byId("Ddate").setValue(oformattedDiscontinueDate);
			}else{
			var oDialogDisDate = sap.ui.getCore().byId("DdateDialog").getDateValue();
			var oformatedDialogDate = oDateFormat.format(oDialogDisDate);
			sap.ui.getCore().byId("DdateDialog").setValue(oformatedDialogDate);
			}
		},
		onClearData: function (oEvent) {
			this.getView().byId("productId").setValue("");
			this.getView().byId("productName").setValue("");
			this.getView().byId("date").setValue("");
			this.getView().byId("Ddate").setValue("");
			this.getView().byId("rating").setValue(0);
			this.getView().byId("descriptionId").setValue("");
			this.getView().byId("price").setValue("");
		},
		rangeIndicatorLivechange: function (oEvent) {
			debugger;
			var oValue = oEvent.getParameters("value");
			if (oValue === 1) {

			} else if (oValue === 2) {

			} else if (oValue === 3) {

			} else if (oValue === 4) {

			} else if (oValue === 5) {

			}
		},
		onItemEdit: function (oEvent) {
			debugger;
			this.oselectedObject = oEvent.getSource().getBindingContext().getObject();
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy-MM-dd\'T\'HH:mm:ss"
			});
			this.oselectedObject.ReleaseDate = oDateFormat.format(this.oselectedObject.ReleaseDate);
			this.oselectedObject.DiscontinuedDate = oDateFormat.format(this.oselectedObject.DiscontinuedDate);
			if (!this.EditDialog) {
				this.EditDialog = sap.ui.xmlfragment("ZCrudOperation.ZCrudOperation/model/EditDataDialog", this);
			}
			var oJson = new sap.ui.model.json.JSONModel();
			oJson.setData(this.oselectedObject);
			sap.ui.getCore().byId("editDataId").bindElement("/");
			sap.ui.getCore().byId("editDataId").setModel(oJson);
			this.EditDialog.open();
		},
		HandleproductId: function (oEvent) {
			debugger;
			var oModelData = this.oDataModel.oData;
			var oValue = oEvent.getSource().getValue().trim();
			var oExistingId = this.getView().byId("id_Table2").getItems();
			for (var i = 0; i < oExistingId.length; i++) {
				var oId = oExistingId[i].getCells()[0].getText();
				if (oId === oValue) {
					this.getView().byId("productId").setValueState("Error");
					this.getView().byId("productId").setValueStateText("ID is Already Existing");
					return;
				} else {
					this.getView().byId("productId").setValueState("Success");
					this.getView().byId("productId").setValueStateText("ID is Available");
				}
			}
		},
		onItemDelete: function (oEvent) {
			debugger;
			var path = oEvent.getSource().getBindingContext().getPath();
			var oSelectedIndex = path.split("/")[1];
			this.oDataModel.oData;

			var m = oEvent.getSource().getParent();

			var tbl = this.getView().byId("id_Table2");

			var idx = m.getBindingContext().getPath();

			this.oDataModel.remove("/Products" + "(" + (oEvent.getSource().getBindingContext().getObject.ID) + ")", {
				success: function () {
					alert("Success")
				},
				error: function () {
					alert("Error")
				}
			})
		},
		onDialogCancel: function (oEvent) {
			this.EditDialog.close();
		},
		onSubmitDialogData: function (oEvent) {
			debugger;
			var oBj = {};
			oBj.ID = Number(sap.ui.getCore().byId("productIdDialog").getValue());
			oBj.Name = sap.ui.getCore().byId("productNameDialog").getValue();
			oBj.ReleaseDate = sap.ui.getCore().byId("dateDialog").getValue();
			oBj.DiscontinuedDate = sap.ui.getCore().byId("DdateDialog").getValue();
			oBj.Rating = Number(sap.ui.getCore().byId("ratingDialog").getValue());
			oBj.Description = sap.ui.getCore().byId("descriptionIdDialog").getValue();
			oBj.Price = sap.ui.getCore().byId("priceDialog").getValue();
			var that = this;
			this.oDataModel.update("/Products" + "(" + (this.oselectedObject.ID) + ")", oBj, {
				success: function () {
					var msg = "Values Updated Successfully";
					sap.m.MessageBox.show(msg);
					that.EditDialog.close();
				},
				error: function () {
					sap.m.MessageBox.show("Values not saved");
				}
			});
		},
		onLogOut: function(oEve){
			debugger;
			sap.m.MessageBox.confirm("Are you sure you want to LogOut? \n\n if Yes clisk OK!!!",{
				actions:[MessageBox.Action.OK,MessageBox.Action.CANCEL],
				onClose:function(oAction){
					if(oAction === "OK"){
						window.location.reload(window.location.href);
					}
				}
			});
		//	window.location.reload(window.location.href);
		},
		downloadData: sap.m.Table.prototype.exportData ||function(oEvent){
			debugger;
			var oUplaodCollection = this.getView().byId("Table_Id");
			var oModel = oUplaodCollection.getModel();
			
				var oExport = new Export({

				exportType: new ExportTypeCSV({
					fileExtension: "csv",
					separatorChar: ";"
				}),

				models: oModel,

				rows: {
					path: "/results"
				},
				columns: [{
					name: "Employee ID",
					template: {
						content: "{EmployeeID}"
					}
				}, {
					name: "Full Name",
					template: {
						content: "{TitleOfCourtesy} {LastName} {FirstName}"
					}
				}, {
					name: "Job Title",
					template: {
						content: "{Title}"
					}
				}, {
					name: "Date Of BirthDate",
					template: {
						content: "{BirthDate}"
					}
				}, {
					name: "Hire Date",
					template: {
						content: "{HireDate}"
					}
				},{
					name: "City",
					template: {
						content: "{City}"
					}
				},{
					name: "Region",
					template: {
						content: "{Region}"
					}
				},{
					name: "Country",
					template: {
						content: "{Country}"
					}
				},{
					name: "Address",
					template: {
						content: "{Address}"
					}
				}]
			});
			console.log(oExport);
			oExport.saveFile().catch(function(oError) {

			}).then(function() {
				oExport.destroy();
			});
		}
	});
});