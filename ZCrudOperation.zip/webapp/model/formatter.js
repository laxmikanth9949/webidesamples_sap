sap.ui.define([
		"sap/ui/core/format/NumberFormat",
		"sap/ui/core/format/DateFormat",
		"../model/formatter"
	],
	function (NumberFormat, DateFormat, formatter) {
		"use strict";
		return {
			formatDate: function (date) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
					format: "yMMMd"
						//	pattern: "EEE, MMM d, yyyy"
				});
				return oDateFormat.format(date);
			},
			Uppercase: function (sValue) {

				return sValue.toLocaleUpperCase();

			},
			RegionisEmpty: function (NoCountry) {
				if (!NoCountry) {
					return "-----";
				} else {
					return NoCountry;
				}
			},
			highlightRow: function (sColorValue) {
				return sColorValue ? "Success" : "Error";
				if(sColorValue === "USA"){
					return "Success";
				}else if(sColorValue === "UK"){
					return "Error";
				}
			},
			ReleasediscontinueDates: function (sDateValue) {
				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd\'T\'HH:mm:ss"
				});
				oDateFormat.format(sDateValue);
			}

		};
	});