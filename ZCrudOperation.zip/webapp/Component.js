sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"ZCrudOperation/ZCrudOperation/model/models",
	"sap/m/MessageBox"
], function (UIComponent, Device, models, MessageBox) {
	"use strict";

	return UIComponent.extend("ZCrudOperation.ZCrudOperation.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			this.userLoginDialog();
			debugger;
		//	this.oLoginPage.open();

			// enable routing
			//	this.getRouter().initialize();

					// set the device model
			//	this.setModel(models.createDeviceModel(), "device");
			//	this.userLoginDialog();
		},
		userLoginDialog: function (oEvent) {
			var that = this;
			this.oLoginPage = new sap.m.Dialog({
				title: "User LogIn",
				titleAlignment: "Center",
				id: "IdLogin",
				draggable: false,
				contentHeight: "35%",
				contentWidth: "30%",
				content: [
					new sap.ui.layout.form.SimpleForm({
						editable: true,
						title: "",
						class: "sapUiSizeCompact",
						content: [
							new sap.m.Label({
								text: "UserName",
								design: "Bold"
							}),
							new sap.m.Input({
								value: "",
								id: "idUsername",
								valueState: "None",
								placeholder: "Enter User Name"
							}),
							new sap.m.Label({
								text: "Password",
								design: "Bold"
							}),
							new sap.m.Input({
								value: "",
								id: "idPassword",
								type: "Password",
								valueState: "None",
								placeholder: "Enter Password"
							}),
							new sap.m.Label({
								text: "",
								design: "Bold"
							}),
							new sap.m.Link({
								text:"Forgot Password",
								target:"_blank",
								press:function(oEvent){
									window.open("https://www.sap.com");
								}
							})
						]
					}),
				],
				beginButton: new sap.m.Button({
					text: "LogIn",
					press: function (oEve) {
						debugger;
						var ouserName = oEve.getSource().getParent().getContent()[0].getContent()[1].getValue();
						var opassword = oEve.getSource().getParent().getContent()[0].getContent()[3].getValue();
						
					/*	if(ouserName === "Laxmikanth" && opassword === "Lishika@99515"){*/
							oEve.getSource().getParent().close();
							// enable routing
							this.getRouter().initialize();

							// set the device model
							this.setModel(models.createDeviceModel(), "device");
							sap.m.MessageToast.show("You logged Successfully");
					/*	}else{
						//	 MessageBox.error("Invalid UserName and Password \n Try to login with valid credentials");
							oEve.getSource().getParent().getContent()[0].getContent()[1].setValueState("Error");
							oEve.getSource().getParent().getContent()[0].getContent()[3].setValueState("Error");
							oEve.getSource().getParent().getContent()[0].getContent()[1].setValue("");
							oEve.getSource().getParent().getContent()[0].getContent()[3].setValue("");
							sap.m.MessageToast.show("Invalid UserName and Password");
							 this.userLoginDialog();
						}*/
						
					}.bind(this)
				}),
				endButton: new sap.m.Button({
					text: "Cancel",
					press: function (oEve) {
						oEve.getSource().getParent().close();
						return;
					}
				}),
			});
			this.oLoginPage.addStyleClass("sapUiSizeCompact");
			this.oLoginPage.open();
		}
	});
});