sap.ui.define([
	"ZCrudOperation/ZCrudOperation/test/unit/controller/View1.controller"
], function () {
	"use strict";
});