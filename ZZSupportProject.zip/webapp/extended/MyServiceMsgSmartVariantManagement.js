jQuery.sap.declare("com.ZSupportProject.ZZSupportProject.extended.MyServiceMsgSmartVariantManagement");
jQuery.sap.require("sap.ui.comp.smartvariants.SmartVariantManagement");
jQuery.sap.require("sap.ui.comp.variants.VariantManagement");
jQuery.sap.require("sap.m.CheckBox");
jQuery.sap.require("sap.ui.layout.GridData");
jQuery.sap.require("sap.m.Column");
jQuery.sap.require("sap.m.Text");
jQuery.sap.require("sap.ui.core.TextAlign");
jQuery.sap.require("sap.m.PopinDisplay");


sap.ui.comp.smartvariants.SmartVariantManagement.extend("com.ZSupportProject.ZZSupportProject.extended.MyServiceMsgSmartVariantManagement", {

	metadata: {
		library: "com.ZSupportProject.ZZSupportProject.extended",
		properties: {
			showNotification: {
				type: "boolean",
				defaultValue: true
			},
			notificationLabel: {
				type: "string",
				defaultValue: "Notification"
			},
			enableManageSaveAsButton: {
				type: "boolean",
				defaultValue: true
			}
		}
	},

	renderer: function(oRm, oControl) {
		sap.ui.comp.variants.VariantManagement.getMetadata().getRenderer().render(oRm, oControl);
	},

	init: function() {
		// execute standard control method
		sap.ui.comp.smartvariants.SmartVariantManagement.prototype.init.apply(this, arguments);

		this.oNotificationSelect = new sap.m.CheckBox(this.getId() + "-notification", {
			text: this.getNotificationLabel(),
			enabled: true,
			visible: this.getShowNotification(),
			width: "100%"
		});
		
		this.aNotifVariants = [];
	},

	exit: function() {
		// execute standard control method
		sap.ui.comp.smartvariants.SmartVariantManagement.prototype.exit.apply(this, arguments);

		if (this.oNotificationSelect) {
			this.oNotificationSelect.destroy();
			this.oNotificationSelect = undefined;
		}

		this.aNotifVariants = [];
	},

	//_handleManageNotificationSelectionChanged is not called right now
	_handleManageNotificationSelectionChanged: function(oCheckBox) {
		var oManageItem = oCheckBox.getParent();

		var sNotif = "false";
		var bFound = false;

		if (oCheckBox.getSelected() === true) {
			sNotif = "true";
		}

		for (var i in this.aNotifVariants) {
			if (this.aNotifVariants[i].key === oManageItem.getKey()) {
				this.aNotifVariants[i].notif = sNotif;
				bFound = true;
				break;
			}
		}

		if (!bFound) {
			this.aNotifVariants.push({
				key: oManageItem.getKey(),
				notif: sNotif
			});
		}
		
		this._eventDone();

	},

	_initalizeSaveAsDialog: function() {

		//Data is retrieved at _handleVariantSaveAs

		// execute standard control method
		sap.ui.comp.variants.VariantManagement.prototype._initalizeSaveAsDialog.apply(this, arguments);

		if (this.getShowNotification()) {
			//Add addition control for notification
			this.oNotificationSelect.setVisible(true);
			this.oSaveDialogOptionsGrid.addContent(this.oNotificationSelect);
		}
	},

	_initalizeManagementTableColumns: function() {
		// execute standard control method
		sap.ui.comp.variants.VariantManagement.prototype._initalizeManagementTableColumns.apply(this, arguments);

		if (this.getShowNotification()) {
			if (this._bNotificationColumnAdded) {
				return;
			}
			this.oManagementTable.insertColumn(new sap.m.Column({
				header: new sap.m.Text({
					text: this.getNotificationLabel()
				}),
				width: "5rem",
				hAlign: sap.ui.core.TextAlign.Center,
				demandPopin: true,
				popinDisplay: sap.m.PopinDisplay.Inline,
				minScreenWidth: "800px"
			}), this.oManagementTable.getColumns().length - 1);

			this._bNotificationColumnAdded = true;
		}
	},

	_createVariantEntries: function(mVariants) {
		//Creates entries into the variant management control, based on the list of variants

		// execute standard control method
		sap.ui.comp.smartvariants.SmartVariantManagement.prototype._createVariantEntries.apply(this, arguments);

		var aList = this.getVariantItems();

		for (var i = 0; i < aList.length; i++) {
			var oVariant = mVariants[aList[i].getKey()];
			var sValue = "false";
			if (oVariant) {
				var oContent = oVariant.getContent();
				if (oContent && (oContent.notification !== undefined)) {
					sValue = "" + oContent.notification + "";
				}

				aList[i].addCustomData(new sap.ui.core.CustomData({
					key: "notification",
					value: sValue,
					writeToDom: true
				}));
			}
		}
	},

	_openVariantManagementDialog: function() {
		// execute standard control method
		sap.ui.comp.variants.VariantManagement.prototype._openVariantManagementDialog.apply(this, arguments);

		this.aNotifVariants = [];

		var that = this;

		// var fSelectNotify = function(oControlEvent) {
		// 	var oEvent = that._createEvent("notificationSelectionChange", that._handleManageNotificationSelectionChanged);
		// 	oEvent.args.push(this);
		// 	that._addEvent(oEvent);
		// };

		var oItems = this.oVariantList.getItems();
		for (var iH = 0; iH < oItems.length; iH++) {
			var oChB = new sap.m.CheckBox(this.oVariantManage.getId() + "-notification-" + iH, {
				selected: false,
				enabled: true//,
				//select: fSelectNotify
			});
			if (oItems[iH].getReadOnly() || oItems[iH].getLabelReadOnly()) {
				oChB.setEnabled(false);
				oChB.setSelected(false);
			}
			if (oItems[iH].getCustomData() && oItems[iH].getCustomData().length && oItems[iH].getCustomData()[0].getValue()) {
				var bNotif = false;
				var u = this.oManagementTable.getItems()[iH];
				if (oItems[iH].getCustomData()[0].getValue() === "true") {
					bNotif = true;
				}
				oChB.setSelected(bNotif);
				u.insertCell(oChB, u.getCells().length - 1);
			} else {
				u = this.oManagementTable.getItems()[iH];
				u.insertCell(oChB, u.getCells().length - 1);
			}
		}
	},

	// _handleManageSavePressed: function() {
	// 	//this is called if ok button is clicked within Manage dialog
	// 	// execute standard control method
	// 	sap.ui.comp.variants.VariantManagement.prototype._handleManageSavePressed.apply(this, arguments);

	// 	if (!this.getShowNotification()) {
	// 		return;
	// 	}

	// 	var iLen = 0;
	// 	var iDel = 0;
	// 	for (iLen = this.aRemovedVariants.length, iDel = 0; iDel < iLen; ++iDel) {
	// 		for (var i in this.aNotifVariants) {
	
	// 			if (this.aRemovedVariants[iDel] === this.aNotifVariants[i].key) {
	// 				this.aNotifVariants.splice(i, 1);
	// 				break;
	// 			}
	// 		}			
	// 	}

	// 	if (this.aNotifVariants.length > 0) {
	// 		this.fireManage({
	// 			notif: this.aNotifVariants
	// 		});
	// 	}
	// },
	
	_handleManageSavePressed : function() {
		var oNewItems = this.oManagementTable.getItems();
		var oItem;
		var fireSelect = false;
		var sName = "";
		var oOriginalItem = null;
		var iD = 0;

		for (var iG = 0; iG < oNewItems.length; iG++) {
			oItem = this.oVariantList.getItemByKey(oNewItems[iG].getKey());
		/*	if (oNewItems[iG].getCells()[0].getValue) {
				sName = oNewItems[iG].getCells()[0].getValue();
			}
			if (oNewItems[iG].getCells()[0].getTitle) {
				sName = oNewItems[iG].getCells()[0].getTitle();
			}*/
			if (oNewItems[iG].getCells()[1].getValue) {
				sName = oNewItems[iG].getCells()[1].getValue();
			}
			if (oNewItems[iG].getCells()[1].getTitle) {
				sName = oNewItems[iG].getCells()[1].getTitle();
			}
			sName = sName.trim();
			if (oItem.getText() !== sName) {
				this.aRenamedVariants.push({
					key: oItem.getKey(),
					name: sName
				});
				oOriginalItem = this.getItemByKey(oNewItems[iG].getKey());
				oOriginalItem.setText(sName);
				if (oOriginalItem.setLifecyclePackage) {
					oOriginalItem.setLifecyclePackage(oNewItems[iG].getLifecyclePackage());
					oOriginalItem.setLifecycleTransportId(oNewItems[iG].getLifecycleTransportId());
				}

				if (this.lastSelectedVariantKey === oItem.getKey()) {
					this.oVariantText.setText(sName);
					// BCP 1670301513
// this.bDirty = false;
// this.oVariantModifiedText.setVisible(false);
// this.oModel.setProperty("/enabled", false);
				}
			}

			if (this.getShowExecuteOnSelection() && oItem.getExecuteOnSelection && oItem.getExecuteOnSelection() !== oNewItems[iG].getCells()[2].getSelected()) {
				// execute on selection changed
				var bFlag = oNewItems[iG].getCells()[2].getSelected();
				var oItemTmp = this.getItemByKey(oNewItems[iG].getKey());

				if (!oItemTmp && (this.getSupportExecuteOnSelectOnSandardVariant() & (oNewItems[iG].getKey() === this.getStandardVariantKey()/* this.STANDARDVARIANTKEY */))) {
					oItemTmp = new sap.ui.comp.variants.VariantItem();
				}

				if (oItemTmp && oItemTmp.setExecuteOnSelection) {
					oItemTmp.setExecuteOnSelection(bFlag);

					if (this.getSupportExecuteOnSelectOnSandardVariant() & (oNewItems[iG].getKey() === this.getStandardVariantKey())) {
						this._executeOnSelectForStandardVariantByUser(bFlag);
					}
					this.aExeVariants.push({
						key: oItem.getKey(),
						exe: bFlag
					});
					if (oItemTmp.setLifecyclePackage) {
						oItemTmp.setLifecyclePackage(oNewItems[iG].getLifecyclePackage());
						oItemTmp.setLifecycleTransportId(oNewItems[iG].getLifecycleTransportId());
					}
				}
			}
			
			if (this.getShowNotification() && oItem.getCustomData() && oItem.getCustomData().length && oItem.getCustomData()[0].getValue() !== ""+oNewItems[iG].getCells()[oNewItems[iG].getCells().length - 2].getSelected()+"") {
				// execute on selection changed for notification
				var sNotif = "false";
				if(oNewItems[iG].getCells()[oNewItems[iG].getCells().length - 2].getSelected() === true){
					sNotif = "true";
				}

				oItemTmp = this.getItemByKey(oNewItems[iG].getKey());
				if (oItemTmp) {
					oItemTmp.removeAllCustomData();
					oItemTmp.addCustomData(new sap.ui.core.CustomData({key:"notification", value: sNotif, writeToDom: true}));
					this.aNotifVariants.push({
						key: oItem.getKey(),
						notif: sNotif
					});
				}
			}			
		}

		if (this.oManagementDialog) {
			this.oManagementDialog.close();
		}
		   
		//this._manageButtonState();
		
		if (this.bVariantItemMode === false) {
			if (this.getDefaultVariantKey() !== this.sNewDefaultKey) {
				var oItemTmpDef = null;
				if (this.sNewDefaultKey === this.getStandardVariantKey()) {
					oItemTmpDef = this.getItemByKey(this.getDefaultVariantKey());
					this.fireSave({
						name: oItemTmpDef.getText(),
						overwrite: true,
						key: oItemTmpDef.getKey(),
						def: false
					});
				} else {
					oItemTmpDef = this.getItemByKey(this.sNewDefaultKey);
					this.fireSave({
						name: oItemTmpDef.getText(),
						overwrite: true,
						key: oItemTmpDef.getKey(),
						def: true
					});
				}
			}
		}
		this.setDefaultVariantKey(this.sNewDefaultKey);

		for (iD = 0; iD < this.aRemovedVariants.length; iD++) {
			oItem = this.getItemByKey(this.aRemovedVariants[iD]);
			for (var iE = 0; iE < this.aRemovedVariantTransports.length; iE++) {
				if (this.aRemovedVariants[iD] === this.aRemovedVariantTransports[iE].key) {
					var oManageItem = this.aRemovedVariantTransports[iE];
					if (oItem.setLifecyclePackage) {
						oItem.setLifecycleTransportId(oManageItem.transport);
					}
					break;
				}
			}
		}

		this.fireManage({
			renamed: this.aRenamedVariants,
			deleted: this.aRemovedVariants,
			exe: this.aExeVariants,
			def: this.getDefaultVariantKey(),
			notif: this.aNotifVariants
		});

		for (iD = 0; iD < this.aRemovedVariants.length; iD++) {
			oItem = this.getItemByKey(this.aRemovedVariants[iD]);
			if (oItem) {
				this._removeItem(oItem);
				oItem.destroy();
			}
			if (this.lastSelectedVariantKey === this.aRemovedVariants[iD]) {
				fireSelect = true;
				this._setSelectedItem(null);
				this.bDirty = false;
				this.oVariantModifiedText.setVisible(false);
				this.oModel.setProperty("/enabled", false);
			}
		}

		if (fireSelect) {
			this.bFireSelect = true;
		}
		this._eventDone();
	},	

	fireManage: function(oVariantInfo) {
		//sap.ui.comp.smartvariants.SmartVariantManagement.prototype.fireManage.apply(this, arguments);

		// if (oVariantInfo) {
		// 	if (oVariantInfo.notif) {
		// 		this._setNotificationSelections(oVariantInfo.notif);
		// 		this._save();
		// 		this.fireEvent("manage", oVariantInfo);
		// 	}
		// }
		
		var i;

		if (oVariantInfo) {

			if (oVariantInfo.renamed) {

				for (i = 0; i < oVariantInfo.renamed.length; i++) {
					this._renameVariant(oVariantInfo.renamed[i]);
				}
			}

			if (oVariantInfo.deleted) {
				this._deleteVariants(oVariantInfo.deleted);
			}

			if (oVariantInfo.exe) {
				this._setExecuteOnSelections(oVariantInfo.exe);
			}

			if (oVariantInfo.def) {

				var sDefaultVariantKey = this._getDefaultVariantKey();
				if (sDefaultVariantKey !== oVariantInfo.def) {
					this._setDefaultVariantKey(oVariantInfo.def);
				}
			}
			
			if (oVariantInfo.notif) {
				this._setNotificationSelections(oVariantInfo.notif);
			}
			

			if ((oVariantInfo.notif && oVariantInfo.notif.length > 0) || (oVariantInfo.deleted && oVariantInfo.deleted.length > 0) || (oVariantInfo.renamed && oVariantInfo.renamed.length > 0) || (oVariantInfo.exe && oVariantInfo.exe.length > 0) || oVariantInfo.def) {
				this._save();
			}

			this.fireEvent("manage", oVariantInfo);
		}
		
	},
	
	_setNotificationSelections: function(aVariantInfo) {
		var i;
		if (aVariantInfo && aVariantInfo.length) {

			for (i = 0; i < aVariantInfo.length; i++) {

				if (aVariantInfo[i].key === this.getStandardVariantKey()) {
					continue;
				}
				
			var oVariant = aVariantInfo[i].key;
				if (oVariant) {
				var oJson = oVariant;
				if (oJson) {
				// var notification = aVariantInfo[i].notif;
					//oVariant.setContent(oJson);
				}
				var notification = this._getChange(aVariantInfo[i].key);
				this._appendLifecycleInformation(notification, aVariantInfo[i].key);
				//var oVariant = this._getChange(aVariantInfo[i].key);
				//if (oVariant) {
				//	var oJson = oVariant.getContent();
				//	if (oJson) {
				//		oJson.notification = aVariantInfo[i].notif;
				//		oVariant.setContent(oJson);
				//	}

				//	this._appendLifecycleInformation(oVariant, aVariantInfo[i].key);
				}
			}
		}
	},

	_setVariantListItemProperties: function(oItem, oVariantListItem) {
		//set Manage and Save as Button property: changed by Tammy Wang I319741 2017.8.20
		if(!this.getEnableManageSaveAsButton()){
			oItem.getParent().oVariantManage.setEnabled(false);
			oItem.getParent().oVariantSaveAs.setVisible(false);
		}
		
		
		var sNotif = "false";

		// execute standard control method
		sap.ui.comp.variants.VariantManagement.prototype._setVariantListItemProperties.apply(this, arguments);

		if (oItem.getCustomData() && oItem.getCustomData().length && oItem.getCustomData()[0].getValue() !== undefined) {
			sNotif = oItem.getCustomData()[0].getValue();
		}

		var oNotifData = new sap.ui.core.CustomData({
			key: "notification",
			value: sNotif,
			writeToDom: true
		});
		oVariantListItem.removeAllCustomData();
		oVariantListItem.addCustomData(oNotifData);

	},

	_newVariant: function(oVariantInfo) {
		// execute standard control method
		sap.ui.comp.smartvariants.SmartVariantManagement.prototype._newVariant.apply(this, arguments);

		var sID = this.getInitialSelectionKey();
		// var oChange = this._oControlPersistence.getChange(sID);
		// var oContent = oChange.getContent();

		var sNotif = "false";
		if (this.oNotificationSelect) {
			if (this.oNotificationSelect.getSelected()) {
				sNotif = "true";
			}

			this.oNotificationSelect.setSelected(false);
		}

		var oItem = this._getSelectedItem();
		var oNotifData = new sap.ui.core.CustomData({
			key: "notification",
			value: sNotif,
			writeToDom: true
		});
		oItem.addCustomData(oNotifData);

		// oContent.notification = sNotif;
	},

	_updateVariant: function(oVariantInfo) {
		// execute standard control method
		sap.ui.comp.smartvariants.SmartVariantManagement.prototype._updateVariant.apply(this, arguments);

		var sID = oVariantInfo.key;
		var oChange = this._oControlPersistence.getChange(sID);
		var oContent = oChange.getContent();

		var sNotif = "false";
		var oItem = this.getItemByKey(oVariantInfo.key);

		if (oItem.getCustomData() && oItem.getCustomData().length && oItem.getCustomData()[0].getValue() !== undefined) {
			sNotif = oItem.getCustomData()[0].getValue();
		}

		oContent.notification = sNotif;
	}

});
//# sourceURL=https://supportshell-tnxd3nxr8c.dispatcher.int.sap.eu2.hana.ondemand.com/applications/servicemessage/~5b7f95b58bfb8077cf59ace147963463a5e20d82~/extended/MyServiceMsgSmartVariantManagement-dbg.js?eval