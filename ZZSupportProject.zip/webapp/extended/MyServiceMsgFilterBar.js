/*
 * Copyright (C) 2009-2023 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.declare("com.ZSupportProject.ZZSupportProject.extended.MyServiceMsgFilterBar");
jQuery.sap.require("sap.ui.comp.filterbar.FilterBar");
jQuery.sap.require("com.ZSupportProject.ZZSupportProject.extended.MyServiceMsgSmartVariantManagement");
jQuery.sap.require("sap.ui.layout.GridRenderer");

sap.ui.comp.filterbar.FilterBar.extend("com.ZSupportProject.ZZSupportProject.extended.MyServiceMsgFilterBar", {

		metadata : {
			library : "com.ZSupportProject.ZZSupportProject.extended",
			properties : {
				showNotificationFB: { type: "boolean", defaultValue: true },
				notificationLabelFB: { type: "string", defaultValue: "Notification" },
				enableManageSaveAsButtonFB:{ type: "boolean", defaultValue: true }
			}
		},
		
	renderer: sap.ui.layout.GridRenderer.render,
	

	_initializeVariantManagement: function() {
		var oPersInfo = new sap.ui.comp.smartvariants.PersonalizableInfo({
			type: "filterBar",
			keyName: "persistencyKey"
		});
		//oPersInfo.addControl(this); -> does not work with UI5 1.46
		oPersInfo.setControl(this);

		this._oSmartVM.addPersonalizableControl(oPersInfo);
		sap.ui.comp.filterbar.FilterBar.prototype._initializeVariantManagement.apply(this, arguments);
	},

	_applyVariant: function(oVariant, sContext) {

		if (oVariant && oVariant.version === "V2") {
			oVariant = this.mergeVariant(this._getStandardVariant(), oVariant, sContext);
		}

		sap.ui.comp.filterbar.FilterBar.prototype._applyVariant.apply(this, arguments);
	},

	_createVariantManagement: function() {
		//var oFilterBar = this; 
		this._oSmartVM = new com.ZSupportProject.ZZSupportProject.extended.MyServiceMsgSmartVariantManagement({
			showExecuteOnSelection: false,
			showNotification:  this.getShowNotificationFB(),
			notificationLabel: this.getNotificationLabelFB(),
			enableManageSaveAsButton: this.getEnableManageSaveAsButtonFB(),
			showShare: false,
			initialise: [function() {
				var sVariantID = this.getCurrentVariantId();
				if (!sVariantID || sVariantID.length === 0) {
					this.fireStandardVariant();
				}
			}, this]
		});
		return this._oSmartVM;
	},

	init: function() {
		sap.ui.comp.filterbar.FilterBar.prototype.init.apply(this, arguments);

		this.setPersistencyKey("com.ZSupportProject.ZZSupportProject");
		this._initializeVariantManagement();
	},

	getCurrentVariantId: function() {
		return this._oSmartVM.getCurrentVariantId();
	},

	setCurrentVariantId: function(sVariantKey, bDoNotApplyVariant) {
		return this._oSmartVM.setCurrentVariantId(sVariantKey, bDoNotApplyVariant);
	}

});
//# sourceURL=https://supportshell-tnxd3nxr8c.dispatcher.int.sap.eu2.hana.ondemand.com/applications/servicemessage/~5b7f95b58bfb8077cf59ace147963463a5e20d82~/extended/MyServiceMsgFilterBar-dbg.js?eval