sap.ui.define([
	"com/ZSupportProject/ZZSupportProject/test/unit/controller/View1.controller"
], function () {
	"use strict";
});