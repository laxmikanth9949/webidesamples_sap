sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/format/DateFormat",
	"com/ZSupportProject/ZZSupportProject/model/models",
	"sap/m/Token",
	"sap/ui/model/json/JSONModel",
	"sap/ui/comp/valuehelpdialog/ValueHelpDialog",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageToast",
	"com/ZSupportProject/ZZSupportProject/model/formatter",
	"sap/base/util/deepExtend",
	"sap/ui/model/BindingMode",
	"sap/ui/core/Fragment"
], function (Controller,DateFormat,models, Token, JSONModel, ValueHelpDialog, ODataModel, MessageToast, formatter, deepExtend, BindingMode, Fragment) {
	"use strict";

	return Controller.extend("com.ZSupportProject.ZZSupportProject.controller.View1", {
		formatter: formatter,
		
				oDataInitial: {
			// Static data
			Items: [
				{
					columnKey: "EmployeeID",
					text: "EMP ID"
				}, {
					columnKey: "TitleOfCourtesy",
					text: "Title Of Courtesy"
				}, {
					columnKey: "FirstName",
					text: "First Name"
				}, {
					columnKey: "LastName",
					text: "Last Name"
				}, {
					columnKey: "Title",
					text: "Title"
				}, {
					columnKey: "BirthDate",
					text: "Birth Date"
				}, {
					columnKey: "HireDate",
					text: "Hire Date"
				}, {
					columnKey: "Address",
					text: "Address"
				}, {
					columnKey: "City",
					text: "City"
				}, {
					columnKey: "Region",
					text: "Region"
				}, {
					columnKey: "PostalCode",
					text: "Postal Code"
				}, {
					columnKey: "Country",
					text: "Country"
				}, {
					columnKey: "ReportsTo",
					text: "Reports To"
				}, {
					columnKey: "PhotoPath",
					text: "Photo Path"
				}, {
					columnKey: "Notes",
					text: "Notes"
				}, {
					columnKey: "HomePhone",
					text: "Phone"
				}, {
					columnKey: "Photo",
					text: "Photo"
				}
			],
			// Runtime data
			ColumnsItems: [
				{
					columnKey: "EmployeeID",
					visible: true,
					index: 0
				}, {
					columnKey: "TitleOfCourtesy",
					visible: true,
					index: 1
				}, {
					columnKey: "FirstName",
					visible: false
				}, {
					columnKey: "LastName",
					visible: false
				}, {
					columnKey: "Title",
					visible: false
				}, {
					columnKey: "BIrthDate",
					visible: false
				}, {
					columnKey: "HireDate",
					visible: false
				}, {
					columnKey: "Address",
					visible: false
				}, {
					columnKey: "City",
					visible: false
				}, {
					columnKey: "Region",
					visible: false
				}, {
					columnKey: "PostalCode",
					visible: false
				}, {
					columnKey: "Country",
					visible: false
				}, {
					columnKey: "ReportsTo",
					visible: false
				}, {
					columnKey: "PhotoPath",
					visible: false
				}, {
					columnKey: "Notes",
					visible: false
				}, {
					columnKey: "HomePhone",
					visible: false
				}, {
					columnKey: "Photo",
					visible: false
				}
			],
			ShowResetEnabled: false
		},
			// Runtime model
		oJSONModel: null,

		oDataBeforeOpen: {},
		
		onInit: function () {
			this.oJSONModel = new JSONModel(deepExtend({}, this.oDataInitial));
			this.oJSONModel.setDefaultBindingMode(BindingMode.TwoWay);
			this.oModel = this.getOwnerComponent().getModel();
		//	this.getView().byId("EmployeeID").setModel(this.oModel);
			this.dataRead();
		},
		formatPhoto : function(photo){
            var oReutrn =  "data:image/png;base64," + photo.substring(104);
            return oReutrn;
        },
        date: function (oDate) {
			if (!oDate || !(oDate instanceof Date)) return;
			var oDateFormat = DateFormat.getDateInstance({
				pattern: "MMM d,YYYY"
			}, new sap.ui.core.Locale("en-US"));
			return oDateFormat.format(oDate);
		},
		onUpdateFinished:function(oEvent){
			debugger;
		},
		onClear:function(oEvent){
				this.getView().byId("City").setSelectedKeys([]);
				this.getView().byId("EmployeeID").setSelectedKeys([]);
				 this.getView().byId("Country").setSelectedKeys([]);
		},
		dataRead: function(oEvent){
		//	this.oModel.setDefaultMethod("GET");
			this.oModel.read("/Employees",{
				success:function(oData){
				var	oJson = new sap.ui.model.json.JSONModel();
					oJson.setData(oData);
				//	this.getView().byId("idTable").setModel(oJson);
				//	this.getView().setModel(oJson);
				this.getView().byId("EmployeeID").setModel(oJson);
				this.getView().byId("City").setModel(oJson);
				this.getView().byId("Country").setModel(oJson);
				}.bind(this),
				error:function(oResponce){
				}.bind(this)
			});
		},
		
		onOK: function(oEvent) {
			this.oDataBeforeOpen = {};
			oEvent.getSource().close();
		},

		onCancel: function(oEvent) {
			this.oJSONModel.setProperty("/", deepExtend([], this.oDataBeforeOpen));

			this.oDataBeforeOpen = {};
			oEvent.getSource().close();
		},

		onReset: function() {
			this.oJSONModel.setProperty("/", deepExtend([], this.oDataInitial));
		},
		onTablePersonalise: function () {
            var oView = this.getView();

			if (!this._pPersonalizationDialog){
				this._pPersonalizationDialog = Fragment.load({
					id: oView.getId(),
					name: "com.ZSupportProject.ZZSupportProject.fragment.PersonalizationDialog",
					controller: this
				}).then(function(oPersonalizationDialog){
					oView.addDependent(oPersonalizationDialog);
					oPersonalizationDialog.setModel(this.oJSONModel);
					return oPersonalizationDialog;
				}.bind(this));
			}
			this._pPersonalizationDialog.then(function(oPersonalizationDialog){
				this.oJSONModel.setProperty("/ShowResetEnabled", this._isChangedColumnsItems());
				this.oDataBeforeOpen = deepExtend({}, this.oJSONModel.getData());
				oPersonalizationDialog.open();
			}.bind(this));
        },
        _isChangedColumnsItems: function() {
			var fnGetArrayElementByKey = function(sKey, sValue, aArray) {
				var aElements = aArray.filter(function(oElement) {
					return oElement[sKey] !== undefined && oElement[sKey] === sValue;
				});
				return aElements.length ? aElements[0] : null;
			};
			var fnGetUnion = function(aDataBase, aData) {
				if (!aData) {
					return deepExtend([], aDataBase);
				}
				var aUnion = deepExtend([], aData);
				aDataBase.forEach(function(oMItemBase) {
					var oMItemUnion = fnGetArrayElementByKey("columnKey", oMItemBase.columnKey, aUnion);
					if (!oMItemUnion) {
						aUnion.push(oMItemBase);
						return;
					}
					if (oMItemUnion.visible === undefined && oMItemBase.visible !== undefined) {
						oMItemUnion.visible = oMItemBase.visible;
					}
					if (oMItemUnion.width === undefined && oMItemBase.width !== undefined) {
						oMItemUnion.width = oMItemBase.width;
					}
					if (oMItemUnion.total === undefined && oMItemBase.total !== undefined) {
						oMItemUnion.total = oMItemBase.total;
					}
					if (oMItemUnion.index === undefined && oMItemBase.index !== undefined) {
						oMItemUnion.index = oMItemBase.index;
					}
				});
				return aUnion;
			};
			var fnIsEqual = function(aDataBase, aData) {
				if (!aData) {
					return true;
				}
				if (aDataBase.length !== aData.length) {
					return false;
				}
				var fnSort = function(a, b) {
					if (a.columnKey < b.columnKey) {
						return -1;
					} else if (a.columnKey > b.columnKey) {
						return 1;
					} else {
						return 0;
					}
				};
				aDataBase.sort(fnSort);
				aData.sort(fnSort);
				var aItemsNotEqual = aDataBase.filter(function(oDataBase, iIndex) {
					return oDataBase.columnKey !== aData[iIndex].columnKey || oDataBase.visible !== aData[iIndex].visible || oDataBase.index !== aData[iIndex].index || oDataBase.width !== aData[iIndex].width || oDataBase.total !== aData[iIndex].total;
				});
				return aItemsNotEqual.length === 0;
			};

			var aDataRuntime = fnGetUnion(this.oDataInitial.ColumnsItems, this.oJSONModel.getProperty("/ColumnsItems"));
			return !fnIsEqual(aDataRuntime, this.oDataInitial.ColumnsItems);
		},
        variantOnSave: function (oEvent){
        	debugger;	
        	var existingVariantData = [];
        	var variantDetails = oEvent.getParameters();
        	var existingSelectedVariant = null;
        	var defaultVariant = "";
			if (variantDetails.def) {
				defaultVariant = "X";
			}
			
			for (var i = 0; i < existingVariantData.length; i++) {
				if (variantDetails.key === existingVariantData[i].VariantID) {
					existingVariantData[i].IsDefault = defaultVariant;
					existingSelectedVariant = existingVariantData[i];
				}
			}
			var cityName = this.getView().byId("City").getSelectedKeys();
			var empId = this.getView().byId("EmployeeID").getSelectedKeys();
			var countryName = this.getView().byId("Country").getSelectedKeys();
			
			var variantData = {
				City : cityName,
				EmployeeID : empId,
				Country : countryName
			};
			
			sap.ui.core.BusyIndicator.show();

			if (existingSelectedVariant) {
				existingSelectedVariant.VariantContent = JSON.stringify(variantData);
				this.updateVariants(null, existingSelectedVariant, this);
			} else {
				var newEntry = {
					"VariantSetName": "TEAM_SRSAPP",
					"VariantDisplayName": variantDetails.name,
					"VariantContent": JSON.stringify(variantData),
					"IsDefault": defaultVariant,
					"Scope": "LOCAL"
				};
				this.createVariants(variantDetails.name, newEntry, this, variantData);
			}
        },
        VariantOnManage: function(oEvent){
        	debugger;
        },
        VariantOnSelect: function(oEvent){
        	debugger;
        },
        createVariants: function (variantName, payload, context) {
			this.oModel.create("/Employee", payload, {
				success: function (oData, resp) {
					context.dataRead(true, false, oData.VariantID);
				},
				error: function (err) {
				//	models.showErrorMessage(context, err);
					context.dataRead(true, false, null);
				}
			});
		},
		onSearch: function(oEvent){
			
			var oFilters = [];
			var cityName = this.getView().byId("City").getSelectedKeys();
			var empId = this.getView().byId("EmployeeID").getSelectedKeys();
			var countryName = this.getView().byId("Country").getSelectedKeys();
			
			if(cityName.length === 0 && empId.length === 0 && countryName.length === 0){
				debugger;
				var emptyJson = new sap.ui.model.json.JSONModel();
				this.getView().byId("idTable").setModel(emptyJson);
				this.getView().byId("idTable").getModel().refresh(true);
				sap.m.MessageToast.show("Please select atleast one");
				return;
			}else{
			if (empId.length !== 0) {
				for (var i = 0; i < empId.length; i++) {
					var filter0 = new sap.ui.model.Filter("EmployeeID",
						sap.ui.model.FilterOperator.EQ, empId[i]);
					oFilters.push(filter0);
				}
			}
			if(cityName.length !== 0) {
				for (var i = 0; i < cityName.length; i++) {
					var filter1 = new sap.ui.model.Filter("City",
						sap.ui.model.FilterOperator.EQ, cityName[i]);
					oFilters.push(filter1);
				}
			}
			if (countryName.length !== 0) {
				for (var i = 0; i < countryName.length; i++) {
					var filter2 = new sap.ui.model.Filter("Country",
						sap.ui.model.FilterOperator.EQ, countryName[i]);
					oFilters.push(filter2);
				}
			}
			this.Filter = oFilters;
			this.getSearchResult(oFilters);
			}
		},
		getSearchResult: function(oFilters, sType){
			this.oModel.read("/Employees",{
				filters: oFilters,
				success: function (oData, oResponse) {
					this.getView().setBusy(false);
					var	oJson = new sap.ui.model.json.JSONModel();
					oJson.setData(oData);
				//	this.getView().byId("idTable").getModel().oData = [];
					this.getView().byId("idTable").setModel(oJson);
					this.getView().byId("idTable").getModel().refresh(true);
					sap.m.MessageToast.show("Search Completed");
				}.bind(this),
				error: function(oResponce){
					debugger;
				}.bind(this)
			});
		}
	/*	_handleMultiComboxSelectionChange: function (oEvent, id) {
			var changedItemName = oEvent.getParameters().changedItem.getText();
			var changedItemStatus = oEvent.getParameters().selected;
			var oMultiComBox = this.getView().byId(id);

			if (changedItemName === "Select All") {
				if (changedItemStatus === true) {
					oMultiComBox.setSelectedItems(oMultiComBox.getItems());
				} else if (changedItemStatus === false) {
					oEvent.getSource().removeAllSelectedItems();
				}
			} else {
				var itemsNumber = oMultiComBox.getItems().length;
				var selectedItemsNumber = oMultiComBox.getSelectedItems().length;
				if (selectedItemsNumber < itemsNumber && oMultiComBox.getSelectedKeys()[0] === "") {
					oMultiComBox.removeSelectedItem(oMultiComBox.getItems()[0]);
				} else if (selectedItemsNumber + 1 === itemsNumber) {
					oMultiComBox.setSelectedItems(oMultiComBox.getItems());
				}
			}
		},
		onSelectionChangeEmp: function(oEvent){
			this._handleMultiComboxSelectionChange(oEvent, "EmployeeID");
		},
		onSelectionChangeCity: function(oEvent){
			this._handleMultiComboxSelectionChange(oEvent, "City");
		},
		onSelectionChangeCountry: function(oEvent){
			this._handleMultiComboxSelectionChange(oEvent, "Country");
		}*/
	});
});