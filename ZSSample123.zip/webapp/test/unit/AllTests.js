sap.ui.define([
	"sample123/ZSSample123/test/unit/controller/Main.controller"
], function () {
	"use strict";
});