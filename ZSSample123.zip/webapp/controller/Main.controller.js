sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller,MessageBox) {
	"use strict";

	return Controller.extend("sample123.ZSSample123.controller.Main", {
		onInit: function () {

		},
		onPress : function(oEvent){
			MessageBox.success("Hello World \n Hello world");
		}
	});
});