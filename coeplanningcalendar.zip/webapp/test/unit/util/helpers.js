sap.ui.define([
    "sap/coe/planning/calendar/util/helpers"
], function(oHelpers) {
    "use strict";

    QUnit.module("Util - helpers");

    QUnit.test("Should be possible to import an instance", function(assert) {
        assert.ok(oHelpers, "Was possible to import the instance");
    });

});
