sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/type/Date",
	"sap/ui/core/syncStyleClass",
	"sap/ui/core/Fragment",
	"sap/ui/table/TablePersoController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/comp/library",
	"sap/ui/export/library",
	"sap/ui/export/Spreadsheet",
	"sap/m/Token",
	"sap/m/MessageBox",
	"jquery.sap.global",
	"../libs/lodash.min"
], function (Controller, JSONModel, typeDate, syncStyleClass, Fragment, TablePersoController, Filter, FilterOperator, compLibrary,
	exportLibrary, Spreadsheet, Token, MessageBox, jQuery) {
	"use strict";
	var EdmType = exportLibrary.EdmType;
	return Controller.extend("corp.sap.crmdownloadtool.controller.DownloadList", {
			onInit: function () {
				var that = this;
				this.defaultVariant = {
					"visibleFilters":["StatOrderno","ZzfgoliveD","PartnerNo","ZzsRating","ReasonCode","Category","Zzfagsinvol","Zzfscenario","Zzfcusttyp","Pv","CreateTime","ChangeTime"],
					"filtersValues":{},
					"tablePerso":{_persoSchemaVersion: "1.0",aColumns:[]}
				};
				this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
				this.oCaseModel = new JSONModel();
				this.getView().setModel(this.oCaseModel, "CaseModel");
				this.oUserModel = this.getOwnerComponent().getModel("userapi");
				this.oUiModel = new JSONModel({
					Filter: {
						text: "Filtered by None"
					},
					filters: {
						StatOrderno: [],
						goLiveStart: null,
						goLiveEnd: null,
						creation_start: null,
						creation_end: null,
						last_change_start: null,
						last_change_end: null,
						PartnerNo: [],
						ZzsRating: [],
						ReasonCode: [],
						Category: [],
						Zzfagsinvol: [],
						Zzfcusttyp: [],
						Zzfscenario: [],
						Pv:""
					},
					busy: true,
					canExport: false,
					numberOfCases:0
				});

				this.getView().setModel(this.oUiModel, "uiModel");
				this.oFilterBar = this.getView().byId("filterbar");
				this.addSnappedLabel();
				this.dLoadVariants = jQuery.Deferred();
				this.dLoadDownloadCols = jQuery.Deferred();
				this.dLoadPersoCols = jQuery.Deferred();
				this.loadVariants();
				
				
				this.downloadColsModel = new JSONModel("model/downloadCols.json");
				this.persoColsModel = new JSONModel("model/persoCols.json");
				this.persoColsModel.attachRequestCompleted(this._bindTableColumn.bind(this));
				this.downloadColsModel.attachRequestCompleted(function(){
					that._downloadColsModelComplete(this);
				});
				this.getView().setModel(this.downloadColsModel, "downLoadCols");
				this.getView().setModel(this.persoColsModel, "persoCols");
				
				
				jQuery.when(this.dLoadVariants, this.dLoadDownloadCols, this.dLoadPersoCols ).done(function ( variantContent, r2, r3 ) {
					this._applyVariantData(variantContent,true);
					this._iniTablePerso(variantContent.tablePerso);
					this.oUiModel.setProperty("/busy", false);
				}.bind(this));
				// var oModel = this.getView().getModel();
				// oModel.attachBatchRequestCompleted(function(oEvent){
				// 	var params = oEvent.getParameters();
				// 	console.log(params);
				// });
			},
			/**
			 * table personalization
			 */
			_iniTablePerso:function(tablePerso){
				var that = this;
				var oPersoData = jQuery.extend({},tablePerso);
				var PersoService = {
					getPersData : function () {
						var oDeferred = jQuery.Deferred();
						if (!this._oBundle) {
							this._oBundle = oPersoData;
						}
						var oBundle = this._oBundle;
						oDeferred.resolve(oBundle);
						return oDeferred.promise();
					},
			
					setPersData : function (oBundle, bFromSelection) {
						var oDeferred = jQuery.Deferred();
						this._oBundle = oBundle;
						if(!bFromSelection){
							that._compareVariantData();
						}
						oDeferred.resolve();
						return oDeferred.promise();
					},
					delPersData: function(){
						var oDeferred = jQuery.Deferred();
						this._oBundle = null;
						oDeferred.resolve();
						return oDeferred.promise();
					},
			
					resetPersData : function () {
						var oDeferred = new jQuery.Deferred();
						var oInitialData = jQuery.extend({},oPersoData);
						//set personalization
						this._oBundle = oInitialData;
						that._compareVariantData();
						oDeferred.resolve();
						return oDeferred.promise();
					}
				};
				this._oTPC = new TablePersoController({
					table: this.byId("caseTable"),
					persoService: PersoService
				});
			},
			/**
			 * open table personalization dialog
			 */
			onPersoButtonPressed: function (oEvent) {
				this._oTPC.openDialog();
			},
			/**
			 * column settings for excel are downloaded
			 */
			_downloadColsModelComplete:function(oModel){
				oModel.setSizeLimit(oModel.getData().length);
				this.dLoadDownloadCols.resolve();
			},
			/**
			 * generate table columns
			 */
			_bindTableColumn:function(){
				var oTable = this.byId("caseTable");
				var aColsData = this.persoColsModel.getData();
				for(var j = 0; j < aColsData.length; j++){
					var colData = aColsData[j];
					var oText = new sap.m.Text({text:"{CaseModel>"+colData.name+"}"});
					if(colData.type === "Date" || colData.type === "DateTime"){
						var datePattern = "yyyy/MM/dd HH:mm";
						if(colData.name === "ZzfgoliveD"){
							datePattern = "yyyy/MM/dd";
						}
						oText = new sap.m.Text({text:"{path:'CaseModel>"+colData.name+"',type: 'sap.ui.model.type.Date',formatOptions: {pattern: '"+datePattern+"',UTC: true}}"});
					}
					var sColId = colData.name + "Col";
					var oCol = new sap.ui.table.Column(sColId, {
						autoResizable: true,
						minWidth:150,
						sortProperty:colData.name,
						filterProperty:colData.name,
						showFilterMenuEntry:true,
						showSortMenuEntry:true,
						visible:colData.visible,
						label: new sap.m.Label({text:colData.label}),
						template: oText
					});
					oTable.addColumn(oCol);
					this.defaultVariant.tablePerso.aColumns.push({
						id: oCol.getParent().getId()+"-"+sColId,
						order: j,
						text: colData.label,
						visible: colData.visible
					});
				}
				var oBindings = oTable.getBinding("rows");
				oBindings.attachChange(function(oEvent){
					 this.oUiModel.setProperty("/numberOfCases", oEvent.getSource().iLength);
				}.bind(this));
				this.dLoadPersoCols.resolve();
			},
			/**
			 * get visible filters in filter bar
			 * @returns {object} an object of visible filters and corresponding filter path
			 */
			_getVisibleFilters:function(){
				var aFilters = this.oFilterBar.getFilterGroupItems();
				var aVisibleFilters = [];
				var aVisibleFilterPath = [];
				for (var i = 0; i < aFilters.length; i++) {
					var oFilter = aFilters[i];
					var oControl = this.oFilterBar.determineControlByFilterItem(oFilter);
					var sFilterPath = oControl.getName();
					if(oFilter.getVisibleInFilterBar()){
						aVisibleFilters.push(oFilter);
						aVisibleFilterPath.push(sFilterPath);
					}
				}
				return {
					filters: aVisibleFilters,
					paths: aVisibleFilterPath
				};
			},
			/**
			 * get filters with value in filter bar
			 * @returns {object} an object of filters with value and corresponding label
			 */
			_getFiltersWithValue: function () {
				var aFilters = this.oFilterBar.getFilterGroupItems();
				var aFiltersWithValue = [];
				var aFiltersWithValueLabel = [];
				for (var i = 0; i < aFilters.length; i++) {
					var oControl = this.oFilterBar.determineControlByFilterItem(aFilters[i]);
					var sControlName = oControl.getMetadata().getName();
					var oFilterWithValue = null;

					if (sControlName === "sap.m.MultiComboBox" && oControl.getSelectedKeys().length ||
						sControlName === "sap.m.DateRangeSelection" && oControl.getSecondDateValue() ||
						sControlName === "sap.m.MultiInput" && oControl.getTokens().length) {
						oFilterWithValue = aFilters[i];
					}
					if (oFilterWithValue) {
						aFiltersWithValue.push(oFilterWithValue);
						aFiltersWithValueLabel.push(oFilterWithValue.getLabel());
					}
				}
				return {
					filters: aFiltersWithValue,
					labels: aFiltersWithValueLabel
				};
			},
			/**
			 * apply variant data to filters and table columns
			 * @param {object} variants variant content object
			 * @param {boolean} isInit true: invoked from app initial, false: invoked from variant selection
			 */
			_applyVariantData: function(variants, isInit){
				this.currentVariant = JSON.parse(JSON.stringify(variants));
				if(variants){
					//apply filters
					var aFilters = this.oFilterBar.getFilterGroupItems();
					for (var i = 0; i < aFilters.length; i++) {
						var oControl = this.oFilterBar.determineControlByFilterItem(aFilters[i]);
						var filterPath = oControl.getName();
						var sControlName = oControl.getMetadata().getName();
						var filterValue = variants.filtersValues[filterPath];
						
						if(variants.visibleFilters.indexOf(filterPath) === -1){
							aFilters[i].setVisibleInFilterBar(false);
						}else{
							aFilters[i].setVisibleInFilterBar(true);
						}
						
						if(filterValue){
							if (sControlName === "sap.m.MultiComboBox") {
								oControl.setSelectedKeys(filterValue);
							} else if (sControlName === "sap.m.DateRangeSelection") {
								 oControl.setDateValue(new Date(filterValue.dateValue));
								 oControl.setSecondDateValue(new Date(filterValue.secondDateValue));
							} else if (sControlName === "sap.m.MultiInput") {
								var aTokens = [];
								for (var k = 0; k < filterValue.length; k++) {
									var oTk = filterValue[k];
									aTokens.push(new Token({
										key: oTk.key,
										text: oTk.text
									}).data("range", oTk.range));
									
								}
								oControl.setTokens(aTokens);
							}
						}else{
							if (sControlName === "sap.m.MultiComboBox") {
								oControl.setSelectedKeys([]);
							} else if (sControlName === "sap.m.DateRangeSelection") {
								 oControl.setDateValue(null);
								 oControl.setSecondDateValue(null);
							} else if (sControlName === "sap.m.MultiInput") {
								oControl.setTokens([]);
							}
						}
					}
					//apply table personal
					if(!isInit){
						this._oTPC.getPersoService().setPersData(variants.tablePerso, true);
						this._oTPC.refresh();
					}
				}
				
				var oFiltersWithValue = this._getFiltersWithValue();
				this.oUiModel.setProperty("/Filter/text", this.getFormattedSummaryText(oFiltersWithValue.labels));
				
			},
			onHelp: function(){
				window.open("https://go.sap.corp/CRM-DL-tool-info");	
			},
			/**
			 * search cases
			 * @param {object} search event
			 */
			onSearch: function (oEvent) {
				var oModel = this.getView().getModel();
				var oFiltersWithValue = this._getFiltersWithValue();
				var aFilters = oFiltersWithValue.filters;
				var aSFilters = [];
				var ValueHelpRangeOperation = compLibrary.valuehelpdialog.ValueHelpRangeOperation;
				for (var i = 0; i < aFilters.length; i++) {
					var filter = aFilters[i];
					var oControl = this.oFilterBar.determineControlByFilterItem(filter);
					var sControlName = oControl.getMetadata().getName();
					if (oControl) {
						var filterPath = oControl.getName();
						// if (oControl.getValue && oControl.getValue()) {
						// 	var oSFilter = new Filter({
						// 		path: filterPath,
						// 		operator: FilterOperator.EQ,
						// 		value1: oControl.getValue()
						// 	});
						// 	aSFilters.push(oSFilter);
						// } else 
						if (sControlName === "sap.m.MultiComboBox" && oControl.getSelectedKeys().length) {
							var aKeys = oControl.getSelectedKeys();
							var aKeyFilter = [];
							for (var j = 0; j < aKeys.length; j++) {
								var sKey = aKeys[j];
								aKeyFilter.push(new Filter({
									path: filterPath,
									operator: FilterOperator.EQ,
									value1: sKey
								}));
							}
							if (aKeyFilter.length) {
								var oSFilter = new Filter({
									filters: aKeyFilter,
									and: false
								});
								aSFilters.push(oSFilter);
							}
						} else if (sControlName === "sap.m.DateRangeSelection" && oControl.getSecondDateValue()) {
							var oDateValue = oControl.getDateValue();
							var oSecondDateValue = oControl.getSecondDateValue();
							var oSFilter = new Filter({
								filters: [
									new Filter({
										path: filterPath,
										operator: FilterOperator.GE,
										value1: oDateValue
									}), new Filter({
										path: filterPath,
										operator: FilterOperator.LE,
										value1: oSecondDateValue
									})
								],
								and: true
							});
							aSFilters.push(oSFilter);
						} else if (sControlName === "sap.m.MultiInput" && oControl.getTokens().length) {
							var aTokens = oControl.getTokens();
							var aKeyFilter = [];
							var aNEKeyFilter = [];
							for (var k = 0; k < aTokens.length; k++) {
								var oToken = aTokens[k];
								var oTKProperties = oToken.data("range");
								var tokenValue1 = oTKProperties.value1;
								var tokenValue2 = oTKProperties.value2;
								var sFilterOperator = FilterOperator[oTKProperties.operation];
								if (oTKProperties.operation === ValueHelpRangeOperation.Empty) {
									tokenValue1 = "";
									tokenValue2 = "";
									sFilterOperator = FilterOperator.EQ;
								}
								if (oTKProperties.exclude) {
									aNEKeyFilter.push(new Filter({
										path: oTKProperties.keyField,
										operator: FilterOperator.NE,
										value1: tokenValue1
									}));
								} else {
									aKeyFilter.push(new Filter({
										path: oTKProperties.keyField,
										operator: sFilterOperator,
										value1: tokenValue1,
										value2: tokenValue2
									}));
								}
							}
							if (aKeyFilter.length) {
								var oSFilter = new Filter({
									filters: aKeyFilter,
									and: false
								});
								aSFilters.push(oSFilter);
								//Service Team PartnerFct eq 'ZSERST01' and PartnerNo
								if (filterPath === "PartnerNo") {
									aSFilters.push(new Filter({
										path: "PartnerFct",
										operator: FilterOperator.EQ,
										value1: "ZSERST01"
									}));
								}
							}
							if (aNEKeyFilter.length) {
								var oSFilter = new Filter({
									filters: aNEKeyFilter,
									and: true
								});
								aSFilters.push(oSFilter);
							}
						}
					}
				}

				this.oUiModel.setProperty("/busy", true);
				oModel.read("/CaseSet", {
					filters: aSFilters,
					// urlParameters: {
					//       "$expand": "ReasonSet"
					//   },
					success: function (oData) {
						console.log(oData);
						if (oData.results && oData.results.length) {
							var nCaseLength = oData.results.length;
							_.remove(oData.results, function(oCase) {
							  return oCase.Blocked;
							});
							
							console.log(oData.results.length+"||"+nCaseLength);
							if(oData.results.length < nCaseLength){
								MessageBox.alert("Due to GDPR Compliance one or More Transactions/Cases could not be shown.");
							}
							this.oUiModel.setProperty("/canExport", true);
						} else {
							this.oUiModel.setProperty("/canExport", false);
						}
						this.oUiModel.setProperty("/busy", false);
						this.oCaseModel.setData(oData);
					}.bind(this),
					error: function () {
						this.oUiModel.setProperty("/busy", false);
						this.oUiModel.setProperty("/canExport", false);
					}.bind(this)
				})
			},
			onFilter: function (oEvent) {
				var oTable = oEvent.getSource();
				var caseNumber = oTable.getBinding("rows").getLength();
				this.oUiModel.setProperty("/numberOfCases", caseNumber);
			},
			onFiltersDialogClosed: function (oEvent) {
				this._compareVariantData();
			},
			onFieldChange: function (oEvent) {
				var oFiltersWithValue = this._getFiltersWithValue();
				this.removeSnappedLabel(); /* because in case of label with an empty text, */
				this.addSnappedLabel(); /* a space for the snapped content will be allocated and can lead to title misalignment */
				this.oUiModel.setProperty("/Filter/text", this.getFormattedSummaryText(oFiltersWithValue.labels));
				this._compareVariantData();
				// var oVM = this.getView().byId("idVM");
				// oVM.currentVariantSetModified(true);
			},
			_compareVariantData:function(){
				var oVM = this.getView().byId("idVM");
				var tmpVariant = JSON.parse(JSON.stringify(this._getVariantContentData()));
				var sameVariant = _.isEqual(tmpVariant, this.currentVariant);
				if(!sameVariant){
					oVM.currentVariantSetModified(true);
				}else{
					oVM.currentVariantSetModified(false);
				}
			},
			addSnappedLabel: function () {
				var oSnappedLabel = this.getSnappedLabel();
				oSnappedLabel.attachBrowserEvent("click", this.onToggleHeader, this);
				this.getPageTitle().addSnappedContent(oSnappedLabel);
			},
			getFormattedSummaryText: function (aFiltersLabel) {
				if (aFiltersLabel.length > 0) {
					return "Filtered By (" + aFiltersLabel.length + "): " + aFiltersLabel.join(", ");
				} else {
					return "Filtered by None";
				}
			},
			onToggleHeader: function () {
				this.getPage().setHeaderExpanded(!this.getPage().getHeaderExpanded());
			},
			removeSnappedLabel: function () {
				this.getPageTitle().destroySnappedContent();
			},
			getPage: function () {
				return this.getView().byId("downloadListPage");
			},
			getPageTitle: function () {
				return this.getPage().getTitle();
			},
			getSnappedLabel: function () {
				return new sap.m.Label({
					text: "{uiModel>/Filter/text}"
				});
			},
			onValueHelpRequested: function (oEvent) {
				console.log(oEvent);
				var oView = this.getView();
				this._oMultiInput = oEvent.getSource();
				this._oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
					title: this._oMultiInput.data("label"),
					supportRanges: true,
					supportRangesOnly: true,
					ok: this.onValueHelpOkPress.bind(this),
					cancel: this.onValueHelpCancelPress.bind(this),
					afterClose: this.onValueHelpAfterClose.bind(this)
				});
				this._oValueHelpDialog.setRangeKeyFields([{
					label: this._oMultiInput.data("label"),
					key: this._oMultiInput.getName(),
					type: this._oMultiInput.data("type")
				}]);
				this._oValueHelpDialog.setTokens(oEvent.getSource().getTokens());
				syncStyleClass(oView.getController().getOwnerComponent().getContentDensityClass(), oView, this._oValueHelpDialog);
				this._oValueHelpDialog.open();
			},
			onValueHelpOkPress: function (oEvent) {
				var aTokens = oEvent.getParameter("tokens");
				this._oMultiInput.setTokens(aTokens);
				// this._oMultiInput.fireTokenUpdate({
				// 	type:"add"
				// })
				this._oValueHelpDialog.close();
				this.onFieldChange();
			},

			onValueHelpCancelPress: function () {
				this._oValueHelpDialog.close();
			},

			onValueHelpAfterClose: function () {
				this._oValueHelpDialog.destroy();
			},
			createColumnConfig: function () {
				var oTable = this._oTable;
				var oColsType = {
					MainCustomerId: EdmType.String,
					MainCustomerName: EdmType.String,
					ExtKey: EdmType.String,
					CaseTitle: EdmType.String,
					StatOrdernoText: EdmType.String,
					CrmCategoryIdText: EdmType.String,
					ReasonCodeText: EdmType.String,
					InitiativeText: EdmType.String,
					ZzfcusttypText: EdmType.String,
					ZzfgoliveD: EdmType.Date,
					ChangeTime: EdmType.Date
				};
				var aCols = [];
				var aColumns = oTable.getColumns();
				for (var i = 0; i < aColumns.length; i++) {
					var oColumn = aColumns[i];
					var bindingPath = oColumn.getTemplate().getBindingPath("text");
					if (oColumn.getVisible()) {
						aCols.push({
							label: oColumn.getLabel().getText(),
							property: bindingPath,
							type: oColsType[bindingPath]
						});
					}
				}
				return aCols;
			},
			onDownloadButtonPressed:function(){
				if (!this.oWarningMessageDialog) {
					this.oWarningMessageDialog = new sap.m.Dialog({
						type: sap.m.DialogType.Message,
						title: "Disclaimer",
						state: sap.ui.core.ValueState.Warning,
						contentWidth:"500px",
						content: new sap.ui.core.HTML({ 
							content: '<p>You should only keep personal data as long as it is necessary for the specified business purpose. For more information, please review <a rel="external" href="https://portal.wdf.sap.corp/go/dataprotection" target="_blank">SAP\'s Data Protection & Privacy Policy</a>.</p><p>You must delete any information or documents older than three (3) years. For more information, please review <a href="https://portal.wdf.sap.corp/go/igrm" target="_blank">SAP\'s Information Governance & Records Management Policy</a>.</p>'
						}),
						beginButton: new sap.m.Button({
							type: sap.m.ButtonType.Emphasized,
							text: "OK",
							press: function () {
								this.oWarningMessageDialog.close();
								
								var aCols = this.downloadColsModel.getData();
								var oTable = this.byId('caseTable');
								var aColumns = oTable.getColumns();
								var aVisibleCols = [];
								for (var i = 0; i < aColumns.length; i++) {
									var oColumn = aColumns[i];
									var bindingPath = oColumn.getTemplate().getBindingPath("text");
									if (oColumn.getVisible()) {
										aVisibleCols.push(bindingPath);
									}
								}
								for (var j = 0; j < aCols.length; j++) {
									if(aVisibleCols.indexOf(aCols[j].name) !== -1){
										aCols[j]["selected"] = true;
									}else{
										aCols[j]["selected"] = false;
									}
								}
								this.downloadColsModel.refresh();
								if (!this.byId("DownloadColsDialog")) {
									// load asynchronous XML fragment
									Fragment.load({
										id: this.getView().getId(),
										name: "corp.sap.crmdownloadtool.fragments.DownloadColsDialog",
										controller: this
									}).then(function (oDialog) {
										// connect dialog to the root view of this component (models, lifecycle)
										this.getView().addDependent(oDialog);
										oDialog.open();
									}.bind(this));
								} else {
									this.byId("DownloadColsDialog").open();
								}
								
							}.bind(this)
						})
					});
				}
	
				this.oWarningMessageDialog.open();
				
			},
			onColumnSearch: function (oEvent) {
				var sValue = oEvent.getParameter("value");
				var oFilter = new Filter("name", FilterOperator.Contains, sValue);
				var oBinding = oEvent.getParameter("itemsBinding");
				oBinding.filter([oFilter]);
			},
			onDownloadConfirm:function(oEvent){
				var selectedCtx = oEvent.getParameter("selectedContexts");
				var aCols = [];
				for(var i=0; i<selectedCtx.length; i++){
					var selectedData = selectedCtx[i].getObject();
					aCols.push({
						label: selectedData.label,
						property: selectedData.name,
						type: EdmType[selectedData.type]?EdmType[selectedData.type]:EdmType.String
					});
				}
				this._export(aCols);
				
			},
			_export: function (aCols) {
				var oSettings, oSheet, aCases;
				if (!this._oTable) {
					this._oTable = this.byId('caseTable');
				}

				var oModel = this.getView().getModel("CaseModel");
				aCases = oModel.getProperty('/results');

				oSettings = {
					workbook: {
						columns: aCols
					},
					dataSource: aCases,
					fileName: 'CONFIDENTIAL_Cases.xlsx'
				};

				oSheet = new Spreadsheet(oSettings);
				oSheet.build()
					.then(function () {
						// MessageToast.show('Spreadsheet export has finished');
					})
					.finally(oSheet.destroy);
			},
			loadVariants: function () {
				var oModel = new sap.ui.model.json.JSONModel();
				var oDataModel = this.getView().getModel();
				oDataModel.read("/VariantDataSet",{
					filters:[
						new Filter({
							path: "OwnerId",
							operator: FilterOperator.EQ,
							value1: this.oUserModel.getProperty("/name")
						}),
					],
					success:function (oData) {
						console.log(oData);
						var selected = "*standard*";
						var variantContent;
						for(var i = 0; i < oData.results.length;i++){
							if(oData.results[i].IsDefault){
								selected = oData.results[i].VariantId;
								variantContent = JSON.parse(oData.results[i].VariantContent);
								// this._applyVariantData(JSON.parse(oData.results[i].VariantContent));
								break;
							}
						}
						if(selected === "*standard*"){
							variantContent = this.defaultVariant;
							// this._applyVariantData(this.defaultVariant);
						}
						oModel.setData({
							VariantSet: oData.results,
							selectedVariant:selected
						});
						this.dLoadVariants.resolve(variantContent);
					}.bind(this),
					error:function (err) {
						console.log("Service Failed");
						this.dLoadVariants.resolve(null);
					}.bind(this)
				});
				this.getView().setModel(oModel, "variant");
			},
			_getVariantContentData: function () {
				var save = Object.create(null);
				//get filter variant
				var oFiltersWithValue = this._getFiltersWithValue();
				var aFilters = oFiltersWithValue.filters;
				save.visibleFilters = this._getVisibleFilters().paths;
				save.filtersValues = {};
				for (var i = 0; i < aFilters.length; i++) {
					var filter = aFilters[i];
					var oControl = this.oFilterBar.determineControlByFilterItem(filter);
					var sControlName = oControl.getMetadata().getName();
					if (oControl) {
						var filterPath = oControl.getName();
						if (sControlName === "sap.m.MultiComboBox" && oControl.getSelectedKeys().length) {
							var aKeys = oControl.getSelectedKeys();
							save.filtersValues[filterPath] = aKeys;
						} else if (sControlName === "sap.m.DateRangeSelection" && oControl.getSecondDateValue()) {
							var oDateValue = oControl.getDateValue();
							var oSecondDateValue = oControl.getSecondDateValue();
							save.filtersValues[filterPath] = {
								dateValue: oDateValue,
								secondDateValue: oSecondDateValue
							};
						} else if (sControlName === "sap.m.MultiInput" && oControl.getTokens().length) {
							var aTokens = oControl.getTokens();
							var aSavedTokens =[];
							for (var k = 0; k < aTokens.length; k++) {
								var oToken = aTokens[k];
								var oTKProperties = oToken.data("range");
								aSavedTokens.push({
									key: oToken.getKey(),
									text: oToken.getText(),
									range: oTKProperties
								});
							}
							save.filtersValues[filterPath] = aSavedTokens;
						}
					}
				}
				//get table variant
				this._oTPC.getPersoService().getPersData().done(function(personData){
					save.tablePerso = jQuery.extend({},personData);
				});
				return save;
			},
			onSave: function (oEvent) {
				var oDataModel = this.getView().getModel();
				var params = oEvent.getParameters();
				if (params.overwrite) {
					console.log("ov");
					//Get selected Variants Data
					var selectedKey = oEvent.getSource().getSelectionKey();
					var bindingPath = oEvent.getSource().getItemByKey(selectedKey).getBindingContext("variant").getPath();
					var modelData = this.getView().getModel("variant").getProperty(bindingPath);
					var save = this._getVariantContentData();
					modelData.VariantContent = JSON.stringify(save);
					// $.extend(modelData, save);
					this.getView().getModel("variant").refresh();
					oDataModel.update("/VariantDataSet(guid'"+modelData.VariantId+"')",modelData,{
						success:function () {
							console.log("Update default successful");
						},
						error:function () {
							console.log("Update default failed");
						}
					});
				} else {
					console.log("new");
					var newFilterData = this._getVariantContentData();
					var newEntry = {
						VariantSetName:params.key,
						OwnerId:this.oUserModel.getProperty("/name"),
						VariantDisplayName:params.name,
						Scope:"LOCAL",
						IsDefault:params.def ? "X":"",
						VariantContent: JSON.stringify(newFilterData)
					};
					if(params.def){
						this._resetDefaultVariant();
					}
					//Updating database via Odata
					oDataModel.create("/VariantDataSet", newEntry,{
						success:function (oData) {
							//Updating Json Model Local Data
							var Data = this.getView().getModel("variant").getData().VariantSet;
							Data.push(newEntry);
							this.getView().getModel("variant").refresh();
						}.bind(this),
						error:function (err) {
							console.log("Service Failed");
						}
					});

				}
			},

			onManage: function (oEvent) {
				var oDataModel =  this.getView().getModel();
				var params = oEvent.getParameters();
				var renamed = params.renamed;
				var deleted = params.deleted;
				var defaultKey = params.def;
				var oVM = oEvent.getSource();
				//rename backend data       
				if (renamed.length) {
					renamed.forEach(function (rename) {
						var renamePayload = this._getVariantItemDataByKey(rename.key);
						renamePayload.VariantDisplayName = rename.name;
						if(rename.key === defaultKey){
							renamePayload.IsDefault = "X";
						}
						oDataModel.update("/VariantDataSet(guid'"+rename.key+"')",renamePayload,{
							success:function () {
								console.log("Update successful");
							},
							error:function () {
								console.log("Update failed");
							}
						});

					}.bind(this));
				}else if(defaultKey !== "*standard*"){
					var defaultPayload = this._getVariantItemDataByKey(defaultKey);
					defaultPayload.IsDefault = "X";
					oDataModel.update("/VariantDataSet(guid'"+defaultKey+"')",defaultPayload,{
						success:function () {
							console.log("Update default successful");
						},
						error:function () {
							console.log("Update default failed");
						}
					});
				}else if(defaultKey === "*standard*"){
					this._resetDefaultVariant();
				}
				//delete backend data             

				if (deleted.length) {
					deleted.forEach(function (remove) {
						oDataModel.remove("/VariantDataSet(guid'"+remove+"')",{
							success:function(){
								console.log("Delete successful");
							},
							error:function () {
								console.log("Delete failed");
							}
						});
					});

			}

		},
		onSelect:function(oEvent){
			var sSelectedKey = oEvent.getParameters().key;
			var oVariantData = this._getVariantItemDataByKey(sSelectedKey);
			//reset column filter and sorter
			var oTable = this.getView().byId("caseTable");
			// var oBinding = oTable.getBinding();
			// oBinding.aSorters = null;
			// oBinding.aFilters = null;
			// oTable.getModel("CaseModel").refresh(true);
			
			var columns = oTable.getColumns();
			var sortedCols = oTable.getSortedColumns();
			  for (var i = 0, l = columns.length; i < l; i++) {
			    var isFiltered = columns[i].getFiltered();
			    if (isFiltered) {
			      // clear column filter if the filter is set
			      columns[i].filter("");
			    }
			    if (sortedCols.indexOf(columns[i]) < 0) {
			      columns[i].setSorted(false);
			     }
			  }
			
			if(oVariantData){
				this._applyVariantData(JSON.parse(oVariantData.VariantContent));
			}else{
				this._applyVariantData(this.defaultVariant);
			}
		},
		_getVariantItemDataByKey: function(key){
			var oVM = this.getView().byId("idVM");
			var aVariantItems = oVM.getVariantItems();
			for(var i = 0; i < aVariantItems.length; i++){
				if(aVariantItems[i].getBindingContext("variant")){
					var oItemData = aVariantItems[i].getBindingContext("variant").getObject();
					if(oItemData.VariantId === key){
						return oItemData;
					}
				}
			}
			return null;
		},
		_resetDefaultVariant: function(exclusions){
			var oVM = this.getView().byId("idVM");
			var oDataModel = this.getView().getModel();
			var aVariantItems = oVM.getVariantItems();
			for(var i = 0; i < aVariantItems.length; i++){
				if(aVariantItems[i].getBindingContext("variant")){
					var oItemData = aVariantItems[i].getBindingContext("variant").getObject();
					oItemData.IsDefault = "";
					// if(exclusions && exclusions.indexOf(oItemData.VariantId) === -1){
					oDataModel.update("/VariantDataSet(guid'"+oItemData.VariantId+"')",oItemData,{
						success:function () {
							console.log("Update default successful");
						},
						error:function () {
							console.log("Update default failed");
						}
					});
					// }
				}
			}
		}
		/*
		var abc = sap.ui.core.format.DateFormat.getDateInstance({pattern:"yyyyMMddTHH:mm:ss"});abc.format(sap.ui.getCore().byId('__input0').getTokens()[0].getCustomData()[0].getValue().value1)
		*/
	});
});