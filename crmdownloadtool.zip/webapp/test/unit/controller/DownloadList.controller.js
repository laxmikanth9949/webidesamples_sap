/*global QUnit*/

sap.ui.define([
	"corp/sap/crmdownloadtool/controller/DownloadList.controller"
], function (Controller) {
	"use strict";

	QUnit.module("DownloadList Controller");

	QUnit.test("I should test the DownloadList controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});