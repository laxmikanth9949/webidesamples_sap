sap.ui.define([
	"corp/sap/crmdownloadtool/test/unit/controller/DownloadList.controller"
], function () {
	"use strict";
});