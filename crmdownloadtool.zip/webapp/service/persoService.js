sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
	"use strict";
	
	var initPersoData = {
			_persoSchemaVersion: "1.0",
			aColumns : [
				// {
				// 	id: "CDT-caseTable-MainCustomerIDCol",
				// 	order: 0,
				// 	text: "Main Customer ID",
				// 	visible: false
				// },
				// {
				// 	id: "CDT-caseTable-MainCustomerNameCol",
				// 	order: 1,
				// 	text: "Main Customer Name",
				// 	visible: false
				// },
				// {
				// 	id: "CDT-caseTable-CaseIDCol",
				// 	order: 2,
				// 	text: "Case ID",
				// 	visible: true
				// },
				// {
				// 	id: "CDT-caseTable-CaseDescriptionCol",
				// 	order: 3,
				// 	text: "Case Description",
				// 	visible: true
				// },
				// {
				// 	id: "CDT-caseTable-CaseStatusCol",
				// 	order: 4,
				// 	text: "Case Status",
				// 	visible: true
				// },
				// {
				// 	id: "CDT-caseTable-CaseCategoryDescriptionCol",
				// 	order: 5,
				// 	text: "Case Category Description",
				// 	visible: true
				// },
				// {
				// 	id: "CDT-caseTable-CaseReasonDescriptionCol",
				// 	order: 6,
				// 	text: "CaseReason Description",
				// 	visible: true
				// },
				// {
				// 	id: "CDT-caseTable-InitiativeCol",
				// 	order: 7,
				// 	text: "Initiative",
				// 	visible: true
				// },
				// {
				// 	id: "CDT-caseTable-CustomerTypeCol",
				// 	order: 8,
				// 	text: "Customer Type",
				// 	visible: true
				// },
				// {
				// 	id: "CDT-caseTable-GoLiveDateCol",
				// 	order: 9,
				// 	text: "Go-Live Date",
				// 	visible: true
				// },
				// {
				// 	id: "CDT-caseTable-LastChangedDateCol",
				// 	order: 10,
				// 	text: "Last Changed Date",
				// 	visible: true
				// }
			]
		};
	// Very simple page-context personalization
	// persistence service, not for productive use!
	var PersoService = {

		oPersoData : jQuery.extend({},initPersoData),

		getPersData : function () {
			var oDeferred = new jQuery.Deferred();
			if (!this._oBundle) {
				this._oBundle = this.oPersoData;
			}
			var oBundle = this._oBundle;
			oDeferred.resolve(oBundle);
			return oDeferred.promise();
		},

		setPersData : function (oBundle) {
			var oDeferred = new jQuery.Deferred();
			this._oBundle = oBundle;
			oDeferred.resolve();
			return oDeferred.promise();
		},
		delPersData: function(){
			var oDeferred = new jQuery.Deferred();
			this._oBundle = null;
			oDeferred.resolve();
			return oDeferred.promise();
		},

		resetPersData : function () {
			var oDeferred = new jQuery.Deferred();
			var oInitialData = jQuery.extend({},initPersoData);

			//set personalization
			this._oBundle = oInitialData;

			//reset personalization, i.e. display table as defined
	//		this._oBundle = null;

			oDeferred.resolve();
			return oDeferred.promise();
		},

		//this caption callback will modify the TablePersoDialog' entry for the 'Weight' column
		//to 'Weight (Important!)', but will leave all other column names as they are.
		getCaption : function (oColumn) {
			// if (oColumn.getHeader() && oColumn.getHeader().getText) {
			// 	if (oColumn.getHeader().getText() === "Weight") {
			// 		return "Weight (Important!)";
			// 	}
			// }
			return null;
		},

		// getGroup : function(oColumn) {
		// 	if ( oColumn.getId().indexOf('productCol') != -1 ||
		// 			oColumn.getId().indexOf('supplierCol') != -1) {
		// 		return "Primary Group";
		// 	}
		// 	return "Secondary Group";
		// }
	};

	return PersoService;

});
