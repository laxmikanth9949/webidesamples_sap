sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/HashChanger",
	"sap/support/mccactivities/model/DataManager",
	"sap/support/mccactivities/model/models",
	"sap/support/mccactivities/util/Intercept",
	"sap/ui/model/Filter",
	"sap/m/MessageToast"
], function (UIComponent, JSONModel, HashChanger, DataManager, models, Intercept, Filter, MessageToast) {
	"use strict";

	return UIComponent.extend("sap.support.mccactivities.Component", {
		_bEditMode: false,
		_bSettingsEditMode: false,
		sUser: "",
		sCurActivityId: "",
		fReadFirstAct: true,
		sFirstSlash: "/",

		metadata: {
			manifest: "json"
		},

		config: {
			reportingId: "MCC Activities"
		},

		init: function () {
			UIComponent.prototype.init.apply(this, arguments);
			//this._checkEnvironment();
			this._requireReuseLib();
			this.oDataManager = new DataManager(this);
		},

		onSuccess: function () {
			sap.git.usage.Reporting.setUser(this, this.sUser);
			this.getRouter().initialize();
		},

		onFailed: function (error) {
			if (this.oAuth.auth) {
				MessageToast.show("Error while reading data!\nLog:" + error);
				this.getRouter().initialize();
			} else {
				this._navigateToNotFound();
			}
		},

		_navigateToNotFound: function () {
			this.getRouter().getTargets().display(["emptyMaster", "notFound"]);
		},

		navTo: function (oRoute) {
			this.getRouter().navTo(oRoute);
		},

		getDataSource: function (service) {
			var sReturnValue;
			sReturnValue = this.sFirstSlash + "intic/sap/ZS_CX_CCS_SRV/";
			// switch (service) {
			// 	case "env_PG_AGS_DASHBOARDS":
			// 		sReturnValue = this.sFirstSlash + "intic/sap/ZS_CX_CCS_SRV/";
			// 		break;
			// 	case "env_PG_MDF":
			// 		sReturnValue = this.sFirstSlash + "sap/opu/odata/svx/MDF_SRV/";
			// 		break;
			// 	case "env_PG_ESCALATIONS":
			// 		sReturnValue = this.sFirstSlash + "sap/opu/odata/sap/ZS_ESCALATIONS/";
			// 		break;
			// 	default:
			// 		sReturnValue = this.sFirstSlash + "intic/sap/ZS_CX_CCS_SRV/";
			// }
			return sReturnValue;
		},

		getCurrentRoute: function () {
			return HashChanger.getInstance().getHash();
		},

		registerForPush: function () {
			//MessageToast.show("sap.Push: " + JSON.stringify(sap.Push));
			if (sap.Push) {
				//sap.m.MessageToast.show("try to register");
				var nTypes = sap.Push.notificationType.SOUNDS | sap.Push.notificationType.ALERT | sap.Push.notificationType.BADGE;
				sap.Push.registerForNotificationTypes(nTypes, this.regSuccess.bind(this), this.regFailure.bind(this),
					this.processNotificationFrontend.bind(this), ""); //GCM Sender ID, null for APNS
				//{}, ""); //GCM Sender ID, null for APNS
			}
		},

		regSuccess: function (result) {
			//sap.m.MessageToast.show("Successfully registered:" + JSON.stringify(result));
			//console.log("Successfully registered:" + JSON.stringify(result));
		},

		regFailure: function (errorInfo) {
			sap.m.MessageToast.show("Error while registering:" + JSON.stringify(errorInfo));
		},

		refreshNotification: function () {
			//sap.m.MessageToast.show("sap.Push: " + JSON.stringify(sap.Push));
			//this.getRouter().navTo("pushNotification");
		},

		processNotificationFrontend: function (notification) {
			sap.m.MessageBox.confirm("You received a new push notification. Do you want to check it in Notification Message center?", {
				onClose: function (oAction) {
					if (oAction === "OK") {
						this.getRouter().navTo("pushNotification");
					}
				}.bind(this)
			});
		},

		resetBadgeSuccess: function (result) {
			sap.m.MessageToast.show("Badge has been reset: " + JSON.stringify(result));
		},

		_requireReuseLib: function () {
			this._mobileReporting();

			try {
				jQuery.sap.require("sap.support.mccactivities.HelpScreens.CaseF4Help");
			} catch (oEvent) {
				sap.m.MessageToast.show(oEvent);
			}

			try {
				jQuery.sap.require("sap.support.mccactivities.HelpScreens.CustomerF4Help");
			} catch (oEvent) {
				sap.m.MessageToast.show(oEvent);
			}

			// Add push notification event (Device push notification register)
			document.addEventListener("onSapLogonSuccess", this.registerForPush.bind(this), false);
			document.addEventListener("onSapResumeSuccess", this.refreshNotification.bind(this), false);
			//this.registerForPush();
		},

		// _checkEnvironment: function() {
		// 	var url = document.location.toString();
		// 	var arrUrl = url.split("//");
		// 	var start = arrUrl[1].indexOf("/");
		// 	var relUrl = arrUrl[1].substring(start);
		// 	if (relUrl.indexOf("?") !== -1) {
		// 		relUrl = relUrl.split("?")[0];
		// 	}
		// 	//if current path is '/webapp/', means application is running in local web IDE
		// 	var bLocalWebIde = relUrl.indexOf("/webapp/") > -1;
		// 	this.sFirstSlash = bLocalWebIde ? "/" : "";

		// 	this.sFioriLaunchpad = !window["sap-fiori-ui5-bootstrap"] ? "" : "sap/fiori/mccactivities/";
		// },

		_mobileReporting: function () {
			sap.git = sap.git || {};
			sap.git.usage = sap.git.usage || {};
			sap.git.usage.Reporting = {
				_lp: null,
				_load: function (a) {
					this._lp = this._lp || sap.ui.getCore().loadLibrary("sap.git.usage", {
						url: "ht" + "tps://trackingshallwe.hana.ondemand.com/web-client/v3",
						async: !0
					});
					this._lp.then(function () {
						a(sap.git.usage.MobileUsageReporting);
					}, this._loadFailed);
				},
				_loadFailed: function (a) {
					jQuery.sap.log.warning("[sap.git.usage.MobileUsageReporting]", "Loading failed: " + a);
				},
				setup: function (a) {
					this._load(function (b) {
						b.setup(a);
					});
				},
				addEvent: function (a, b) {
					this._load(function (c) {
						c.addEvent(a, b);
					});
				},
				setUser: function (a, b) {
					this._load(function (c) {
						c.setUser(a, b);
					});
				}
			};

			sap.git.usage.Reporting.setup(this);
		}
	});

});