function openValueHelpCustomer(fieldId, oController, searchOnly) {
	//	ID Pop Up: valueHelpCustomer

	// Variables which need to be filled in the controller:
	//  - customerFavF4Help
	//  - env_PG_ESCALATIONS (for calling GW Service)
	//  - oModelCustomer
	//  - Method -> getCustomerFavorites
	//  - user
	//	- customerF4help 

	// fieldId have to start with "MASTER" if only save and no select (F4 Help) should be possible
	if (sap.ui.getCore().byId("valueHelpCustomer") != undefined)
		sap.ui.getCore().byId("valueHelpCustomer").destroy();

	var oValueHelpDialogCustomerID = new sap.m.Dialog("valueHelpCustomer", {
		title: "Customer Search",
		close: function(oEvent) {}
	});
	oController.oModelCustomer = new sap.ui.model.json.JSONModel();
	this.oController = oController;

	//-------------------------------------- Radio Buttons --------------------------------------------------------------

	if (searchOnly != true) {
		var oLayout = new sap.m.FlexBox("matrixCustomerF4Help");
		//
		//  oLayout.setLayoutFixed(false);
		//  oLayout.setColumns(3);

		var radioButtonCustomers = jQuery.proxy(function(oEvent) {
			if (oEvent.getSource().getId() == "radioButtonFavoritesCustomer") {
				sap.ui.getCore().byId("LayoutCustomerF4Help").setVisible(false);

				sap.ui.getCore().byId("fastSearchCustomerID").setVisible(false);
				sap.ui.getCore().byId("buttonCustomerF4HelpSearch").setVisible(false);
				sap.ui.getCore().byId("buttonCustomerF4HelpBack").setVisible(false);

				//	  		  if(fieldId.indexOf("MASTER") > -1)
				//	  			  sap.ui.getCore().byId("buttonCustomerF4HelpSelect").setVisible(false);
				//	  		  else  sap.ui.getCore().byId("buttonCustomerF4HelpSelect").setVisible(true);

				sap.ui.getCore().byId("buttonCustomerF4HelpSelectandFav").setVisible(false);
				sap.ui.getCore().byId("button_CUSTOMER_REM").setVisible(true);

				var table = sap.ui.getCore().byId("customerTableF4Help");

				oController.oModelCustomer.setData({
					modelData: oController.customerFavF4Help
				});
				table.setModel(oController.oModelCustomer);
				table.bindAggregation("items", "/modelData", sap.ui.getCore().byId("oTemplateCustTable"));

				sap.ui.getCore().byId("customerTableF4Help").setVisible(true);

			} else if (oEvent.getSource().getId() == "radioButtonFastSearchCustomer") {
				sap.ui.getCore().byId("fastSearchCustomerID").setVisible(true);
				sap.ui.getCore().byId("LayoutCustomerF4Help").setVisible(false);
				sap.ui.getCore().byId("customerTableF4Help").setVisible(true);
				sap.ui.getCore().byId("buttonCustomerF4HelpSearch").setVisible(false);
				sap.ui.getCore().byId("buttonCustomerF4HelpBack").setVisible(false);
				sap.ui.getCore().byId("buttonCustomerF4HelpSelect").setVisible(true);
				sap.ui.getCore().byId("buttonCustomerF4HelpSelectandFav").setVisible(true);
				sap.ui.getCore().byId("button_CUSTOMER_REM").setVisible(false);
				table = sap.ui.getCore().byId("customerTableF4Help");
			} else {
				sap.ui.getCore().byId("fastSearchCustomerID").setVisible(false);

				//	  		  if(fieldId.indexOf("MASTER") > -1)
				//	  		  {
				//	  			  sap.ui.getCore().byId("buttonCustomerF4HelpSearch").setVisible(true);
				//	  			  sap.ui.getCore().byId("buttonCustomerF4HelpSaveandFav").setVisible(false);
				//	  		  }
				//	  		  else
				//	  		  {
				//	  			  sap.ui.getCore().byId("buttonCustomerF4HelpSearch").setVisible(true);
				//	  			  sap.ui.getCore().byId("buttonCustomerF4HelpSaveandFav").setVisible(false);
				//	  		  }

				sap.ui.getCore().byId("buttonCustomerF4HelpBack").setVisible(false);
				sap.ui.getCore().byId("buttonCustomerF4HelpSelect").setVisible(false);
				sap.ui.getCore().byId("buttonCustomerF4HelpSelectandFav").setVisible(false);
				sap.ui.getCore().byId("customerTableF4Help").setVisible(false);
				sap.ui.getCore().byId("LayoutCustomerF4Help").setVisible(true);
				sap.ui.getCore().byId("button_CUSTOMER_REM").setVisible(false);
				table = sap.ui.getCore().byId("customerTableF4Help");
			}
		}, this);

		var oRB1 = new sap.m.RadioButton("radioButtonFavoritesCustomer", {
			text: 'Favorites',
			tooltip: 'Favorites',
			groupName: 'Customers',
			selected: true,
			select: radioButtonCustomers
		});

		var oRB2 = new sap.m.RadioButton("radioButtonFastSearchCustomer", {
			text: 'Fast Search',
			tooltip: 'Fast Search',
			groupName: 'Customers',
			select: radioButtonCustomers
		});

		oRB2.setVisible(false);

		var oRB3 = new sap.m.RadioButton("radioButtonSearchCustomer", {
			text: 'Search',
			tooltip: 'Search',
			groupName: 'Customers',
			select: radioButtonCustomers
		});

		oLayout.addItem(oRB1);
		oLayout.addItem(oRB2);
		oLayout.addItem(oRB3);

		oValueHelpDialogCustomerID.addContent(oLayout);

	}

	//-------------------------------------- Fast Search --------------------------------------------------------------

	var fastSearchCustomer = jQuery.proxy(function(oEvent) {
		startFastSearchCustomer(oEvent.getParameter("liveValue"));
	}, this);

	var iCustomerIDFastSearch = new sap.m.Input({
		id: 'fastSearchCustomerID',
		type: sap.m.InputType.Number,
		placeholder: 'Customer ID...',
		liveChange: fastSearchCustomer,
	});

	oValueHelpDialogCustomerID.addContent(iCustomerIDFastSearch);
	iCustomerIDFastSearch.setVisible(false);

	//-------------------------------------- Result Table --------------------------------------------------------------

	var o18nCustTable = new sap.ui.model.json.JSONModel();
	//comment out
	/*o18nCustTable.setData({
		erp_cust: "ERP Cust #",
		erp_name: "Name"
	});
	sap.ui.getCore().setModel(o18nCustTable, "i18nCustTable");*/

	var aColumnsCustTable = [
		new sap.m.Column({
			hAlign: "Left",
			styleClass: "limit",
			width: "30%",
			header: new sap.m.Label({
				text: "ERP Cust #"
			})
		}),
		new sap.m.Column({
			hAlign: "Left",
			styleClass: "limit",
			width: "70%",
			header: new sap.m.Label({
				text: "Name"
			})
		}),
	];

	if (sap.ui.getCore().byId("oTemplateCustTable") == undefined) {
		var oTemplatePhases = new sap.m.ColumnListItem("oTemplateCustTable", {
			unread: false,
			vAlign: "Middle",
			cells: [new sap.m.Text({
					text: "{key}",
				}),
				new sap.m.Text({
					text: "{value}",
				}),
			]
		});
	}

	if (sap.ui.getCore().byId("customerTableF4Help") == undefined) {
		var oHelpTableCustomer = new sap.m.Table("customerTableF4Help", {
			growing: false,
			growingThreshold: 2,
			inset: false,
			mode: "SingleSelect",
			showUnread: true,
			growingScrollToLoad: false,
			columns: aColumnsCustTable
		});
		oValueHelpDialogCustomerID.addContent(oHelpTableCustomer);
	}

	oHelpTableCustomer.setVisible(false);

	//-------------------------------------- Customer Search View --------------------------------------------------------------

	var oLayoutCustomerF4HelpSearch = new sap.m.FlexBox("LayoutCustomerF4Help", {
		direction: sap.m.FlexDirection.Column
	});

	var lCustBP = new sap.m.Label({
		text: 'Cust. BP'
	});
	var iCustBP = new sap.m.Input({
		id: 'custBPF4',
		type: sap.m.InputType.Number,
		placeholder: 'BP Number'
	});
	oLayoutCustomerF4HelpSearch.addItem(lCustBP);
	oLayoutCustomerF4HelpSearch.addItem(iCustBP);

	var lCustERP = new sap.m.Label({
		text: 'Cust. Number'
	});
	var iCustERP = new sap.m.Input({
		id: 'custERPF4',
		type: sap.m.InputType.Number,
		placeholder: 'ERP Number'
	});
	oLayoutCustomerF4HelpSearch.addItem(lCustERP);
	oLayoutCustomerF4HelpSearch.addItem(iCustERP);

	var lCustName = new sap.m.Label({
		text: 'Cust. Name'
	});
	var iCustName = new sap.m.Input({
		id: 'custNameF4',
		type: sap.m.InputType.Text,
		placeholder: 'Cust. Name'
	});
	oLayoutCustomerF4HelpSearch.addItem(lCustName);
	oLayoutCustomerF4HelpSearch.addItem(iCustName);

	var lCountry = new sap.m.Label({
		text: 'Country'
	});
	var iCountry = new sap.m.Input({
		id: 'custCountryCodeF4',
		type: sap.m.InputType.Text,
		placeholder: 'Country code e.g. DE'
	});
	oLayoutCustomerF4HelpSearch.addItem(lCountry);
	oLayoutCustomerF4HelpSearch.addItem(iCountry);

	var lZip = new sap.m.Label({
		text: 'Zip'
	});
	var iZip = new sap.m.Input({
		id: 'custZipF4',
		type: sap.m.InputType.Text,
	});
	oLayoutCustomerF4HelpSearch.addItem(lZip);
	oLayoutCustomerF4HelpSearch.addItem(iZip);

	var lCity = new sap.m.Label({
		text: 'City'
	});
	var iCity = new sap.m.Input({
		id: 'custCityF4',
		type: sap.m.InputType.Text,
	});
	oLayoutCustomerF4HelpSearch.addItem(lCity);
	oLayoutCustomerF4HelpSearch.addItem(iCity);

	oValueHelpDialogCustomerID.addContent(oLayoutCustomerF4HelpSearch);

	if (searchOnly)
		oLayoutCustomerF4HelpSearch.setVisible(true);
	else
		oLayoutCustomerF4HelpSearch.setVisible(false);

	//-------------------------------------- Buttons + Evenets --------------------------------------------------------------

	var searchCustomer = jQuery.proxy(function(oEvent) {

		var searchFields = new Object();
		searchFields.custBP = new sap.m.Text();
		searchFields.custBP = iCustBP.getValue();

		searchFields.custERP = new sap.m.Text();
		searchFields.custERP = iCustERP.getValue();

		searchFields.custName = new sap.m.Text();
		searchFields.custName = iCustName.getValue();

		searchFields.custCountry = new sap.m.Text();
		searchFields.custCountry = iCountry.getValue();

		searchFields.custZip = new sap.m.Text();
		searchFields.custZip = iZip.getValue();

		searchFields.custCity = new sap.m.Text();
		searchFields.custCity = iCity.getValue();

		if (searchFields.custBP === "" && searchFields.custERP === "" && searchFields.custName === "" && searchFields.custCountry === "" &&
			searchFields.custZip === "" && searchFields.custCity === "") {
			sap.m.MessageToast.show("No Search Criteria Entered");
		} else {
			iCustBP.removeAllCustomData();
			iCustERP.removeAllCustomData();
			iCustName.removeAllCustomData();
			iCountry.removeAllCustomData();
			iZip.removeAllCustomData();
			iCity.removeAllCustomData();

			iCustBP.setValue("");
			iCustERP.setValue("");
			iCustName.setValue("");
			iCountry.setValue("");
			iZip.setValue("");
			iCity.setValue("");

			//  view.customerF4help = "x";

			//		  if(fieldId.indexOf("MASTER") > -1)
			//		  {
			//			  sap.ui.getCore().byId("buttonCustomerF4HelpSelect").setVisible(false);
			//			  sap.ui.getCore().byId("buttonCustomerF4HelpSelectandFav").setVisible(false);
			//			  sap.ui.getCore().byId("buttonCustomerF4HelpSaveandFav").setVisible(true);
			//		  }
			//		  else
			//		  {
			//			  sap.ui.getCore().byId("buttonCustomerF4HelpSelect").setVisible(true);
			//			  sap.ui.getCore().byId("buttonCustomerF4HelpSelectandFav").setVisible(true);
			//			  sap.ui.getCore().byId("buttonCustomerF4HelpSaveandFav").setVisible(false);
			//		  }
			//		  
			//		  sap.ui.getCore().byId("customerTableF4Help").setVisible(true);
			//		  sap.ui.getCore().byId("LayoutCustomerF4Help").setVisible(false);
			//		  sap.ui.getCore().byId("buttonCustomerF4HelpBack").setVisible(true);
			//		  sap.ui.getCore().byId("buttonCustomerF4HelpSearch").setVisible(false);
			//		  sap.ui.getCore().byId("button_CUSTOMER_REM").setVisible(false);

			if (searchOnly) {
				sap.ui.getCore().byId("customerTableF4Help").setVisible(true);
				sap.ui.getCore().byId("LayoutCustomerF4Help").setVisible(false);
				sap.ui.getCore().byId("buttonCustomerF4HelpBack").setVisible(true);
				sap.ui.getCore().byId("buttonCustomerF4HelpSearch").setVisible(false);
				sap.ui.getCore().byId("button_CUSTOMER_REM").setVisible(false);
				sap.ui.getCore().byId("buttonCustomerF4HelpSelect").setVisible(true);
				sap.ui.getCore().byId("buttonCustomerF4HelpSelectandFav").setVisible(false);
				sap.ui.getCore().byId("buttonCustomerF4HelpSaveandFav").setVisible(false);
				sap.ui.getCore().byId("buttonCustomerF4HelpCancel").setVisible(false);
			}

			startSearchCustomer(searchFields);
		}
	}, this);

	var selectCustomer = jQuery.proxy(function(oEvent) {

		var oCore = sap.ui.getCore();
		var oMatnrInput = fieldId;
		var oSel = oHelpTableCustomer.getModel().getProperty(oHelpTableCustomer.getSelectedContextPaths()[0]);

		if (oSel != null) {
			oMatnrInput.setValue(oSel["key"]);
			oMatnrInput.setTooltip(oSel["value"]);
			//		  setCustomerInformation();
			if (sap.ui.getCore().byId("valueHelpCustomer") != undefined) {
				sap.ui.getCore().byId("valueHelpCustomer").close();
				oEvent.getSource().getParent().destroy();
			}
		} else sap.m.MessageToast.show("Please Select an entry first!");

	}, this);

	var selectCustomerandFav = jQuery.proxy(function(oEvent) {

		var oCore = sap.ui.getCore();
		var oMatnrInput = oCore.byId(fieldId);
		var oSel = oHelpTableCustomer.getModel().getProperty(oHelpTableCustomer.getSelectedContextPaths()[0]);

		if (oSel != null) {
			oMatnrInput.setValue(oSel["key"]);
			oMatnrInput.setTooltip(oSel["value"]);

			//		  setCustomerInformation();
			this.setSavedViewCustomer(oMatnrInput.getValue(), "");

			if (sap.ui.getCore().byId("valueHelpCustomer") != undefined) {
				sap.ui.getCore().byId("valueHelpCustomer").close();
				oEvent.getSource().getParent().destroy();
			}
		} else sap.m.MessageToast.show("Please Select an entry first!");

	}, this);

	var saveCustomerandFav = jQuery.proxy(function(oEvent) {

		var oCore = sap.ui.getCore();
		var oSel = oHelpTableCustomer.getModel().getProperty(oHelpTableCustomer.getSelectedContextPaths()[0]);

		if (oSel != null) {
			this.setSavedViewCustomer(oSel["key"], "X");
			//location.reload();
			window.history.go(0);
		}

	}, this);

	var backCustomer = jQuery.proxy(function(oEvent) {
		sap.ui.getCore().byId("customerTableF4Help").setVisible(false);
		sap.ui.getCore().byId("LayoutCustomerF4Help").setVisible(true);
		sap.ui.getCore().byId("buttonCustomerF4HelpBack").setVisible(false);
		sap.ui.getCore().byId("buttonCustomerF4HelpSelect").setVisible(false);
		sap.ui.getCore().byId("buttonCustomerF4HelpSearch").setVisible(true);
		sap.ui.getCore().byId("button_CUSTOMER_REM").setVisible(false);
		sap.ui.getCore().byId("buttonCustomerF4HelpSelectandFav").setVisible(false);
		sap.ui.getCore().byId("buttonCustomerF4HelpSaveandFav").setVisible(false);
		sap.ui.getCore().byId("buttonCustomerF4HelpCancel").setVisible(true);

	}, this);

	var customer_favorites_remove = jQuery.proxy(function(oEvent) {

		var oCore = sap.ui.getCore();
		var oMatnrInput = oCore.byId("idMatnrInputMyCustomer");
		var oSel = oHelpTableCustomer.getModel().getProperty(oHelpTableCustomer.getSelectedContextPaths()[0]);

		if (oSel != null) {
			//		  if(fieldId.indexOf("MASTER") > -1)
			//			  this.deleteSavedViewCustomer(oSel["key"], "X");
			//		  else  
			this.deleteSavedViewCustomer(oSel["key"], "");

			sap.ui.getCore().byId("valueHelpCustomer").close();
		}

		if (sap.ui.getCore().byId("valueHelpCustomer") != undefined)
			oEvent.getSource().getParent().destroy();

	}, this);

	var oCancelButton = new sap.m.Button("buttonCustomerF4HelpCancel", {
		text: "Cancel",
		press: function(oEvent) {
			oEvent.getSource().getParent().close();

			if (oEvent.getSource().getParent() != undefined)
				oEvent.getSource().getParent().destroy();

		}
	});

	if (sap.ui.getCore().byId("buttonCustomerF4HelpSearch") == undefined) {
		var oSearchButton = new sap.m.Button("buttonCustomerF4HelpSearch", {
			text: "Search",
			press: searchCustomer
		});
	}

	if (sap.ui.getCore().byId("buttonCustomerF4HelpSelect") == undefined) {
		var oSelectButton = new sap.m.Button("buttonCustomerF4HelpSelect", {
			text: "Select",
			press: selectCustomer
		});
	}

	if (sap.ui.getCore().byId("buttonCustomerF4HelpSelectandFav") == undefined) {
		var oSelectandFavButton = new sap.m.Button("buttonCustomerF4HelpSelectandFav", {
			text: "Select and save as favorite",
			press: selectCustomerandFav
		});
	}

	if (sap.ui.getCore().byId("buttonCustomerF4HelpSaveandFav") == undefined) {
		var oSaveFavButton = new sap.m.Button("buttonCustomerF4HelpSaveandFav", {
			text: "Save as favorite",
			press: saveCustomerandFav
		});
	}

	if (sap.ui.getCore().byId("button_CUSTOMER_REM") == undefined) {
		var oOkButtonCustomer_REM = new sap.m.Button("button_CUSTOMER_REM", {
			text: "Remove Customer from Favorites",
			press: customer_favorites_remove,
		});
	}

	if (sap.ui.getCore().byId("buttonCustomerF4HelpBack") == undefined) {
		var oBackButton = new sap.m.Button("buttonCustomerF4HelpBack", {
			text: "Back",
			press: backCustomer
		});
	}

	oValueHelpDialogCustomerID.addButton(oBackButton);
	oValueHelpDialogCustomerID.addButton(oCancelButton);
	oValueHelpDialogCustomerID.addButton(oSearchButton);
	oValueHelpDialogCustomerID.addButton(oSelectButton);
	oValueHelpDialogCustomerID.addButton(oSaveFavButton);
	oValueHelpDialogCustomerID.addButton(oOkButtonCustomer_REM);
	oValueHelpDialogCustomerID.addButton(oSelectandFavButton);
	oValueHelpDialogCustomerID.open();

	sap.ui.getCore().byId("customerTableF4Help").setVisible(true);
	sap.ui.getCore().byId("buttonCustomerF4HelpBack").setVisible(false);

	//  if(fieldId.indexOf("MASTER") > -1)
	//	  sap.ui.getCore().byId("buttonCustomerF4HelpSelect").setVisible(false);

	sap.ui.getCore().byId("buttonCustomerF4HelpSearch").setVisible(false);
	sap.ui.getCore().byId("buttonCustomerF4HelpSelectandFav").setVisible(false);
	sap.ui.getCore().byId("button_CUSTOMER_REM").setVisible(true);
	sap.ui.getCore().byId("buttonCustomerF4HelpSaveandFav").setVisible(false);

	var table = sap.ui.getCore().byId("customerTableF4Help");

	oController.oModelCustomer.setData({
		modelData: oController.customerFavF4Help
	});

	table.setModel(oController.oModelCustomer);
	table.bindAggregation("items", "/modelData", sap.ui.getCore().byId("oTemplateCustTable"));

	if (searchOnly) {
		sap.ui.getCore().byId("fastSearchCustomerID").setVisible(false);
		sap.ui.getCore().byId("LayoutCustomerF4Help").setVisible(true);
		sap.ui.getCore().byId("customerTableF4Help").setVisible(false);
		sap.ui.getCore().byId("buttonCustomerF4HelpSearch").setVisible(true);
		sap.ui.getCore().byId("buttonCustomerF4HelpBack").setVisible(false);
		sap.ui.getCore().byId("buttonCustomerF4HelpSelect").setVisible(false);
		sap.ui.getCore().byId("buttonCustomerF4HelpSelectandFav").setVisible(false);
		sap.ui.getCore().byId("button_CUSTOMER_REM").setVisible(false);
	}

}

//----------------------------------------------------------------------------------------------------
// FAST Search -- Customer
//----------------------------------------------------------------------------------------------------
function startFastSearchCustomer(filter) {

	var that = this;
	var custURL = this.oController.env_PG_ESCALATIONS + "BPAccountList?$filter=";
	custURL += "account_name eq '" + filter + "' and type eq 'B'";
	custURL += "&$format=json";

	that.listCustomerF4Help = [];

	jQuery.ajax({
		async: false,
		url: custURL,
		type: "get",
		dataType: "json",
		success: function(data) {

			var oCase = new Object();
			oCase = data.d.results;

			for (var i = 0; i < oCase.length; i++) {

				that.listCustomerF4Help[i] = {};
				that.listCustomerF4Help[i].key = oCase[i].customer_no;
				that.listCustomerF4Help[i].value = oCase[i].account_name;

			}

			var table = sap.ui.getCore().byId("customerTableF4Help");
			that.oController.oModelCustomer.setData({
				modelData: that.listCustomerF4Help
			});
			table.setModel(that.oController.oModelCustomer);
			table.bindAggregation("items", "/modelData", sap.ui.getCore().byId("oTemplateCustTable"));

		},
		error: function() {
			sap.m.MessageToast.show("Error during search");
		}
	});
}

//----------------------------------------------------------------------------------------------------
// Search -- Customer
//----------------------------------------------------------------------------------------------------

function startSearchCustomer(searchFields) {

	var table = sap.ui.getCore().byId("customerTableF4Help");
	table.setBusy(true);

	var clickbuttonSearchCustomerResult = jQuery.proxy(function(oEvent) {
		sap.m.MessageToast.show("select Customer");
		var source = oEvent.getSource();
		var attributes = source.getAttributes();
		var properties = attributes[1].getProperty("text");
		this._BPcustNoSelected = properties.substring(7, properties.length);
		properties = attributes[0].getProperty("text");
		this._ERPcustNoSelected = properties.substring(8, properties.length);
		this._custNameSelected = source.getProperty("title");

		//		this._view._app.to("activityAppSearchCustResultFavorites");

	}, this);

	var filter = "";
	var count = 0;
	var that = this;
	this.customerSearchCount++;
	var custURL = this.oController.env_PG_ESCALATIONS + "/BPAccountList?$filter=";

	if (searchFields.custBP != "" && searchFields.custBP != "0") {
		filter += "partner%20eq%20'" + searchFields.custBP + "'";
		count++;
	}
	if (searchFields.custERP !== "" && searchFields.custERP != "0") {
		if (count > 0)
			filter += "and%20customer_no%20eq%20'" + searchFields.custERP + "'%20";
		else filter += "customer_no%20eq%20'" + searchFields.custERP + "'%20";
		count++;
	}
	if (searchFields.custName != "" && searchFields.custName != "0") {
		if (count > 0)
			filter += "and%20mc_name1%20eq%20'" + searchFields.custName + "'%20";
		else filter += "mc_name1%20eq%20'" + searchFields.custName + "'%20";
		count++;
	}
	if (searchFields.custCountry != "" && searchFields.custCountry != "0") {
		if (count > 0)
			filter += "and%20country%20eq%20'" + searchFields.custCountry + "'%20";
		else filter += "country%20eq%20'" + searchFields.custCountry + "'%20";
		count++;
	}
	if (searchFields.custZip != "" && searchFields.custZip != "0") {
		if (count > 0)
			filter += "and%20zip%20eq%20'" + searchFields.custZip + "'%20";
		else filter += "zip%20eq%20'" + searchFields.custZip + "'%20";
		count++;
	}
	if (searchFields.custCity != "" && searchFields.custCity != "0") {
		if (count > 0)
			filter += "and%20city%20eq%20'" + searchFields.custCity + "'%20";
		else filter += "city%20eq%20'" + searchFields.custCity + "'%20";
		count++;
	}

	custURL += filter + "%20and%20type%20eq%20'A'";

	if (count > 0) {

		//		if(that.view.customerF4help != "x")
		//			this.view._app.to("activityAppLoadingView");

		custURL += "&$format=json";

		that.listCustomerF4Help = [];

		jQuery.ajax({
			async: true,
			url: custURL,
			type: "get",
			dataType: "json",
			success: function(data) {

				var customers = new Object();
				customers = data.d.results;

				for (var i = 0; i < customers.length; i++) {
					if (customers[i].customer_no != "") {
						that.listCustomerF4Help[that.listCustomerF4Help.length] = {};
						that.listCustomerF4Help[that.listCustomerF4Help.length - 1].key = customers[i].customer_no;
						that.listCustomerF4Help[that.listCustomerF4Help.length - 1].value = customers[i].account_name;
					}
				}

				table = sap.ui.getCore().byId("customerTableF4Help");
				that.oController.oModelCustomer.setData({
					modelData: that.listCustomerF4Help
				});

				table.setModel(that.oController.oModelCustomer);
				table.bindAggregation("items", "/modelData", sap.ui.getCore().byId("oTemplateCustTable"));

				table.setBusy(false);

			},
			error: function() {
				sap.m.MessageToast.show("Error during search");
				//				that._view._app.to("activityAppStart");
			}

		});
	}
}

//----------------------------------------------------------------------------------------------------
//set saved view - Customer
//----------------------------------------------------------------------------------------------------
function setSavedViewCustomer(custNo, flag) {

	var alreadyFavorite;

	for (var i = 0; i < this.oController.customerFavF4Help.length; i++) {
		if (this.oController.customerFavF4Help[i].key != custNo)
			alreadyFavorite = false;
		else {
			alreadyFavorite = true;
			break;
		}
	}

	if (!alreadyFavorite) {
		var that = this;
		var sUrl = '/intic/sap/SVX/MDF_SRV/';
		var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);

		oModel.refreshSecurityToken();
		var oModelHeaders = oModel.getHeaders();

		var oHeaders = {
			"x-csrf-token": oModelHeaders['x-csrf-token'],
			"Content-Type": "application/json; charset=utf-8",
		};
		var sCollection = sUrl + "Favorites";

		var oModelPICreate = new sap.ui.model.json.JSONModel({
			PIList: [{
				Entity: custNo,
				Type: 'C',
				Groupid: 'SUPPORT'
			}]
		});

		jQuery.ajax({

			async: false,
			url: sCollection,
			type: "POST",
			dataType: "json",
			headers: oHeaders,
			data: JSON.stringify(oModelPICreate.oData.PIList[0]),
			success: function(data) {
				sap.m.MessageToast.show("Created Successfull");
			},

			error: function() {
				sap.m.MessageToast.show("Creation failed");

			}
		});

		//Comment out errors
		/*if(flag == "")
			createFavoriteFromF4Help();*/
	} else {
		sap.m.MessageToast.show("Customer already set as favorite");
	}

}

//Comment out errors
/*function createFavoriteFromF4Help() {

	var custList = sap.ui.getCore().byId("myCustomerList");
	this.oController.getCustomerFavorites();
	custList.destroyItems();
	
	var clickListCustomer = jQuery.proxy(function(oEvent) {
		
		var source = oEvent.getSource();
		var properties = source.getSelectedItem().getTitle();
		var ERPcustNoSelected = properties.substring(0, properties.indexOf("/"));
		var CustomerName = properties.substring(properties.indexOf("/")+1);
		
		sap.ui.getCore().byId("detail").destroyContent();
		
		var urlFilter = ERPcustNoSelected+"'";
		
		sap.ui.getCore().byId("detail").addContent(setTiles("CUSTOMER", ERPcustNoSelected, CustomerName, urlFilter));
		setTileNumbers();
		
	}, this);

	for(var i = 0; i < this.oController.customerFavArray.length; i++)
	{
		if(sap.ui.getCore().byId("ID"+this.oController.customerFavArray[i].customer_r3_no) == undefined)
		{
			custList.addItem(new sap.m.StandardListItem("ID"+this.oController.customerFavArray[i].customer_r3_no,{
				title : this.oController.customerFavArray[i].customer_r3_no + "/" + this.oController.customerFavArray[i].custome_name,
				type: sap.m.ListType.Active,
				showMarkers: true,
				markFavorite: this.oController.customerFavArray[i].favorite,
				select : clickListCustomer,
			}));
		}
	}	
}*/

//----------------------------------------------------------------------------------------------------
//delete saved view - Custoemr
//----------------------------------------------------------------------------------------------------
function deleteSavedViewCustomer(custNo, flag) {
	// save all customers who schould be shwon on first page
	//Achtung - StartPage muss angepasst werden...

	var user = "";
	if (this.controllerNav == undefined)
		user = this.oController.user;
	/*else this.controllerNav.user;*/

	var that = this;
	var sUrl = '/intic/sap/SVX/MDF_SRV/';
	var sCollection = sUrl + "Favorites(Type='C',Entity='" + custNo + "',Userid='" + user + "',Groupid='SUPPORT')";

	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	oModel.refreshSecurityToken();

	var oEntry = {};

	oEntry.Entity = custNo;
	oEntry.Type = "C";
	oEntry.Userid = user;
	oEntry.Groupid = "SUPPORT";

	var linkRemove = "/Favorites(Type='C',Entity='" + custNo + "',Userid='" + user + "',Groupid='SUPPORT')";

	oModel.remove(linkRemove, oEntry, null, function() {
		sap.m.MessageToast.show("Deleted Successfull");
	}, function() {
		sap.m.MessageToast.show("Deletion failed");
	});

	if (flag == "") {
		if (this.controllerNav != undefined) {
			//Comment out errors
			//createCustomerFavoriteFromF4Help();
		} else {
			this.oController.getCustomerFavorites();
		}
	} else
	//location.reload();
		window.history.go(0);

}