//this._sFLP = this._checkIfFLP();
this.sFirstSlash = "/";//this._checkIfWebIDE();
this._oModelResults = new sap.ui.model.json.JSONModel();
this._oDataModelCaseId = new sap.ui.model.odata.v2.ODataModel({
	json: true,
	serviceUrl: this.sFirstSlash + "intic/sap/ZS_CX_CCS_SRV/"
});
this._oResult = {
	caseId: "",
	custNo: ""
};

function openValueHelpDialog(oCaseId, oCustNo, oController) {
	var that = this;
	var oValueHelpDialogCaseID = new sap.m.Dialog("iValueHelpCaseID", {
		title: "Dialog",
		beginButton: new sap.m.Button({
			text: "OK",
			press: function(oEvent) {
				that._dialogConfirm(oEvent, oController);
			}
		}),
		endButton: new sap.m.Button({
			text: "Cancel",
			press: function(oEvent) {
				that._dialogClose(oEvent);
			}
		})
	});

	var oObjectHeader = new sap.m.ObjectHeader("iF4ObjectHeader", {
		title: "Case Help",
		backgroundDesign: "Transparent"
	});

	var oIconTabBar = new sap.m.IconTabBar({
		items: [new sap.m.IconTabFilter({
			text: "Search",
			content: new sap.ui.layout.VerticalLayout({
				content: [new sap.ui.layout.form.SimpleForm("iSearchSimpleForm", {
					maxContainerCols: 1,
					layout: "ResponsiveGridLayout",
					editable: true,
					labelSpanXL: 3,
					labelSpanL: 3,
					labelSpanM: 3,
					labelSpanS: 6,
					emptySpanXL: 4,
					emptySpanL: 4,
					emptySpanM: 4,
					emptySpanS: 1,
					content: [new sap.m.Label({
						text: "Case Id"
					}), new sap.m.Input("iCaseIdInput", {
						type: "Number"
					}), new sap.m.Label({
						text: "ERP Number"
					}), new sap.m.Input("iERPNoInput", {
						type: "Number"
					}), new sap.m.Label({
						text: "CRM BP Number"
					}), new sap.m.Input("iBPNoInput", {
						type: "Number"
					}), new sap.m.Label({
						text: "Customer Name"
					}), new sap.m.Input("iCusNameInput", {
						type: "Text"
					}), new sap.m.Label({
						text: "Free Text field"
					}), new sap.m.Input("iFreeTextInput", {
						type: "Text"
					})]
				}), new sap.m.Button("iSearchBtn", {
					type: "Accept",
					text: "Search",
					press: function(oEvent) {
						that._onPressSearch(oController);
					}
				}), new sap.m.Table("iResultsTable", {
					mode: "SingleSelectLeft",
					headerToolbar: new sap.m.Toolbar({
						content: new sap.m.Title({
							text: "Results"
						})
					}),
					columns: [new sap.m.Column({
						header: new sap.m.Text({
							text: "Case ID"
						})
					}), new sap.m.Column({
						header: new sap.m.Text({
							text: "Title"
						}),
						minScreenWidth: "Tablet",
						demandPopin: true
					}), new sap.m.Column({
						header: new sap.m.Text({
							text: "Type"
						}),
						minScreenWidth: "Tablet",
						demandPopin: true
					}), new sap.m.Column({
						header: new sap.m.Text({
							text: "CRM BP Number"
						}),
						minScreenWidth: "Tablet",
						demandPopin: true
					}), new sap.m.Column({
						header: new sap.m.Text({
							text: "Customer Number"
						}),
						minScreenWidth: "Tablet",
						demandPopin: true
					}), new sap.m.Column({
						header: new sap.m.Text({
							text: "Customer Name"
						})
					})],
					items: {
						path: "caseIdResults>/results",
						template: new sap.m.ColumnListItem({
							cells: [new sap.m.Text({
								text: "{caseIdResults>case_id}"
							}), new sap.m.Text({
								text: "{caseIdResults>case_title}"
							}), new sap.m.Text({
								text: "{caseIdResults>case_type_text}"
							}), new sap.m.Text({
								text: "{caseIdResults>customer_bp_id}"
							}), new sap.m.Text({
								text: "{caseIdResults>customer_r3_no}"
							}), new sap.m.Text({
								text: "{caseIdResults>customer_name}"
							})]
						})
					}
				})]
			})
		}), new sap.m.IconTabFilter({
			text: "Favorites",
			content: new sap.m.Table("iFavTable", {
				headerToolbar: new sap.m.Toolbar({
					content: new sap.m.Title({
						text: "Favorite Case Id"
					})
				})
			})
		})]
	});

	oValueHelpDialogCaseID.addContent(oObjectHeader);
	oValueHelpDialogCaseID.addContent(oIconTabBar);

	// Handle if customer number is input
	this._checkInitialSearch(oCaseId, oCustNo, oController);

	// Set Model
	this._setResultsModel(oController);
	// Add dependent to view
	oController.getView().addDependent(oValueHelpDialogCaseID);
	oValueHelpDialogCaseID.open();
}

function _checkInitialSearch(oCaseId, oCustNo, oController) {
	if ((oCaseId !== null && oCaseId !== "") || (oCustNo !== null && oCustNo !== "")) {
		if (oCaseId !== null && oCaseId !== "") {
			sap.ui.getCore().byId("iCaseIdInput").setValue(oCaseId);
		}
		if (oCustNo !== null && oCustNo !== "") {
			sap.ui.getCore().byId("iERPNoInput").setValue(oCustNo);
		}
		this._onPressSearch(oController);
	}
}

function _dialogConfirm(oEvent, oController) {
	var oItem = sap.ui.getCore().byId("iResultsTable").getSelectedItem();
	if (oItem !== null) {
		this._oResult.caseId = oItem.getCells()[0].getProperty("text");
		this._oResult.custNo = oItem.getCells()[4].getProperty("text");
		oController.setSelectedCaseResult(this._oResult);
	}
	this._dialogClose(oEvent);
}

function _dialogClose(oEvent) {
	oEvent.getSource().getParent().close();
	oEvent.getSource().getParent().destroy();
}

function _setResultsModel(oController) {
	oController.getView().setModel(this._oModelResults, "caseIdResults");
}

function _readCaseIdData(oController) {
	var that = this;
	this._oDataModelCaseId.read("/CaseList", {
		filters: that._setFilter(),
		success: function(oData) {
			that._oModelResults.setData(oData);
			that._setResultsModel(oController);
			sap.ui.getCore().byId("iResultsTable").setBusy(false);
		},
		error: function() {
			sap.ui.getCore().byId("iResultsTable").setBusy(false);
		}
	});
}

function _setFilter() {
	var vEq = sap.ui.model.FilterOperator.EQ;
	//var vNe = sap.ui.model.FilterOperator.NE;
	var aFilter = [];
	if (sap.ui.getCore().byId("iCaseIdInput").getValue() !== "") {
		aFilter.push(new sap.ui.model.Filter("case_id", vEq, sap.ui.getCore().byId("iCaseIdInput").getValue()));
	}
	if (sap.ui.getCore().byId("iERPNoInput").getValue() !== "") {
		aFilter.push(new sap.ui.model.Filter("customer_r3_no", vEq, sap.ui.getCore().byId("iERPNoInput").getValue()));
	}
	if (sap.ui.getCore().byId("iBPNoInput").getValue() !== "") {
		aFilter.push(new sap.ui.model.Filter("customer_bp_id", vEq, sap.ui.getCore().byId("iBPNoInput").getValue()));
	}
	if (sap.ui.getCore().byId("iCusNameInput").getValue() !== "") {
		aFilter.push(new sap.ui.model.Filter("customer_name", vEq, sap.ui.getCore().byId("iCusNameInput").getValue()));
	}
	if (sap.ui.getCore().byId("iFreeTextInput").getValue() !== "") {
		aFilter.push(new sap.ui.model.Filter("free_text", vEq, sap.ui.getCore().byId("iFreeTextInput").getValue()));
	}
	//case_type ZS02 Engagement Cases
	aFilter.push(new sap.ui.model.Filter("case_type", vEq, "ZS02"));
	//status without 90 Closed, 98 Restricts
	aFilter.push(new sap.ui.model.Filter("status", vEq, "71"));
	aFilter.push(new sap.ui.model.Filter("status", vEq, "80"));
	aFilter.push(new sap.ui.model.Filter("status", vEq, "81"));
	aFilter.push(new sap.ui.model.Filter("status", vEq, "99"));

	return aFilter;
}

function _checkIfWebIDE() {
	var url = document.location.toString();
	var arrUrl = url.split("//");
	var start = arrUrl[1].indexOf("/");
	var relUrl = arrUrl[1].substring(start);
	if (relUrl.indexOf("?") !== -1) {
		relUrl = relUrl.split("?")[0];
	}
	//if current path is '/webapp/', means application is running in local web IDE
	var bLocalWebIde = relUrl.indexOf("/webapp/") > -1;
	return bLocalWebIde ? "/" : "";
}

function _checkIfFLP() {
	return !window["sap-fiori-ui5-bootstrap"] ? "" : "/sap/fiori/mccactivities";
}

// Events handler
function _onPressSearch(oController) {
	sap.ui.getCore().byId("iResultsTable").setBusy(true);
	this._readCaseIdData(oController);
}