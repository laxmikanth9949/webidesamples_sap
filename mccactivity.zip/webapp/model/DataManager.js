sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/support/mccactivities/model/models",
	"sap/support/mccactivities/model/help",
	"sap/support/mccactivities/model/appData"
], function(Object, JSONModel, MessageToast, models, help, appData) {
	"use strict";

	return Object.extend("sap.support.mccactivities.model.DataManager", {
		constructor: function(component) {
			this.oComponent = component;
			this.aResPromise = [];
			this._createModel();
			this._setData();
			this.loadData();
			return this;
		},

		_createModel: function() {
			// Set the device model
			this.oComponent.setModel(models.createDeviceModel(), "device");
			
			if(this.oComponent.getModel("device").getProperty("/isPhone")) {
				// Remove "/" for mobile app
				this.oComponent.sFirstSlash = "";
			}
			// Set user profile odata model
			this.oComponent.oDataUserProfile = models.createNewODataModel(this.oComponent.sFirstSlash + "intic/SVT/USER_PROFILE_SRV/", false);
			this.oComponent.oDataUserProfileBatch = models.createNewODataModel(this.oComponent.sFirstSlash + "intic/SVT/USER_PROFILE_SRV/", true);
			
			// AGS Dashboards oData model
			this.oComponent.oDashBoardsModel = models.createNewODataModel(this.oComponent.sFirstSlash + "intic/sap/ZS_CX_CCS_SRV/", false);

			// Global json model
			this.oComponent.setModel(models.createNewJSONModel("OneWay"), "UserProfile");
			this.oComponent.setModel(models.createNewJSONModel("OneWay"), "UserProfileEdit");
			this.oComponent.setModel(models.createNewJSONModel("TwoWay"), "VisibleList");
			this.oComponent.setModel(models.createNewJSONModel("OneWay"), "SettingList");
			this.oComponent.setModel(models.createNewJSONModel("OneWay"), "MyActivity");
			this.oComponent.setModel(models.createNewJSONModel("TwoWay"), "ListActivity");
			this.oComponent.setModel(models.createNewJSONModel("OneWay"), "NeedPushNotif");
			this.oComponent.setModel(models.createNewJSONModel("OneWay"), "DefaultCategory");
			this.oComponent.setModel(models.createNewJSONModel("OneWay"), "CreateControl");
			this.oComponent.setModel(models.createNewJSONModel("OneWay"), "NotificationMsg");
			this.oComponent.setModel(new sap.ui.model.json.JSONModel({"channel":"mccactivity"}), "QualtricsData"); //Qualtrics
		},

		loadData: function() {
			// this.readAuth().then(
			// 	function() {
			// 		this.readServiceTeamList();
			// 		Promise.all([this.readStatusList(), this.readCategoryList(), this.readRatingList(), this.readPriorityList()]).then(function() {
			// 			return this.readUserProfileData();
			// 		}.bind(this)).then(function() {
			// 			return this._visibleListRace();
			// 		}.bind(this)).then(function() {
			// 			this.oComponent.onSuccess();
			// 		}.bind(this)).catch(function(error) {
			// 			this.oComponent.onSuccess();
			// 		}.bind(this));
			// 	}.bind(this),
			// 	function(error) {
			// 		this.oComponent.onFailed(error);
			// 	}.bind(this)
			// );
			this.readServiceTeamList();
			Promise.all([this.readStatusList(), this.readCategoryList(), this.readRatingList(), this.readPriorityList()]).then(function() {
				return this.readUserProfileData();
			}.bind(this)).then(function() {
				this.oComponent.onSuccess();
				return this._visibleListRace();
			}.bind(this));
		},

		loadActivitiesList: function() {
			this._visibleListRace();
		},

		loadSingleList: function(sList) {
			switch (sList) {
				case "Assigned":
					return this.readAssignedAct();
				case "CreatedByMe":
					return this.readCreByMeAct();
				case "Favorites":
					return this.readFavoriteAct();
				case "ForMyFavoriteCustomers":
					return this.readFavoriteCustomerAct();
				case "ServiceTeam":
					return this.readServiceTeamAct();
			}
		},

		setVisibleList: function(aList) {
			this.removeVisibleList().then(function() {
				this.saveVisibleList(aList);
			}.bind(this)).catch(function(error) {
				sap.m.MessageToast.show("No visible lists!");
			});
		},

		_visibleListRace: function() {
			var oVisList = this.oComponent.getModel("VisibleList").getData();
			if (oVisList) {
				var bHaveVisList = false;
				this.aResPromise = [];
				for (var index in oVisList) {
					if (oVisList[index].visible) {
						switch (index) {
							case "Assigned":
								bHaveVisList = true;
								this.aResPromise.push(this.readAssignedAct());
								break;
							case "CreatedByMe":
							default:
								bHaveVisList = true;
								this.aResPromise.push(this.readCreByMeAct());
								break;
							case "Favorites":
								bHaveVisList = true;
								this.aResPromise.push(this.readFavoriteAct());
								break;
							case "ForMyFavoriteCustomers":
								bHaveVisList = true;
								this.aResPromise.push(this.readFavoriteCustomerAct());
								break;
							case "ServiceTeam":
								bHaveVisList = true;
								this.aResPromise.push(this.readServiceTeamAct());
								break;
						}
					}
				}
				if (bHaveVisList) {
					return Promise.race(this.aResPromise);
				} else {
					this.resolvePromise();
				}
			} else {
				return this.resolvePromise();
			}
		},

		resolvePromise: function() {
			return new Promise(function(resolve) {
				sap.m.MessageToast.show("No visible lists!");
				resolve();
			});
		},

		// Promise 1: Read Authorization
		// readAuth: function() {
		// 	return new Promise(function(resolve, reject) {
		// 		this.oComponent.oDashBoardsModel.read("/AuthorizationCheckSet", {
		// 			filters: help.setAuthCheckFilters(),
		// 			success: function(oData) {
		// 				var authItems = oData.results;
		// 				for (var iIndex in authItems) {
		// 					if (authItems[iIndex].authorzied === "yes" || authItems[iIndex].authorzied === "X") {
		// 						this.oComponent.oAuth.auth = true;
		// 					}
		// 				}
		// 				if (this.oComponent.oAuth.auth) {
		// 					resolve();
		// 				} else {
		// 					reject("No authorization!");
		// 				}
		// 			}.bind(this),
		// 			error: function(error) {
		// 				reject(error);
		// 			}
		// 		});
		// 	}.bind(this));
		// },

		// Promise 2.1: Read Status List
		readStatusList: function() {
			return new Promise(function(resolve, reject) {
				this.oComponent.oDashBoardsModel.read("/SettingList", {
					filters: help.setStatusListFilters(),
					success: function(oData) {
						this.oComponent.getModel("SettingList").setProperty("/StatusList", oData.results);
						resolve();
					}.bind(this),
					error: function(error) {
						reject(error);
					}
				});
			}.bind(this));
		},

		// Promise 2.2: Read Category List
		readCategoryList: function() {
			return new Promise(function(resolve, reject) {
				this.oComponent.oDashBoardsModel.read("/SettingList", {
					filters: help.setCategoryListFilters(),
					success: function(oData) {
						/*oData.results.push({
							key: "CATEGORY",
							value1: "",
							value2: "",
							value3: "(empty)"
						});*/
						this.oComponent.getModel("SettingList").setProperty("/CategoryList", oData.results);
						resolve();
					}.bind(this),
					error: function(error) {
						reject(error);
					}
				});
			}.bind(this));
		},

		// Promise 2.3: Read Rating List
		readRatingList: function() {
			return new Promise(function(resolve, reject) {
				this.oComponent.oDashBoardsModel.read("/SettingList", {
					filters: help.setRatingListFilters(),
					success: function(oData) {
						this.oComponent.getModel("SettingList").setProperty("/RatingList", oData.results);
						resolve();
					}.bind(this),
					error: function(error) {
						reject(error);
					}
				});
			}.bind(this));
		},

		// Promise 2.4: Read Priority List
		readPriorityList: function() {
			return new Promise(function(resolve, reject) {
				this.oComponent.oDashBoardsModel.read("/SettingList", {
					filters: help.setPriorityListFilters(),
					success: function(oData) {
						this.oComponent.getModel("SettingList").setProperty("/PriorityList", oData.results);
						resolve();
					}.bind(this),
					error: function(error) {
						reject(error);
					}
				});
			}.bind(this));
		},
		
		// OData read 2.5: Read Service Team List
		readServiceTeamList: function() {
			this.oComponent.oDashBoardsModel.read("/SettingList", {
				filters: help.setServiceTeamListFilters(),
				success: function(oData) {
					this.oComponent.getModel("SettingList").setProperty("/RegionList", models.groupServiceTeam(oData.results));
				}.bind(this),
				error: function(error) {
					MessageToast.show("Error while reading data!\nLog:" + error);
				}
			});
		},

		// Promise 3: Read User Profile Data
		readUserProfileData: function() {
			return new Promise(function(resolve, reject) {
				this.oComponent.oDataUserProfile.read("/Entries", {
					filters: help.setUserProfileFilters(),
					success: function(oData) {
						if (oData.results.length === 0) {
							reject("No authorization in I7*");
						} else {
							var oDataUP = models.handleGroupData(oData.results);
							this.oComponent.getModel("UserProfile").setData(oDataUP);
							this.oComponent.getModel("UserProfileEdit").setData($.extend({}, oDataUP));
							this._setUserData();
							resolve();
						}
					}.bind(this),
					error: function(error) {
						reject(error);
					}
				});
			}.bind(this));
		},

		// Promise 4.1: Read Assigned Activities
		readAssignedAct: function() {
			return new Promise(function(resolve, reject) {
				this.oComponent.oDashBoardsModel.read("/ActivityList", {
					filters: help.setAssignedFilters(this.oComponent.getModel("MyActivity").getProperty("/data"), this.oComponent.getModel(
						"SettingList").getProperty("/CategoryList"), this.oComponent.getModel("SettingList").getProperty("/StatusList")),
					success: function(oData) {
						models.setSearchString(oData.results);
						this._setFirstActivityId(oData.results);
						this.oComponent.getModel("ListActivity").setProperty("/Assigned", oData.results.filter(function(item) {
							return item.activity_person_user_id === this.oComponent.sUser;
						}.bind(this)));
						resolve();
					}.bind(this),
					error: function(error) {
						reject(error);
					}
				});
			}.bind(this));
		},

		// Promise 4.2: Read CreatedByMe Activities
		readCreByMeAct: function() {
			return new Promise(function(resolve, reject) {
				this.oComponent.oDashBoardsModel.read("/ActivityList", {
					filters: help.setCreByMeFilters(this.oComponent.sUser, this.oComponent.getModel("SettingList").getProperty("/CategoryList"),
						this.oComponent.getModel("SettingList").getProperty("/StatusList")),
					success: function(oData) {
						models.setSearchString(oData.results);
						this._setFirstActivityId(oData.results);
						this.oComponent.getModel("ListActivity").setProperty("/CreatedByMe", oData.results);
						resolve();
					}.bind(this),
					error: function(error) {
						reject(error);
					}
				});
			}.bind(this));
		},

		// Promise 4.3: Read Favorite Activities
		readFavoriteAct: function() {
			return new Promise(function(resolve, reject) {
				this.oComponent.oDashBoardsModel.read("/ActivityList", {
					filters: help.setFavoriteFilters(this.oComponent.getModel("UserProfile").getProperty("/FAVORITE_ACTIVITIES"), this.oComponent
						.getModel("SettingList").getProperty("/CategoryList"), this.oComponent.getModel("SettingList").getProperty("/StatusList")),
					success: function(oData) {
						models.setSearchString(oData.results);
						this._setFirstActivityId(oData.results);
						this.oComponent.getModel("ListActivity").setProperty("/Favorites", oData.results);
						resolve();
					}.bind(this),
					error: function(error) {
						reject(error);
					}
				});
			}.bind(this));
		},

		// Promise 4.4: Read Favorite Customers' Activities
		readFavoriteCustomerAct: function() {
			return new Promise(function(resolve, reject) {
				this.oComponent.oDashBoardsModel.read("/ActivityList", {
					filters: help.setFavoriteCustomerFilters(this.oComponent.getModel("UserProfile").getProperty("/FAVORITE_CUSTOMERS"), this.oComponent
						.getModel("SettingList").getProperty("/CategoryList"), this.oComponent.getModel("SettingList").getProperty("/StatusList")),
					success: function(oData) {
						models.setSearchString(oData.results);
						this._setFirstActivityId(oData.results);
						this.oComponent.getModel("ListActivity").setProperty("/ForMyFavoriteCustomers", oData.results);
						resolve();
					}.bind(this),
					error: function(error) {
						reject(error);
					}
				});
			}.bind(this));
		},

		// Promise 4.5: Read Selected Service Team's Activities
		readServiceTeamAct: function() {
			return new Promise(function(resolve, reject) {
				this.oComponent.oDashBoardsModel.read("/ActivityList", {
					filters: help.setServiceTeamFilters(this.oComponent.getModel("UserProfile").getProperty(
							"/APP_MCC_ACTIVITIES_DEFAULT_STEAM") ? this.oComponent.getModel("UserProfile").getProperty(
							"/APP_MCC_ACTIVITIES_DEFAULT_STEAM").Value : "", this.oComponent
						.getModel("SettingList").getProperty("/CategoryList"), this.oComponent
						.getModel("SettingList").getProperty("/StatusList")),
					success: function(oData) {
						models.setSearchString(oData.results);
						this._setFirstActivityId(oData.results);
						this.oComponent.getModel("ListActivity").setProperty("/ServiceTeam", oData.results);
						resolve();
					}.bind(this),
					error: function(error) {
						reject(error);
					}
				});
			}.bind(this));
		},

		//
		saveCategoryFilter: function(aCateg) {
			return new Promise(function(resolve, reject) {
				this.oComponent.oDataUserProfile.remove("/Entries(Username='',Attribute='APP_MCC_ACTIVITIES_VISIBLE_CATEG',Field='')", {
					success: function() {
						if (Array.isArray(aCateg)) {
							if (aCateg.length !== 0) {
								var sDeferredGroup = "category";
								this.oComponent.oDataUserProfileBatch.setDeferredGroups([sDeferredGroup]);
								$.each(aCateg, function(index, item) {
									this.oComponent.oDataUserProfileBatch.create("/Entries", {
										Attribute: "APP_MCC_ACTIVITIES_VISIBLE_CATEG",
										Value: item
									}, {
										groupId: sDeferredGroup
									});
								}.bind(this));
								this.oComponent.oDataUserProfileBatch.submitChanges({
									groupId: sDeferredGroup,
									success: function(oData) {
										resolve();
									},
									error: function(error) {
										reject(error);
									}
								});
							}
						}
					}.bind(this),
					error: function(error) {
						reject(error);
					}
				});
			}.bind(this));
		},

		saveStatusFilter: function(aStatus) {
			return new Promise(function(resolve, reject) {
				this.oComponent.oDataUserProfile.remove("/Entries(Username='',Attribute='APP_MCC_ACTIVITIES_VISIBLE_STATU',Field='')", {
					success: function() {
						if (Array.isArray(aStatus)) {
							if (aStatus.length !== 0) {
								var sDeferredGroup = "status";
								this.oComponent.oDataUserProfileBatch.setDeferredGroups([sDeferredGroup]);
								$.each(aStatus, function(index, item) {
									this.oComponent.oDataUserProfileBatch.create("/Entries", {
										Attribute: "APP_MCC_ACTIVITIES_VISIBLE_STATU",
										Value: item
									}, {
										groupId: sDeferredGroup
									});
								}.bind(this));
								this.oComponent.oDataUserProfileBatch.submitChanges({
									groupId: sDeferredGroup,
									success: function(oData) {
										resolve();
									},
									error: function(error) {
										reject(error);
									}
								});
							}
						}
					}.bind(this),
					error: function(error) {
						reject(error);
					}
				});
			}.bind(this));
		},

		removeVisibleList: function() {
			return new Promise(function(resolve, reject) {
				this.oComponent.oDataUserProfile.remove("/Entries(Username='',Attribute='APP_MCC_ACTIVITIES_VISIBLE_LISTS',Field='')", {
					success: function() {
						resolve();
					},
					error: function(error) {
						reject(error);
					}
				});
			}.bind(this));
		},

		saveVisibleList: function(aList) {
			if (!Array.isArray(aList)) {
				aList = [];
			}
			var sDeferredGroup = "list";
			this.oComponent.oDataUserProfileBatch.setDeferredGroups([sDeferredGroup]);
			$.each(aList, function(index, item) {
				this.oComponent.oDataUserProfileBatch.create("/Entries", {
					"Attribute": "APP_MCC_ACTIVITIES_VISIBLE_LISTS",
					"Value": item,
					success: function() {},
					error: function() {}
				}, {
					groupId: sDeferredGroup
				});
			}.bind(this));
			this.oComponent.oDataUserProfileBatch.submitChanges({
				groupId: sDeferredGroup,
				success: function() {},
				error: function() {}
			});
		},

		createNeedPushNotification: function() {
			this.oComponent.oDataUserProfile.create("/Entries", {
				"Attribute": "NEED_MCC_PUSHNOTIFICATION",
				"Value": "YES",
				success: function() {}
			});
		},
		
		updateNeedPushNotification: function(sFlag) {
			this.oComponent.oDataUserProfile.update("/Entries(Username='',Attribute='NEED_MCC_PUSHNOTIFICATION',Field='')", {
				"Value": sFlag
			}, {
				success: function() {},
				error: function() {}
			});
		},
		
		updateUserProfileAttribute: function(sAttribute, sValue) {
			this.oComponent.oDataUserProfile.update("/Entries(Username='',Attribute='" + sAttribute + "',Field='')", {
				"Value": sValue
			}, {
				success: function() {},
				error: function() {}
			});	
		},
		
		
		// Notification Message Page
		readNotificationMsg: function(callBack) {
			this.oComponent.oDashBoardsModel.read("/pushnotfmsgSet", {
				success: function(oData) {
					var aMsg = [];
					if (oData) {
						if (Array.isArray(oData.results)) {
							aMsg = oData.results;
						}
					}
					this.oComponent.getModel("NotificationMsg").setProperty("/Messages", aMsg);
					if (callBack && Object.prototype.toString.call(callBack) === "[object Function]") {
						callBack(this.oComponent);
					}
				}.bind(this),
				error: function() {}
			});
		},
		
		updateNotificationMsg: function(sMsgKey) {
			if (sMsgKey) {
				this.oComponent.oDashBoardsModel.update("/pushnotfmsgSet(msg_key='" + sMsgKey + "')", {
					"msg_key": sMsgKey
				}, {
					success: function(oSuccess) {
						this.readNotificationMsg();
					}.bind(this),
					error: function(oError) {}
				});
			}
		},
		
		removeNotificationMsg: function(sMsgKey) {
			if (sMsgKey) {
				this.oComponent.oDashBoardsModel.remove("/pushnotfmsgSet(msg_key='" + sMsgKey + "')", {
					success: function(oSuccess) {
						this.readNotificationMsg();
					}.bind(this),
					error: function(oError) {}
				});
			}
		},

		_setData: function() {
			this.oComponent.getModel("SettingList").setProperty("/NewRegionList", appData.regionData);
			this.oComponent.getModel("SettingList").setProperty("/Template", appData.cloudTemplate);
			this.oComponent.getModel("SettingList").setProperty("/TopicList", appData.serviceTeams);
			
			this.oComponent.getModel("CreateControl").setProperty("/InvalidCaseIdDialogAccept", true);
			this.oComponent.getModel("CreateControl").setProperty("/NoAccountDialogAccept", true);
			this.oComponent.getModel("CreateControl").setProperty("/EFOSDialogAccept", true);
		},

		_setUserData: function() {
			// Set current user
			this.oComponent.sUser = this.oComponent.getModel("UserProfile").getProperty("/USERNAME").Value;
			// Set visible list
			var aVisList = this.oComponent.getModel("UserProfile").getProperty("/APP_MCC_ACTIVITIES_VISIBLE_LISTS");
			if (!aVisList) {
				aVisList = [{
					Value: "Assigned"
				}, {
					Value: "CreatedByMe"
				}, {
					Value: "Favorites"
				}];
				this.saveVisibleList(["Assigned", "CreatedByMe", "Favorites"]);
			}
			this.oComponent.getModel("VisibleList").setData(models.setVisibleListData(appData.visibleList, aVisList));

			// Set selected status
			this.oComponent.getModel("SettingList").setProperty("/StatusList", models.setSelectedFilterData(this.oComponent.getModel(
				"SettingList").getProperty("/StatusList"), this.oComponent.getModel(
				"UserProfile").getProperty("/APP_MCC_ACTIVITIES_VISIBLE_STATU")));
			// Set selected category
			this.oComponent.getModel("SettingList").setProperty("/CategoryList", models.setSelectedFilterData(this.oComponent.getModel(
				"SettingList").getProperty("/CategoryList"), this.oComponent.getModel(
				"UserProfile").getProperty("/APP_MCC_ACTIVITIES_VISIBLE_CATEG")));
			// Set need push notification
			if (this.oComponent.getModel("UserProfile").getProperty("/NEED_MCC_PUSHNOTIFICATION")) {
				switch (this.oComponent.getModel("UserProfile").getProperty("/NEED_MCC_PUSHNOTIFICATION").Value) {
					case "YES":
						this.oComponent.getModel("NeedPushNotif").setProperty("/result", true);
						break;
					case "NO":
					default:
						this.oComponent.getModel("NeedPushNotif").setProperty("/result", false);
						break;
				}
			} else {
				this.createNeedPushNotification();
				this.oComponent.getModel("NeedPushNotif").setProperty("/result", true);
			}
			// Set default category
			if (this.oComponent.getModel("UserProfile").getProperty("/APP_MCC_ACTIVITIES_DEFAULT_CATEG")) {
				this.oComponent.getModel("DefaultCategory").setProperty("/result", this.oComponent.getModel("UserProfile").getProperty(
					"/APP_MCC_ACTIVITIES_DEFAULT_CATEG").Value);
			}
		},
		
		_setFirstActivityId: function(aActivity) {
			if (jQuery.sap.getUriParameters().get("event") !== "display" && this.oComponent.fReadFirstAct) {
				if (!this.oComponent.sCurActivityId && aActivity.length) {
					this.oComponent.sCurActivityId = aActivity[0].activity_id;
					if (this.oComponent.getCurrentRoute() === "detail" || this.oComponent.getCurrentRoute() === "") {
						sap.ui.getCore().getEventBus().publish("sap.support.mccactivities", "DisplayActivity", {
							id: this.oComponent.sCurActivityId
						});
						this.oComponent.fReadFirstAct = false;
					}
				}
			}
		}
	});
});