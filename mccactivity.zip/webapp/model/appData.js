sap.ui.define([], function () {
	"use strict";
	return {
		visibleList: {
			"Assigned": {
				"value": "Assigned to me",
				"visible": false
			},
			"CreatedByMe": {
				"value": "Created by me",
				"visible": false
			},
			"Favorites": {
				"value": "My Favorites",
				"visible": false
			},
			"ForMyFavoriteCustomers": {
				"value": "For favorite customers",
				"visible": false
			},
			"ServiceTeam": {
				"value": "For selected service team",
				"visible": false
			}
		},
		notFoundUrl: "ht" + "tps://support.wdf.sap.corp/sap/support/notes/2149660",
		serviceTeams: {
			"apa": [{
				"name": "Enter Service Team ID",
				"service_team_id": "",
				"ism_cat": []
			}, {
				"name": "Engagement Support",
				"service_team_id": 16122383,
				"ism_cat": ["1", "7"]
			}, {
				"name": "Digital Platform HANA",
				"service_team_id": 14235363,
				"ism_cat": ["2"]
			}, {
				"name": "Hybrid Lifecyle Mgmt",
				"service_team_id": 29788190,
				"ism_cat": ["6"]
			}, {
				"name": "Digital Core -S/4HANA",
				"service_team_id": 25970641,
				"ism_cat": ["3"]
			}, {
				"name": "Lead 2 Cash",
				"service_team_id": 31471673,
				"ism_cat": ["0"]
			}, {
				"name": "Total Workforce Mgmt",
				"service_team_id": 31471679,
				"ism_cat": ["0"]
			}, {
				"name": "Source 2 Pay",
				"service_team_id": 31471689,
				"ism_cat": ["0"]
			}, {
				"name": "Design 2 Operate",
				"service_team_id": 31458971,
				"ism_cat": ["0"]
			}, {
				"name": "Innovation Adopt & Intelligent Tech",
				"service_team_id": 14629050,
				"ism_cat": ["0"]
			}, {
				"name": "Digital Platform SCP",
				"service_team_id": 31458975,
				"ism_cat": ["0"]
			}],
			
			"apg": [{
				"name": "Enter Service Team ID",
				"service_team_id": "",
				"ism_cat": []
			}, {
				"name": "Engagement Support",
				"service_team_id": 14217680,
				"ism_cat": ["1", "7"]
			}, {
				"name": "Digital Platform HANA",
				"service_team_id": 14235363,
				"ism_cat": ["2"]
			}, {
				"name": "Hybrid Lifecyle Mgmt",
				"service_team_id": 29788190,
				"ism_cat": ["6"]
			}, {
				"name": "Digital Core -S/4HANA",
				"service_team_id": 25970641,
				"ism_cat": ["3"]
			}, {
				"name": "Lead 2 Cash",
				"service_team_id": 31471673,
				"ism_cat": ["0"]
			}, {
				"name": "Total Workforce Mgmt",
				"service_team_id": 31471679,
				"ism_cat": ["0"]
			}, {
				"name": "Source 2 Pay",
				"service_team_id": 31471689,
				"ism_cat": ["0"]
			}, {
				"name": "Design 2 Operate",
				"service_team_id": 31458971,
				"ism_cat": ["0"]
			}, {
				"name": "Innovation Adopt & Intelligent Tech",
				"service_team_id": 14629050,
				"ism_cat": ["0"]
			}, {
				"name": "Digital Platform SCP",
				"service_team_id": 31458975,
				"ism_cat": ["0"]
			}],
			"api": [{
				"name": "Enter Service Team ID",
				"service_team_id": "",
				"ism_cat": []
			}, {
				"name": "Engagement Support",
				"service_team_id": 14722020,
				"ism_cat": ["1", "7"]
			}, {
				"name": "Digital Platform HANA",
				"service_team_id": 14235363,
				"ism_cat": ["2"]
			}, {
				"name": "Hybrid Lifecyle Mgmt",
				"service_team_id": 29788190,
				"ism_cat": ["6"]
			}, {
				"name": "Digital Core -S/4HANA",
				"service_team_id": 25970641,
				"ism_cat": ["3"]
			}, {
				"name": "Lead 2 Cash",
				"service_team_id": 31471673,
				"ism_cat": ["0"]
			}, {
				"name": "Total Workforce Mgmt",
				"service_team_id": 31471679,
				"ism_cat": ["0"]
			}, {
				"name": "Source 2 Pay",
				"service_team_id": 31471689,
				"ism_cat": ["0"]
			}, {
				"name": "Design 2 Operate",
				"service_team_id": 31458971,
				"ism_cat": ["0"]
			}, {
				"name": "Innovation Adopt & Intelligent Tech",
				"service_team_id": 14629050,
				"ism_cat": ["0"]
			}, {
				"name": "Digital Platform SCP",
				"service_team_id": 31458975,
				"ism_cat": ["0"]
			}],
			"apj": [{
				"name": "Enter Service Team ID",
				"service_team_id": "",
				"ism_cat": []
			}, {
				"name": "Engagement Support",
				"service_team_id": 16122385,
				"ism_cat": ["1", "7"]
			}, {
				"name": "Digital Platform HANA",
				"service_team_id": 14235363,
				"ism_cat": ["2"]
			}, {
				"name": "Hybrid Lifecyle Mgmt",
				"service_team_id": 29788190,
				"ism_cat": ["6"]
			}, {
				"name": "Digital Core -S/4HANA",
				"service_team_id": 25970641,
				"ism_cat": ["3"]
			}, {
				"name": "Lead 2 Cash",
				"service_team_id": 31471673,
				"ism_cat": ["0"]
			}, {
				"name": "Total Workforce Mgmt",
				"service_team_id": 31471679,
				"ism_cat": ["0"]
			}, {
				"name": "Source 2 Pay",
				"service_team_id": 31471689,
				"ism_cat": ["0"]
			}, {
				"name": "Design 2 Operate",
				"service_team_id": 31458971,
				"ism_cat": ["0"]
			}, {
				"name": "Innovation Adopt & Intelligent Tech",
				"service_team_id": 14629050,
				"ism_cat": ["0"]
			}, {
				"name": "Digital Platform SCP",
				"service_team_id": 31458975,
				"ism_cat": ["0"]
			}],
			"apk": [{
				"name": "Enter Service Team ID",
				"service_team_id": "",
				"ism_cat": []
			}, {
				"name": "Engagement Support",
				"service_team_id": 22163161,
				"ism_cat": ["1", "7"]
			}, {
				"name": "Digital Platform HANA",
				"service_team_id": 14235363,
				"ism_cat": ["2"]
			}, {
				"name": "Hybrid Lifecyle Mgmt",
				"service_team_id": 29788190,
				"ism_cat": ["6"]
			}, {
				"name": "Digital Core -S/4HANA",
				"service_team_id": 25970641,
				"ism_cat": ["3"]
			}, {
				"name": "Lead 2 Cash",
				"service_team_id": 31471673,
				"ism_cat": ["0"]
			}, {
				"name": "Total Workforce Mgmt",
				"service_team_id": 31471679,
				"ism_cat": ["0"]
			}, {
				"name": "Source 2 Pay",
				"service_team_id": 31471689,
				"ism_cat": ["0"]
			}, {
				"name": "Design 2 Operate",
				"service_team_id": 31458971,
				"ism_cat": ["0"]
			}, {
				"name": "Innovation Adopt & Intelligent Tech",
				"service_team_id": 14629050,
				"ism_cat": ["0"]
			}, {
				"name": "Digital Platform SCP",
				"service_team_id": 31458975,
				"ism_cat": ["0"]
			}],
			"aps": [{
				"name": "Enter Service Team ID",
				"service_team_id": "",
				"ism_cat": []
			}, {
				"name": "Engagement Support",
				"service_team_id": 16122387,
				"ism_cat": ["1", "7"]
			}, {
				"name": "Digital Platform HANA",
				"service_team_id": 14235363,
				"ism_cat": ["2"]
			}, {
				"name": "Hybrid Lifecyle Mgmt",
				"service_team_id": 29788190,
				"ism_cat": ["6"]
			}, {
				"name": "Digital Core -S/4HANA",
				"service_team_id": 25970641,
				"ism_cat": ["3"]
			}, {
				"name": "Lead 2 Cash",
				"service_team_id": 31471673,
				"ism_cat": ["0"]
			}, {
				"name": "Total Workforce Mgmt",
				"service_team_id": 31471679,
				"ism_cat": ["0"]
			}, {
				"name": "Source 2 Pay",
				"service_team_id": 31471689,
				"ism_cat": ["0"]
			}, {
				"name": "Design 2 Operate",
				"service_team_id": 31458971,
				"ism_cat": ["0"]
			}, {
				"name": "Innovation Adopt & Intelligent Tech",
				"service_team_id": 14629050,
				"ism_cat": ["0"]
			}, {
				"name": "Digital Platform SCP",
				"service_team_id": 31458975,
				"ism_cat": ["0"]
			}],
			"emea": [{
				"name": "Enter Service Team ID",
				"service_team_id": "",
				"ism_cat": []
			}, {
				"name": "Engagement Support",
				"service_team_id": 16539820,
				"ism_cat": ["1", "7"]
			}, {
				"name": "Digital Platform HANA",
				"service_team_id": 14217791,
				"ism_cat": ["2"]
			}, {
				"name": "Hybrid Lifecyle Mgmt",
				"service_team_id": 29765610,
				"ism_cat": ["6"]
			}, {
				"name": "Digital Core -S/4HANA",
				"service_team_id": 16673868,
				"ism_cat": ["3"]
			}, {
				"name": "Lead 2 Cash",
				"service_team_id": 31471672,
				"ism_cat": ["0"]
			}, {
				"name": "Total Workforce Mgmt",
				"service_team_id": 31471678,
				"ism_cat": ["0"]
			}, {
				"name": "Source 2 Pay",
				"service_team_id": 31471688,
				"ism_cat": ["0"]
			}, {
				"name": "Design 2 Operate",
				"service_team_id": 31458970,
				"ism_cat": ["0"]
			}, {
				"name": "Innovation Adopt & Intelligent Tech",
				"service_team_id": 14235826,
				"ism_cat": ["0"]
			}, {
				"name": "Digital Platform SCP",
				"service_team_id": 31458974,
				"ism_cat": ["0"]
			}],
			"lac": [{
				"name": "Enter Service Team ID",
				"service_team_id": "",
				"ism_cat": []
			}, {
				"name": "Engagement Support",
				"service_team_id": 15966792,
				"ism_cat": ["1", "7"]
			}, {
				"name": "Digital Platform HANA",
				"service_team_id": 14235365,
				"ism_cat": ["2"]
			}, {
				"name": "Hybrid Lifecyle Mgmt",
				"service_team_id": 29788192,
				"ism_cat": ["6"]
			}, {
				"name": "Digital Core -S/4HANA",
				"service_team_id": 25970643,
				"ism_cat": ["3"]
			}, {
				"name": "Lead 2 Cash",
				"service_team_id": 31471675,
				"ism_cat": ["0"]
			}, {
				"name": "Total Workforce Mgmt",
				"service_team_id": 31471681,
				"ism_cat": ["0"]
			}, {
				"name": "Source 2 Pay",
				"service_team_id": 31495299,
				"ism_cat": ["0"]
			}, {
				"name": "Design 2 Operate",
				"service_team_id": 31495304,
				"ism_cat": ["0"]
			}, {
				"name": "Innovation Adopt & Intelligent Tech",
				"service_team_id": 15963535,
				"ism_cat": ["0"]
			}, {
				"name": "Digital Platform SCP",
				"service_team_id": 31458978,
				"ism_cat": ["0"]
			}],
			"na": [{
				"name": "Enter Service Team ID",
				"service_team_id": "",
				"ism_cat": []
			}, {
				"name": "Engagement Support",
				"service_team_id": 21710213,
				"ism_cat": ["1", "7"]
			}, {
				"name": "Digital Platform HANA",
				"service_team_id": 14235364,
				"ism_cat": ["2"]
			}, {
				"name": "Hybrid Lifecyle Mgmt",
				"service_team_id": 29788191,
				"ism_cat": ["6"]
			}, {
				"name": "Digital Core -S/4HANA",
				"service_team_id": 25970644,
				"ism_cat": ["3"]
			}, {
				"name": "Lead 2 Cash",
				"service_team_id": 31471674,
				"ism_cat": ["0"]
			}, {
				"name": "Total Workforce Mgmt",
				"service_team_id": 31471680,
				"ism_cat": ["0"]
			}, {
				"name": "Source 2 Pay",
				"service_team_id": 31495298,
				"ism_cat": ["0"]
			}, {
				"name": "Design 2 Operate",
				"service_team_id": 31495302,
				"ism_cat": ["0"]
			}, {
				"name": "Innovation Adopt & Intelligent Tech",
				"service_team_id": 19198289,
				"ism_cat": ["0"]
			}, {
				"name": "Digital Platform SCP",
				"service_team_id": 31458977,
				"ism_cat": ["0"]
			}]
		},
		// serviceTeams: [{
		// 	"Region": "APJ",
		// 	"Topic": [{
		// 		"name": "Cloud",
		// 		"service_team_id": 19093065
		// 	}, {
		// 		"name": "Engagement Support APJ-ANZ",
		// 		"service_team_id": 16122383
		// 	}, {
		// 		"name": "Engagement Support APJ-IN",
		// 		"service_team_id": 14722020
		// 	}, {
		// 		"name": "Engagement Support APJ-JP",
		// 		"service_team_id": 16122385
		// 	}, {
		// 		"name": "Engagement Support APJ-KOR",
		// 		"service_team_id": 22163161
		// 	}, {
		// 		"name": "Engagement Support APJ-NA",
		// 		"service_team_id": 14217680
		// 	}, {
		// 		"name": "Engagement Support APJ-SEA",
		// 		"service_team_id": 16122387
		// 	}, {
		// 		"name": "HANA",
		// 		"service_team_id": 14235363
		// 	}, {
		// 		"name": "HEC",
		// 		"service_team_id": 21002935
		// 	}, {
		// 		"name": "ICC",
		// 		"service_team_id": 14629050
		// 	}, {
		// 		"name": "IV",
		// 		"service_team_id": 21002934
		// 	}, {
		// 		"name": "OCC",
		// 		"service_team_id": 14629051
		// 	}, {
		// 		"name": "Hybrid APJ-NA",
		// 		"service_team_id": 25978270
		// 	}, {
		// 		"name": "Hybrid rest APJ",
		// 		"service_team_id": 25978261
		// 	}]
		// }, {
		// 	"Region": "EMEA",
		// 	"Topic": [{
		// 		"name": "ALM",
		// 		"service_team_id": 14235825
		// 	}, {
		// 		"name": "Cloud",
		// 		"service_team_id": 17877275
		// 	}, {
		// 		"name": "Engagement Support",
		// 		"service_team_id": 16539820
		// 	}, {
		// 		"name": "HANA",
		// 		"service_team_id": 14217791
		// 	}, {
		// 		"name": "ICC",
		// 		"service_team_id": 14235826
		// 	}, {
		// 		"name": "IV",
		// 		"service_team_id": 16439712
		// 	}, {
		// 		"name": "OCC",
		// 		"service_team_id": 14235827
		// 	}, {
		// 		"name": "Hybrid",
		// 		"service_team_id": 25674544
		// 	}]
		// }, {
		// 	"Region": "Global",
		// 	"Topic": [{
		// 		"name": "Cloud",
		// 		"service_team_id": 19568810
		// 	}, {
		// 		"name": "HANA",
		// 		"service_team_id": 13732949
		// 	}, {
		// 		"name": "HEC",
		// 		"service_team_id": 18689308
		// 	}, {
		// 		"name": "ICC",
		// 		"service_team_id": 18841329
		// 	}, {
		// 		"name": "MCC",
		// 		"service_team_id": 20672944
		// 	}]
		// }, {
		// 	"Region": "LAC",
		// 	"Topic": [{
		// 		"name": "ALM",
		// 		"service_team_id": 15963558
		// 	}, {
		// 		"name": "Cloud",
		// 		"service_team_id": 17403528
		// 	}, {
		// 		"name": "Engagement Support",
		// 		"service_team_id": 15966792
		// 	}, {
		// 		"name": "HANA",
		// 		"service_team_id": 14235365
		// 	}, {
		// 		"name": "HEC",
		// 		"service_team_id": 21002936
		// 	}, {
		// 		"name": "ICC",
		// 		"service_team_id": 15963535
		// 	}, {
		// 		"name": "IV",
		// 		"service_team_id": 18560700
		// 	}, {
		// 		"name": "OCC",
		// 		"service_team_id": 15963537
		// 	}, {
		// 		"name": "Value Management",
		// 		"service_team_id": 21462794
		// 	}, {
		// 		"name": "Hybrid",
		// 		"service_team_id": 25978266
		// 	}]
		// }, {
		// 	"Region": "NA",
		// 	"Topic": [{
		// 		"name": "Cloud",
		// 		"service_team_id": 16755384
		// 	}, {
		// 		"name": "Engagement Support",
		// 		"service_team_id": 21710213
		// 	}, {
		// 		"name": "HANA",
		// 		"service_team_id": 14235364
		// 	}, {
		// 		"name": "ICC",
		// 		"service_team_id": 19198289
		// 	}, {
		// 		"name": "IV",
		// 		"service_team_id": 18860623
		// 	}, {
		// 		"name": "OCC",
		// 		"service_team_id": 19198290
		// 	}, {
		// 		"name": "Value Management",
		// 		"service_team_id": 21462798
		// 	}, {
		// 		"name": "Hybrid",
		// 		"service_team_id": 25978264
		// 	}]
		// }],
		iccTemplate: [{
			"line": "Project Name:"
		}, {
			"line": "E.g. Finance Transformation - Central Finance Prototype"
		}, {
			"line": "_________"
		}, {
			"line": "Project Scope:"
		}, {
			"line": "Prototype"
		}, {
			"line": "for implementation of Central Finance…."
		}, {
			"line": "__________"
		}, {
			"line": "Project Dates(Start, Go Live):"
		}, {
			"line": "Project Start Date: 01.07 .2015 Go - Live: 01.07 .2016"
		}, {
			"line": "__________"
		}, {
			"line": "SAP solutions in scope:"
		}, {
			"line": "E.g Central Finance"
		}, {
			"line": "____________"
		}, {
			"line": "Implementation Partner:"
		}, {
			"line": "E.g.: SAP"
		}, {
			"line": "____________"
		}, {
			"line": "Project Size(#consultants, budget):"
		}, {
			"line": "e.g.: 5 / 6 Million\u20AC"
		}, {
			"line": "____________"
		}, {
			"line": "General project information:"
		}, {
			"line": "This project……."
		}, {
			"line": "____________"
		}, {
			"line": "Reasons"
		}, {
			"line": "for positioning ICC / Challenges where customer expects AGS help:"
		}, {
			"line": "Please explain"
		}, {
			"line": "____________"
		}, {
			"line": "Initial / current Status(date):"
		}, {
			"line": "____________"
		}, {
			"line": "ICC building blocks in scope:"
		}, {
			"line": "Rapid Prototyping ?"
		}, {
			"line": "Gap Validation ?"
		}, {
			"line": "Safeguarding ?"
		}, {
			"line": "____________"
		}, {
			"line": "Status Solution Manager :"
		}, {
			"line": "Release, Preparation status"
		}, {
			"line": "for ALM, etc"
		}, {
			"line": "____________"
		}, {
			"line": "Further information :"
		}, {
			"line": "ADD Information about the customer expectations"
		}, {
			"line": "Add information about your expectation"
		}, {
			"line": "Add information about the Sales deal and positionning."
		}],
		cloudTemplate: [{
			"line": "Request description:"
		}, {
			"line": "<Please feel free to describe your request within this email as plain text. For more complex situations please complete the questionnaire below as this will accelerate request handling.>\n\n"
		}, {
			"line": "_________"
		}, {
			"line": "Involved Stakeholders:"
		}, {
			"line": "_________"
		}, {
			"line": "Request Reason (please mark):"
		}, {
			"line": "[ ] Critical Customer Situation"
		}, {
			"line": "[ ] Cross Issue (additional customers at risk?)"
		}, {
			"line": "[ ] Service Request (particular MaxAttention)"
		}, {
			"line": "[ ] Success Plan Support <Preferred Care/ES/…>"
		}, {
			"line": "[ ] Engagement Review"
		}, {
			"line": "[ ] Other"
		}, {
			"line": "_________"
		}, {
			"line": "Business Impact (please mark and complete):"
		}, {
			"line": "[ ] Go-live endangered? If checked: <DATE>"
		}, {
			"line": "[ ] Business down or not usable? if checked: <please specify>"
		}, {
			"line": "[ ] Users affected: if checked: <How many are affected>"
		}, {
			"line": "[ ] Subscription Renewal at Risk"
		}, {
			"line": "[ ] Financial impact: if checked: <AMOUNT $>"
		}, {
			"line": "[ ] Other: if checked: <please specify e.g. customer is keynote speaker at Sapphire>"
		}, {
			"line": "_________"
		}, {
			"line": "Request reason & expectations/required actions from MCC Cloud:"
		}, {
			"line": "(please specify details around selected business impact and project status)"
		}, {
			"line": "_________"
		}, {
			"line": "Related Incidents:"
		}, {
			"line": "(BCP Ticket # - JIRA Ticket # - Product – Module – Priority – Business Impact - Which steps were taken before this request (e.g. CIM)? Why was it not sufficient?)"
		}],
		creationData: {
			caseId: "",
			erpCust: "",
			title: "",
			desc: "",
			priority: "5",
			category: "ZB4",
			region: "",
			topic: "",
			serviceTeam: "",
			dateTo: "",
			requestor: "",
			requestorVisible: false
		},
		regionData: [{
			"name": "Please Select",
			"key": ""
		}, {
			"name": "EMEA",
			"key": "emea"
		}, {
			"name": "NA",
			"key": "na"
		}, {
			"name": "LAC",
			"key": "lac"
		}, {
			"name": "APJ-IND",
			"key": "api"
		}, {
			"name": "APJ-KOR",
			"key": "apk"
		}, {
			"name": "APJ-JP",
			"key": "apj"
		}, {
			"name": "APJ-GC",
			"key": "apg"
		}, {
			"name": "APJ-SEA",
			"key": "aps"
		}, {
			"name": "APJ-ANZ",
			"key": "apa"
		}]
	};
});