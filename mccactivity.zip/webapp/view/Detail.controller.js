sap.ui.define([
	"sap/support/mccactivities/util/BaseController",
	"sap/support/mccactivities/util/Formatter",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/support/mccactivities/model/help"
], function (Controller, Formatter, Filter, MessageToast, MessageBox, help) {
	"use strict";
	return Controller.extend("sap.support.mccactivities.view.Detail", {
		_oModel: new sap.ui.model.json.JSONModel({}),
		_oModelEdit: new sap.ui.model.json.JSONModel({}),
		_oModelStatus: new sap.ui.model.json.JSONModel({}),
		_oModelSolutions: new sap.ui.model.json.JSONModel({}),
		//activityDetail: {},
		activityNotes: {},
		formatter: Formatter,

		onInit: function () {
			this._setImageSRC();
			this.getHelpValueLists();
			this._oModelStatus.setData({
				display: true,
				edit: false
			});
			this.getView().setModel(this._oModelStatus, "Status");
			this.getView().setModel(this._oModelStatus, "Solutions");
			this.getEventBus().subscribe("sap.support.mccactivities", "DisplayActivity", this.prepareActivityData, this);
			this.getEventBus().subscribe("sap.support.mccactivities", "LeaveEditMode", this.onCancel, this);
			this.getEventBus().subscribe("sap.support.mccactivities", "SearchSolutions", this.searchSolutions, this);
		},

		onBeforeRendering: function () {
			var sCurActId = this.getOwnerComponent().sCurActivityId;
			if (sCurActId) {
				this.getActivityDetails(sCurActId);
			}
		},

		getHelpValueLists: function () {
			//this.getRegionList();
			this.getCategoryList();
			this.getStatusList(false);
			this.getRatingList();
			this.getPriorityList();
		},

		prepareActivityData: function (sChannel, sEvent, oData) {
			this.getActivityDetails(oData.id);
			this._activityId = oData.id;
		},

		onHeaderActIdPressed: function (oEvent) {
			var sLink = "ht" + "tps://mccactivity-" + this.getAccount() + ".hana" + ".ondemand.com/?activityid=" + this._activityId +
				"&event=display";
			sap.m.URLHelper.redirect(sLink, true);
		},

		onLinkActivityId: function (oEvent) {
			var sLink = "ht" + "tps://ic" + this.getSystem() +
				".wdf.sap.corp/sap(bD1lbiZjPTAwMSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?" +
				"crm-object-type=BT126_APPT&crm-object-action=B&sap-language=EN&crm-object-keyname=OBJECT_ID&crm-object-" +
				"value=" + oEvent.getSource().getText();
			sap.m.URLHelper.redirect(sLink, true);
		},

		onLinkCaseId: function (oEvent) {
			var sLink = "ht" + "tps://ic" + this.getSystem() + ".wdf.sap.corp/" +
				"sap/bc/bsp/sap/crm_ui_start/default.htm?" +
				"crm-object-type=CRM_CMG&crm-object-action=B&sap-language=EN&crm-object-keyname=EXT_KEY&crm-object-" +
				"value=" + oEvent.getSource().getText();
			sap.m.URLHelper.redirect(sLink, true);
		},

		onSetFavorite: function () {
			var sActivityId = this.getView().getModel("Detail").getProperty("/activity_id");
			var oModel = this.getOwnerComponent().oDataUserProfile;
			oModel.create("/Entries", {
				"Attribute": "FAVORITE_ACTIVITIES",
				"Value": sActivityId
			}, {
				success: function () {
					oModel.read("/Entries", {
						filters: [new Filter("Attribute", "EQ", "FAVORITE_ACTIVITIES")],
						success: function (oData) {
							this.getOwnerComponent().getModel("UserProfile").setProperty("/FAVORITE_ACTIVITIES", oData.results);
							this.getOwnerComponent().getModel("UserProfileEdit").setProperty("/FAVORITE_ACTIVITIES", oData.results);
							this.afterFavoriteChanged();
						}.bind(this)
					});
				}.bind(this)
			});
			//this.afterFavoriteChanged();
			this.searchSolutions();
		},

		onRemoveFavorite: function () {
			var sActivityId = this.getView().getModel("Detail").getProperty("/activity_id");
			var oModel = this.getOwnerComponent().oDataUserProfile;
			var aFavoriteActivities = this.getOwnerComponent().getModel("UserProfile").getProperty("/FAVORITE_ACTIVITIES");
			var iField;
			for (var index = 0; index < aFavoriteActivities.length; index++) {
				if (aFavoriteActivities[index].Value === sActivityId) {
					iField = aFavoriteActivities[index].Field;
					oModel.remove("/Entries(Username='',Attribute='FAVORITE_ACTIVITIES',Field='" + iField + "')", {
						success: function () {
							oModel.read("/Entries", {
								filters: [new Filter("Attribute", "EQ", "FAVORITE_ACTIVITIES")],
								success: function (oData) {
									this.getOwnerComponent().getModel("UserProfile").setProperty("/FAVORITE_ACTIVITIES", oData.results);
									this.getOwnerComponent().getModel("UserProfileEdit").setProperty("/FAVORITE_ACTIVITIES", oData.results);
									this.afterFavoriteChanged();
								}.bind(this)
							});
						}.bind(this)
					});
					break;
				}
			}
		},

		setFavoriteFlag: function (oActivity) {
			if (Object.prototype.toString.call(oActivity) === "[object Object]" && oActivity.activity_id) {
				var bFlag = false;
				var aFavorites = this.getOwnerComponent().getModel("UserProfile").getProperty("/FAVORITE_ACTIVITIES");
				if (Array.isArray(aFavorites)) {
					$.each(aFavorites, function (index, item) {
						if (item.Value && item.Value === oActivity.activity_id) {
							bFlag = true;
							return false;
						}
					});
				}
				oActivity._bFavorite = bFlag;
				return oActivity;
			} else {
				return false;
			}
		},

		afterFavoriteChanged: function () {
			this.getOwnerComponent().oDataManager.loadSingleList("Favorites");
			this.getActivityDetails(this._activityId);
		},

		onNavBack: function () {
			var that = this;
			var fnNavBack = function () {
				that.navTo("master");
			};
			if (this.getOwnerComponent()._bEditMode || this.leaveEditSettings()) {
				//jQuery.sap.require("sap.m.MessageBox");
				MessageBox.confirm("Leave the edit page without saving?", {
					onClose: function (oAction) {
						if (oAction === "OK") {
							that.getOwnerComponent()._bSettingsEditMode = false;
							that.getEventBus().publish("sap.support.mccactivities", "LeaveEditMode");
							fnNavBack();
						}
					}
				});
			} else {
				fnNavBack();
			}
		},

		prepareNote: function (oData) {
			this.getView().getModel("Detail").setProperty("/ActivityNotes", oData.d);
			var aNoteResults = this.getView().getModel("Detail").getData().ActivityNotes.results;
			var aFeedItems = [];
			var index = 0;
			var oFeedItem = {
				name: "",
				time: "",
				text: "\n"
			};
			while (aNoteResults.length > index) {
				if (index === aNoteResults.length - 1) {
					oFeedItem.text = oFeedItem.text + aNoteResults[index].tdline;
					oFeedItem.text += "\n";
					aFeedItems.push(oFeedItem);
					oFeedItem = {
						name: "",
						time: "",
						text: ""
					};
					index++;
				} else {
					switch (aNoteResults[index].tdline) {
					case "Description":
						oFeedItem.time = aNoteResults[index + 1].tdline.replace(/\s+/g, " ").split(" ", 2).join(" ");
						oFeedItem.name = aNoteResults[index + 2].tdline;
						index = index + 3;
						break;
					case "":
						index++;
						break;
					case "____________________":
						aFeedItems.push(oFeedItem);
						oFeedItem = {
							name: "",
							time: "",
							text: ""
						};
						index++;
						break;
					default:
						oFeedItem.text = oFeedItem.text + aNoteResults[index].tdline;
						oFeedItem.text += "\n";
						index++;
					}
				}
			}
			this.getView().getModel("Detail").setProperty("/NoteList", aFeedItems);
			this.copyDetailModelToEditModel();
			this.getEventBus().publish("sap.support.mccactivities", "SearchSolutions");
		},

		copyDetailModelToEditModel: function () {
			var oDetailData = this.getView().getModel("Detail").getData();
			var oDetailEditData = jQuery.extend(true, {}, oDetailData);
			this.getView().getModel("DetailEdit").setData(oDetailEditData);
		},

		onSaveNote: function (oEvent) {
			this.updateActivityNote(oEvent, null, false);
		},

		onSaveNoteAndSendMCC: function (oEvent) {
			var oRejectModel = {
				activity_status: "E0011",
				activity_person_user_id: ""
			};
			this.updateActivityNote(oEvent, oRejectModel, true);
		},

		onSaveNoteAndClose: function (oEvent) {
			/*
			Set trigger close trigger.
			*/
			document.cookie = "qualtrics=close";
			this.getOwnerComponent()._QualtricsTriggerClose = true;

			var oCloseModel = {
				activity_status: "E0014"
			};
			MessageBox.confirm(
				this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("txt_msgCloseAct"), {
					onClose: function (oAction) {
						if (oAction === "OK") {
							this.updateActivityNote(oEvent, oCloseModel, true);
						}
					}.bind(this)
				}
			);
		},

		updateActivityNote: function (oEvent, oUpdateModel, fRefreshMaster) {
			var sNote = this.getView().byId("detailTextAreaInput").getProperty("value");
			var oModel = oUpdateModel && Object.prototype.toString.call(oUpdateModel) === "[object Object]" ? this.copyObject(oUpdateModel) : {};
			if (this._activityId) {
				this.getView().setBusy(true);
				if (sNote) {
					this.eventUsage(false, "Add notes");
					this.updateActivityRequest(this._activityId, $.extend({}, oModel, {
						Notes: sNote
					}), fRefreshMaster);
				} else {
					this.updateActivityRequest(this._activityId, $.extend({}, oModel), fRefreshMaster);
				}
			}
		},

		updateActivityRequest: function (sActId, oActModel, fRefreshMaster) {
			if (sActId && oActModel && JSON.stringify(oActModel) !== "{}") {
				this.getOwnerComponent().oDashBoardsModel.update("/ActivityList('" + sActId + "')", oActModel, {
					success: function (oData) {
						this.getActivityDetails(sActId);
						if (fRefreshMaster) {
							this.getOwnerComponent().oDataManager.loadActivitiesList();
						}
						this.getView().byId("detailTextAreaInput").setValue("");
						this._setNotesActionButtonsEnable("");
					}.bind(this),
					error: function (error) {
						MessageToast.show("Error during update");
						this.getView().setBusy(false);
					}.bind(this)
				});
			}
		},

		handleInput: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			this._setNotesActionButtonsEnable(sValue);
		},

		_setNotesActionButtonsEnable: function (sText) {
			if (sText) {
				this.getView().byId("detailButtonInput").setEnabled(true);
				this.getView().byId("iNoteAndSendMCC").setEnabled(true);
				//this.getView().byId("iNoteAndClose").setEnabled(true);
				this.getView().byId("detailTextAreaInput").setBusy(false);
			} else {
				this.getView().byId("detailButtonInput").setEnabled(false);
				this.getView().byId("iNoteAndSendMCC").setEnabled(false);
				//this.getView().byId("iNoteAndClose").setEnabled(false);
			}
		},

		onOverflow: function (oEvent) {
			var oButton = oEvent.getSource();
			if (!this._actionSheet) {
				this._actionSheet = sap.ui.xmlfragment("sap.support.mccactivities.fragment.DetailActionSheet", this);
				this.getView().addDependent(this._actionSheet);
			}
			this._actionSheet.openBy(oButton);
		},

		onUseAsTemplate: function () {
			var oModel = this.getView().getModel("Detail");
			var oActivity = {
				caseid: oModel.getProperty("/ActivityCases/results/0/transactions_case_id"),
				serviceteam: oModel.getProperty("/activity_service_team"),
				customer: oModel.getProperty("/activity_customer"),
				priority: oModel.getProperty("/activity_priority"),
				category: oModel.getProperty("/activity_cat"),
				personuserid: oModel.getProperty("/activity_person_user_id")
			};
			this.navTo("create");
			this.getEventBus().publish("sap.support.mccactivities", "CreateUsingTemplate", {
				data: oActivity
			});
		},

		onUseAsRequestor: function () {
			this.navTo("create");
			this.getEventBus().publish("sap.support.mccactivities", "CreateUsingRequestor", {
				data: {
					title: "Create on behalf",
					desc: "Create on behalf"
				}
			});
		},

		onEdit: function () {
			sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), "Edit activity");
			this.getOwnerComponent()._bEditMode = true;
			var oView = this.getView();
			oView.byId("status").setSelectedKey(this.getView().getModel("Detail").getData().activity_status);
			this.getCategoryList(false, this.getView().getModel("Detail").getData());
			oView.byId("category").setSelectedKey(this.getView().getModel("Detail").getData().activity_cat);
			oView.byId("rating").setSelectedKey(this.getView().getModel("Detail").getData().activity_rating);
			oView.byId("priority").setSelectedKey(this.getView().getModel("Detail").getData().activity_priority);
			var oInServiceTeam = oView.byId("inServiceTeam");
			var oRegion = oView.byId("region");
			var oTopic = oView.byId("topic");
			if (oInServiceTeam.getValue() === "") {
				oRegion.setSelectedKey(-1);
				oRegion.setVisible(false);
				oTopic.setVisible(false);
				oInServiceTeam.setVisible(true);
				oInServiceTeam.setEnabled(false);
				oInServiceTeam.setPlaceholder("No service team entered");
			} else {
				oInServiceTeam.setVisible(true);
				oInServiceTeam.setEnabled(false);
				oRegion.setVisible(false);
				oTopic.setVisible(false);
			}
			this.getView().getModel("Status").setData({
				display: false,
				edit: true
			});
			this.getView().byId("IconTabBar").setSelectedKey("detailEdit");
		},

		onSave: function () {
			this.checkInputs();
		},

		checkInputs: function () {
			var bSave = true;
			var oView = this.getView();
			if (oView.byId("inPersonUserID").getValue() === "") {
				bSave = false;
			}

			this.saveActivity();
		},

		getChangeData: function () {
			var oView = this.getView();
			var oActivity = {
				userId: oView.byId("inPersonUserID").getValue(),
				caseid: oView.byId("idMatnrInputCaseID").getValue(),
				serviceTeam: oView.byId("inServiceTeam").getValue(),
				status: oView.byId("status").getSelectedKey(),
				category: oView.byId("category").getSelectedKey(),
				rating: oView.byId("rating").getSelectedKey(),
				priority: oView.byId("priority").getSelectedKey(),
				planned_date_to: "/Date(" + Date.parse(oView.byId("inPlannedDateTo").getValue()) + ")/"
			};
			return oActivity;
		},

		saveActivity: function () {
			var that = this;
			var oActivityData = this.getChangeData();
			var sUrl = that.getDataSource("env_PG_AGS_DASHBOARDS");
			var sCollection = sUrl + "ActivityList('" + that._activityId + "')";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			sap.ui.getCore().setModel(oModel);
			oModel.refreshSecurityToken();
			var oModelHeaders = oModel.getHeaders();
			var oHeaders = {
				"x-csrf-token": oModelHeaders['x-csrf-token'],
				"Content-Type": "application/json; charset=utf-8",
				"x-http-method": "MERGE"
			};
			var entries = {};
			if (oActivityData.serviceTeam !== null && oActivityData.serviceTeam !== "0") {
				entries.activity_service_team = oActivityData.serviceTeam;
			} else {
				entries.activity_service_team = "";
			}
			if (oActivityData.category !== null && oActivityData.category !== "0") {
				entries.activity_cat = oActivityData.category;
			} else {
				entries.category = "";
			}
			if (oActivityData.priority !== null && oActivityData.priority !== "0") {
				entries.activity_priority_code = oActivityData.priority;
			} else {
				entries.activity_priority_code = "";
			}
			if (oActivityData.caseid !== null && oActivityData.caseid !== "0") {
				entries.activity_case_id = oActivityData.caseid;
			} else {
				entries.activity_case_id = "";
			}
			if (oActivityData.rating !== null && oActivityData.rating !== "0") {
				entries.rating = oActivityData.rating;
			} else {
				entries.rating = "";
			}
			oModel = new sap.ui.model.json.JSONModel({
				TASK_UpdateActivityList: [{
					activity_person_user_id: Formatter.uppercaseLeadingLetter(oActivityData.userId),
					activity_service_team: entries.activity_service_team,
					activity_status: oActivityData.status,
					activity_rating: entries.rating,
					activity_cat: entries.activity_cat,
					activity_priority: entries.activity_priority_code,
					//activity_planned_date: oActivityData.planned_date,
					activity_planned_date_to: oActivityData.planned_date_to,
					CaseId: entries.activity_case_id
				}]
			});
			jQuery.ajax({
				async: true,
				url: sCollection,
				type: "POST",
				dataType: "json",
				headers: oHeaders,
				data: JSON.stringify(oModel.oData.TASK_UpdateActivityList[0]),
				success: function () {
					that.getActivityDetails(that._activityId);
					that.getOwnerComponent().oDataManager.loadActivitiesList();
					that.onCancel();
				},
				error: function () {
					sap.m.MessageToast.show("Error during update");
					that.onCancel();
				}
			});
		},

		onCancel: function () {
			this.copyDetailModelToEditModel();
			this.getView().byId("topic").setVisible(false);
			this.getOwnerComponent()._bEditMode = false;
			this.getView().getModel("Status").setData({
				display: true,
				edit: false
			});
			this.getView().byId("IconTabBar").setSelectedKey("detail");
		},

		onCancelDialog: function (oEvent) {
			this._oCreateDialog.close();
		},

		searchSolutions: function () {
			var oAct = this.getView().getModel("Detail").getData();
			var reqData = {
				"userId": this.getOwnerComponent().sUser,
				"title": oAct.activity_description,
				"problemDescription": this._handleActNoteList(oAct.NoteList),
				"firstEntry": 0,
				"lastEntry": 10,
				"queryId": oAct.activity_id,
				"serviceTeam": oAct.activity_service_team,
				"customerNumber": oAct.customer_id,
				"customerCountry": oAct.country
			};
			
		    var reqDataAc = {
				"header": oAct.activity_description,
				"note": this._handleActNoteList(oAct.NoteList)
			};
			
			this._readSolActData(reqDataAc, "Actv");
			
			this._readSolutionData(reqData, "noComp");
			reqData["component"] = "XX-SER-MCC";
			reqData["FilterSolutionStatus"] = ["Released Internally"];
			this._readSolutionData(reqData, "Comp");
		},

		_readSolutionData: function (reqData, sModelName) {
			var sUrl = this.getOwnerComponent().sFirstSlash + "services/ism/incident-solution-matching/v1/basicauth/";
			$.ajax({
				url: sUrl,
				type: "POST",
				async: true,
				contentType: "application/json",
				data: JSON.stringify(reqData),
				success: function (oData) {
					if (oData && oData.result_list && oData.result_list.length > 0) {
						var solutions = oData.result_list;
						$.each(solutions, function (index, item) {
							item.link = "ht" + "tp://launchpad.support.sap.com/#/notes/" + item.nr;
						});
					}
					this.getView().getModel("Solutions").setProperty("/" + sModelName, solutions);
				}.bind(this)
			});
		},

		_readSolActData: function (reqData, sModelName) {
			var that = this;
			var sUrl = this.getOwnerComponent().sFirstSlash + "services/ism/mcc-activity-activity-matching-service/v0/basicauth/";
			$.ajax({
				url: sUrl,
				type: "POST",
				async: true,
				contentType: "application/json",
				data: JSON.stringify(reqData),
				success: function (oData, status, response) {
					if (oData && oData.activities && oData.activities.length > 0) {
						var solutions = oData.activities;
						$.each(solutions, function (index, item) {
							item.link = "ht" + "tps://mccactivity-" + that.getAccount() + ".hana" + ".ondemand.com/?activityid=" + item[0] +
								"&event=display";
							item.nr = item[0];
							item.title = item[1];
							item.type = "Activity";
						});
					}
					that.getView().getModel("Solutions").setProperty("/" + sModelName, solutions);
				}.bind(this),
				error: function (error) {
					var txt = error.responseText;
				}
			});
		}, 

		onSelectSolution: function (oEvent) {
			window.open(oEvent.getSource().getCustomData()[0].getValue());
		},

		_handleActNoteList: function (aNote) {
			var result = "";
			if (Array.isArray(aNote)) {
				result += "MCC";
				aNote.forEach(function (item) {
					result += item.text;
				});
			}
			return result.replace(/[\r\n]/g, " ");
		},

		openQuickView: function (oEvent) {
			if (!this._oQuickView) {
				this._oQuickView = sap.ui.xmlfragment("sap.support.mccactivities.fragment.NoCaseQuickView", this);
				this.getView().addDependent(this._oQuickView);
			}
			// delay because addDependent will do a async rerendering and the actionSheet will immediately close without it.
			var oButton = oEvent.getSource();
			jQuery.sap.delayedCall(0, this, function () {
				this._oQuickView.openBy(oButton);
			});
		},

		onExit: function () {
			if (this._oQuickView) {
				this._oQuickView.destroy();
			}
		},

		onMailToPersonResponsible: function () {
			var sUserId = this.getView().getModel("Detail").getProperty("/activity_person_user_id");
			this.MailTo(sUserId);
		},

		onMailToLastChanger: function () {
			var sUserId = this.getView().getModel("Detail").getProperty("/ChangedBy");
			this.MailTo(sUserId);
		},

		onMailToCreator: function () {
			var sUserId = this.getView().getModel("Detail").getProperty("/activity_created_by");
			this.MailTo((this._checkValidEmailTo(sUserId) ? sUserId : ""));
		},

		onShareViaMail: function () {
			this.MailTo("");
		},

		MailTo: function (sRecipient) {
			var sActivityId = this.getView().getModel("Detail").getProperty("/activity_id");
			var sSubject = "[CONFIDENTIAL] MCC Activity with ID: " + sActivityId;
			var sRequestor = this.getView().getModel("Detail").getProperty("/activity_created_by");
			var aNoteList = this.getView().getModel("Detail").getProperty("/NoteList");
			var sCcAddress, sNote = "";
			sCcAddress = this._checkValidEmailTo(sRequestor) ? sRequestor : "";
			if (sCcAddress === sRecipient) {
				sCcAddress = "";
			}
			if (aNoteList && aNoteList.length > 0 && aNoteList[0]) {
				sNote = "\n------------------------------------------------------------------------------------------------------------------\n" +
					aNoteList[0].name + ":\n" + this._cutLastNote(aNoteList[0].text) + "\n" + aNoteList[0].time +
					"\n------------------------------------------------------------------------------------------------------------------";
			}
			var sShareEmailText = "Dear colleague,\n\nPlease have a look at MCC Activity " + sActivityId + "." + sNote +
				"\n\nTo access the MCC Activity please use the links below." +
				"\n\nLink to UI5 App:\nht" +
				"tps://mccactivity-" + this.getAccount() +
				".hana.ondemand.com/?event=display&activityid=" + sActivityId + " " +
				"\n\nLink to CRM Web UI:\nht" +
				"tps://ic" + this.getSystem() +
				".wdf.sap.corp/sap(bD1lbiZjPTAwMSZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?&crm-object-type=BT126_APPT&crm-object-action=B&sap-language=EN&crm-object-keyname=OBJECT_ID&crm-object-value=" +
				sActivityId + " " +
				"\n\n\n------------------------------------------------------------------------------------------------------------------\n" +
				"DISCLAIMER: This document is confidential and should only be used internally.\n" +
				"------------------------------------------------------------------------------------------------------------------" +
				"\n\nCreated by MCC Actvities App";
			if (this.getOwnerComponent().getModel("device").getProperty("/isPhone") && sRecipient !== "") {
				sRecipient += "@exchange.sap.corp";
			}

			sap.m.URLHelper.triggerEmail(sRecipient, sSubject, sShareEmailText, sCcAddress);
		},

		_cutLastNote: function (sNote) {
			var sRes = "";
			if (Object.prototype.toString.call(sNote) === "[object String]") {
				if (sNote.length > 380) {
					var subNote = sNote.substr(0, 380);
					if (subNote.lastIndexOf(" ") > 300) {
						sRes = subNote.substr(0, subNote.lastIndexOf(" ")) + "...\n";
					} else {
						sRes = subNote + "...\n";
					}
				} else {
					sRes = sNote;
				}
			}
			return sRes;
		},

		onChange: function (oEvent) {
			if (this._activityId) {
				var oUploadCollection = oEvent.getSource();
				oUploadCollection.setBusy(true);
				var sUrl = this.getDataSource("env_PG_AGS_DASHBOARDS");
				var oModel = new sap.ui.model.odata.v2.ODataModel(sUrl, true);
				var uploadUrl = sUrl + "ActivityList('" + this._activityId + "')/Attachment";
				sap.ui.getCore().setModel(oModel);
				oModel.refreshSecurityToken();
				var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
					name: "x-csrf-token",
					value: sap.ui.getCore().getModel().getHeaders()['x-csrf-token']
				});
				oUploadCollection.setUploadUrl(uploadUrl);
				oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
				oUploadCollection.upload();
			}
		},

		onBeforeUploadStarts: function (oEvent) {
			// Header Slug
			var oCustomerHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "slug",
				value: oEvent.getParameter("fileName")
			});
			oEvent.getParameters().addHeaderParameter(oCustomerHeaderSlug);
		},

		onUploadComplete: function (oEvent) {
			var oUploadCollection = oEvent.getSource();
			if (this._activityId !== "") {
				this.eventUsage(false, "Upload attachments");
				this.getOwnerComponent().oDashBoardsModel.read("/ActivityList", {
					filters: help.setSingleActSearchFilters(this._activityId),
					urlParameters: {
						"$expand": "PartiesInvolved,ActivityCases,Attachment"
					},
					success: function (data) {
						oUploadCollection.setBusy(false);
						this._setRefreshDetailModel(this.prepareDateNew(data));

					}.bind(this),
					error: function () {
						oUploadCollection.setBusy(false);
						sap.m.MessageToast.show("Error during activity search. Please reload this page.");
					}
				});
			}
		},

		onFileSizeExceed: function (oEvent) {
			sap.m.MessageToast.show("Please choose a file less than 10 MB.");
		},

		onFileNameExceed: function (oEvent) {
			sap.m.MessageToast.show("Please choose a file name less than 100 characters.");
		},

		_setRefreshDetailModel: function (oData) {
			this._oModel.setData(oData);
			this._oModelEdit.setData(oData);
			this.getView().setModel(this._oModel, "Detail");
			this.getView().setModel(this._oModelEdit, "DetailEdit");
		},

		_setImageSRC: function () {
			var oImageSRC = jQuery.sap.getModulePath("sap.support.mccactivities") + "/res/mdr2.png";
			var oImageModel = new sap.ui.model.json.JSONModel();
			oImageModel.setProperty("/mdr2", oImageSRC);
			this.getView().setModel(oImageModel, "Image");
		},

		_checkValidEmailTo: function (oStr) {
			if (!oStr) {
				return false;
			} else {
				switch (oStr.substr(0, 1)) {
				case "D":
				case "I":
					return oStr.length === 7 && /^[0-9]+$/.test(oStr.substr(1, 6));
				case "C":
					return oStr.length === 8 && /^[0-9]+$/.test(oStr.substr(1, 7));
				default:
					return this._emailFormatCheck(oStr);
				}
			}
		},

		_emailFormatCheck: function (oText) {
			var reg =
				/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
			return reg.test(oText);
		},
		feedback: function () { //Qualtrics
			document.cookie = "qualtrics=permanent";
			/*eslint-disable */
			QSI.API.unload();
			QSI.API.load().then(QSI.API.run());
			/*eslint-enable */
		}

	});
});