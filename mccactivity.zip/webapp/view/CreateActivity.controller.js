sap.ui.define([
	"sap/support/mccactivities/util/BaseController",
	"sap/support/mccactivities/util/Formatter",
	"sap/support/mccactivities/model/appData",
	"sap/support/mccactivities/model/models",
	"sap/support/mccactivities/model/help",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function(Controller, Formatter, appData, models, help, JSONModel, MessageToast) {
	"use strict";
	return Controller.extend("sap.support.mccactivities.view.CreateActivity", {
		oFlagCallMe: false,
		oFlagCreateByEvent: false,
		oFlagCreateByTemplate: false,

		onInit: function() {

			this._requireOtherModule();
			this._setCreateModel();
			this._setRegionModel();

			//this.getView().setBusyIndicatorDelay(0);
			this.getView().setBusy(false);

			this.getEventBus().subscribe("sap.support.mccactivities", "CreateUsingTemplate", this.prepareInputFields, this);
			this.getEventBus().subscribe("sap.support.mccactivities", "CreateUsingRequestor", this.prepareRequestorInputFields, this);
			//this.getEventBus().subscribe("sap.support.mccactivities", "CreateUsingEvent", this.prepareEventInputFields, this);
			//this.getHelpValueLists();
			this.getView().addEventDelegate({
				onBeforeShow: function() {
					this._getEventCreationProperties();
					this._checkCaseIDFilled();
				}.bind(this)
			});
			
			this.getView().setModel(new sap.ui.model.json.JSONModel({}), "solutions");
			
			this._setSolutionVisible();
		},

		// #Actions
		onCaseIdChange: function() {
			this._checkERPCustomerFilled();
		},
		
		_checkCaseIDFilled: function() {
			var oUserProfileModel = $.extend(true, {}, this.getOwnerComponent().getModel("UserProfile"));
			if (oUserProfileModel && this.getView().getModel("Creation").getProperty("/caseId") === "") {
				this.getView().getModel("Creation").setProperty("/caseId", oUserProfileModel.getProperty("/APP_MCC_ACTIVITIES_DEFAULT_CASE") ?
					oUserProfileModel.getProperty("/APP_MCC_ACTIVITIES_DEFAULT_CASE").Value :
					"");
				this._readERPCustNo();
			}
		},
		
		_getEventCreationProperties: function() {
			var oUriPara = $.sap.getUriParameters();
			var oModelCreation = this.getView().getModel("Creation");
			var fCase = false;
			var fCustomer = false;
			if (oUriPara.get("caseid") !== null) {
				oModelCreation.setProperty("/caseId", oUriPara.get("caseid"));
				fCase = true;
			}
			if (oUriPara.get("erpcust") !== null) {
				oModelCreation.setProperty("/erpCust", oUriPara.get("erpcust"));
				fCustomer = true; 
			}
			if (oUriPara.get("category") !== null) {
				oModelCreation.setProperty("/category", oUriPara.get("category"));
			}
			if (oUriPara.get("title") !== null) {
				oModelCreation.setProperty("/title", oUriPara.get("title"));
			}
			if (oUriPara.get("desc") !== null) {
				oModelCreation.setProperty("/desc", oUriPara.get("desc"));
			}
			if (oUriPara.get("serviceteam") !== null && oUriPara.get("serviceteam") !== "") {
				oModelCreation.setProperty("/serviceTeam", oUriPara.get("serviceteam"));
				this.oFlagCreateByEvent = true;
			}
			
			if (fCase && fCustomer) {
				this.oFlagCreateByEvent = true;
				this._checkCaseCustMatched();
			} else if (fCase && !fCustomer) {
				this.oFlagCreateByEvent = true;
				this._readERPCustNo(true);
			} else if (!fCase && fCustomer){
				this.oFlagCreateByEvent = true;
				this._readCaseId();
			}
		},

		onSetDefaults: function() {
			this.oFlagCreateByEvent = false;
			var oUserProfileModel = $.extend(true, {}, this.getOwnerComponent().getModel("UserProfile"));
			if (oUserProfileModel) {
				// Case Id
				this.getView().getModel("Creation").setProperty("/caseId", oUserProfileModel.getProperty("/APP_MCC_ACTIVITIES_DEFAULT_CASE") ?
					oUserProfileModel.getProperty("/APP_MCC_ACTIVITIES_DEFAULT_CASE").Value :
					"");
				// ERP Customer Number
				this._readERPCustNo();
				// Default Description
				//this.checkSetDefaultDescription();
				// Priority
				this.getView().getModel("Creation").setProperty("/priority", "5");
				// Category
				this.getView().getModel("Creation").setProperty("/category", "ZB4");
				/*this.getView().getModel("Creation").setProperty("/category", this.getOwnerComponent().getModel("DefaultCategory").getProperty(
					"/result"));*/
				// // Service Team
				// var sServiceTeam = oUserProfileModel.getProperty("/APP_MCC_ACTIVITIES_DEFAULT_STEAM") ? oUserProfileModel.getProperty(
				// 	"/APP_MCC_ACTIVITIES_DEFAULT_STEAM").Value : "";
				// if (sServiceTeam) {
				// 	this.setServiceTeam(sServiceTeam);
				// }
				// Requestor Visible
				this.getView().getModel("Creation").setProperty("/requestorVisible", false);
				// Requestor
				this.getView().getModel("Creation").setProperty("/requestor", "");
			}
		},

		onCancel: function() {
			this.onClear();
			this.onNavBack();
		},

		onClear: function() {
			this.oFlagCallMe = false;
			this.oFlagCreateByEvent = false;
			this.oFlagCreateByTemplate = false;
			// this.getView().byId("topic").setVisible(false);
			// this.getView().byId("inServiceTeam").setVisible(false);
			this._setCreateModel();
			this._setSolutionVisible();
		},

		onCreate: function() {
			/*
				Does not show Qualtrics Survey, when creation is on behalf.
				Set trigger if activity is created on behalf. 
				Set trigger create trigger.
			*/
			document.cookie= "qualtrics=create"; //Qualtrics 
			this.getOwnerComponent()._QualtricsTriggerIsOnBehalf = this.getView().getModel("Creation").getProperty("/requestorVisible"); //Qualtrics
			this.getOwnerComponent()._QualtricsTriggerFromCreate = true; //Qualtrics
			
			this.getView().byId("iBtnCreateAct").setEnabled(false);
			//clear "Call Me" flag
			this.oFlagCallMe = false;
			this._sCheck = this.checkInputs();
			this.getView().setBusy(true);
			
			if (this._sCheck.indexOf("invalidCaseId") > -1 && this._sCheck.indexOf("false") === -1) {
				this._oInvalidCaseIdDialog = sap.ui.xmlfragment("sap.support.mccactivities.fragment.InvalidCaseIdDialog", this);
				this.getView().addDependent(this._oInvalidCaseIdDialog);
				this._oInvalidCaseIdDialog.open();
			} else {
				this.checkMissingAccount(this._sCheck);
			}
		},

		onCallMe: function() {
			this.onClear();
			//set "Call Me" flag
			this.oFlagCallMe = true;
			var oUserProfileModel = $.extend(true, {}, this.getOwnerComponent().getModel("UserProfile"));
			if (oUserProfileModel) {
				// Case Id
				this.getView().getModel("Creation").setProperty("/caseId", oUserProfileModel.getProperty("/APP_MCC_ACTIVITIES_DEFAULT_CASE") ?
					oUserProfileModel.getProperty("/APP_MCC_ACTIVITIES_DEFAULT_CASE").Value :
					"");
				// ERP Customer Number
				this._readERPCustNo();
				// Title
				this.getView().getModel("Creation").setProperty("/title", "Please call me");
				// Description
				this.getView().getModel("Creation").setProperty("/desc", "Please call me");
				// Priority
				this.getView().getModel("Creation").setProperty("/priority", "1");
				/*// Category
				this.getView().getModel("Creation").setProperty("/category", "ZB4");*/
				// Service Team
				// var sServiceTeam = oUserProfileModel.getProperty("/APP_MCC_ACTIVITIES_DEFAULT_STEAM") ? oUserProfileModel.getProperty(
				// 	"/APP_MCC_ACTIVITIES_DEFAULT_STEAM").Value : "";
				// var aData = this.getOwnerComponent().getModel("SettingList").getProperty("/RegionList");
				// for (var indexRegion = 0; indexRegion < aData.length; indexRegion++) {
				// 	for (var indexTopic = 0; indexTopic < aData[indexRegion].Topic.length; indexTopic++) {
				// 		// use "==" because type of serviceTeam doesn't match
				// 		if (aData[indexRegion].Topic[indexTopic].service_team_id == sServiceTeam) {
				// 			this.getView().byId("region").setSelectedKey(indexRegion);
				// 			this.checkSelectedRegion(indexRegion);
				// 			this.setCMTopic(aData[indexRegion].Region);
				// 		}
				// 	}
				// }
			}
		},

		// #Help functions
		// getHelpValueLists: function() {
		// 	//this.getRegionList();
		// 	//this.getPriorityList();
		// 	//this.getCategoryList(true);
		// 	//this.getView().byId("priority").setSelectedKey("5");
		// 	//this.getView().byId("category").setSelectedKey("Z88");
		// },
		
		onUpdateSolutions: function() {
			this._setSolutionVisible();
			var sRegionKey = this.getOwnerComponent().getModel("UserProfile").getProperty("/APP_MCC_ACTIVITIES_REGION/Value");
				if (!sRegionKey) {
					this.getView().byId("iBtnCreateAct").setEnabled(true);
					this.getView().setBusy(false);
					// jQuery.sap.require("sap.m.MessageBox");
					// sap.m.MessageBox.error("Please set your default Region in 'Settings': Actions List(left-bottom corner)->Settings->Defaults");
					var content = "<p>Please set your default Region in <a target='_blank' href='ht" + "tps://mccactivity-" + this.getAccount() + ".hana.ondemand.com/?event=settings&tag=Defaults'>Defaults</a> page.";
					var dialog = new sap.m.Dialog({
						title: "Error",
						type: "Message",
						state: "Error",
						content: [new sap.ui.core.HTML({
							content: content
						})],
						endButton: new sap.m.Button({
							text: "Cancel",
							press: function() {
								dialog.close();
							}
						}),
						afterClose: function() {
							dialog.destroy();
						}
					});
					dialog.open();
					return;
				}
				var oUriPara = $.sap.getUriParameters();
				if(this.oFlagCreateByEvent === true && oUriPara.get("serviceteam") !== null && oUriPara.get("serviceteam") !== "") {
					this.getView().getModel("Creation").setProperty("/serviceTeam", oUriPara.get("serviceteam"));
				}else{
					var sDesc = this.getView().getModel("Creation").getProperty("/desc");
					var sTitle = this.getView().getModel("Creation").getProperty("/title");
					var oRegionData = this.getView().getModel("Region").getData();
					var aRegionData = [];
					for(var i in oRegionData) {
						aRegionData.push(oRegionData[i]);
					}
					for(var j = 0; j < aRegionData.length; j++) {
						var sRegionName;
						if(aRegionData[j].key === sRegionKey) {
							sRegionName = aRegionData[j].name;
							break;
						}else {
							sRegionName = sRegionKey;
						}
					}
					var proData = {
						"note": sTitle + " " + sDesc,
						"region": sRegionName
					};
					var sUrl = this.getOwnerComponent().sFirstSlash + "services/ism/mcc-activity-categorisation-service/v1/basicauth/";
					$.ajax({
						url: sUrl,
						type: "POST",
						async: true,
						contentType: "application/json",
						timeout: 5000,
						headers: {
							"authorization": "sEyKsc3RNxGxZBM5vv2RjSBKQ5WQue5E"
						},
						data: JSON.stringify(proData),
						success: function(oData) {
							this.getView().getModel("Creation").setProperty("/serviceTeam", oData.service_team);
							//this.checkCreateActivity(this.getSearchfields());
						}.bind(this),
						error: function(error) {
							this.getView().getModel("Creation").setProperty("/serviceTeam", this._searchServiceTeamNo(sRegionKey, "1"));
							//this.checkCreateActivity(this.getSearchfields());
						}.bind(this)
					});
				}
			var oCreateData = this.getView().getModel("Creation");
			var reqData = {
				"userId": this.getOwnerComponent().sUser,
				"title": oCreateData.getProperty("/title"),
				"problemDescription": oCreateData.getProperty("/desc"),
				"firstEntry": 0,
				"lastEntry": 10,
				"queryId":oCreateData.getProperty("/caseId"),
				"serviceTeam": oCreateData.getProperty("/serviceTeam"),
				"customerNumber": oCreateData.getProperty("/erpCust"),
				"customerCountry": "Germany"
			};
			
			this._readSolutionData(reqData, "noComp");
			reqData["component"] = "XX-SER-MCC";
			reqData["FilterSolutionStatus"] = ["Released Internally"];
			this._readSolutionData(reqData, "Comp");
			
			var reqDataAc = {
				"header": oCreateData.getProperty("/title"),
				"note": oCreateData.getProperty("/desc")
			};
			
			this._readSolActData(reqDataAc, "Actv");
		},
		
		onChangeSolution: function(oEvent) {
			window.open(oEvent.getSource().getCustomData()[0].getValue());	
		},
		
		_readSolutionData: function(reqData, sModelName) {
			var sUrl = this.getOwnerComponent().sFirstSlash + "services/ism/incident-solution-matching/v1/basicauth/";
			$.ajax({
				url: sUrl,
				type: "POST",
				async: true,
				contentType: "application/json",
				data: JSON.stringify(reqData),
				success: function(oData) {
					if(oData && oData.result_list && oData.result_list.length > 0) {
						var solutions = oData.result_list;
						$.each(solutions, function(index, item) {
							item.link = "ht" + "tp://launchpad.support.sap.com/#/notes/" + item.nr;
						});
					}
					this.getView().getModel("solutions").setProperty("/" + sModelName, solutions);
				}.bind(this)
			});
		},
		
       _readSolActData: function(reqData, sModelName) {
       	   var that = this;
			var sUrl = this.getOwnerComponent().sFirstSlash + "services/ism/mcc-activity-activity-matching-service/v0/basicauth/"; 
			$.ajax({
				url: sUrl,
				type: "POST",
				async: true,
				contentType: "application/json",
				data: JSON.stringify(reqData),
				success: function(oData, status, response) {
					if(oData && oData.activities && oData.activities.length > 0) {
						var solutions = oData.activities;
						$.each(solutions, function(index, item) {
							item.link = "ht" + "tps://mccactivity-" + that.getAccount() + ".hana" + ".ondemand.com/?activityid=" + item[0] +
				                 "&event=display";
				            item.nr = item[0];
				            item.title = item[1];
				            item.type = "Activity";
						});
					}
					that.getView().getModel("solutions").setProperty("/" + sModelName, solutions); 
				}.bind(this),
				error: function(error) {
					var txt = error.responseText;
				}
			});
		},
		
		_setSolutionVisible: function() {
			var sDesc = this.byId("inTitle").getValue(),
				sTitle = this.byId("inDescription").getValue();	
			var aId = ["exSolLabel", "solList1", "inSolLabel", "solList2", "acSolLabel", "solList3"];
			for(var i = 0; i < aId.length; i++) {
				if(sDesc.length === 0 && sTitle.length === 0) {
					this.byId(aId[i]).setVisible(false);
				}else{
					this.byId(aId[i]).setVisible(true);
				}
			}
		},

		_setCreateModel: function() {
			var oModel = models.createNewJSONModel("TwoWay");
			oModel.setData($.extend(true, {}, appData.creationData));
			this.getView().setModel(oModel, "Creation");
		},
		
		_setRegionModel: function() {
			var oModel = models.createNewJSONModel("TwoWay");
			oModel.setData($.extend(true, {}, appData.regionData));
			this.getView().setModel(oModel, "Region");
		},

		_requireOtherModule: function() {
			jQuery.sap.require("sap.support.mccactivities.HelpScreens.CaseF4Help");
		},

		_readERPCustNo: function(bUpdate) {
			var sCaseId = this.getView().getModel("Creation").getProperty("/caseId");
			if (this._checkValidCaseId(sCaseId)) {
				var aFilter = [];
				aFilter.push(new sap.ui.model.Filter("case_id", sap.ui.model.FilterOperator.EQ, sCaseId));
				this.getOwnerComponent().oDashBoardsModel.read("/CaseList", {
					filters: aFilter,
					success: function(oData) {
						var sCust = this.getView().getModel("Creation").getProperty("/erpCust");
						if (oData.results[0] !== undefined && (bUpdate || !this.oFlagCreateByEvent || sCust === "") && (!this.oFlagCreateByTemplate || sCust === "")) {
							this.getView().getModel("Creation").setProperty("/erpCust", oData.results[0].customer_r3_no);
						}
					}.bind(this)
				});
			}
		},
		
		_readCaseId: function() {
			var sCust = this.getView().getModel("Creation").getProperty("/erpCust");
			this.getOwnerComponent().oDashBoardsModel.read("/CaseList/$count", {
				filters: help.setCaseIdSearchFilters(sCust),
				success: function(oData) {
					if (oData < 200) {
						switch(oData) {
							case "1":
								this.getOwnerComponent().oDashBoardsModel.read("/CaseList", {
									filters: help.setCaseIdSearchFilters(sCust),
									success: function(data) {
										if(data.results.length === 1) {
											this.getView().getModel("Creation").setProperty("/caseId", data.results[0].case_id);
										}
									}.bind(this),
									error: function(error) {}
								});
								break;
							case "0":
								break;
							default:
								this.onCaseIdF4();
								break;
						}
					}
				}.bind(this),
				error: function(error) {}
			});
		},
		
		_checkCaseCustMatched: function() {
			var sCaseId = this.getView().getModel("Creation").getProperty("/caseId");
			var sCust = this.getView().getModel("Creation").getProperty("/erpCust");
			if (this._checkValidCaseId(sCaseId) && sCust) {
				this.getOwnerComponent().oDashBoardsModel.read("/CaseList/$count", {
					filters: help.setCaseIdSearchFilters(sCust, sCaseId),
					success: function(oData) {
						if (oData !== "1") {
							jQuery.sap.require("sap.m.MessageBox");
							sap.m.MessageBox.confirm("Warning: ERP number and case ID do not match!");
						}
					}.bind(this),
					error: function(error) {}
				});
			}
		},

		_checkERPCustomerFilled: function() {
			var oCaseIdInput = this.getView().byId("idMatnrInputCaseID");
			var oERPNoInput = this.getView().byId("inAccount");
			if (oCaseIdInput.getValue() !== "" && oERPNoInput.getValue() === "") {
				if (this._checkValidCaseId(oCaseIdInput.getValue())) {
					var aFilter = [];
					aFilter.push(new sap.ui.model.Filter("case_id", sap.ui.model.FilterOperator.EQ, oCaseIdInput.getValue()));
					this.getOwnerComponent().oDashBoardsModel.read("/CaseList", {
						filters: aFilter,
						success: function(oData) {
							if (oData.results[0] !== undefined) {
								oERPNoInput.setValue(oData.results[0].customer_r3_no);
							}
						}
					});
				}
			}
		},

		_checkValidCaseId: function(oValue) {
			if ((oValue.length === 8 && oValue.substr(0, 1) === "2") || (oValue.length === 10 && oValue.substr(0, 3) === "002")) {
				return true;
			} else {
				return false;
			}
		},

		prepareInputFields: function(sChannel, sEvent, oData) {
			var oInputData = oData.data;
			this.oFlagCreateByTemplate = true;
			// Case Id
			this.getView().getModel("Creation").setProperty("/caseId", oInputData.caseid);
			// ERP Customer Number
			this.getView().getModel("Creation").setProperty("/erpCust", oInputData.customer);
			// Priority
			this.getView().getModel("Creation").setProperty("/priority", oInputData.priority);
			// Category
			this.getView().getModel("Creation").setProperty("/category", oInputData.category);
			//Service Team
			this.getView().getModel("Creation").setProperty("/serviceTeam", oInputData.serviceteam);
		},
		
		prepareRequestorInputFields: function(sChannel, sEvent, oData) {
			var oInputData = oData.data;
			this.getView().getModel("Creation").setProperty("/requestorVisible", true);
			this.getView().getModel("Creation").setProperty("/title", oInputData.title);
			this.getView().getModel("Creation").setProperty("/desc", oInputData.desc);
		},

		prepareEventInputFields: function(sChannel, sEvent, oData) {
			var oInputData = oData.data;
			this.getView().getModel("Creation").setProperty("/caseId", oInputData.caseid);
			this.getView().getModel("Creation").setProperty("/erpCust", oInputData.customer);
			this.getView().getModel("Creation").setProperty("/priority", oInputData.priority);
			this.getView().getModel("Creation").setProperty("/category", oInputData.category);
			/*this.byId("category").setSelectedKey(oInputData.category);*/
			//this.byId("inPersonUserID").setValue(oInputData.personuserid);
			if (oInputData.serviceteam && oInputData.serviceteam !== "") {
				this.getView().getModel("Creation").setProperty("/serviceTeam", oInputData.serviceteam);
				this.oFlagCreateByEvent = true;
			}
			this.getView().getModel("Creation").setProperty("/title", oInputData.title);
			this.getView().getModel("Creation").setProperty("/desc", oInputData.desc);
			
			if (oInputData.customer && oInputData.caseid) {
				this.oFlagCreateByEvent = true;
				this._checkCaseCustMatched();
			} else if (!oInputData.customer && oInputData.caseid) {
				this.oFlagCreateByEvent = true;
				this._readERPCustNo(true);
			} else if (oInputData.customer && !oInputData.caseid){
				this.oFlagCreateByEvent = true;
				this._readCaseId();
			}
		},

		cancelInvalidCaseIdDialog: function() {
			if (this._oInvalidCaseIdDialog) {
				this._oInvalidCaseIdDialog.close();
			}
			this.getView().byId("iBtnCreateAct").setEnabled(true);
			this.getView().setBusy(false);
		},

		createActitivityWithoutCaseId: function() {
			this.getView().setBusy(true);
			this.getOwnerComponent().getModel("CreateControl").setProperty("/InvalidCaseIdDialogAccept", false);
			if (this._oInvalidCaseIdDialog) {
				this._oInvalidCaseIdDialog.close();
			}
			this.checkMissingAccount(this._sCheck);
		},

		checkMissingAccount: function(sCheck) {
			var that = this;
			if (sCheck.indexOf("missingAccount") > -1 && sCheck.indexOf("false") === -1) {
				that.getOwnerComponent().getModel("CreateControl").setProperty("/InvalidCaseIdDialogAccept", true);
				that._oNoAccountDialog = sap.ui.xmlfragment("sap.support.mccactivities.fragment.NoAccountDialog", this);
				that.getView().addDependent(that._oNoAccountDialog);
				that._oNoAccountDialog.open();
			} else {
				this._setServiceTeam();
			}
		},

		createActitivityWithoutAccount: function() {
			this.getView().setBusy(true);
			this.getOwnerComponent().getModel("CreateControl").setProperty("/NoAccountDialogAccept", false);
			if (this._oNoAccountDialog) {
				this._oNoAccountDialog.close();
			}
			this._setServiceTeam();
		},
		
		checkCreateActivity: function(searchFields_activity) {
			this._searchFields_activity = searchFields_activity;
			if (this._searchFields_activity.category === "ZZN" && searchFields_activity.title.substring(0, 6).search("EFOS:") === -1) {
				this.getOwnerComponent().getModel("CreateControl").setProperty("/NoAccountDialogAccept", true);
				this._oEFOSDialog = sap.ui.xmlfragment("sap.support.mccactivities.fragment.EFOSDialog", this);
				this.getView().addDependent(this._oEFOSDialog);
				this._oEFOSDialog.open();
			} else {
				this.createActivity(this._searchFields_activity);
			}
		},
		
		_setServiceTeam: function() {
			if (this.oFlagCreateByEvent) {
				this.checkCreateActivity(this.getSearchfields());
			} else if (this.oFlagCreateByTemplate) {
				this.oFlagCreateByTemplate = false;
				this.checkCreateActivity(this.getSearchfields());
			} else {
				var sRegionKey = this.getOwnerComponent().getModel("UserProfile").getProperty("/APP_MCC_ACTIVITIES_REGION/Value");
				if (!sRegionKey) {
					this.getView().byId("iBtnCreateAct").setEnabled(true);
					this.getView().setBusy(false);
					// jQuery.sap.require("sap.m.MessageBox");
					// sap.m.MessageBox.error("Please set your default Region in 'Settings': Actions List(left-bottom corner)->Settings->Defaults");
					var content = "<p>Please set your default Region in <a target='_blank' href='ht" + "tps://mccactivity-" + this.getAccount() + ".hana.ondemand.com/?event=settings&tag=Defaults'>Defaults</a> page.";
					var dialog = new sap.m.Dialog({
						title: "Error",
						type: "Message",
						state: "Error",
						content: [new sap.ui.core.HTML({
							content: content
						})],
						endButton: new sap.m.Button({
							text: "Cancel",
							press: function() {
								dialog.close();
							}
						}),
						afterClose: function() {
							dialog.destroy();
						}
					});
					dialog.open();
					return;
				}
				var sDesc = this.getView().getModel("Creation").getProperty("/desc");
				var sTitle = this.getView().getModel("Creation").getProperty("/title");
				var oRegionData = this.getView().getModel("Region").getData();
				var aRegionData = [];
				for(var i in oRegionData) {
					aRegionData.push(oRegionData[i]);
				}
				for(var j = 0; j < aRegionData.length; j++) {
					var sRegionName;
					if(aRegionData[j].key === sRegionKey) {
						sRegionName = aRegionData[j].name;
						break;
					}else {
						sRegionName = sRegionKey;
					}
				}
				var reqData = {
					"note": sTitle + " " + sDesc,
					"region": sRegionName
				};
				var sUrl = this.getOwnerComponent().sFirstSlash + "services/ism/mcc-activity-categorisation-service/v1/basicauth/";
				$.ajax({
					url: sUrl,
					type: "POST",
					async: true,
					contentType: "application/json",
					timeout: 5000,
					headers: {
						"authorization": "sEyKsc3RNxGxZBM5vv2RjSBKQ5WQue5E"
					},
					data: JSON.stringify(reqData),
					success: function(oData) {
						this.getView().getModel("Creation").setProperty("/serviceTeam", oData.service_team);
						this.checkCreateActivity(this.getSearchfields());
					}.bind(this),
					error: function(error) {
						this.getView().getModel("Creation").setProperty("/serviceTeam", this._searchServiceTeamNo(sRegionKey, "1"));
						this.checkCreateActivity(this.getSearchfields());
					}.bind(this)
				});
			}
		},
		
		_searchServiceTeamNo: function(sRegionKey, sIsmCat) {
			var aRegionList = this.getOwnerComponent().getModel("SettingList").getProperty("/TopicList")[sRegionKey];
			var sServiceTeam = "";
			if (aRegionList && aRegionList.length) {
				$.each(aRegionList, function(index, item) {
					if (item.ism_cat.indexOf(sIsmCat) !== -1) {
						sServiceTeam = String(item.service_team_id);
						return false;
					}
				});
				if (!sServiceTeam) {
					MessageToast.show("Error while loading service team!");
				}
			} else {
				MessageToast.show("Error while loading service team!");
			}
			return sServiceTeam;
		},

		cancelNoAccountDialog: function() {
			if (this._oNoAccountDialog) {
				this._oNoAccountDialog.close();
			}
			this.getView().byId("iBtnCreateAct").setEnabled(true);
			this.getView().setBusy(false);
		},

		getSearchfields: function() {
			var oModelCreation = this.getView().getModel("Creation");
			var oSearchfields = {
				actDescr: oModelCreation.getProperty("/desc"),
				title: oModelCreation.getProperty("/title"),
				BPNo: "",
				ERPNo: oModelCreation.getProperty("/erpCust"),
				serviceTeam: oModelCreation.getProperty("/serviceTeam"),
				category: oModelCreation.getProperty("/category"),
				prio: oModelCreation.getProperty("/priority"),
				caseID: oModelCreation.getProperty("/caseId"),
				requestorVisible: oModelCreation.getProperty("/requestorVisible"),
				requestor: oModelCreation.getProperty("/requestor")
			};
			return oSearchfields;
		},

		checkInputs: function() {
			var sCreate = "";
			var oView = this.getView();
			var oAccount = oView.byId("inAccount");
			if (!oAccount.getValue()) {
				sCreate = sCreate + "missingAccount";
			}
			var oCaseId = oView.byId('idMatnrInputCaseID');
			if (!oCaseId.getValue()) {
				sCreate = sCreate + "invalidCaseId";
			}
			return sCreate;
		},

		setSelectedCaseResult: function(oData) {
			this.getView().byId("idMatnrInputCaseID").setValue(oData.caseId);
			this.getView().byId("inAccount").setValue(oData.custNo);
		},

		// setCMTopic: function(region) {
		// 	var serviceTeam = sap.support.mccactivities.util.Formatter.formatCMRegion(region);
		// 	if (serviceTeam !== "") {
		// 		this.setServiceTeam(serviceTeam);
		// 	}
		// },

		// checkSetDefaultDescription: function() {
		// 	var oModelCreation = this.getView().getModel("Creation");
		// 	if ((oModelCreation.getProperty("/desc") === "" || /^\s+$/.test(oModelCreation.getProperty("/desc"))) && (oModelCreation.getProperty("/serviceTeam") === "19093065" || oModelCreation.getProperty("/serviceTeam") === "17877275" || oModelCreation.getProperty("/serviceTeam") === "19568810" || oModelCreation.getProperty("/serviceTeam") === "17403528" || oModelCreation.getProperty("/serviceTeam") === "16755384" )) {
		// 		oModelCreation.setProperty("/desc", this.setDefaultDescription());
		// 	}
		// },

		// setDefaultDescription: function() {
		// 	var oDescription = "";
		// 	var oModel = this.getOwnerComponent().getModel("SettingList");
		// 	if (oModel && oModel.getProperty("/Template")) {
		// 		var oLines = oModel.getProperty("/Template");
		// 		for (var iIndex in oLines) {
		// 			oDescription = oDescription + oLines[iIndex].line + "\n";
		// 		}
		// 	}
		// 	return oDescription;
		// },

		// onCreateTopicChange: function(oEvent) {
		// 	this.onTopicChange(oEvent);
		// 	this.checkSetDefaultDescription();
		// },
		feedback: function() {//Qualtrics
			document.cookie= "qualtrics=permanent";
			var curr = sap.qualtricsData;
			sap.qualtricsData = {};
			 /*eslint-disable */
			QSI.API.unload();
			QSI.API.load().then(QSI.API.run());		
			 /*eslint-enable */ 
			sap.qualtricsData = curr; 
		},

		onNavBack: function() {
			this.navTo("master");
		}
	});
});