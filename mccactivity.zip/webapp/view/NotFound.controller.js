sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("sap.support.mccactivities.view.NotFound", {
    	onInit: function() {
    		var oUrl = "ht" + "tps://support.wdf.sap.corp/sap/support/notes/2149660";
    		this.getView().byId("iLink").setText(oUrl);
    		this.getView().byId("iLink").setHref(oUrl);
    	}
	});
});