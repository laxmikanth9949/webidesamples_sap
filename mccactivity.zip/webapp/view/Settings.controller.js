sap.ui.define([
	"sap/support/mccactivities/util/BaseController",
	"sap/support/mccactivities/util/Formatter"
], function(Controller, Formatter) {
	"use strict";
	return Controller.extend("sap.support.mccactivities.view.Settings", {
		_oSettingListEdit: new sap.ui.model.json.JSONModel({}),
		_oNeedPushNotifEdit: new sap.ui.model.json.JSONModel({}),
		_oUserProfileEdit: new sap.ui.model.json.JSONModel({}),
		_oCurrentTopic: new sap.ui.model.json.JSONModel({
			list: [],
			selected: ""
		}),
		_saveSettingsStatus: true,
		_customerNumberSelected: "",

		onInit: function() {

			this._requireOtherModule();

			this.getView().setModel(this._oSettingListEdit, "SettingsEdit");
			this.getView().setModel(this._oNeedPushNotifEdit, "NeedPushNotifEdit");
			this.getView().setModel(this._oUserProfileEdit, "UserProfileEdit");
			//this.getView().setModel(this._oCurrentTopic, "CurrentTopic");
			
			//that.getRegionList();

			//Events
			this.getOwnerComponent().getEventBus().subscribe("sap.support.mccactivities", "ReadListSettings", this.copyListSettingsToEditModel,
				this);
			this.getOwnerComponent().getEventBus().subscribe("sap.support.mccactivities", "ReadNeedPushNotification", this.copyNeedPushNotifToEditModel,
				this);
			this.getOwnerComponent().getEventBus().subscribe("sap.support.mccactivities", "ReadUserProfile", this.copyUserProfileDataToEditModel,
				this);
			this.getOwnerComponent().getEventBus().subscribe("sap.support.mccactivities", "CheckSettingsChanged", this.handleCheckSettingsChanged,
				this);
			this.getEventBus().subscribe("sap.support.mccactivities", "SettingsUsingEvent", this.settingsEventInputFields,
				this);
				
				
			this.getOwnerComponent().getEventBus().subscribe("sap.support.mccactivities", "RecoverSettings", this.copyDataToEditModel, this);

			//Set Customer Search oData Model
			this.env_PG_ESCALATIONS = this.getOwnerComponent().sFirstSlash + "services/customer/search";

			this.copyDataToEditModel();
		},

		_requireOtherModule: function() {
			jQuery.sap.require("sap.support.mccactivities.HelpScreens.CustomerF4Help");
			jQuery.sap.require("sap.support.mccactivities.HelpScreens.CaseF4Help");
		},

		settingsEventInputFields: function(sChannel, sEvent, oData) {
			var iKey;
			switch (oData.data) {
				case "Defaults":
					iKey = "1";
					break;
				default:
					iKey = "0";
					break;
			}
			this.getView().byId("iIconTabBar").setSelectedKey(iKey);
		},

		// prepareServiceTeamSelection: function() {
		// 	var sDefautServiceTeam = this.getView().getModel("UserProfileEdit").getProperty("/APP_MCC_ACTIVITIES_DEFAULT_STEAM");
		// 	if (sDefautServiceTeam) {
		// 		this.setServiceTeam(sDefautServiceTeam.Value);
		// 	} else {
		// 		this.getView().byId("region").setSelectedKey(this.getView().getModel("UserProfileEdit").getProperty(
		// 			"/APP_DATA_MCC_ACTIVITIES_DEFAULT_REGION"));
		// 		var sRegionKey = this.getView().byId("region").getSelectedKey();
		// 		this.checkSelectedRegion(sRegionKey);
		// 	}
		// },

		copyDataToEditModel: function() {
			// Set Current Topic Model
			this.getView().setModel(this._oCurrentTopic, "CurrentTopic");
			// Settings
			this.copyListSettingsToEditModel();
			// Need Push Notification
			this.copyNeedPushNotifToEditModel();
			// Default Category
			/*this.copyDefaultCategoryToEditModel();*/
			// User Profile
			this.copyUserProfileDataToEditModel();
		},

		copyListSettingsToEditModel: function() {
			var oSettingData = this.getOwnerComponent().getModel("VisibleList").getData();
			var oSettingsEditData = jQuery.extend(true, {}, oSettingData);
			this.getView().getModel("SettingsEdit").setData(oSettingsEditData);
		},

		copyNeedPushNotifToEditModel: function() {
			var oNeedPushNotifData = this.getOwnerComponent().getModel("NeedPushNotif").getData();
			var oNeedPushNotifEditData = jQuery.extend(true, {}, oNeedPushNotifData);
			this.getView().getModel("NeedPushNotifEdit").setData(oNeedPushNotifEditData);
		},

		/*copyDefaultCategoryToEditModel: function() {
			var oDefaultCategData = this.getOwnerComponent().getModel("DefaultCategory").getData();
			var oDefaultCategEditData = jQuery.extend(true, {}, oDefaultCategData);
			this.getView().getModel("DefaultCategoryEdit").setData(oDefaultCategEditData);
		},*/

		copyUserProfileDataToEditModel: function() {
			var oUserProfileData = this.getOwnerComponent().getModel("UserProfile").getData();
			var oUserProfileEditData = jQuery.extend(true, {}, oUserProfileData);
			this.getView().getModel("UserProfileEdit").setData(oUserProfileEditData);

			//this.prepareServiceTeamSelection();
			this._updateServiceTeamSelection();
		},
		
		_updateServiceTeamSelection: function() {
			var sRegionKey = this.getView().getModel("UserProfileEdit").getProperty("/APP_MCC_ACTIVITIES_REGION/Value");
			var sServiceTeam = this.getView().getModel("UserProfileEdit").getProperty("/APP_MCC_ACTIVITIES_DEFAULT_STEAM/Value");
			var oTopicList = this.getOwnerComponent().getModel("SettingList").getProperty("/TopicList");
			if (sRegionKey) {
				this.getView().getModel("CurrentTopic").setProperty("/list", oTopicList[sRegionKey]);
				this.getView().getModel("CurrentTopic").setProperty("/selected", sServiceTeam);
			}
		},
		
		onDefaultRegionChange: function(oEvent) {
			this.getView().getModel("UserProfileEdit").setProperty("/APP_MCC_ACTIVITIES_DEFAULT_STEAM/Value", "");
			this._updateServiceTeamSelection();
		},
		
		onDefaultTopicChange: function(oEvent) {
			this.getView().getModel("UserProfileEdit").setProperty("/APP_MCC_ACTIVITIES_DEFAULT_STEAM/Value", this.getView().getModel("CurrentTopic").getProperty("/selected"));
		},

		onIconTabBarSelected: function(oEvent) {
			if (oEvent.getParameter("item").getKey() === "3") {
				this.getView().byId("iBtnFooterSave").setVisible(false);
				this.getView().byId("iBtnFooterCancel").setVisible(false);
			} else {
				this.getView().byId("iBtnFooterSave").setVisible(true);
				this.getView().byId("iBtnFooterCancel").setVisible(true);
			}
		},

		getCaseId: function() {
			var iCaseId = this.getView().byId("idMatnrInputCaseID").getValue();
			var oProperty = this.getView().getModel("UserProfileEdit").getProperty("/APP_MCC_ACTIVITIES_DEFAULT_CASE");
			oProperty.Value = iCaseId;
			this.getView().getModel("UserProfileEdit").setProperty("/APP_MCC_ACTIVITIES_DEFAULT_CASE", oProperty);
		},

		onSave: function() {
			if (this._defaultRegionEmpty()) {
				jQuery.sap.require("sap.m.MessageBox");
				sap.m.MessageBox.error("Please select your region.", {});
			} else {
				this.saveListSettings();
				this.saveNeedPushNotif();
				/*this.saveDefaultCateg();*/
				this.saveDefaultServiceTeam();
				this.saveDefaultCase();
				this.saveDefaultRegion();
	
				this._showMessageAfterSavingSettings();
				this.getOwnerComponent()._bSettingsEditMode = false;
			}
		},

		saveListSettings: function() {
			if (this._listSettingsChanged()) {
				this.eventUsage(false, "Change/Save List Setting");
				var oSettingsEditData = this.getView().getModel("SettingsEdit").getData();
				var auxData = [];
				for (var index in oSettingsEditData) {
					if (oSettingsEditData[index].visible) {
						auxData.push(index);
					}
				}
				this.getModel("VisibleList").setData($.extend(true, {}, oSettingsEditData));
				this.getDataManager().setVisibleList(auxData);
			}
		},

		saveNeedPushNotif: function() {
			if (this._needPushNotifChanged()) {
				var oNeedPushNotifEditModel = this.getView().getModel("NeedPushNotifEdit");
				var oResult = oNeedPushNotifEditModel.getProperty("/result");
				var oNPNValue;
				this.getModel("NeedPushNotif").setData($.extend(true, {}, oNeedPushNotifEditModel.getData()));
				if (oResult) {
					oNPNValue = "YES";
				} else {
					oNPNValue = "NO";
				}
				this.getDataManager().updateNeedPushNotification(oNPNValue);
			}
		},

		/*saveDefaultCateg: function() {
			if (this._defaultCategChanged()) {
				var oDefaultCategEditModel = this.getView().getModel("DefaultCategoryEdit");
				var oValue = oDefaultCategEditModel.getProperty("/result");
				this.getModel("DefaultCategory").setData($.extend(true, {}, oDefaultCategEditModel.getData()));
				this.getDataManager().updateUserProfileAttribute("APP_MCC_ACTIVITIES_DEFAULT_CATEG", oValue);
			}
		},*/

		saveDefaultServiceTeam: function() {
			if (this._defaultServiceTeamChanged()) {
				var sAttribute = "APP_MCC_ACTIVITIES_DEFAULT_STEAM";
				var oProperty = this.getView().getModel("UserProfileEdit").getProperty("/" + sAttribute);
				this.getModel("UserProfile").setProperty("/" + sAttribute, $.extend(true, {}, oProperty));
				this.getDataManager().updateUserProfileAttribute(sAttribute, oProperty.Value);
				this.getDataManager().loadSingleList("ServiceTeam");
			}
		},

		saveDefaultCase: function() {
			if (this._defaultCaseChanged()) {
				sap.git.usage.Reporting.addEvent(this.getOwnerComponent(), "Save Case ID");
				var sAttribute = "APP_MCC_ACTIVITIES_DEFAULT_CASE";
				var oProperty = this.getView().getModel("UserProfileEdit").getProperty("/" + sAttribute);
				this.getModel("UserProfile").setProperty("/" + sAttribute, $.extend(true, {}, oProperty));
				this.getDataManager().updateUserProfileAttribute(sAttribute, oProperty.Value);
			}
		},
		
		saveDefaultRegion: function() {
			if (this._defaultRegionChanged()) {
				var sAttribute = "APP_MCC_ACTIVITIES_REGION";
				var oProperty = this.getView().getModel("UserProfileEdit").getProperty("/" + sAttribute);
				this.getModel("UserProfile").setProperty("/" + sAttribute, $.extend(true, {}, oProperty));
				this.getDataManager().updateUserProfileAttribute(sAttribute, oProperty.Value);
			}
		},

		handleCheckSettingsChanged: function() {
			if (this._listSettingsChanged() || this._needPushNotifChanged() || /*this._defaultCategChanged() ||*/ this._defaultServiceTeamChanged() ||
				this._defaultCaseChanged() || this._defaultRegionChanged()) {
				this.getOwnerComponent()._bSettingsEditMode = true;
			}
		},

		_listSettingsChanged: function() {
			var oSettingsEditData = this.getView().getModel("SettingsEdit").getData();
			var oVisibleListData = this.getModel("VisibleList").getData();
			for (var index in oSettingsEditData) {
				if (oSettingsEditData[index].visible !== oVisibleListData[index].visible) {
					return true;
				}
			}
			return false;
		},

		_needPushNotifChanged: function() {
			return this.getView().getModel("NeedPushNotifEdit").getProperty("/result") !== this.getModel("NeedPushNotif").getProperty("/result");
		},

		/*_defaultCategChanged: function() {
			return this.getView().getModel("DefaultCategoryEdit").getProperty("/result") !== this.getModel("DefaultCategory").getProperty(
				"/result");
		},*/

		_defaultServiceTeamChanged: function() {
			return this.getView().getModel("UserProfileEdit").getProperty("/APP_MCC_ACTIVITIES_DEFAULT_STEAM").Value !== this.getModel(
				"UserProfile").getProperty("/APP_MCC_ACTIVITIES_DEFAULT_STEAM").Value;
		},

		_defaultCaseChanged: function() {
			return this.getView().getModel("UserProfileEdit").getProperty("/APP_MCC_ACTIVITIES_DEFAULT_CASE").Value !== this.getModel(
				"UserProfile").getProperty("/APP_MCC_ACTIVITIES_DEFAULT_CASE").Value;
		},
		
		_defaultRegionChanged: function() {
			return this.getView().getModel("UserProfileEdit").getProperty("/APP_MCC_ACTIVITIES_REGION").Value !== this.getModel(
				"UserProfile").getProperty("/APP_MCC_ACTIVITIES_REGION").Value;
		},
		
		_defaultRegionEmpty: function() {
			return this.getView().getModel("UserProfileEdit").getProperty("/APP_MCC_ACTIVITIES_REGION").Value === "";
		},

		onSettingsCaseIdF4: function() {
			window.openValueHelpDialog(this.byId("idMatnrInputCaseID").getValue(), "", this);
		},

		setSelectedCaseResult: function(oData) {
			this.getView().byId("idMatnrInputCaseID").setValue(oData.caseId);
		},

		// #Favorite Customers Section
		handleAddFavCustomers: function(oEvent) {
			if (!this._oCustomerDialog) {
				this._oCustomerDialog = sap.ui.xmlfragment("sap.support.mccactivities.fragment.InputCustomerNumber", this);
				this.getView().addDependent(this._oCustomerDialog);
			}
			this._oCustomerDialog.open();
		},

		handleDelFavCustomers: function(oEvent) {
			/*var oCustomerData = this.getView().getModel("UserProfileEdit").getProperty("/FAVORITE_CUSTOMERS");
			oCustomerData = oCustomerData ? oCustomerData : [];*/
			var oItem = oEvent.getParameter("listItem");
			var keyData = oItem.getCustomData();
			var customerSelected = oItem.getProperty("title");
			for (var i = 0; i < keyData.length; i++) {
				if (keyData[i].getKey() === "field") {
					this._customerNumberSelected = keyData[i].getValue();
				}
			}
			if (!this._oDeleteCutomerDialog) {
				this._oDeleteCutomerDialog = new sap.m.Dialog({
					title: this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("txt_deleteCustNum"),
					horizontalScrolling: false,
					content: [
						new sap.m.Text({
							text: "You will remove " + customerSelected + " from favorite list."
						})
					],
					beginButton: new sap.m.Button({
						text: this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("txt_ok"),
						press: function(bEvent) {
							this.onConfirmCustomerDelete(bEvent);
						}.bind(this)
					}),
					endButton: new sap.m.Button({
						text: this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("txt_cancel"),
						press: function(eEvent) {
							this.cancelDeleteCustomerDialog(eEvent);
						}.bind(this)
					})
				}).addStyleClass("sapUiContentPadding");
			}
			this._oDeleteCutomerDialog.open();
		},

		onConfirmCustomer: function(oEvent) {
			var that = this;
			var oInput = sap.ui.getCore().byId("iCustomerInput");
			var oCustData = this.getView().getModel("UserProfileEdit").getProperty("/FAVORITE_CUSTOMERS");
			oCustData = oCustData ? oCustData : [];
			var sCustNr = oInput.getValue();
			var oModelUP = this.getOwnerComponent().oDataUserProfile;
			if (!sCustNr) {
				oInput.setValueState("Error");
				return;
			}
			while (sCustNr.length < 10) {
				sCustNr = "0" + sCustNr;
			}
			oInput.setValueState("None");
			//this flag is wether the customer already exists in favorite customer list
			var flag = true;
			for (var i = 0; i < oCustData.length; i++) {
				if (sCustNr === oCustData[i].Value) {
					flag = false;
				}
			}
			if (flag) {
				that.eventUsage(false, "Change Favorite Customers");
				oModelUP.create("/Entries", {
					"Attribute": "FAVORITE_CUSTOMERS",
					"Value": sCustNr
				}, {
					success: function(oEvent) {
						that._getFavoriteDatas();
						sap.m.MessageToast.show("Successfully added the favorite customer");
					},
					error: function(oEvent) {
						sap.m.MessageToast.show("Error when adding the favorite customer");
					}
				});
				if (this._oCustomerDialog) {
					this._oCustomerDialog.close();
				}
			} else {
				sap.m.MessageToast.show("Customer " + sCustNr + " Already exists in your favorite list");
			}
		},

		cancelCustomerDialog: function(oEvent) {
			if (this._oCustomerDialog) {
				this._oCustomerDialog.close();
			}
		},

		onConfirmCustomerDelete: function(oEvent) {
			this.getOwnerComponent().oDataUserProfile.remove("/Entries(Username='',Attribute='FAVORITE_CUSTOMERS',Field='" +
				this._customerNumberSelected + "')", {
					success: function() {
						//Clear selected customer number
						this._customerNumberSelected = "";
						this._getFavoriteDatas();
						sap.m.MessageToast.show("Successfully remove the customer from favorite list");
					}.bind(this),
					error: function() {
						sap.m.MessageToast.show("Error when removing the customer from favorite list");
					}
				}
			);
			if (this._oDeleteCutomerDialog) {
				this._oDeleteCutomerDialog.close();
			}
		},

		cancelDeleteCustomerDialog: function(oEvent) {
			if (this._oDeleteCutomerDialog) {
				//Clear selected customer number
				this._customerNumberSelected = "";
				this._oDeleteCutomerDialog.close();
			}
		},

		_getFavoriteDatas: function() {
			var oModelO = this.getOwnerComponent().oDataUserProfile;
			oModelO.read("/Entries", {
				filters: [new sap.ui.model.Filter("Attribute", sap.ui.model.FilterOperator.EQ, "FAVORITE_CUSTOMERS")],
				success: function(oData) {
					if (oData) {
						var aData = oData.results;
						this.getView().getModel("UserProfileEdit").setProperty("/FAVORITE_CUSTOMERS", aData);
						this.getOwnerComponent().getModel("UserProfile").setProperty("/FAVORITE_CUSTOMERS", aData);
						this.getOwnerComponent().oDataManager.loadSingleList("ForMyFavoriteCustomers");
					}
					this.getView().getModel("UserProfileEdit").refresh();
					this.getOwnerComponent().getModel("UserProfile").refresh();
				}.bind(this),
				error: function() {
					// Please add error handling here
				}
			});

		},

		_showMessageAfterSavingSettings: function() {
			if (!this._saveSettingsStatus) {
				sap.m.MessageToast.show("Error during saving");
			} else {
				sap.m.MessageToast.show("Your changes are saved");
			}
			this._saveSettingsStatus = true;
		},

		onCancel: function() {
			this.copyDataToEditModel();
			this.onNavBack();
		},

		onNavBack: function() {
			this.getOwnerComponent()._bSettingsEditMode = false;
			this.navTo("master");
		}
	});
});