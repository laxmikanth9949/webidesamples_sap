jQuery.sap.declare("sap.support.mccactivities.util.Formatter");

sap.support.mccactivities.util.Formatter = {

	formatRating: function(oEvent) {
		switch (oEvent) {
			case "G":
				return "Green";
			case "Y":
				return "Yellow";
			case "R":
				return "Red";
			default:
				return "";
		}
	},

	formatTimestamp: function(oTime) {
		if (Object.prototype.toString.call(oTime) === "[object String]") {
			if (oTime.length === 14 && /^[0-9]+.?[0-9]*$/.test(oTime)) {
				var oMonth;
				switch (oTime.substr(4, 2)) {
					case "01":
						oMonth = "January";
						break;
					case "02":
						oMonth = "Febuary";
						break;
					case "03":
						oMonth = "March";
						break;
					case "04":
						oMonth = "April";
						break;
					case "05":
						oMonth = "May";
						break;
					case "06":
						oMonth = "June";
						break;
					case "07":
						oMonth = "July";
						break;
					case "08":
						oMonth = "August";
						break;
					case "09":
						oMonth = "September";
						break;
					case "10":
						oMonth = "October";
						break;
					case "11":
						oMonth = "November";
						break;
					case "12":
						oMonth = "December";
						break;
					default:
						return "";
				}
				return oMonth + " " + oTime.substr(6, 2) + ", " + oTime.substr(0, 4) + " " + oTime.substr(8, 2) + ":" + oTime.substr(10, 2) + ":" +
					oTime.substr(12, 2);
			} else {
				return "";
			}
		} else {
			return "";
		}
	},

	formatMsgIsRead: function(oFlag) {
		if (oFlag === "") {
			return "High";
		} else {
			return "None";
		}
	},

	formatCMRegion: function(region) {
		switch (region) {
			case "APJ":
				return "16122383";
			case "EMEA":
				return "16539820";
			case "LAC":
				return "15966792";
			case "NA":
				return "21710213";
			default:
				return "";
		}
	},

	activityStatusState: function(activity_status) {
		if (activity_status === "E0010") {
			return "Success";
		}
		return "None";
	},

	activityStatusStateDetail: function(activity_status) {
		if (activity_status === "New") {
			return "Success";
		}
		return "None";
	},

	activityPriorityState: function(activity_priority) {
		if (activity_priority === "1") {
			return "Error";
		} else if (activity_priority === "3") {
			return "Warning";
		} else {
			return "None";
		}
	},

	activityPriorityStateDetail: function(activity_priority) {
		if (activity_priority === "Very high") {
			return "Error";
		} else if (activity_priority === "High") {
			return "Warning";
		} else {
			return "None";
		} 
	},

	downloadUrl: function(oAttach) {
		if (oAttach.class === "CRM_P_URL") {
			return oAttach.file_type;
		} else {
			return oAttach.__metadata.media_src;
		}
	},
	
	countMasterListItem: function(aList) {
		return  "(" + (Array.isArray(aList) ? aList.length : 0) + ")";
	},
	
	notiMsgActId: function(objId, data) {
		if (objId) {
			return objId;
		} else {
			return data;
		}
	},
	
	uppercaseLeadingLetter: function(sStr) {
		if (Object.prototype.toString.call(sStr) !== "[object String]") {
			return "";
		}
		return sStr.substring(0, 1).toUpperCase() + sStr.substring(1);
	},
	
	formatInputValueState: function(str) {
		if (str) {
			return "None";
		} else {
			return "Error";
		}
	},
	
	formatRegionValueState: function(num) {
		if (num && !isNaN(num) && parseInt(num, 0) !== -1) {
			return "None";
		} else {
			return "Error";
		}
	},
	
	formatTopicValueState: function(num) {
		if (num) {
			if (!isNaN(num) && num < 1) {
				return "Error";
			} else {
				return "None";
			}
		} else {
			return "Error";
		}
	},
	
	formatCreateEnable: function(sTitle, sDesc) {
		if (sTitle && sDesc) {
			return true;
		} else {
			return false;
		}
	},
	
	formatMasterBtnEnable: function(sUserId, sCreator, aPartiesInvolved, fDisplay, sStatus) {
		if (sUserId && fDisplay && sStatus && sStatus !== "E0014") {
			if (sCreator && sCreator === sUserId) {
				return true;
			} else if (aPartiesInvolved && Array.isArray(aPartiesInvolved.results)) {
				var fRequestor = false;
				$.each(aPartiesInvolved.results, function(index, item) {
					if (item.parties_function === "Requestor" && item.xubname === sUserId) {
						fRequestor = true;
						return false;
					}
				});
				return fRequestor;
			} else {
				return false;
			}
		} else {
			return false;
		}
	},
	
	formatMainPartnerFlag: function(sValue) {
		switch(sValue) {
			case "X":
				return true;
			default:
				return false;
		}
	},
	
	formatTopicVisibility: function(sKey) {
		if (sKey) {
			return true;
		} else {
			return false;
		}
	},
	
	formatServiceTeamEnable: function(sKey) {
		if (sKey) {
			return false;
		} else {
			return true;
		}
	}

	/*
	discontinuedStatusState : function(sDate) {
		return sDate ? "Error" : "None";
	},

	discontinuedStatusValue : function(sDate) {
		return sDate ? "Discontinued" : "";
	},

	currencyValue : function (value) {
		return parseFloat(value).toFixed(2);
	}
	*/
};