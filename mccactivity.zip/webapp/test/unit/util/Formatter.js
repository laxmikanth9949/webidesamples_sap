sap.ui.define([
	"sap/support/mccactivities/util/Formatter",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(formatter) {
	"use strict";

	QUnit.module("util - Formatter: Test cases for Formatter");
	
	QUnit.test("Should see no rating when key is 'undefined'", function(assert) {
		assert.strictEqual(formatter.formatRating(undefined), "");
	});
	
	QUnit.test("Should see 'Green' rating when key is 'G'", function(assert) {
		assert.strictEqual(formatter.formatRating("G"), "Green");
	});
	
	QUnit.test("Should see 'Yello' rating when key is 'Y'", function(assert) {
		assert.strictEqual(formatter.formatRating("Y"), "Yellow");
	});
	
	QUnit.test("Should see 'Red' rating when key is 'R'", function(assert) {
		assert.strictEqual(formatter.formatRating("R"), "Red");
	});
	
	QUnit.test("Should see no rating when key is 'O'", function(assert) {
		assert.strictEqual(formatter.formatRating("O"), "");
	});
	
	QUnit.test("Should see '' when timestamp is 'undefined'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp(undefined), "");
	});
	
	QUnit.test("Should see '' when timestamp is 'abc'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("abc"), "");
	});
	
	QUnit.test("Should see '' when timestamp is '20170201'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("20170201"), "");
	});
	
	QUnit.test("Should see 'January 01, 2017 12:03:45' when timestamp is '20170101120345'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("20170101120345"), "January 01, 2017 12:03:45");
	});
	
	QUnit.test("Should see 'Febuary 01, 2017 12:03:45' when timestamp is '20170201120345'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("20170201120345"), "Febuary 01, 2017 12:03:45");
	});
	
	QUnit.test("Should see 'March 01, 2017 12:03:45' when timestamp is '20170301120345'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("20170301120345"), "March 01, 2017 12:03:45");
	});
	
	QUnit.test("Should see 'April 01, 2017 12:03:45' when timestamp is '20170401120345'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("20170401120345"), "April 01, 2017 12:03:45");
	});
	
	QUnit.test("Should see 'May 01, 2017 12:03:45' when timestamp is '20170501120345'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("20170501120345"), "May 01, 2017 12:03:45");
	});
	
	QUnit.test("Should see 'June 01, 2017 12:03:45' when timestamp is '20170601120345'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("20170601120345"), "June 01, 2017 12:03:45");
	});
	
	QUnit.test("Should see 'July 01, 2017 12:03:45' when timestamp is '20170701120345'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("20170701120345"), "July 01, 2017 12:03:45");
	});
	
	QUnit.test("Should see 'August 01, 2017 12:03:45' when timestamp is '20170801120345'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("20170801120345"), "August 01, 2017 12:03:45");
	});
	
	QUnit.test("Should see 'September 01, 2017 12:03:45' when timestamp is '20170901120345'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("20170901120345"), "September 01, 2017 12:03:45");
	});
	
	QUnit.test("Should see 'October 01, 2017 12:03:45' when timestamp is '20171001120345'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("20171001120345"), "October 01, 2017 12:03:45");
	});
	
	QUnit.test("Should see 'November 01, 2017 12:03:45' when timestamp is '20171101120345'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("20171101120345"), "November 01, 2017 12:03:45");
	});
	
	QUnit.test("Should see 'December 01, 2017 12:03:45' when timestamp is '20171201120345'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("20171201120345"), "December 01, 2017 12:03:45");
	});
	
	QUnit.test("Should see '' when timestamp is '20171301000000'", function(assert) {
		assert.strictEqual(formatter.formatTimestamp("20171301000000"), "");
	});
	
	QUnit.test("Should see 'None' when flag is 'undefined'", function(assert) {
		assert.strictEqual(formatter.formatMsgIsRead(undefined), "None");	
	});
	
	QUnit.test("Should see 'None' when flag is 'X'", function(assert) {
		assert.strictEqual(formatter.formatMsgIsRead("X"), "None");	
	});
	
	QUnit.test("Should see 'High' when flag is ''", function(assert) {
		assert.strictEqual(formatter.formatMsgIsRead(""), "High");	
	});
	
	QUnit.test("Should see '' when region of 'Call Me' functionality is 'undefined'", function(assert) {
		assert.strictEqual(formatter.formatCMRegion(undefined), "");	
	});
	
	QUnit.test("Should see '16122383' when region of 'Call Me' functionality is 'APJ'", function(assert) {
		assert.strictEqual(formatter.formatCMRegion("APJ"), "16122383");	
	});
	
	QUnit.test("Should see '16539820' when region of 'Call Me' functionality is 'EMEA'", function(assert) {
		assert.strictEqual(formatter.formatCMRegion("EMEA"), "16539820");	
	});
	
	QUnit.test("Should see '15966792' when region of 'Call Me' functionality is 'LAC'", function(assert) {
		assert.strictEqual(formatter.formatCMRegion("LAC"), "15966792");	
	});
	
	QUnit.test("Should see '21710213' when region of 'Call Me' functionality is 'NA'", function(assert) {
		assert.strictEqual(formatter.formatCMRegion("NA"), "21710213");	
	});
	
	QUnit.test("Should see '' when region of 'Call Me' functionality is 'OTHERS'", function(assert) {
		assert.strictEqual(formatter.formatCMRegion("OTHERS"), "");	
	});
	
	QUnit.test("Should see 'None' when activity status is 'undefined'", function(assert) {
		assert.strictEqual(formatter.activityStatusState(undefined), "None");	
	});
	
	QUnit.test("Should see 'None' when activity status is 'E0011'", function(assert) {
		assert.strictEqual(formatter.activityStatusState("E0011"), "None");	
	});
	
	QUnit.test("Should see 'Success' when activity status is 'E0010'", function(assert) {
		assert.strictEqual(formatter.activityStatusState("E0010"), "Success");	
	});
	
	QUnit.test("Should see 'None' when activity status detail is 'undefined'", function(assert) {
		assert.strictEqual(formatter.activityStatusStateDetail(undefined), "None");	
	});
	
	QUnit.test("Should see 'None' when activity status detail is 'In Process'", function(assert) {
		assert.strictEqual(formatter.activityStatusStateDetail("In Process"), "None");	
	});
	
	QUnit.test("Should see 'Success' when activity status detail is 'New'", function(assert) {
		assert.strictEqual(formatter.activityStatusStateDetail("New"), "Success");	
	});
	
	QUnit.test("Should see 'None' when activity priority is 'undefined'", function(assert) {
		assert.strictEqual(formatter.activityPriorityState(undefined), "None");	
	});
	
	QUnit.test("Should see 'Error' when activity priority is '1'", function(assert) {
		assert.strictEqual(formatter.activityPriorityState("1"), "Error");	
	});
	
	QUnit.test("Should see 'Warning' when activity priority is '3'", function(assert) {
		assert.strictEqual(formatter.activityPriorityState("3"), "Warning");	
	});
	
	QUnit.test("Should see 'None' when activity priority is '5'", function(assert) {
		assert.strictEqual(formatter.activityPriorityState("5"), "None");	
	});
	
	QUnit.test("Should see 'None' when activity priority detail is 'undefined'", function(assert) {
		assert.strictEqual(formatter.activityPriorityStateDetail(undefined), "None");	
	});
	
	QUnit.test("Should see 'Error' when activity priority detail is 'Very high'", function(assert) {
		assert.strictEqual(formatter.activityPriorityStateDetail("Very high"), "Error");	
	});
	
	QUnit.test("Should see 'Warning' when activity priority detail is 'High'", function(assert) {
		assert.strictEqual(formatter.activityPriorityStateDetail("High"), "Warning");	
	});
	
	QUnit.test("Should see 'None' when activity priority detail is 'Low'", function(assert) {
		assert.strictEqual(formatter.activityPriorityStateDetail("Low"), "None");	
	});
	
	QUnit.test("Should see 'undefined' when notification message object id and data are 'undefined' and 'undefined'", function(assert) {
		assert.strictEqual(formatter.notiMsgActId(undefined, undefined), undefined);	
	});
	
	QUnit.test("Should see '123456' when notification message object id and data are 'undefined' and '123456'", function(assert) {
		assert.strictEqual(formatter.notiMsgActId(undefined, "123456"), "123456");	
	});
	
	QUnit.test("Should see '123456' when notification message object id and data are '123456' and '654321'", function(assert) {
		assert.strictEqual(formatter.notiMsgActId("123456", "654321"), "123456");	
	});
	
	QUnit.test("Should return '' when uppercase leading letter of 'undefined'", function(assert) {
		assert.strictEqual(formatter.uppercaseLeadingLetter(undefined), "");
	});
	
	QUnit.test("Should return '' when input parameter of uppercase leading letter is not a string", function(assert) {
		assert.strictEqual(formatter.uppercaseLeadingLetter(["test"]), "");
	});
	
	QUnit.test("Should return 'test' when input parameter of uppercase leading letter is 'test'", function(assert) {
		assert.strictEqual(formatter.uppercaseLeadingLetter("Test"), "Test");
	});
	
	QUnit.test("Should return '12345' when input parameter of uppercase leading letter is '12345'", function(assert) {
		assert.strictEqual(formatter.uppercaseLeadingLetter("12345"), "12345");
	});
	
	QUnit.test("Should return 't12345' when input parameter of uppercase leading letter is '12345'", function(assert) {
		assert.strictEqual(formatter.uppercaseLeadingLetter("t12345"), "T12345");
	});
	
	QUnit.module("util - Formatter: Test cases for function 'formatMasterBtnEnable'");
	
	QUnit.test("Should return 'false' when all input parameters are 'undefined'", function(assert) {
		assert.strictEqual(formatter.formatMasterBtnEnable(), false);
	});
	
	QUnit.test("Should return 'false' when only user id is 'undefined'", function(assert) {
		assert.strictEqual(formatter.formatMasterBtnEnable(undefined, "a456", {results: ["a789"]}, true, "E123"), false);
	});
	
	QUnit.test("Should return 'false' when creator id and parties involved are 'undefined'", function(assert) {
		assert.strictEqual(formatter.formatMasterBtnEnable("a123", undefined, undefined, true, "E123"), false);
	});
	
	QUnit.test("Should return 'false' when only display flag is 'undefined'", function(assert) {
		assert.strictEqual(formatter.formatMasterBtnEnable("a123", "a456", {results: ["a789"]}, undefined, "E123"), false);
	});
	
	QUnit.test("Should return 'false' when only activity status is 'undefined'", function(assert) {
		assert.strictEqual(formatter.formatMasterBtnEnable("a123", "a456", {results: ["a789"]}, true, undefined), false);
	});
	
	QUnit.test("Should return 'false' when display flag is 'false'", function(assert) {
		assert.strictEqual(formatter.formatMasterBtnEnable("a123", "a123", {results: [{parties_function: "Requestor", xubname: "a123"}]}, false, "E123"), false);
	});
	
	QUnit.test("Should return 'false' when activity status is 'E0014'", function(assert) {
		assert.strictEqual(formatter.formatMasterBtnEnable("a123", "a456", {results: [{parties_function: "Requestor", xubname: "a123"}]}, true, "E0014"), false);
	});
	
	QUnit.test("Should return 'true' when display flag is 'true' and activity status isn't 'E0014' and the user is creator", function(assert) {
		assert.strictEqual(formatter.formatMasterBtnEnable("a123", "a123", {results: [{parties_function: "Requestor", xubname: "a456"}]}, true, "E0011"), true);
	});
	
	QUnit.test("Should return 'true' when display flag is 'true' and activity status isn't 'E0014' and the user is requestor", function(assert) {
		assert.strictEqual(formatter.formatMasterBtnEnable("a123", "a456", {results: [{parties_function: "Requestor", xubname: "a123"}]}, true, "E0010"), true);
	});
	
	QUnit.test("Should return 'true' when display flag is 'true' and activity status isn't 'E0014' and the user is one of the requestors", function(assert) {
		assert.strictEqual(formatter.formatMasterBtnEnable("a123", "a456", {results: [{parties_function: "Requestor", xubname: "a456"}, {parties_function: "Requestor", xubname: "a123"}, {parties_function: "Requestor", xubname: "a789"}]}, true, "E0010"), true);
	});
	
	QUnit.test("Should return 'false' when display flag is 'true' and activity status isn't 'E0014' and the user isn't creator or requestor", function(assert) {
		assert.strictEqual(formatter.formatMasterBtnEnable("a123", "a456", {results: [{parties_function: "", xubname: "a123"}, {parties_function: "Requestor", xubname: "a789"}]}, true, "E0010"), false);
	});
	
	QUnit.test("Should return 'true' when main partner flag is 'X'.", function(assert) {
		assert.strictEqual(formatter.formatMainPartnerFlag("X"), true);
	});
	
	QUnit.test("Should return 'false' when main partner flag is undefined.", function(assert) {
		assert.strictEqual(formatter.formatMainPartnerFlag(), false);
	});
	
	QUnit.test("Should return 'false' when main partner flag is 'XX'.", function(assert) {
		assert.strictEqual(formatter.formatMainPartnerFlag("XX"), false);
	});
	
});