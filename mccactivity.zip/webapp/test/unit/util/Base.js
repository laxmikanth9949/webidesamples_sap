sap.ui.require([
	"sap/support/mccactivities/util/BaseController",
	"sap/ui/core/mvc/View",
	"sap/ui/core/UIComponent",
	"sap/ui/core/mvc/Controller"
], function(BaseController, View, Component, Controller) {
	"use strict";

	QUnit.module("util - Base: Test cases for Base Controller", {
		beforeEach: function() {
			this.oController = new BaseController();
			this.oComponent = new Component();
			this.oViewStub = new View({});
			sinon.stub(Controller.prototype, "getView").returns(this.oViewStub);
			sinon.stub(Controller.prototype, "getOwnerComponent").returns(this.oComponent);
		},
		afterEach: function() {
			Controller.prototype.getOwnerComponent.restore();
			Controller.prototype.getView.restore();
			this.oViewStub.destroy();
			this.oComponent.destroy();
			this.oController.destroy();
		}
	});
	
	QUnit.test("getDataManager: Should return DataManger object when calling this method.", function(assert) {
		this.oComponent.oDataManager = {data: "test"};
		assert.deepEqual(this.oController.getDataManager(), {data: "test"});
	});
	
	QUnit.test("getDataSource: Should get service url from component when calling this method.", function(assert) {
		this.oComponent.getDataSource = function() {
			return ;
		};
		var oStubData = this.stub(this.oComponent, "getDataSource");
		
		this.oController.getDataSource();
		
		assert.strictEqual(oStubData.callCount, 1);
	});
	
	QUnit.test("getSystem: Should return 'd' when current environment is SAP IT Cloud Dev.", function(assert) {
		this.stub(this.oController, "getCurrentUrl").returns("br339jmc4c");
		assert.strictEqual(this.oController.getSystem(), "d");
	});
	
	QUnit.test("getSystem: Should return 't' when current environment is SAP IT Cloud Test.", function(assert) {
		this.stub(this.oController, "getCurrentUrl").returns("sapitcloudt");
		assert.strictEqual(this.oController.getSystem(), "t");
	});
	
	QUnit.test("getSystem: Should return 'd' when current environment is SAP IT Cloud Prod.", function(assert) {
		this.stub(this.oController, "getCurrentUrl").returns("sapitcloud.dispatcher");
		assert.strictEqual(this.oController.getSystem(), "p");
	});
	
	QUnit.test("getSystem: Should return 'p' when current environment is Fiori Launchpad Prod.", function(assert) {
		this.stub(this.oController, "getCurrentUrl").returns("fiorilaunchpad.sap");
		assert.strictEqual(this.oController.getSystem(), "p");
	});
	
	QUnit.test("getSystem: Should return 'd' when current environment is others.", function(assert) {
		this.stub(this.oController, "getCurrentUrl").returns("test");
		assert.strictEqual(this.oController.getSystem(), "d");
	});
	
	QUnit.test("getAccount: Should return account href of Dev when current environment is SAP IT Cloud Dev.", function(assert) {
		this.stub(this.oController, "getCurrentUrl").returns("br339jmc4c");
		assert.strictEqual(this.oController.getAccount(), "br339jmc4c.dispatcher.int.sap.eu2");
	});
	
	QUnit.test("getAccount: Should return account href of Test when current environment is SAP IT Cloud Test.", function(assert) {
		this.stub(this.oController, "getCurrentUrl").returns("sapitcloudt");
		assert.strictEqual(this.oController.getAccount(), "sapitcloudt.dispatcher");
	});
	
	QUnit.test("getAccount: Should return account href of Prod when current environment is SAP IT Cloud Prod.", function(assert) {
		this.stub(this.oController, "getCurrentUrl").returns("sapitcloud.dispatcher");
		assert.strictEqual(this.oController.getAccount(), "sapitcloud.dispatcher");
	});
	
	QUnit.test("getAccount: Should return account href of Prod when current environment is Fiori Launchpad Prod.", function(assert) {
		this.stub(this.oController, "getCurrentUrl").returns("fiorilaunchpad.sap");
		assert.strictEqual(this.oController.getAccount(), "sapitcloud.dispatcher");
	});
	
	QUnit.test("getAccount: Should return account href of Dev when current environment is others.", function(assert) {
		this.stub(this.oController, "getCurrentUrl").returns("test");
		assert.strictEqual(this.oController.getAccount(), "br339jmc4c.dispatcher.int.sap.eu2");
	});
	
	// QUnit.test("onRegionChange: Should set selected region if region changed without 'CallMe' flag.", function(assert) {
	// 	var oEvent = new sap.ui.base.Event(null, null, {selectedItem: new sap.ui.core.Item()});
	// 	var oStubProp = this.stub(sap.ui.base.ManagedObject.prototype, "getProperty");
	// 	var oStubRegion = this.stub(this.oController, "checkSelectedRegion");
	// 	this.oController.oFlagCallMe = false;
		
	// 	this.oController.onRegionChange(oEvent);
		
	// 	assert.strictEqual(oStubRegion.callCount, 1);
	// 	assert.strictEqual(oStubProp.callCount, 1);
	// });
	
	// QUnit.test("onRegionChange: Should set selected region and topic if region changed with 'CallMe' flag.", function(assert) {
	// 	var oEvent = new sap.ui.base.Event(null, null, {selectedItem: new sap.ui.core.Item()});
	// 	var oStubProp = this.stub(sap.ui.base.ManagedObject.prototype, "getProperty");
	// 	var oStubRegion = this.stub(this.oController, "checkSelectedRegion");
	// 	this.oController.setCMTopic = function() {return;};
	// 	this.oController.oFlagCallMe = true;
		
	// 	this.oController.onRegionChange(oEvent);
		
	// 	assert.strictEqual(oStubRegion.callCount, 1);
	// 	assert.strictEqual(oStubProp.callCount, 2);
	// });
	
	// QUnit.test("onTopicChange: Should set service team to input field when topic is changed to one in the list.", function(assert) {
	// 	var oEvent = new sap.ui.base.Event(null, null, {selectedItem: new sap.ui.core.Item()});
	// 	this.stub(sap.ui.core.Item.prototype, "getProperty").returns("3");
	// 	var oInputST = new sap.m.Input();
	// 	this.stub(View.prototype, "byId").returns(oInputST);
		
	// 	this.oController.onTopicChange(oEvent);
		
	// 	assert.strictEqual(oInputST.getValue(), "3");
	// 	assert.strictEqual(oInputST.getVisible(), true);
	// 	assert.strictEqual(oInputST.getEnabled(), false);
	// });
	
	// QUnit.test("onTopicChange: Should set empty to input field when topic is changed to one out of the list.", function(assert) {
	// 	var oEvent = new sap.ui.base.Event(null, null, {selectedItem: new sap.ui.core.Item()});
	// 	this.stub(sap.ui.core.Item.prototype, "getProperty").returns("-1");
	// 	var oInputST = new sap.m.Input();
	// 	this.stub(View.prototype, "byId").returns(oInputST);
		
	// 	this.oController.onTopicChange(oEvent);
		
	// 	assert.strictEqual(oInputST.getValue(), "");
	// 	assert.strictEqual(oInputST.getVisible(), false);
	// 	assert.strictEqual(oInputST.getEnabled(), true);
	// });
	
});