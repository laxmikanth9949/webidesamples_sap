sap.ui.require([
	"sap/support/mccactivities/view/Detail.controller",
	"sap/ui/core/mvc/View",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/core/UIComponent",
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/Router",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/support/mccactivities/model/help",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(DetailController, View, ResourceModel, Component, Controller, Router, ODataModel, MessageToast, MessageBox, help) {
	"use strict";

	QUnit.module("pages - Detail view: Email to", {
		beforeEach: function() {
			this.oController = new sap.support.mccactivities.view.Detail();
			this.oModelI18n = new ResourceModel({
				bundleName: "sap.support.mccactivities.i18n.message_bundle",
				bundleLocale: "EN"
			});
			this.oComponent = new Component();
			this.oComponent.setModel(this.oModelI18n, "i18n");
			sinon.stub(Controller.prototype, "getOwnerComponent").returns(this.oComponent);
			this.oViewStub = new View({});
			sinon.stub(this.oController, "getView").returns(this.oViewStub);
			this.oControlStub = new sinon.stub(this.oViewStub, "byId");
			sinon.stub(sap.m.Dialog.prototype, "open");
			sinon.stub(sap.m.Dialog.prototype, "close");
			sinon.stub(sap.m.MessageToast, "show");
		},
		afterEach: function() {
			this.oController.destroy();
			Controller.prototype.getOwnerComponent.restore();
			this.oModelI18n.destroy();
			this.oComponent.destroy();
			this.oViewStub.destroy();
			sap.m.Dialog.prototype.open.restore();
			sap.m.Dialog.prototype.close.restore();
			sap.m.MessageToast.show.restore();
		}
	});

	QUnit.test("Given undefined then address of 'Email to creator' is invalid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo(undefined), false);
	});

	QUnit.test("Given '' then address of 'Email to creator' is invalid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo(), false);
	});

	QUnit.test("Given 'D123456' then address of 'Email to creator' is valid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo("D123456"), true);
	});

	QUnit.test("Given 'D1234567' then address of 'Email to creator' is invalid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo("D1234567"), false);
	});

	QUnit.test("Given 'D1234ab' then address of 'Email to creator' is invalid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo("D1234ab"), false);
	});

	QUnit.test("Given 'I123456' then address of 'Email to creator' is valid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo("I123456"), true);
	});

	QUnit.test("Given 'I12345' then address of 'Email to creator' is invalid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo("I12345"), false);
	});

	QUnit.test("Given 'I1234ab' then address of 'Email to creator' is invalid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo("I1234ab"), false);
	});

	QUnit.test("Given 'C1234567' then address of 'Email to creator' is valid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo("C1234567"), true);
	});

	QUnit.test("Given 'C12345' then address of 'Email to creator' is invalid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo("C12345"), false);
	});

	QUnit.test("Given 'C12345ab' then address of 'Email to creator' is invalid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo("C12345ab"), false);
	});

	QUnit.test("Given 'SAP Support Backoffice' then address of 'Email to creator' is invalid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo("SAP Support Backoffice"), false);
	});

	QUnit.test("Given 'AGS Backoffice' then address of 'Email to creator' is invalid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo("AGS Backoffice"), false);
	});

	QUnit.test("Given 'AGS@' then address of 'Email to creator' is invalid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo("AGS@"), false);
	});

	QUnit.test("Given 'AGS@sap.' then address of 'Email to creator' is invalid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo("AGS@sap."), false);
	});

	QUnit.test("Given 'test@sap.com' then address of 'Email to creator' is invalid", function(assert) {
		assert.strictEqual(this.oController._checkValidEmailTo("test@sap.com"), true);
	});

	QUnit.module("pages - Detail view: Attachment", {
		beforeEach: function() {
			this.oController = new DetailController();
			this.oComponent = new Component();
			sinon.stub(this.oController, "getDataSource").returns("/abc");
			sinon.stub(Controller.prototype, "getOwnerComponent").returns(this.oComponent);
			sinon.stub(this.oController, "eventUsage");
		},
		afterEach: function() {
			this.oController.destroy();
			this.oController.getDataSource.restore();
			Controller.prototype.getOwnerComponent.restore();
			this.oComponent.destroy();
			this.oController.eventUsage.restore();
		}
	});
	
	QUnit.test("onChange: Should not prepare to upload attachment and not show busy indicator when there is no target activity to store this attachment.", function(assert) {
		// Arrangements
		var oEvent = new sap.ui.base.Event(null, new sap.m.UploadCollection(), null);
		var oStubUpload = this.stub(sap.m.UploadCollection.prototype, "upload");
		this.oController._activityId = "";
		this.stub(sap.ui.core.Core.prototype, "setModel");
		this.stub(sap.ui.model.odata.v2.ODataModel.prototype, "getHeaders").returns({"x-csrf-token": "test"});
		this.stub(sap.ui.core.Core.prototype, "getModel").returns(new sap.ui.model.odata.v2.ODataModel("/abc", true));
		this.stub(sap.m.UploadCollection.prototype, "setUploadUrl");
		this.stub(sap.m.UploadCollection.prototype, "addHeaderParameter");
		// Actions
		this.oController.onChange(oEvent);
		// Assertions
		assert.strictEqual(oStubUpload.callCount, 0);
		assert.strictEqual(oEvent.getSource().getBusy(), false);
	});
	
	QUnit.test("onChange: Should prepare to upload attachment and show busy indicator when there is valid target activity to store this attachment.", function(assert) {
		// Arrangements
		var oEvent = new sap.ui.base.Event(null, new sap.m.UploadCollection(), null);
		var oStubUpload = this.stub(sap.m.UploadCollection.prototype, "upload");
		this.oController._activityId = "12345";
		this.stub(sap.ui.core.Core.prototype, "setModel");
		this.stub(sap.ui.model.odata.v2.ODataModel.prototype, "getHeaders").returns({"x-csrf-token": "test"});
		this.stub(sap.ui.core.Core.prototype, "getModel").returns(new sap.ui.model.odata.v2.ODataModel("/abc", true));
		this.stub(sap.m.UploadCollection.prototype, "setUploadUrl");
		this.stub(sap.m.UploadCollection.prototype, "addHeaderParameter");
		// Actions
		this.oController.onChange(oEvent);
		// Assertions
		assert.strictEqual(oStubUpload.callCount, 1);
		assert.strictEqual(oEvent.getSource().getBusy(), true);
	});
	
	QUnit.test("onChange: Should set correct uploading url when there is valid target activity to store this attachment.", function(assert) {
		// Arrangements
		var oEvent = new sap.ui.base.Event(null, new sap.m.UploadCollection(), null);
		var oStubUrl = this.stub(sap.m.UploadCollection.prototype, "setUploadUrl");
		this.oController._activityId = "12345";
		this.stub(sap.ui.core.Core.prototype, "setModel");
		this.stub(sap.ui.model.odata.v2.ODataModel.prototype, "getHeaders").returns({"x-csrf-token": "test"});
		this.stub(sap.ui.core.Core.prototype, "getModel").returns(new sap.ui.model.odata.v2.ODataModel("/abc", true));
		this.stub(sap.m.UploadCollection.prototype, "addHeaderParameter");
		this.stub(sap.m.UploadCollection.prototype, "upload");
		// Actions
		this.oController.onChange(oEvent);
		// Assertions
		assert.strictEqual(oStubUrl.args[0][0], "/abcActivityList('12345')/Attachment");
	});
	
	QUnit.test("onChange: Should set correct token when there is valid target activity to store this attachment.", function(assert) {
		// Arrangements
		var oEvent = new sap.ui.base.Event(null, new sap.m.UploadCollection(), null);
		var oStubPara = this.stub(sap.m.UploadCollection.prototype, "addHeaderParameter");
		this.oController._activityId = "12345";
		this.stub(sap.ui.core.Core.prototype, "setModel");
		this.stub(sap.ui.model.odata.v2.ODataModel.prototype, "getHeaders").returns({"x-csrf-token": "test"});
		this.stub(sap.ui.core.Core.prototype, "getModel").returns(new sap.ui.model.odata.v2.ODataModel("/abc", true));
		this.stub(sap.m.UploadCollection.prototype, "setUploadUrl");
		this.stub(sap.m.UploadCollection.prototype, "upload");
		// Actions
		this.oController.onChange(oEvent);
		// Assertions
		assert.strictEqual(oStubPara.args[0][0].getName("x-csrf-token"), "x-csrf-token");
		assert.strictEqual(oStubPara.args[0][0].getValue("x-csrf-token"), "test");
	});

	QUnit.test("onBeforeUploadStarts: Should set correct header parameter when before upload starts.", function(assert) {
		// Arrangements
		var oEvent = new sap.ui.base.Event(null, null, {fileName: "name", addHeaderParameter: function(oPara) { this.para = oPara; }});
		// Actions
		this.oController.onBeforeUploadStarts(oEvent);
		// Assertions
		assert.strictEqual(oEvent.getParameters().para.getName(), "slug");
		assert.strictEqual(oEvent.getParameters().para.getValue(), "name");
	});
	
	QUnit.test("onFileSizeExceed: Should show a message when the file size of the uploaded file is exceeded.", function(assert) {
		// Arrangements
		var oStubMessage = this.stub(sap.m.MessageToast, "show");
		// Actions
		this.oController.onFileSizeExceed();
		// Assertions
		assert.strictEqual(oStubMessage.callCount, 1);
	});
	
	QUnit.test("onFileNameExceed: Should show a message when the name of the chosen file is longer than the value specified with the maximumFilenameLength property.", function(assert) {
		// Arrangements
		var oStubMessage = this.stub(sap.m.MessageToast, "show");
		// Actions
		this.oController.onFileNameExceed();
		// Assertions
		assert.strictEqual(oStubMessage.callCount, 1);
	});
	
	QUnit.test("onUploadComplete: Should not reload activity detail after uploading is completed when there is no target activity to store this attachment.", function(assert) {
		// Arrangements
		var oEvent = new sap.ui.base.Event(null, new sap.m.UploadCollection(), null);
		var oStubRead = this.stub(ODataModel.prototype, "read");
		this.oComponent.oDashBoardsModel = new ODataModel({serviceUrl: "test"});
		this.oController._activityId = "";
		// Actions
		this.oController.onUploadComplete(oEvent);
		// Assertions
		assert.strictEqual(oStubRead.callCount, 0);
	});
	
	QUnit.test("onUploadComplete: Should reload activity detail with correct parameters in oData model after uploading is completed when there is valid target activity to store this attachment.", function(assert) {
		// Arrangements
		var oEvent = new sap.ui.base.Event(null, new sap.m.UploadCollection(), null);
		var oStubRead = this.stub(ODataModel.prototype, "read");
		var oStubHelp = this.stub(help, "setSingleActSearchFilters");
		this.oComponent.oDashBoardsModel = new ODataModel({serviceUrl: "test"});
		this.oController._activityId = "12345";
		// Actions
		this.oController.onUploadComplete(oEvent);
		// Assertions
		assert.strictEqual(oStubRead.callCount, 1);
		assert.strictEqual(oStubHelp.callCount, 1);
		assert.strictEqual(oStubRead.args[0][0], "/ActivityList");
		assert.deepEqual(oStubRead.args[0][1].urlParameters, {"$expand": "PartiesInvolved,ActivityCases,Attachment"});
	});
	
	QUnit.test("onUploadComplete: Should update model of target activity and hide busy indicator when reload activity detail successfully.", function(assert) {
		// Arrangements
		var oEvent = new sap.ui.base.Event(null, new sap.m.UploadCollection(), null);
		var oStubRefresh = this.stub(this.oController, "_setRefreshDetailModel");
		var oStubPrepare = this.stub(this.oController, "prepareDateNew");
		this.stub(ODataModel.prototype, "read").yieldsTo("success");
		this.stub(help, "setSingleActSearchFilters");
		this.oComponent.oDashBoardsModel = new ODataModel({serviceUrl: "test"});
		this.oController._activityId = "12345";
		// Actions
		this.oController.onUploadComplete(oEvent);
		// Assertions
		assert.strictEqual(oStubRefresh.callCount, 1);
		assert.strictEqual(oStubPrepare.callCount, 1);
		assert.strictEqual(oEvent.getSource().getBusy(), false);
	});
	
	QUnit.test("onUploadComplete: Should show a message and hide busy indicator when reload activity detail failed.", function(assert) {
		// Arrangements
		var oEvent = new sap.ui.base.Event(null, new sap.m.UploadCollection(), null);
		var oStubMessage = this.stub(sap.m.MessageToast, "show");
		this.stub(ODataModel.prototype, "read").yieldsTo("error");
		this.stub(help, "setSingleActSearchFilters");
		this.oComponent.oDashBoardsModel = new ODataModel({serviceUrl: "test"});
		this.oController._activityId = "12345";
		// Actions
		this.oController.onUploadComplete(oEvent);
		// Assertions
		assert.strictEqual(oStubMessage.callCount, 1);
		assert.strictEqual(oEvent.getSource().getBusy(), false);
	});
	
	QUnit.module("pages - Detail view: Help functions", {
		beforeEach: function() {
			this.oController = new DetailController();
		},
		afterEach: function() {
			this.oController.destroy();
		}
	});
	
	// QUnit.test("getHelpValueLists: Should get all settings list when detail page loads initially", function(assert) {
	// 	var oStubRegion = this.stub(this.oController, "getRegionList");
	// 	var oStubCategory = this.stub(this.oController, "getCategoryList");
	// 	var oStubStatus = this.stub(this.oController, "getStatusList");
	// 	var oStubRating = this.stub(this.oController, "getRatingList");
	// 	var oStubPriority = this.stub(this.oController, "getPriorityList");
	// 	this.oController.getHelpValueLists();
	// 	assert.strictEqual(oStubRegion.callCount, 1);
	// 	assert.strictEqual(oStubCategory.callCount, 1);
	// 	assert.strictEqual(oStubStatus.callCount, 1);
	// 	assert.strictEqual(oStubRating.callCount, 1);
	// 	assert.strictEqual(oStubPriority.callCount, 1);
	// });
	
	QUnit.test("prepareActivityData: Should get detail information of target activity when receive event 'DisplayActivity'", function(assert) {
		var oStubDetail = this.stub(this.oController, "getActivityDetails");
		this.oController.prepareActivityData(null, null, {id: "123"});
		assert.strictEqual(oStubDetail.callCount, 1);
		assert.strictEqual(this.oController._activityId, "123");
	});
	
	QUnit.module("pages - Detail view: Upadate Activity Detail Information", {
		beforeEach: function() {
			this.oModelI18n = new ResourceModel({
				bundleName: "sap.support.mccactivities.i18n.message_bundle",
				bundleLocale: "EN"
			});
			Component.extend("test.MockComponent", {
				oDashBoardsModel: new ODataModel("/sap/opu/odata/test", true),
				oDataManager: {
					loadActivitiesList: function() {}
				}
			});
			this.oComponent = new test.MockComponent();
			this.oComponent.setModel(this.oModelI18n, "i18n");
			this.oController = new DetailController();
			this.oViewStub = new View({});
			sinon.stub(this.oController, "getView").returns(this.oViewStub);
			
			sinon.stub(Controller.prototype, "getOwnerComponent").returns(this.oComponent);
			sinon.stub(this.oController, "eventUsage");
			sinon.stub(this.oViewStub, "setBusy");
		},
		afterEach: function() {
			Controller.prototype.getOwnerComponent.restore();
			this.oController.eventUsage.restore();
			this.oController.getView.restore();
			this.oModelI18n.destroy();
			this.oViewStub.setBusy.restore();
			this.oController.destroy();
			this.oComponent.destroy();
			this.oViewStub.destroy();
		}
	});
	
	
	QUnit.test("Should not send update activity request when activity id is not valid", function(assert) {
		var oStubUpdate = this.stub(ODataModel.prototype, "update");
		this.oController.updateActivityRequest(undefined, {test: "abc"});
		assert.strictEqual(oStubUpdate.callCount, 0);
	});
	
	QUnit.test("Should not send update activity request when update model is not valid", function(assert) {
		var oStubUpdate = this.stub(ODataModel.prototype, "update");
		this.oController.updateActivityRequest("123", {});
		assert.strictEqual(oStubUpdate.callCount, 0);
	});
	
	QUnit.test("Should send update activity request when activity id and update model are valid", function(assert) {
		var oStubUpdate = this.stub(ODataModel.prototype, "update");
		this.oController.updateActivityRequest("123", {test: "abc"});
		assert.strictEqual(oStubUpdate.callCount, 1);
	});
	
	QUnit.test("Should get detail information for current activity, refresh master list and clear notes area when update activity request is successful", function(assert) {
		this.stub(ODataModel.prototype, "update").yieldsTo("success");
		var oStubGetDetail = this.stub(this.oController, "getActivityDetails");
		var oStubRefresh = this.stub(this.oComponent.oDataManager, "loadActivitiesList");
		var oStubInput = this.stub(View.prototype, "byId").returns(new sap.m.TextArea());
		var oStubActionBtn = this.stub(this.oController, "_setNotesActionButtonsEnable");
		this.oController.updateActivityRequest("123", {test: "abc"}, true);
		assert.strictEqual(oStubGetDetail.callCount, 1);
		assert.strictEqual(oStubRefresh.callCount, 1);
		assert.strictEqual(oStubInput.callCount, 1);
		assert.strictEqual(oStubActionBtn.callCount, 1);
	});
	
	QUnit.test("Should get detail information for current activity and clear notes area when update activity request is successful and refresh master flag is false", function(assert) {
		this.stub(ODataModel.prototype, "update").yieldsTo("success");
		var oStubGetDetail = this.stub(this.oController, "getActivityDetails");
		var oStubRefresh = this.stub(this.oComponent.oDataManager, "loadActivitiesList");
		var oStubInput = this.stub(View.prototype, "byId").returns(new sap.m.TextArea());
		var oStubActionBtn = this.stub(this.oController, "_setNotesActionButtonsEnable");
		this.oController.updateActivityRequest("123", {test: "abc"}, false);
		assert.strictEqual(oStubGetDetail.callCount, 1);
		assert.strictEqual(oStubRefresh.callCount, 0);
		assert.strictEqual(oStubInput.callCount, 1);
		assert.strictEqual(oStubActionBtn.callCount, 1);
	});
	
	QUnit.test("Should show error message when update activity request is failed", function(assert) {
		this.stub(ODataModel.prototype, "update").yieldsTo("error");
		/*var oStubGetDetail = this.stub(this.oController, "getActivityDetails");
		var oStubRefresh = this.stub(this.oComponent.oDataManager, "loadActivitiesList");*/
		var oStubMsg = this.stub(MessageToast, "show");
		this.oController.updateActivityRequest("123", {test: "abc"}, true);
		/*assert.strictEqual(oStubGetDetail.callCount, 1);
		assert.strictEqual(oStubRefresh.callCount, 1);*/
		assert.strictEqual(oStubMsg.callCount, 1);
	});
	
	/*QUnit.test("Should show error message, get detail information for current activity when update activity request is failed and refresh master flag is false", function(assert) {
		this.stub(ODataModel.prototype, "update").yieldsTo("error");
		var oStubGetDetail = this.stub(this.oController, "getActivityDetails");
		var oStubRefresh = this.stub(this.oComponent.oDataManager, "loadActivitiesList");
		var oStubMsg = this.stub(MessageToast, "show");
		this.oController.updateActivityRequest("123", {test: "abc"}, false);
		assert.strictEqual(oStubGetDetail.callCount, 1);
		assert.strictEqual(oStubRefresh.callCount, 0);
		assert.strictEqual(oStubMsg.callCount, 1);
	});*/
	
	QUnit.test("Should not call sending update activity request when activity id is empty", function(assert) {
		this.stub(this.oViewStub, "byId").returns(new sap.m.TextArea({value: "Test"}));
		this.oController._activityId = "";
		var oStubRequest = this.stub(this.oController, "updateActivityRequest");
		this.oController.updateActivityNote();
		assert.strictEqual(oStubRequest.callCount, 0);
	});
	
	QUnit.test("Should call sending update activity request without note data when note is empty", function(assert) {
		this.stub(this.oViewStub, "byId").returns(new sap.m.TextArea({value: ""}));
		this.oController._activityId = "12345";
		var oStubRequest = this.stub(this.oController, "updateActivityRequest");
		this.oController.updateActivityNote();
		assert.strictEqual(Boolean(oStubRequest.args[0][1].Notes), false);
	});
	
	QUnit.test("Should call sending update activity request when activity id and note are valid", function(assert) {
		this.stub(this.oViewStub, "byId").returns(new sap.m.TextArea({value: "Test"}));
		this.oController._activityId = "12345";
		var oStubRequest = this.stub(this.oController, "updateActivityRequest");
		this.oController.updateActivityNote();
		assert.strictEqual(oStubRequest.callCount, 1);
	});
	
	QUnit.test("Should only update note and not refresh master list when activity note is saved with no update model and no refresh flag", function(assert) {
		this.stub(this.oViewStub, "byId").returns(new sap.m.TextArea({value: "Test"}));
		this.oController._activityId = "12345";                         
		var oStubRequest = this.stub(this.oController, "updateActivityRequest");
		this.oController.updateActivityNote(null, null, false);
		assert.strictEqual(oStubRequest.args[0][0], "12345");
		assert.deepEqual(oStubRequest.args[0][1], {Notes: "Test"});
		assert.strictEqual(oStubRequest.args[0][2], false);
	});
	
	QUnit.test("Should update current activity properties & note and refresh master list when activity note is saved with additional update model and refresh flag", function(assert) {
		this.stub(this.oViewStub, "byId").returns(new sap.m.TextArea({value: "Test"}));
		this.oController._activityId = "12345";                         
		var oStubRequest = this.stub(this.oController, "updateActivityRequest");
		var oTestModel = {Status: "123", Name: "New"};
		this.oController.updateActivityNote(null, oTestModel, true);
		assert.strictEqual(oStubRequest.args[0][0], "12345");
		assert.deepEqual(oStubRequest.args[0][1], {Status: "123", Name: "New", Notes: "Test"});
		assert.strictEqual(oStubRequest.args[0][2], true);
	});
	
	QUnit.test("Should prepare to save note with no additional update model when saving note only", function(assert) {
		var oStubUpdateNote = this.stub(this.oController, "updateActivityNote");
		this.oController.onSaveNote();
		assert.deepEqual(oStubUpdateNote.args[0][1], null);
		assert.deepEqual(oStubUpdateNote.args[0][2], false);
	});
	
	/*QUnit.test("Should show a message box when saving note and sending to MCC", function(assert) {
		var oStubMsg = this.stub(sap.m.MessageBox, "confirm");
		this.oController.onSaveNoteAndSendMCC();
		assert.strictEqual(oStubMsg.callCount, 1);
	});*/
	
	/*QUnit.test("Should close the message box and update notes with 'reject' model when pressing 'OK' in the 'Save & Send to MCC' message box", function(assert) {
		this.stub(sap.m.MessageBox, "confirm").yieldsTo("onClose", "OK");
		var oStubNote = this.stub(this.oController, "updateActivityNote");
		this.oController.onSaveNoteAndSendMCC();
		assert.strictEqual(oStubNote.callCount, 1);
		assert.deepEqual(oStubNote.args[0][1], {activity_status: "E0011", activity_person_user_id: ""});
	});*/
	
	QUnit.test("Should update notes with 'reject' model when saving note and sending to MCC", function(assert) {
		var oStubNote = this.stub(this.oController, "updateActivityNote");
		this.oController.onSaveNoteAndSendMCC();
		assert.strictEqual(oStubNote.callCount, 1);
		assert.deepEqual(oStubNote.args[0][1], {activity_status: "E0011", activity_person_user_id: ""});
	});
	
	/*QUnit.test("Should just close the message box when pressing 'Cancel' in the 'Save & Send to MCC' message box", function(assert) {
		this.stub(sap.m.MessageBox, "confirm").yieldsTo("onClose", "Cancel");
		var oStubNote = this.stub(this.oController, "updateActivityNote");
		this.oController.onSaveNoteAndSendMCC();
		assert.strictEqual(oStubNote.callCount, 0);
	});*/
	
	QUnit.test("Should show a message box when saving note and close the activity", function(assert) {
		var oStubMsg = this.stub(sap.m.MessageBox, "confirm");
		this.oController.onSaveNoteAndClose();
		assert.strictEqual(oStubMsg.callCount, 1);
	});
	
	QUnit.test("Should close the message box and update close the activity when pressing 'OK' in the 'Close' message box", function(assert) {
		this.stub(sap.m.MessageBox, "confirm").yieldsTo("onClose", "OK");
		var oStubNote = this.stub(this.oController, "updateActivityNote");
		this.oController.onSaveNoteAndClose();
		assert.strictEqual(oStubNote.callCount, 1);
		assert.deepEqual(oStubNote.args[0][1], {activity_status: "E0014"});
	});
	
	QUnit.test("Should just close the message box when pressing 'Cancel' in the 'Close' message box", function(assert) {
		this.stub(sap.m.MessageBox, "confirm").yieldsTo("onClose", "Cancel");
		var oStubNote = this.stub(this.oController, "updateActivityNote");
		this.oController.onSaveNoteAndClose();
		assert.strictEqual(oStubNote.callCount, 0);
	});
	
	QUnit.module("pages - Detail view: Set/Remove Activity Favorite", {
		beforeEach: function() {
			Component.extend("test.MockComponent", {
				oDashBoardsModel: new ODataModel("/sap/opu/odata/test", true),
				oDataManager: {
					loadActivitiesList: function() {}
				}
			});
			this.oComponent = new test.MockComponent();
			this.oController = new DetailController();
			sinon.stub(Controller.prototype, "getOwnerComponent").returns(this.oComponent);
		},
		afterEach: function() {
			Controller.prototype.getOwnerComponent.restore();
			this.oController.destroy();
			this.oComponent.destroy();
		}
	});
	
	function setFavoritModel(aArrary) {
		var oModel = new sap.ui.model.json.JSONModel();
		oModel.setData({FAVORITE_ACTIVITIES: aArrary});
		this.oComponent.setModel(oModel, "UserProfile");
	}
	
	QUnit.test("setFavoriteFlag: Should not flagged favorite when the activity is 'undefined'", function(assert) {
		assert.strictEqual(this.oController.setFavoriteFlag(), false);
	});
	
	QUnit.test("setFavoriteFlag: Should not flagged favorite when data type of the activity is wrong", function(assert) {
		assert.strictEqual(this.oController.setFavoriteFlag([]), false);
	});
	
	QUnit.test("setFavoriteFlag: Should not flagged favorite when the activity has no activity id", function(assert) {
		assert.strictEqual(this.oController.setFavoriteFlag({activity_id: ""}), false);
	});
	
	QUnit.test("setFavoriteFlag: Should not flagged favorite when there is no original favorite activity", function(assert) {
		setFavoritModel.call(this, []);
		assert.strictEqual(this.oController.setFavoriteFlag({activity_id: "123"})._bFavorite, false);
	});
	
	QUnit.test("setFavoriteFlag: Should not flagged favorite when the activity doesn't match original favorite activities", function(assert) {
		setFavoritModel.call(this, [{Value: "123"}, {Value: "456"}]);
		assert.strictEqual(this.oController.setFavoriteFlag({activity_id: "789"})._bFavorite, false);
	});
	
	QUnit.test("setFavoriteFlag: Should flagged favorite when the activity matches original favorite activities", function(assert) {
		setFavoritModel.call(this, [{Value: "123"}, {Value: "456"}]);
		assert.strictEqual(this.oController.setFavoriteFlag({activity_id: "123"})._bFavorite, true);
	});
	
	QUnit.module("pages - Detail view: Cut last note", {
		beforeEach: function() {
			this.oController = new DetailController();
		},
		afterEach: function() {
			this.oController.destroy();
		}
	});
	
	function generateString(nlength) {
		var aRes = new Array(nlength);
		return $.each(aRes, function(index, item) { aRes[index] = "A"; }).join("");
	}
	
	QUnit.test("_cutLastNote: Should return empty string when the last note is not valid", function(assert) {
		assert.strictEqual(this.oController._cutLastNote(), "");
	});
	
	QUnit.test("_cutLastNote: Should return 'abc' when the last note is 'abc'", function(assert) {
		assert.strictEqual(this.oController._cutLastNote("abc"), "abc");
	});
	
	QUnit.test("_cutLastNote: Should return the last note when the last note is a string with length less than 380", function(assert) {
		var aArr379 = generateString(379);
		assert.strictEqual(this.oController._cutLastNote(aArr379), aArr379);
	});
	
	QUnit.test("_cutLastNote: Should return the cutted last note and '...\n' when the last note has long word ending", function(assert) {
		var aArr100 = generateString(100);
		var aArr300 = generateString(300);
		assert.strictEqual(this.oController._cutLastNote(aArr100 + " " + aArr300), aArr100 + " " + generateString(279) + "...\n");
	});
	
	QUnit.test("_cutLastNote: Should return the double cutted last note and '...\n' when the last note has short word ending", function(assert) {
		var aArr100 = generateString(100);
		var aArr310 = generateString(310);
		assert.strictEqual(this.oController._cutLastNote(aArr310 + " " + aArr100), aArr310 + "...\n");
	});
	
	
});