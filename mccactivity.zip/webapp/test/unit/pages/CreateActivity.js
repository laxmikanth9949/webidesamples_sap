sap.ui.require([
	"sap/support/mccactivities/view/CreateActivity.controller",
	"sap/ui/core/mvc/View",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/core/UIComponent",
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/Router",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/Dialog",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(CreateController, View, ResourceModel, Component, Controller, Router, ODataModel, Dialog) {
	"use strict";

	QUnit.module("pages - Create activity view", {
		beforeEach: function() {
			this.oController = new CreateController();
			/*this.oModelI18n = new ResourceModel({
				bundleName: "sap.support.mccactivities.i18n.message_bundle",
				bundleLocale: "EN"
			});*/
			this.oComponent = new Component();
			//this.oComponent.setModel(this.oModelI18n, "i18n");
			sinon.stub(Controller.prototype, "getOwnerComponent").returns(this.oComponent);
			/*this.oRouterStub = new Router();
			sinon.stub(sap.ui.core.UIComponent, "getRouter").returns(this.oRouterStub);*/
			this.oViewStub = new View({});
			sinon.stub(this.oController, "getView").returns(this.oViewStub);
			sinon.stub(this.oController, "_requireOtherModule");
			this.oControlStub = sinon.stub(this.oViewStub, "byId").returns(new sap.m.Select());
			sinon.stub(Dialog.prototype, "open");
			sinon.stub(Dialog.prototype, "close");
			sinon.stub(sap.m.MessageToast, "show");
		},
		afterEach: function() {
			this.oController.destroy();
			Controller.prototype.getOwnerComponent.restore();
			//this.oModelI18n.destroy();
			this.oComponent.destroy();
			//this.oRouterStub.destroy();
			this.oViewStub.destroy();
			Dialog.prototype.open.restore();
			Dialog.prototype.close.restore();
			sap.m.MessageToast.show.restore();
		}
	});
	
	function checkCreateBtnEnabled() {
		this.oControlStub.withArgs("iBtnCreateAct").returns(new sap.m.Button());
		this.oStubCreateBtnEnabled = this.stub(sap.m.Button.prototype, "setEnabled");
	}
	
	function setCreateControlModel() {
		var oCreateControlModel = new sap.ui.model.json.JSONModel({});
		oCreateControlModel.setDefaultBindingMode("OneWay");
		this.oComponent.setModel(oCreateControlModel, "CreateControl");
	}
	
	function setAgsDBODataModel() {
		this.oComponent.oDashBoardsModel = new ODataModel("/sap/opu/odata/test", true);
		//this.oController.oModelAgsDB = new ODataModel("/sap/opu/odata/test", true);
	}
	
	QUnit.test("'Create' button should not be available after 'Create' button is pressed and all mandatory parameters are filled", function(assert) {
		checkCreateBtnEnabled.call(this);
		sinon.stub(this.oController, "checkInputs").returns("");
		sinon.stub(this.oController, "checkMissingAccount");
		this.oController.onCreate();
		
		assert.strictEqual(this.oStubCreateBtnEnabled.withArgs(false).called, true);
	});
	
	QUnit.test("'Create' button should be available after cancel 'InvalidCaseId' Dialog", function(assert) {
		checkCreateBtnEnabled.call(this);
		this.oController.cancelInvalidCaseIdDialog();
		
		assert.strictEqual(this.oStubCreateBtnEnabled.withArgs(true).called, true);
	});
	
	QUnit.test("'Create' button should be available after cancel 'NoAccount' Dialog", function(assert) {
		checkCreateBtnEnabled.call(this);
		this.oController.cancelNoAccountDialog();
		
		assert.strictEqual(this.oStubCreateBtnEnabled.withArgs(true).called, true);
	});
	
	QUnit.test("'Create' button should be available after cancel 'EFOS' Dialog", function(assert) {
		checkCreateBtnEnabled.call(this);
		this.oController.cancelEFOSDialog();
		
		assert.strictEqual(this.oStubCreateBtnEnabled.withArgs(true).called, true);
	});
	
	QUnit.test("'Accept' button in 'InvalidCaseId' Dialog should not be available after it's pressed and no 'NoAccount' Dialog shows", function(assert) {
		setCreateControlModel.call(this);
		sinon.stub(this.oController, "checkCreateActivity");
		sinon.stub(this.oController, "getSearchfields");
		this.stub(this.oController, "checkMissingAccount");
		this.oController._sCheck = "test";
		this.oController.createActitivityWithoutCaseId();
		
		assert.strictEqual(this.oComponent.getModel("CreateControl").getProperty("/InvalidCaseIdDialogAccept"), false);
	});
	
	QUnit.test("'Accept' button in 'InvalidCaseId' Dialog should be available after it's pressed and 'NoAccount' Dialog shows", function(assert) {
		setCreateControlModel.call(this);
		this.oController._sCheck = "missingAccount";
		this.oController.createActitivityWithoutCaseId();
		
		assert.strictEqual(this.oComponent.getModel("CreateControl").getProperty("/InvalidCaseIdDialogAccept"), true);
	});
	
	QUnit.test("'Accept' button in 'NoAccount' Dialog should not be available after it's pressed and no 'EFOS' Dialog shows", function(assert) {
		setCreateControlModel.call(this);
		sinon.stub(this.oController, "_setServiceTeam");
		sinon.stub(this.oController, "getSearchfields").returns({"category": "AAA", "title": "test"});
		this.oController.createActitivityWithoutAccount();
		
		assert.strictEqual(this.oComponent.getModel("CreateControl").getProperty("/NoAccountDialogAccept"), false);
	});
	
	QUnit.test("'Accept' button in 'NoAccount' Dialog should be available after it's pressed and 'EFOS' Dialog shows", function(assert) {
		setCreateControlModel.call(this);
		sinon.stub(this.oController, "getSearchfields").returns({"category": "ZZN", "title": "test"});
		var oStubST = this.stub(this.oController, "_setServiceTeam");
		this.oController.createActitivityWithoutAccount();
		
		assert.strictEqual(this.oComponent.getModel("CreateControl").getProperty("/NoAccountDialogAccept"), false);
		assert.strictEqual(oStubST.callCount, 1);
	});
	
	QUnit.test("'Accept' button in 'EFOS' Dialog should not be available after it's pressed", function(assert) {
		setCreateControlModel.call(this);
		sinon.stub(this.oController, "createActivity");
		this.oController._searchFields_activity = {"title": "test"};
		this.oController.addEFOStoTitle();
		
		assert.strictEqual(this.oComponent.getModel("CreateControl").getProperty("/EFOSDialogAccept"), false);
	});
	
	QUnit.test("'Create' button and all 'Accept' button in Dialogs should be available after an activity is created successfully", function(assert) {
		checkCreateBtnEnabled.call(this);
		setCreateControlModel.call(this);
		setAgsDBODataModel.call(this);
		this.stub(ODataModel.prototype, "create").callsArg(0).yieldsTo("success");
		this.stub(this.oController, "eventUsage");
		this.oController.createActivity({});
		
		assert.strictEqual(this.oStubCreateBtnEnabled.withArgs(true).called, true);
		assert.strictEqual(this.oComponent.getModel("CreateControl").getProperty("/InvalidCaseIdDialogAccept"), true);
		assert.strictEqual(this.oComponent.getModel("CreateControl").getProperty("/NoAccountDialogAccept"), true);
		assert.strictEqual(this.oComponent.getModel("CreateControl").getProperty("/EFOSDialogAccept"), true);
	});
	
	QUnit.test("'Create' button and all 'Accept' button in Dialogs should be available after an activity isn't created successfully", function(assert) {
		var router = new sap.ui.core.routing.Router();
		checkCreateBtnEnabled.call(this);
		setCreateControlModel.call(this);
		setAgsDBODataModel.call(this);
		this.stub(ODataModel.prototype, "create").callsArg(0).yieldsTo("error");
		this.stub(this.oComponent, "getRouter").returns(router);
		this.stub(this.oController, "navTo");
		this.stub(this.oController, "eventUsage");
		this.oController.createActivity({});
		
		assert.strictEqual(this.oStubCreateBtnEnabled.withArgs(true).called, true);
		assert.strictEqual(this.oComponent.getModel("CreateControl").getProperty("/InvalidCaseIdDialogAccept"), true);
		assert.strictEqual(this.oComponent.getModel("CreateControl").getProperty("/NoAccountDialogAccept"), true);
		assert.strictEqual(this.oComponent.getModel("CreateControl").getProperty("/EFOSDialogAccept"), true);
	});
	
	QUnit.test("onInit: Should init 'CreateActivity' controller when navigate to this view firstly.", function(assert) {
		var oStubModel = this.stub(this.oController, "_setCreateModel");
		var oStubEvent = this.stub(sap.ui.core.Core.prototype, "getEventBus").returns(new sap.ui.core.EventBus());
		this.stub(sap.ui.core.EventBus.prototype, "subscribe");
		//var oStubList = this.stub(this.oController, "getHelpValueLists");
		var oStubDelegate = this.stub(View.prototype, "addEventDelegate");
		
		this.oController.onInit();
		
		assert.strictEqual(oStubModel.callCount, 1);
		assert.strictEqual(oStubEvent.callCount, 3);
		//assert.strictEqual(oStubList.callCount, 1);
		assert.strictEqual(oStubDelegate.callCount, 1);
	});
	
	QUnit.test("onCaseIdChange: Should check customer number when case id changed.", function(assert) {
		var oStubCust = this.stub(this.oController, "_checkERPCustomerFilled");
		
		this.oController.onCaseIdChange();
		
		assert.strictEqual(oStubCust.callCount, 1);
	});
	
	QUnit.test("onSetDefaults: Should set 'case id/customer no./description/priority/category/service team/requestor' to default value when current user has an account.", function(assert) {
		var oModelUP = new sap.ui.model.json.JSONModel();
		var oModelCreation = new sap.ui.model.json.JSONModel();
		var oDataUP = {APP_MCC_ACTIVITIES_DEFAULT_CASE: {Value: "123"}, APP_MCC_ACTIVITIES_DEFAULT_STEAM: {Value: "abc"}};
		oModelUP.setData(oDataUP);
		this.oComponent.setModel(oModelUP, "UserProfile");
		this.oViewStub.setModel(oModelCreation, "Creation");
		var oStubCustNo = this.stub(this.oController, "_readERPCustNo");
		//var oStubDesc = this.stub(this.oController, "checkSetDefaultDescription");
		//var oStubST = this.stub(this.oController, "setServiceTeam");
		
		this.oController.onSetDefaults();
		
		assert.strictEqual(oStubCustNo.callCount, 1);
		//assert.strictEqual(oStubDesc.callCount, 1);
		//assert.strictEqual(oStubST.callCount, 1);
		assert.deepEqual(this.oController.getView().getModel("Creation").getData(), {caseId: "123", priority: "5", category: "ZB4", requestorVisible: false, requestor: ""});
	});
	
	QUnit.test("onCancel: Should clear data and navigate back when clicking 'Cancel' button.", function(assert) {
		var oStubClear = this.stub(this.oController, "onClear");
		var oStubNav = this.stub(this.oController, "onNavBack");
		
		this.oController.onCancel();
		
		assert.strictEqual(oStubClear.callCount, 1);
		assert.strictEqual(oStubNav.callCount, 1);
	});
	
	QUnit.test("onClear: Should clear all flags, init service team field and clear the model when clicking 'Clear' button.", function(assert) {
		var oStubModel = this.stub(this.oController, "_setCreateModel");
		
		this.oController.onClear();
		
		assert.strictEqual(this.oController.oFlagCallMe , false);
		assert.strictEqual(this.oController.oFlagCreateByEvent  , false);
		assert.strictEqual(oStubModel.callCount, 1);
	});
	
	QUnit.test("onCallMe: Should set 'case id/customer no./description/priority/service team/requestor' to 'onCallMe' value when current user has an account.", function(assert) {
		var oModelUP = new sap.ui.model.json.JSONModel();
		var oModelCreation = new sap.ui.model.json.JSONModel();
		var oModelSetting = new sap.ui.model.json.JSONModel();
		var oDataUP = {APP_MCC_ACTIVITIES_DEFAULT_CASE: {Value: "123"}, APP_MCC_ACTIVITIES_DEFAULT_STEAM: {Value: "abc"}};
		var oDataRegion = {RegionList: [{Topic: [{service_team_id: "def"}, {service_team_id: "abc"}]}]};
		oModelUP.setData(oDataUP);
		oModelSetting.setData(oDataRegion);
		this.oComponent.setModel(oModelUP, "UserProfile");
		this.oComponent.setModel(oModelSetting, "SettingList");
		this.oViewStub.setModel(oModelCreation, "Creation");
		var oStubClear = this.stub(this.oController, "onClear");
		var oStubCustNo = this.stub(this.oController, "_readERPCustNo");
		//var oStubSelect = this.stub(sap.m.Select.prototype, "setSelectedKey");
		//var oStubRegion = this.stub(this.oController, "checkSelectedRegion");
		//var oStubTopic = this.stub(this.oController, "setCMTopic");
		
		this.oController.onCallMe();
		
		assert.strictEqual(oStubClear.callCount, 1);
		assert.strictEqual(oStubCustNo.callCount, 1);
		//assert.strictEqual(oStubSelect.args[0][0], 0);
		//assert.strictEqual(oStubRegion.callCount, 1);
		//assert.strictEqual(oStubTopic.callCount, 1);
		assert.deepEqual(this.oController.getView().getModel("Creation").getData(), {caseId: "123", priority: "1", title: "Please call me", desc: "Please call me"});
	});
	
	// QUnit.test("getHelpValueLists: Should get all value list from oData model when initial loading.", function(assert) {
	// 	var oStubRegion = this.stub(this.oController, "getRegionList");
	// 	var oStubPriority = this.stub(this.oController, "getPriorityList");
	// 	var oStubSelect = this.stub(sap.m.Select.prototype, "setSelectedKey");
		
	// 	this.oController.getHelpValueLists();
		
	// 	assert.strictEqual(oStubRegion.callCount, 1);
	// 	assert.strictEqual(oStubPriority.callCount, 1);
	// 	assert.strictEqual(oStubSelect.callCount, 1);
	// });
	
	QUnit.test("_checkValidCaseId: Should return true when input value is '20300848'.", function(assert) {
		assert.strictEqual(this.oController._checkValidCaseId("20300848"), true);
	});
	
	QUnit.test("_checkValidCaseId: Should return true when input value is '0020102134'.", function(assert) {
		assert.strictEqual(this.oController._checkValidCaseId("0020102134"), true);
	});
	
	QUnit.test("_checkValidCaseId: Should return true when input value is '0030102134'.", function(assert) {
		assert.strictEqual(this.oController._checkValidCaseId("0030102134"), false);
	});
	
	QUnit.test("prepareInputFields: Should set all input field from UI control when creating activity.", function(assert) {
		var oModelCreation = new sap.ui.model.json.JSONModel();
		this.oViewStub.setModel(oModelCreation, "Creation");
		
		this.oController.prepareInputFields(null, null, {data: {caseid: "123", customer: "abc", priority: "3", category: "1", serviceteam: "789"}});
		
		assert.deepEqual(this.oController.getView().getModel("Creation").getData(), {caseId: "123", erpCust: "abc", priority: "3", category: "1", serviceTeam: "789"});
	});
	
	QUnit.test("prepareRequestorInputFields: Should set all input field from requestor data when creating activity based on requestor.", function(assert) {
		var oModelCreation = new sap.ui.model.json.JSONModel();
		this.oViewStub.setModel(oModelCreation, "Creation");
		
		this.oController.prepareRequestorInputFields(null, null, {data: {title: "test", desc: "new"}});
		
		assert.deepEqual(this.oController.getView().getModel("Creation").getData(), {requestorVisible: true, title: "test", desc: "new"});
	});
	
	QUnit.test("prepareEventInputFields: Should set all input field from event data and check caseid & customer matching when creating activity based on event with case id and customer filled.", function(assert) {
		var oModelCreation = new sap.ui.model.json.JSONModel();
		this.oViewStub.setModel(oModelCreation, "Creation");
		var oStubMatch = this.stub(this.oController, "_checkCaseCustMatched");
		
		this.oController.prepareEventInputFields(null, null, {data: {caseid: "123", customer: "abc", priority: "3", serviceteam: "789", title: "test", desc: "new", category: "created"}});
		
		assert.strictEqual(oStubMatch.callCount, 1);
		assert.deepEqual(this.oController.getView().getModel("Creation").getData(), {caseId: "123", erpCust: "abc", priority: "3", serviceTeam: "789", title: "test", desc: "new", category: "created"});	
	});
	
	QUnit.test("prepareEventInputFields: Should set all input field from event data and read customer data when creating activity based on event with only case id filled.", function(assert) {
		var oModelCreation = new sap.ui.model.json.JSONModel();
		this.oViewStub.setModel(oModelCreation, "Creation");
		var oStubMatch = this.stub(this.oController, "_readERPCustNo");
		
		this.oController.prepareEventInputFields(null, null, {data: {caseid: "123", customer: "", priority: "3", serviceteam: "789", title: "test", desc: "new", category: "created"}});
		
		assert.strictEqual(oStubMatch.callCount, 1);
		assert.deepEqual(this.oController.getView().getModel("Creation").getData(), {caseId: "123", erpCust: "", priority: "3", serviceTeam: "789", title: "test", desc: "new", category: "created"});	
	});
	
	QUnit.test("prepareEventInputFields: Should set all input field from event data and read case id when creating activity based on event with only customer filled.", function(assert) {
		var oModelCreation = new sap.ui.model.json.JSONModel();
		this.oViewStub.setModel(oModelCreation, "Creation");
		var oStubMatch = this.stub(this.oController, "_readCaseId");
		
		this.oController.prepareEventInputFields(null, null, {data: {caseid: "", customer: "abc", priority: "3", serviceteam: "789", title: "test", desc: "new", category: "created"}});
		
		assert.strictEqual(oStubMatch.callCount, 1);
		assert.deepEqual(this.oController.getView().getModel("Creation").getData(), {caseId: "", erpCust: "abc", priority: "3", serviceTeam: "789", title: "test", desc: "new", category: "created"});	
	});
	
	// QUnit.test("onCreateTopicChange: Should handle topic change and check default description when changing topic in creation.", function(assert) {
	// 	var oStubTopic = this.stub(this.oController, "onTopicChange");
	// 	var oStubDefault = this.stub(this.oController, "checkSetDefaultDescription");
		
	// 	this.oController.onCreateTopicChange();
		
	// 	assert.strictEqual(oStubTopic.callCount, 1);
	// 	assert.strictEqual(oStubDefault.callCount, 1);
	// });
	
	QUnit.test("onNavBack: Should navigate back to the last view when clicking 'Back' button.", function(assert) {
		var oStubNav = this.stub(this.oController, "navTo");
		
		this.oController.onNavBack();
		
		assert.strictEqual(oStubNav.callCount, 1);
	});
	
	QUnit.module("pages - Create activity view: Test cases for 'Default Description'", {
		beforeEach: function() {
			this.oController = new CreateController();
			this.oComponent = new Component();
			sinon.stub(Controller.prototype, "getOwnerComponent").returns(this.oComponent);
			this.oViewStub = new View({});
			sinon.stub(this.oController, "getView").returns(this.oViewStub);
			this.oController._setCreateModel();
		},
		afterEach: function() {
			this.oController.destroy();
			this.oComponent.destroy();
			Controller.prototype.getOwnerComponent.restore();
			this.oViewStub.destroy();
		}
	});
	
	// QUnit.test("Should not set default description if description field is filled with content", function(assert) {
	// 	this.oController.getView().getModel("Creation").setProperty("/desc", "abc");
	// 	var oStubSetDesc = this.stub(this.oController, "setDefaultDescription");
	// 	this.oController.checkSetDefaultDescription();
	// 	assert.strictEqual(oStubSetDesc.callCount, 0);
	// });
	
	// QUnit.test("Should set default description if description field is empty and service team is 'Cloud' of APJ", function(assert) {
	// 	this.oController.getView().getModel("Creation").setProperty("/serviceTeam", "19093065");
	// 	var oStubSetDesc = this.stub(this.oController, "setDefaultDescription").returns("Description");
	// 	this.oController.checkSetDefaultDescription();
	// 	assert.strictEqual(oStubSetDesc.callCount, 1);
	// 	assert.strictEqual(this.oController.getView().getModel("Creation").getProperty("/desc"), "Description");
	// });
	
	// QUnit.test("Should set default description if description field is empty and service team is 'Cloud' of EMEA", function(assert) {
	// 	this.oController.getView().getModel("Creation").setProperty("/serviceTeam", "17877275");
	// 	var oStubSetDesc = this.stub(this.oController, "setDefaultDescription").returns("Description");
	// 	this.oController.checkSetDefaultDescription();
	// 	assert.strictEqual(oStubSetDesc.callCount, 1);
	// 	assert.strictEqual(this.oController.getView().getModel("Creation").getProperty("/desc"), "Description");
	// });
	
	// QUnit.test("Should set default description if description field is empty and service team is 'Cloud' of GLOBAL", function(assert) {
	// 	this.oController.getView().getModel("Creation").setProperty("/serviceTeam", "19568810");
	// 	var oStubSetDesc = this.stub(this.oController, "setDefaultDescription").returns("Description");
	// 	this.oController.checkSetDefaultDescription();
	// 	assert.strictEqual(oStubSetDesc.callCount, 1);
	// 	assert.strictEqual(this.oController.getView().getModel("Creation").getProperty("/desc"), "Description");
	// });
	
	// QUnit.test("Should set default description if description field is empty and service team is 'Cloud' of LAC", function(assert) {
	// 	this.oController.getView().getModel("Creation").setProperty("/serviceTeam", "17403528");
	// 	var oStubSetDesc = this.stub(this.oController, "setDefaultDescription").returns("Description");
	// 	this.oController.checkSetDefaultDescription();
	// 	assert.strictEqual(oStubSetDesc.callCount, 1);
	// 	assert.strictEqual(this.oController.getView().getModel("Creation").getProperty("/desc"), "Description");
	// });
	
	// QUnit.test("Should set default description if description field is empty and service team is 'Cloud' of NA", function(assert) {
	// 	this.oController.getView().getModel("Creation").setProperty("/serviceTeam", "16755384");
	// 	var oStubSetDesc = this.stub(this.oController, "setDefaultDescription").returns("Description");
	// 	this.oController.checkSetDefaultDescription();
	// 	assert.strictEqual(oStubSetDesc.callCount, 1);
	// 	assert.strictEqual(this.oController.getView().getModel("Creation").getProperty("/desc"), "Description");
	// });
	
	// QUnit.test("Should set default description if description field is only filled with 'space' and service team is 'Cloud' of NA", function(assert) {
	// 	this.oController.getView().getModel("Creation").setProperty("/desc", "     ");
	// 	this.oController.getView().getModel("Creation").setProperty("/serviceTeam", "16755384");
	// 	var oStubSetDesc = this.stub(this.oController, "setDefaultDescription").returns("Description");
	// 	this.oController.checkSetDefaultDescription();
	// 	assert.strictEqual(oStubSetDesc.callCount, 1);
	// 	assert.strictEqual(this.oController.getView().getModel("Creation").getProperty("/desc"), "Description");
	// });
	
	// QUnit.test("Should not set default description if description field is empty and service team is 'HANA' of APJ", function(assert) {
	// 	this.oController.getView().getModel("Creation").setProperty("/serviceTeam", "14235363");
	// 	var oStubSetDesc = this.stub(this.oController, "setDefaultDescription");
	// 	this.oController.checkSetDefaultDescription();
	// 	assert.strictEqual(oStubSetDesc.callCount, 0);
	// });
	
	// QUnit.test("Should return empty string when template model is undefined", function(assert) {
	// 	assert.strictEqual(this.oController.setDefaultDescription(), "");
	// });
	
	// QUnit.test("Should return combined string when template model is valid", function(assert) {
	// 	this.oController.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel({Template: [{line: "abc"}, {line: "def"}, {line: "123"}]}), "SettingList");
	// 	assert.strictEqual(this.oController.setDefaultDescription(), "abc\ndef\n123\n");
	// });
	
	QUnit.test("checkInputs: Should return customer and case flag when customer and case are not filled.", function(assert) {
		this.stub(View.prototype, "byId").returns(new sap.m.Input());
		this.stub(sap.m.Input.prototype, "getValue").returns("");
		
		assert.strictEqual(this.oController.checkInputs(), "missingAccountinvalidCaseId");
	});
	
	QUnit.test("checkInputs: Should not return customer and case flag when customer and case are filled.", function(assert) {
		this.stub(View.prototype, "byId").returns(new sap.m.Input());
		this.stub(sap.m.Input.prototype, "getValue").returns("test");
		
		assert.strictEqual(this.oController.checkInputs(), "");
	});
	
	QUnit.test("setSelectedCaseResult: Should set case and customer when complete searching in F4 help.", function(assert) {
		this.stub(View.prototype, "byId").returns(new sap.m.Input());
		var oStubValue = this.stub(sap.m.Input.prototype, "setValue");
		
		this.oController.setSelectedCaseResult({caseId: "123", custNo: "abc"});
		
		assert.strictEqual(oStubValue.callCount, 2);
	});
});