sap.ui.require([
	"sap/support/mccactivities/view/MasterActivities.controller",
	"sap/ui/core/mvc/View"
], function(Master, View) {
	"use strict";
	
	QUnit.module("pages - Master activity view", {
		beforeEach: function() {
			this.control = new Master();
			this.oStubView = new View();
		},
		afterEach: function() {
			this.control.destroy();
			this.oStubView.destroy();
		}
	});
	
	/*QUnit.test("Should save 0 status item to DB when select 0 status item", function(assert) {
		this.control.onFilterDialogConfirm();	
	});*/
});