sap.ui.require([
	"sap/support/mccactivities/view/App.controller"
], function(AppController) {
	"use strict";
	
	QUnit.module("pages - App Controller", {
        beforeEach: function() {
            this.oAppController = new AppController();
            this.oViewApp = sap.ui.xmlview("sap.support.mccactivities.view.App");
			this.oViewApp.placeAt("qunit-fixture");
        },
        afterEach: function() {
            this.oAppController.destroy();
            this.oViewApp.destroy();
        }
    });
    
    QUnit.test("Should be possible to create an instance", function(assert) {
        assert.ok(this.oAppController, "Was possible to create the instance");
        assert.strictEqual(this.oAppController.getMetadata().getName(), "sap.support.mccactivities.view.App", "Was created with the expected name");
    });
    
    QUnit.test("Should render the app as sap.m.SplitApp", function(assert) {
    	assert.strictEqual(this.oViewApp.getContent()[0].getMetadata().getName(), "sap.m.SplitApp", "Rendered the right control sap.m.SplitApp");
    });
});