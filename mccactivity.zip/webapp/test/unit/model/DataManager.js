sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/support/mccactivities/model/DataManager",
	"sap/support/mccactivities/model/models",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(Component, DataManager, models, ODataModel) {
	"use strict";

	QUnit.module("model - DataManager: Tests for single model", {
		beforeEach: function() {
			Component.extend("test.MockComponent", {
				//oAuth: {auth: false},
				sUser: ""
			});
			this.oComponent = new test.MockComponent();
			sinon.stub(DataManager.prototype, "loadData");
			sinon.stub(DataManager.prototype, "_setFirstActivityId");
			sinon.stub(ODataModel.prototype, "create");
			sinon.stub(models, "setSearchString");
			this.oDataManager = new DataManager(this.oComponent);
		},

		afterEach: function() {
			DataManager.prototype.loadData.restore();
			DataManager.prototype._setFirstActivityId.restore();
			ODataModel.prototype.create.restore();
			models.setSearchString.restore();
		}
	});

	// QUnit.test("Should see main page when current user has authorization in MCC", function(assert) {
	// 	this.stub(ODataModel.prototype, "read").yieldsTo("success", {
	// 		results: [{
	// 			authorzied: "yes"
	// 		}]
	// 	});
	// 	this.oDataManager.readAuth();
	// 	assert.strictEqual(this.oComponent.oAuth.auth, true);
	// });

	// QUnit.test("Should not see main page when current user doesn't have authorization in MCC", function(assert) {
	// 	this.stub(ODataModel.prototype, "read").yieldsTo("success", {
	// 		results: [{
	// 			authorzied: "no"
	// 		}]
	// 	});
	// 	this.oDataManager.readAuth();
	// 	assert.strictEqual(this.oComponent.oAuth.auth, false);
	// });

	// QUnit.test("Should see message 'Service error' when authorization service is not available", function(assert) {
	// 	var done = assert.async();
	// 	this.stub(ODataModel.prototype, "read").yieldsTo("error", "Service error");
	// 	this.oDataManager.readAuth().catch(function(error) {
	// 		assert.strictEqual(error, "Service error");
	// 		done();
	// 	}.bind(this));
	// });

	QUnit.test("Should not see status list when there is no status list in MCC default settings", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: []
		});
		this.oDataManager.readStatusList();
		assert.deepEqual(this.oComponent.getModel("SettingList").getProperty("/StatusList"), []);
	});

	QUnit.test("Should see 1 status item when there is 1 status in list in MCC default settings", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				value: "status1"
			}]
		});
		this.oDataManager.readStatusList();
		assert.deepEqual(this.oComponent.getModel("SettingList").getProperty("/StatusList"), [{
			value: "status1"
		}]);
	});

	QUnit.test("Should see 2 status items when there are 2 status in list in MCC default settings", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				value: "status1"
			}, {
				value: "status2"
			}]
		});
		this.oDataManager.readStatusList();
		assert.deepEqual(this.oComponent.getModel("SettingList").getProperty("/StatusList"), [{
			value: "status1"
		}, {
			value: "status2"
		}]);
	});

	QUnit.test("Should see message 'Service error' when status service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "read").yieldsTo("error", "Service error");
		this.oDataManager.readStatusList().catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});

	QUnit.test("Should see no category item when there is no category list in MCC default settings", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: []
		});
		this.oDataManager.readCategoryList();
		assert.deepEqual(this.oComponent.getModel("SettingList").getProperty("/CategoryList"), []);
	});

	QUnit.test("Should see 2 category items when there is 1 category in list in MCC default settings", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				value: "category1"
			}]
		});
		this.oDataManager.readCategoryList();
		assert.deepEqual(this.oComponent.getModel("SettingList").getProperty("/CategoryList"), [{
			value: "category1"
		}]);
	});

	QUnit.test("Should see 1 empty category item when there is 2 categories in list in MCC default settings", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				value: "category1"
			}, {
				value: "category2"
			}]
		});
		this.oDataManager.readCategoryList();
		assert.deepEqual(this.oComponent.getModel("SettingList").getProperty("/CategoryList"), [{
			value: "category1"
		}, {
			value: "category2"
		}]);
	});

	QUnit.test("Should see message 'Service error' when category service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "read").yieldsTo("error", "Service error");
		this.oDataManager.readCategoryList().catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});

	QUnit.test("Should not see rating list when there is no rating list in MCC default settings", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: []
		});
		this.oDataManager.readRatingList();
		assert.deepEqual(this.oComponent.getModel("SettingList").getProperty("/RatingList"), []);
	});

	QUnit.test("Should see 1 rating item when there is 1 rating in list in MCC default settings", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				value: "rating1"
			}]
		});
		this.oDataManager.readRatingList();
		assert.deepEqual(this.oComponent.getModel("SettingList").getProperty("/RatingList"), [{
			value: "rating1"
		}]);
	});

	QUnit.test("Should see 2 rating items when there are 2 rating in list in MCC default settings", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				value: "rating1"
			}, {
				value: "rating2"
			}]
		});
		this.oDataManager.readRatingList();
		assert.deepEqual(this.oComponent.getModel("SettingList").getProperty("/RatingList"), [{
			value: "rating1"
		}, {
			value: "rating2"
		}]);
	});

	QUnit.test("Should see message 'Service error' when rating service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "read").yieldsTo("error", "Service error");
		this.oDataManager.readRatingList().catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});

	QUnit.test("Should not see priority list when there is no priority list in MCC default settings", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: []
		});
		this.oDataManager.readPriorityList();
		assert.deepEqual(this.oComponent.getModel("SettingList").getProperty("/PriorityList"), []);
	});

	QUnit.test("Should see 1 priority item when there is 1 priority in list in MCC default settings", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				value: "priority1"
			}]
		});
		this.oDataManager.readPriorityList();
		assert.deepEqual(this.oComponent.getModel("SettingList").getProperty("/PriorityList"), [{
			value: "priority1"
		}]);
	});

	QUnit.test("Should see 2 priority items when there are 2 priority in list in MCC default settings", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				value: "priority1"
			}, {
				value: "priority2"
			}]
		});
		this.oDataManager.readPriorityList();
		assert.deepEqual(this.oComponent.getModel("SettingList").getProperty("/PriorityList"), [{
			value: "priority1"
		}, {
			value: "priority2"
		}]);
	});

	QUnit.test("Should see message 'Service error' when priority service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "read").yieldsTo("error", "Service error");
		this.oDataManager.readPriorityList().catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});

	QUnit.test("Should not see service team list when there is no service team list in MCC default settings", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: []
		});
		this.oDataManager.readServiceTeamList();
		assert.deepEqual(this.oComponent.getModel("SettingList").getProperty("/RegionList"), []);
	});

	QUnit.test("Should see 1 service team item when there is 1 service team item in MCC default settings", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				value1: 123456,
				value2: "ABC",
				value3: "Name"
			}]
		});
		this.oDataManager.readServiceTeamList();
		assert.deepEqual(this.oComponent.getModel("SettingList").getProperty("/RegionList"), [{
			Region: "ABC",
			Topic: [{
				"name": "Name",
				"service_team_id": 123456
			}]
		}]);
	});

	QUnit.test("Should see message 'Service error' when service team service is not available", function(assert) {
		var oStubMsg = this.stub(sap.m.MessageToast, "show");
		this.stub(ODataModel.prototype, "read").yieldsTo("error", "Service error");
		this.oDataManager.readServiceTeamList();
		assert.strictEqual(oStubMsg.callCount, 1);
	});

	QUnit.test("Should see user name when current user has authorization in I7*", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				Attribute: "USERNAME",
				Value: "user"
			}]
		});
		this.oDataManager.readUserProfileData();
		assert.strictEqual(this.oComponent.sUser, "user");
	});
	

	QUnit.test("Should see message 'No authorization in I7*' when current user doesn't have authorization in I7*", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: []
		});
		this.oDataManager.readUserProfileData().catch(function(error) {
			assert.strictEqual(error, "No authorization in I7*");
			done();
		}.bind(this));
	});

	QUnit.test("Should see message 'Service error' when user profile service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "read").yieldsTo("error", "Service error");
		this.oDataManager.readUserProfileData().catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});
	
	QUnit.test("Should see push notification on when current user has set 'NEED_MCC_PUSHNOTIFICATION' to 'YES'", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				Attribute: "USERNAME",
				Value: "user"
			}, {
				Attribute: "NEED_MCC_PUSHNOTIFICATION",
				Value: "YES"
			}]
		});
		this.oDataManager.readUserProfileData();
		assert.strictEqual(this.oComponent.getModel("NeedPushNotif").getProperty("/result"), true);
	});
	
	QUnit.test("Should see push notification off when current user has set 'NEED_MCC_PUSHNOTIFICATION' to 'NO'", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				Attribute: "USERNAME",
				Value: "user"
			}, {
				Attribute: "NEED_MCC_PUSHNOTIFICATION",
				Value: "NO"
			}]
		});
		this.oDataManager.readUserProfileData();
		assert.strictEqual(this.oComponent.getModel("NeedPushNotif").getProperty("/result"), false);
	});
	
	QUnit.test("Should see push notification off when current user has set 'NEED_MCC_PUSHNOTIFICATION' to other value", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				Attribute: "USERNAME",
				Value: "user"
			}, {
				Attribute: "NEED_MCC_PUSHNOTIFICATION",
				Value: "TEST"
			}]
		});
		this.oDataManager.readUserProfileData();
		assert.strictEqual(this.oComponent.getModel("NeedPushNotif").getProperty("/result"), false);
	});
	
	QUnit.test("Should see default category 'TEST' when current user has set 'APP_MCC_ACTIVITIES_DEFAULT_CATEG' to 'TEST'", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				Attribute: "USERNAME",
				Value: "user"
			}, {
				Attribute: "APP_MCC_ACTIVITIES_DEFAULT_CATEG",
				Value: "TEST"
			}]
		});
		this.oDataManager.readUserProfileData();
		assert.strictEqual(this.oComponent.getModel("DefaultCategory").getProperty("/result"), "TEST");
	});
	

	/*QUnit.test("Should get no activity id when current user has no relevant activities", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: []
		});
		this.oDataManager.readMyAct();
		assert.deepEqual(this.oComponent.getModel("MyActivity").getProperty("/data"), []);
	});

	QUnit.test("Should get 1 corresponding activity id when current user has 1 relevant activity", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				key: "456",
				value1: "1",
				value3: "3"
			}]
		});
		this.oDataManager.readMyAct();
		assert.deepEqual(this.oComponent.getModel("MyActivity").getProperty("/data"), ["456"]);
	});

	QUnit.test("Should get 2 corresponding activity ids when current user has 2 relevant activities", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				key: "000",
				value1: "value1"
			}, {
				key: "123",
				value2: "value2"
			}]
		});
		this.oDataManager.readMyAct();
		assert.deepEqual(this.oComponent.getModel("MyActivity").getProperty("/data"), ["000", "123"]);
	});

	QUnit.test("Should see message 'Service error' when my activity service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "read").yieldsTo("error", "Service error");
		this.oDataManager.readMyAct().catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});*/

	QUnit.test("Should get no activity detail when current user has no assigned activity", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: []
		});
		this.oDataManager.readAssignedAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/Assigned"), []);
	});

	QUnit.test("Should get 1 activity detail when current user has 1 assigned activity in total 1", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				activityId: "12345",
				activity_person_user_id: "user"
			}]
		});
		this.oComponent.sUser = "user";
		this.oDataManager.readAssignedAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/Assigned"), [{
			activityId: "12345",
			activity_person_user_id: "user"
		}]);
	});

	QUnit.test("Should get 2 activity detail when current user has 2 assigned activities in total 3", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				activityId: "12345",
				activity_person_user_id: "user"
			}, {
				activityId: "67890",
				activity_person_user_id: "user1"
			}, {
				activityId: "02468",
				activity_person_user_id: "user"
			}]
		});
		this.oComponent.sUser = "user";
		this.oDataManager.readAssignedAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/Assigned"), [{
			activityId: "12345",
			activity_person_user_id: "user"
		}, {
			activityId: "02468",
			activity_person_user_id: "user"
		}]);
	});

	QUnit.test("Should see message 'Service error' when activity detail service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "read").yieldsTo("error", "Service error");
		this.oDataManager.readAssignedAct().catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});

	QUnit.test("Should get no activity detail when current user has no activity created by himself", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: []
		});
		this.oDataManager.readCreByMeAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/CreatedByMe"), []);
	});

	QUnit.test("Should get 1 activity detail when current user has 1 activity created by himself", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				activityId: "12345"
			}]
		});
		this.oDataManager.readCreByMeAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/CreatedByMe"), [{
			activityId: "12345"
		}]);
	});

	QUnit.test("Should get 2 activity detail when current user has 2 activities created by himself", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				activityId: "12345"
			}, {
				activityId: "67890"
			}]
		});
		this.oDataManager.readCreByMeAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/CreatedByMe"), [{
			activityId: "12345"
		}, {
			activityId: "67890"
		}]);
	});

	QUnit.test("Should see message 'Service error' when activity 'creadted by me' service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "read").yieldsTo("error", "Service error");
		this.oDataManager.readCreByMeAct().catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});

	QUnit.test("Should get no activity detail when current user has no favorite activity", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: []
		});
		this.oDataManager.readFavoriteAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/Favorites"), []);
	});

	QUnit.test("Should get 1 activity detail when current user has 1 favorite activity", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				activityId: "12345"
			}]
		});
		this.oDataManager.readFavoriteAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/Favorites"), [{
			activityId: "12345"
		}]);
	});

	QUnit.test("Should get 2 activity detail when current user has 2 favorite activities", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				activityId: "12345"
			}, {
				activityId: "67890"
			}]
		});
		this.oDataManager.readFavoriteAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/Favorites"), [{
			activityId: "12345"
		}, {
			activityId: "67890"
		}]);
	});

	QUnit.test("Should see message 'Service error' when favorite activity service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "read").yieldsTo("error", "Service error");
		this.oDataManager.readFavoriteAct().catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});

	QUnit.test("Should get no activity detail when current user has no favorite customer activity", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: []
		});
		this.oDataManager.readFavoriteCustomerAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/ForMyFavoriteCustomers"), []);
	});

	QUnit.test("Should get 1 activity detail when current user has 1 favorite customer activity", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				activityId: "12345"
			}]
		});
		this.oDataManager.readFavoriteCustomerAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/ForMyFavoriteCustomers"), [{
			activityId: "12345"
		}]);
	});

	QUnit.test("Should get 2 activity detail when current user has 2 favorite customer activities", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				activityId: "12345"
			}, {
				activityId: "67890"
			}]
		});
		this.oDataManager.readFavoriteCustomerAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/ForMyFavoriteCustomers"), [{
			activityId: "12345"
		}, {
			activityId: "67890"
		}]);
	});

	QUnit.test("Should see message 'Service error' when favorite customer activity service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "read").yieldsTo("error", "Service error");
		this.oDataManager.readFavoriteCustomerAct().catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});

	QUnit.test("Should get no activity detail when current user has no selected service team activity", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: []
		});
		this.oDataManager.readServiceTeamAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/ServiceTeam"), []);
	});

	QUnit.test("Should get 1 activity detail when current user has 1 selected service team activity", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				activityId: "12345"
			}]
		});
		this.oDataManager.readServiceTeamAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/ServiceTeam"), [{
			activityId: "12345"
		}]);
	});

	QUnit.test("Should get 2 activity detail when current user has 2 selected service team activities", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {
			results: [{
				activityId: "12345"
			}, {
				activityId: "67890"
			}]
		});
		this.oDataManager.readServiceTeamAct();
		assert.deepEqual(this.oComponent.getModel("ListActivity").getProperty("/ServiceTeam"), [{
			activityId: "12345"
		}, {
			activityId: "67890"
		}]);
	});

	QUnit.test("Should see message 'Service error' when selected service team activity service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "read").yieldsTo("error", "Service error");
		this.oDataManager.readServiceTeamAct().catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});
	
	QUnit.test("Should update need push notification flag when triggering 'updateNeedPushNotification'", function(assert) {
		var oStubUpdate = this.stub(ODataModel.prototype, "update");
		this.oDataManager.updateNeedPushNotification();
		assert.strictEqual(oStubUpdate.callCount, 1);
	});
	
	QUnit.test("Should update user profile attribute when triggering 'updateUserProfileAttribute'", function(assert) {
		var oStubUpdate = this.stub(ODataModel.prototype, "update");
		this.oDataManager.updateUserProfileAttribute();
		assert.strictEqual(oStubUpdate.callCount, 1);
	});
	
	QUnit.test("Should get no notification messages item when return data is not valid", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", undefined);
		this.oDataManager.readNotificationMsg();
		assert.deepEqual(this.oComponent.getModel("NotificationMsg").getProperty("/Messages"), []);
	});
	
	QUnit.test("Should get no notification messages item when results of return data is not valid", function(assert) {
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {});
		this.oDataManager.readNotificationMsg();
		assert.deepEqual(this.oComponent.getModel("NotificationMsg").getProperty("/Messages"), []);
	});
	
	QUnit.test("Should get the same notification message items when results of return data is valid", function(assert) {
		var aData = ["item1", "item2", "item3"];
		this.stub(ODataModel.prototype, "read").yieldsTo("success", { results: aData });
		this.oDataManager.readNotificationMsg();
		assert.deepEqual(this.oComponent.getModel("NotificationMsg").getProperty("/Messages"), aData);
	});
	
	QUnit.test("Should run callback function when results of return data is valid and there is a function input", function(assert) {
		var fCallback = function() {
			sap.m.MessageToast.show("Callback function is called.");
		};
		this.stub(ODataModel.prototype, "read").yieldsTo("success", {});
		var oStubShow = this.stub(sap.m.MessageToast, "show");
		this.oDataManager.readNotificationMsg(fCallback);
		assert.strictEqual(oStubShow.callCount, 1);
	});
	
	QUnit.test("Should not update notification message when message key is not valid", function(assert) {
		var oStubUpdate = this.stub(ODataModel.prototype, "update");
		this.oDataManager.updateNotificationMsg(undefined);
		assert.strictEqual(oStubUpdate.callCount, 0);
	});
	
	QUnit.test("Should update notification message and read them again when message key is valid and service is available", function(assert) {
		var oStubUpdate = this.stub(ODataModel.prototype, "update").yieldsTo("success");
		var oStubRead = this.stub(this.oDataManager, "readNotificationMsg");
		this.oDataManager.updateNotificationMsg("123456");
		assert.strictEqual(oStubUpdate.callCount, 1);
		assert.strictEqual(oStubRead.callCount, 1);
	});
	
	QUnit.test("Should not remove notification message when message key is not valid", function(assert) {
		var oStubRemove = this.stub(ODataModel.prototype, "remove");
		this.oDataManager.removeNotificationMsg(undefined);
		assert.strictEqual(oStubRemove.callCount, 0);
	});
	
	QUnit.test("Should remove notification message and read them again when message key is valid and service is available", function(assert) {
		var oStubRemove = this.stub(ODataModel.prototype, "remove").yieldsTo("success");
		var oStubRead = this.stub(this.oDataManager, "readNotificationMsg");
		this.oDataManager.removeNotificationMsg("123456");
		assert.strictEqual(oStubRemove.callCount, 1);
		assert.strictEqual(oStubRead.callCount, 1);
	});
	
	QUnit.module("model - DataManager: Tests for settings list model", {
		beforeEach: function() {
			Component.extend("test.MockComponent", {
				//oAuth: {auth: false},
				sUser: ""
			});
			this.oComponent = new test.MockComponent();
			sinon.stub(DataManager.prototype, "loadData");
			sinon.stub(models, "setSearchString");
			this.oDataManager = new DataManager(this.oComponent);
		},

		afterEach: function() {
			DataManager.prototype.loadData.restore();
			models.setSearchString.restore();
		}
	});
	
	QUnit.test("Should not create new category item when category list is not valid", function(assert) {
		this.stub(ODataModel.prototype, "remove").yieldsTo("success");
		var oStubCreate = this.stub(ODataModel.prototype, "create");
		this.oDataManager.saveCategoryFilter();
		assert.strictEqual(oStubCreate.callCount, 0);
	});
	
	QUnit.test("Should not create new category item when category list is empty", function(assert) {
		this.stub(ODataModel.prototype, "remove").yieldsTo("success");
		var oStubCreate = this.stub(ODataModel.prototype, "create");
		this.oDataManager.saveCategoryFilter([]);
		assert.strictEqual(oStubCreate.callCount, 0);
	});
	
	QUnit.test("Should create 1 new category item when category list has 1 item", function(assert) {
		this.stub(ODataModel.prototype, "remove").yieldsTo("success");
		var oStubCreate = this.stub(ODataModel.prototype, "create");
		var oStubGroups = this.stub(ODataModel.prototype, "setDeferredGroups");
		var oStubSubmit = this.stub(ODataModel.prototype, "submitChanges").yieldsTo("success");
		this.oDataManager.saveCategoryFilter(["item1"]);
		assert.strictEqual(oStubCreate.callCount, 1);
		assert.strictEqual(oStubGroups.callCount, 1);
		assert.strictEqual(oStubSubmit.callCount, 1);
	});
	
	QUnit.test("Should create 2 new category items when category list has 2 items", function(assert) {
		this.stub(ODataModel.prototype, "remove").yieldsTo("success");
		var oStubCreate = this.stub(ODataModel.prototype, "create");
		var oStubGroups = this.stub(ODataModel.prototype, "setDeferredGroups");
		var oStubSubmit = this.stub(ODataModel.prototype, "submitChanges").yieldsTo("success");
		this.oDataManager.saveCategoryFilter(["item1", "item2"]);
		assert.strictEqual(oStubCreate.callCount, 2);
		assert.strictEqual(oStubGroups.callCount, 1);
		assert.strictEqual(oStubSubmit.callCount, 1);
	});
	
	QUnit.test("Should see message 'Service error' when create category service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "remove").yieldsTo("success");
		this.stub(ODataModel.prototype, "create");
		this.stub(ODataModel.prototype, "setDeferredGroups");
		this.stub(ODataModel.prototype, "submitChanges").yieldsTo("error", "Service error");
		this.oDataManager.saveCategoryFilter(["item1"]).catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});
	
	QUnit.test("Should see message 'Service error' when delete category service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "remove").yieldsTo("error", "Service error");
		this.oDataManager.saveCategoryFilter(["item1"]).catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});
	
	QUnit.test("Should not create new status item when status list is not valid", function(assert) {
		this.stub(ODataModel.prototype, "remove").yieldsTo("success");
		var oStubCreate = this.stub(ODataModel.prototype, "create");
		this.oDataManager.saveStatusFilter();
		assert.strictEqual(oStubCreate.callCount, 0);
	});
	
	QUnit.test("Should not create new status item when status list is empty", function(assert) {
		this.stub(ODataModel.prototype, "remove").yieldsTo("success");
		var oStubCreate = this.stub(ODataModel.prototype, "create");
		this.oDataManager.saveStatusFilter([]);
		assert.strictEqual(oStubCreate.callCount, 0);
	});
	
	QUnit.test("Should create 1 new status item when status list has 1 item", function(assert) {
		this.stub(ODataModel.prototype, "remove").yieldsTo("success");
		var oStubCreate = this.stub(ODataModel.prototype, "create");
		var oStubGroups = this.stub(ODataModel.prototype, "setDeferredGroups");
		var oStubSubmit = this.stub(ODataModel.prototype, "submitChanges").yieldsTo("success");
		this.oDataManager.saveStatusFilter(["item1"]);
		assert.strictEqual(oStubCreate.callCount, 1);
		assert.strictEqual(oStubGroups.callCount, 1);
		assert.strictEqual(oStubSubmit.callCount, 1);
	});
	
	QUnit.test("Should create 2 new status items when status list has 2 items", function(assert) {
		this.stub(ODataModel.prototype, "remove").yieldsTo("success");
		var oStubCreate = this.stub(ODataModel.prototype, "create");
		var oStubGroups = this.stub(ODataModel.prototype, "setDeferredGroups");
		var oStubSubmit = this.stub(ODataModel.prototype, "submitChanges").yieldsTo("success");
		this.oDataManager.saveStatusFilter(["item1", "item2"]);
		assert.strictEqual(oStubCreate.callCount, 2);
		assert.strictEqual(oStubGroups.callCount, 1);
		assert.strictEqual(oStubSubmit.callCount, 1);
	});
	
	QUnit.test("Should see message 'Service error' when create status service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "remove").yieldsTo("success");
		this.stub(ODataModel.prototype, "create");
		this.stub(ODataModel.prototype, "setDeferredGroups");
		this.stub(ODataModel.prototype, "submitChanges").yieldsTo("error", "Service error");
		this.oDataManager.saveStatusFilter(["item1"]).catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});
	
	QUnit.test("Should see message 'Service error' when delete status service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "remove").yieldsTo("error", "Service error");
		this.oDataManager.saveStatusFilter(["item1"]).catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});
	
	QUnit.test("Should not create new status item when status list is not valid", function(assert) {
		var oStubCreate = this.stub(ODataModel.prototype, "create");
		this.oDataManager.saveVisibleList();
		assert.strictEqual(oStubCreate.callCount, 0);
	});
	
	QUnit.test("Should not create new status item when status list is empty", function(assert) {
		var oStubCreate = this.stub(ODataModel.prototype, "create");
		this.oDataManager.saveVisibleList([]);
		assert.strictEqual(oStubCreate.callCount, 0);
	});
	
	QUnit.test("Should create 1 new status item when status list has 1 item", function(assert) {
		var oStubCreate = this.stub(ODataModel.prototype, "create");
		var oStubGroups = this.stub(ODataModel.prototype, "setDeferredGroups");
		var oStubSubmit = this.stub(ODataModel.prototype, "submitChanges").yieldsTo("success");
		this.oDataManager.saveVisibleList(["item1"]);
		assert.strictEqual(oStubCreate.callCount, 1);
		assert.strictEqual(oStubGroups.callCount, 1);
		assert.strictEqual(oStubSubmit.callCount, 1);
	});
	
	QUnit.test("Should create 2 new status items when status list has 2 items", function(assert) {
		var oStubCreate = this.stub(ODataModel.prototype, "create");
		var oStubGroups = this.stub(ODataModel.prototype, "setDeferredGroups");
		var oStubSubmit = this.stub(ODataModel.prototype, "submitChanges").yieldsTo("success");
		this.oDataManager.saveVisibleList(["item1", "item2"]);
		assert.strictEqual(oStubCreate.callCount, 2);
		assert.strictEqual(oStubGroups.callCount, 1);
		assert.strictEqual(oStubSubmit.callCount, 1);
	});
	
	QUnit.test("Should remove all visible list when triggering 'removeVisibleList'", function(assert) {
		var oStubRemove = this.stub(ODataModel.prototype, "remove").yieldsTo("success");
		this.oDataManager.removeVisibleList();
		assert.strictEqual(oStubRemove.callCount, 1);
	});
	
	QUnit.test("Should see message 'Service error' when delete status service is not available", function(assert) {
		var done = assert.async();
		this.stub(ODataModel.prototype, "remove").yieldsTo("error", "Service error");
		this.oDataManager.removeVisibleList().catch(function(error) {
			assert.strictEqual(error, "Service error");
			done();
		}.bind(this));
	});

	QUnit.module("model - DataManager: Tests for help functions", {
		beforeEach: function() {
			this.oComponent = new Component();
			sinon.stub(DataManager.prototype, "loadData");
			this.oDataManager = new DataManager(this.oComponent);
		},

		afterEach: function() {
			DataManager.prototype.loadData.restore();
		}
	});

	QUnit.test("Should see a message toast when entity 'APP_MCC_ACTIVITIES_VISIBLE_LISTS' of user profile model is not available", function(
		assert) {
		var oStub = this.stub(sap.m.MessageToast, "show");
		this.oDataManager._visibleListRace();
		assert.strictEqual(oStub.callCount, 1);
	});

	QUnit.test("Should see a message toast when current user has no visible list", function(assert) {
		var oStubMsg = this.stub(sap.m.MessageToast, "show");
		this.oComponent.getModel("UserProfile").setProperty("/APP_MCC_ACTIVITIES_VISIBLE_LISTS", []);
		this.oDataManager._visibleListRace();
		assert.strictEqual(oStubMsg.callCount, 1);
	});
	
	QUnit.test("Should reload visible activity list when triggering function 'loadActivitiesList'", function(assert) {
		var oStubFn = this.stub(this.oDataManager, "_visibleListRace");
		this.oDataManager.loadActivitiesList();
		assert.strictEqual(oStubFn.callCount, 1);
	});
	
	QUnit.test("Should reload assigned activity list when load single list with 'Assigned'", function(assert) {
		var oStubFn = this.stub(this.oDataManager, "readAssignedAct");
		this.oDataManager.loadSingleList("Assigned");
		assert.strictEqual(oStubFn.callCount, 1);
	});
	
	QUnit.test("Should reload my activity list when load single list with 'CreatedByMe'", function(assert) {
		var oStubFn = this.stub(this.oDataManager, "readCreByMeAct");
		this.oDataManager.loadSingleList("CreatedByMe");
		assert.strictEqual(oStubFn.callCount, 1);
	});
	
	QUnit.test("Should reload favorite activity list when load single list with 'Favorites'", function(assert) {
		var oStubFn = this.stub(this.oDataManager, "readFavoriteAct");
		this.oDataManager.loadSingleList("Favorites");
		assert.strictEqual(oStubFn.callCount, 1);
	});
	
	QUnit.test("Should reload favorite customers activity list when load single list with 'ForMyFavoriteCustomers'", function(assert) {
		var oStubFn = this.stub(this.oDataManager, "readFavoriteCustomerAct");
		this.oDataManager.loadSingleList("ForMyFavoriteCustomers");
		assert.strictEqual(oStubFn.callCount, 1);
	});
	
	QUnit.test("Should reload selected service team activity list when load single list with 'ServiceTeam'", function(assert) {
		var oStubFn = this.stub(this.oDataManager, "readServiceTeamAct");
		this.oDataManager.loadSingleList("ServiceTeam");
		assert.strictEqual(oStubFn.callCount, 1);
	});
	
	QUnit.test("Should read no activity data when visible list model is 'undefined'", function(assert) {
		var oStubResolve = this.stub(this.oDataManager, "resolvePromise");
		this.oComponent.getModel("VisibleList").setData(undefined);
		this.oDataManager._visibleListRace();
		assert.strictEqual(oStubResolve.callCount, 1);
	});
	
	QUnit.test("Should read no activity data when visible list data is empty", function(assert) {
		var oStubResolve = this.stub(this.oDataManager, "resolvePromise");
		this.oDataManager._visibleListRace();
		assert.strictEqual(oStubResolve.callCount, 1);
	});
	
	QUnit.test("Should read assigned activity data when only assigned list is visible", function(assert) {
		var oStubRace = this.stub(Promise, "race");
		var oStubAssigned = this.stub(this.oDataManager, "readAssignedAct").returns("Assigned");
		this.oComponent.getModel("VisibleList").setData({Assigned: {visible: true}});
		this.oDataManager._visibleListRace();
		assert.strictEqual(oStubAssigned.callCount, 1);
		assert.strictEqual(oStubRace.withArgs(["Assigned"]).called, true);
	});
	
	QUnit.test("Should read created by me activity data when assigned list isn't visible and created by me list is visible", function(assert) {
		var oStubRace = this.stub(Promise, "race");
		var oStubAssigned = this.stub(this.oDataManager, "readAssignedAct").returns("Assigned");
		var oStubCreatedByMe = this.stub(this.oDataManager, "readCreByMeAct").returns("CreatedByMe");
		this.oComponent.getModel("VisibleList").setData({Assigned: {visible: false}, CreatedByMe: {visible: true}});
		this.oDataManager._visibleListRace();
		assert.strictEqual(oStubAssigned.callCount, 0);
		assert.strictEqual(oStubCreatedByMe.callCount, 1);
		assert.strictEqual(oStubRace.withArgs(["CreatedByMe"]).called, true);
	});
	
	QUnit.test("Should read activity data when relevant list is visible", function(assert) {
		var oStubRace = this.stub(Promise, "race");
		var oStubAssigned = this.stub(this.oDataManager, "readAssignedAct").returns("Assigned");
		var oStubCreatedByMe = this.stub(this.oDataManager, "readCreByMeAct").returns("CreatedByMe");
		var oStubFavorites = this.stub(this.oDataManager, "readFavoriteAct").returns("Favorites");
		var oStubForMyFavoriteCustomers = this.stub(this.oDataManager, "readFavoriteCustomerAct").returns("ForMyFavoriteCustomers");
		var oStubServiceTeam = this.stub(this.oDataManager, "readServiceTeamAct").returns("ServiceTeam");
		this.oComponent.getModel("VisibleList").setData({Assigned: {visible: true}, CreatedByMe: {visible: false}, Favorites: {visible: true}, ForMyFavoriteCustomers: {visible: true}, ServiceTeam: {visible: true}});
		this.oDataManager._visibleListRace();
		assert.strictEqual(oStubAssigned.callCount, 1);
		assert.strictEqual(oStubCreatedByMe.callCount, 0);
		assert.strictEqual(oStubFavorites.callCount, 1);
		assert.strictEqual(oStubForMyFavoriteCustomers.callCount, 1);
		assert.strictEqual(oStubServiceTeam.callCount, 1);
		assert.strictEqual(oStubRace.withArgs(["Assigned", "Favorites", "ForMyFavoriteCustomers", "ServiceTeam"]).called, true);
	});
	
	QUnit.test("Should read created by me activity data when assigned list couldn't be recognized", function(assert) {
		var oStubRace = this.stub(Promise, "race");
		var oStubCreatedByMe = this.stub(this.oDataManager, "readCreByMeAct").returns("CreatedByMe");
		this.oComponent.getModel("VisibleList").setData({Test: {visible: true}});
		this.oDataManager._visibleListRace();
		assert.strictEqual(oStubCreatedByMe.callCount, 1);
		assert.strictEqual(oStubRace.withArgs(["CreatedByMe"]).called, true);
	});

});