sap.ui.define([
	"sap/support/mccactivities/model/models",
	"sap/ui/thirdparty/sinon",
	"sap/ui/thirdparty/sinon-qunit"
], function(models) {
	"use strict";
	QUnit.module("model - models: Test cases for models functions");

	QUnit.test("Should get 'OneWay' binding mode when creating a device model", function(assert) {
		assert.strictEqual(models.createDeviceModel().getDefaultBindingMode(), "OneWay");
	});

	QUnit.test("Should get correct parameters when creating an oData model", function(assert) {
		var oDataModel = models.createNewODataModel("a/b/c", false);
		assert.strictEqual(oDataModel.sDefaultUpdateMethod, "MERGE");
		assert.strictEqual(oDataModel.sServiceUrl, "a/b/c");
	});

	QUnit.test("Should get 'OneWay' binding mode when creating an 'OneWay' JSON model", function(assert) {
		assert.strictEqual(models.createNewJSONModel("OneWay").getDefaultBindingMode(), "OneWay");
	});

	QUnit.test("Should return an empty object when type group content is not an array", function(assert) {
		assert.deepEqual(models.handleGroupData(undefined), {});
	});

	QUnit.test("Should return correct object when group content has one series attribute", function(assert) {
		assert.deepEqual(models.handleGroupData([{
			Field: "1",
			Attribute: "attr1"
		}]), {
			attr1: [{
				Field: "1",
				Attribute: "attr1"
			}]
		});
	});

	QUnit.test("Should return correct object when group content has one individual attribute", function(assert) {
		assert.deepEqual(models.handleGroupData([{
			Field: "",
			Attribute: "attr1"
		}]), {
			attr1: {
				Field: "",
				Attribute: "attr1"
			}
		});
	});

	QUnit.test("Should return correct object when group content has two series attributes and two individual attributes", function(assert) {
		var aGroup = [{
			Field: "1",
			Attribute: "attr1",
			Value: "1"
		}, {
			Field: "2",
			Attribute: "attr1",
			Value: "2"
		}, {
			Field: "",
			Attribute: "attr2",
			Value: "A"
		}, {
			Field: "",
			Attribute: "attr3",
			Value: "B"
		}];
		var oExp = {
			attr1: [{
				Field: "1",
				Attribute: "attr1",
				Value: "1"
			}, {
				Field: "2",
				Attribute: "attr1",
				Value: "2"
			}],
			attr2: {
				Field: "",
				Attribute: "attr2",
				Value: "A"
			},
			attr3: {
				Field: "",
				Attribute: "attr3",
				Value: "B"
			}
		};
		assert.deepEqual(models.handleGroupData(aGroup), oExp);
	});

	QUnit.test("Should return 'undefined' when default visible list is 'undefined'", function(assert) {
		assert.strictEqual(models.setVisibleListData(undefined, []), undefined);
	});

	QUnit.test("Should be visible when default visible list matches user's settings", function(assert) {
		assert.deepEqual(models.setVisibleListData({
			attr1: {
				visible: false
			}
		}, [{
			Value: "attr1"
		}]), {
			attr1: {
				visible: true
			}
		});
	});

	QUnit.test("Should not be visible when default visible list mis-matches user's settings", function(assert) {
		assert.deepEqual(models.setVisibleListData({
			attr1: {
				visible: false
			}
		}, [{
			Value: "attr2"
		}]), {
			attr1: {
				visible: false
			}
		});
	});

	QUnit.test("Should be partial visible when default visible list matches partial user's settings", function(assert) {
		assert.deepEqual(models.setVisibleListData({
			attr1: {
				visible: false
			},
			attr2: {
				visible: false
			}
		}, [{
			Value: "attr2"
		}, {
			Value: "attr3"
		}]), {
			attr1: {
				visible: false
			},
			attr2: {
				visible: true
			}
		});
	});

	QUnit.test("Should return '[]' when filter list and user data is 'undefined'", function(assert) {
		assert.deepEqual(models.setSelectedFilterData(undefined, undefined), []);
	});

	QUnit.test("Should return '[]' when filter list is 'undefined' and user data is valid", function(assert) {
		assert.deepEqual(models.setSelectedFilterData(undefined, [{
			Value: "A"
		}, {
			Value: "B"
		}]), []);
	});

	QUnit.test("Should set 'selected' false to all filter list items when filter list is valide and user data is 'undefined'", function(
		assert) {
		assert.deepEqual(models.setSelectedFilterData([{
			value1: "A"
		}, {
			value1: "B"
		}], undefined), [{
			value1: "A",
			bSelected: false
		}, {
			value1: "B",
			bSelected: false
		}]);
	});

	QUnit.test(
		"Should set 'selected' true to filter list items when match to to user data and set 'selected' false to filter list items when don't match to to user data",
		function(assert) {
			assert.deepEqual(models.setSelectedFilterData([{
				value1: "A"
			}, {
				value1: "B"
			}], [{
				Value: "A"
			}, {
				Value: "C"
			}]), [{
				value1: "A",
				bSelected: true
			}, {
				value1: "B",
				bSelected: false
			}]);
		});

	QUnit.test("Should return an empty array when there is no grouping data", function(assert) {
		assert.deepEqual(models.groupServiceTeam(), []);
	});

	QUnit.test("Should return an empty array when grouping invalid data type of service team list", function(assert) {
		assert.deepEqual(models.groupServiceTeam("test"), []);
	});

	QUnit.test("Should return correct region and 1 topic item when there is 1 service team item", function(assert) {
		assert.deepEqual(models.groupServiceTeam([{
			value1: "123",
			value2: "ABC",
			value3: "Name"
		}]), [{
			Region: "ABC",
			Topic: [{
				name: "Name",
				service_team_id: "123"
			}]
		}]);
	});

	QUnit.test("Should return correct region and 3 topic item when there is 3 service team item", function(assert) {
		var aServiceTeamList = [{
			value1: 123,
			value2: "ABC",
			value3: "Name1"
		}, {
			value1: 456,
			value2: "ABC",
			value3: "Name2"
		}, {
			value1: 789,
			value2: "DEF",
			value3: "Name3"
		}];
		var aExpectList = [{
			"Region": "ABC",
			"Topic": [{
				"name": "Name1",
				"service_team_id": 123
			}, {
				"name": "Name2",
				"service_team_id": 456
			}]
		}, {
			"Region": "DEF",
			"Topic": [{
				"name": "Name3",
				"service_team_id": 789
			}]
		}];
		assert.deepEqual(models.groupServiceTeam(aServiceTeamList), aExpectList);
	});
});