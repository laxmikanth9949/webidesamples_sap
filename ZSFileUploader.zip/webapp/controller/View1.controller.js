/*global XLSX*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/BusyIndicator",
	"sap/m/MessageBox"
], function (Controller,BusyIndicator,MessageBox) {
	"use strict";
	var sResponsivePaddingClasses = "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer";

	return Controller.extend("com.sample.ZSFileUploader.controller.View1", {
		
		onInit: function () {
			this.localModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(this.localModel, "localModel");

		},
		onMessageBox: function(){
		debugger;
		var textLink = new sap.m.Link({
			"text":"<p><strong>This can happen if:</strong></p>",
			"wrapping":true,
			"href":"www.google.com",
			"rel":"www.sap.com",
			"validateUrl":true
		});
		MessageBox.information("Hello World" + " " + textLink ,{
			details: "<p><strong>This can happen if:</strong></p>" +
					"<ul>" +
					"<li>You are not connected to the internet</li>" +
					"<li>a backend component is not <em>available</em></li>" +
					"<li>or an underlying system is down</li>" +
					"</ul>" +
					"<p>Get more help <a href='//www.sap.com' target='_top'>SAP.com</a>.",
				contentWidth: "100px",
				styleClass: sResponsivePaddingClasses
		});
		},
		onUpload: function (e) {
			this._import(e.getParameter("files") && e.getParameter("files")[0]);
		},

		_import: function (file) {
			var that = this;
			var excelData = {};
			if (file && window.FileReader) {
				var reader = new FileReader();
				reader.onload = function (e) {
					var data = e.target.result;
					var workbook = XLSX.read(data, {
						type: 'binary'
					});
					workbook.SheetNames.forEach(function (sheetName) {
						// Here is your object for every sheet in workbook
						excelData = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);

					});
					// Setting the data to the local model 
					that.localModel.setData({
						items: excelData
					});
					that.localModel.refresh(true);
				};
				reader.onerror = function (ex) {
					console.log(ex);
				};
				reader.readAsBinaryString(file);
			}
		}
	});
});