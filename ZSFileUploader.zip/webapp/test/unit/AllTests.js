sap.ui.define([
	"com/sample/ZSFileUploader/test/unit/controller/View1.controller"
], function () {
	"use strict";
});