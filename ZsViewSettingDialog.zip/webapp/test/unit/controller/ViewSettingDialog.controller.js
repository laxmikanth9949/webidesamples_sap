/*global QUnit*/

sap.ui.define([
	"Sample/ZsViewSettingDialog/ZsViewSettingDialog/controller/ViewSettingDialog.controller"
], function (Controller) {
	"use strict";

	QUnit.module("ViewSettingDialog Controller");

	QUnit.test("I should test the ViewSettingDialog controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});