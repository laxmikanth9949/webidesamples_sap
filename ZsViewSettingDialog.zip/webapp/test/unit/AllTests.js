sap.ui.define([
	"Sample/ZsViewSettingDialog/ZsViewSettingDialog/test/unit/controller/ViewSettingDialog.controller"
], function () {
	"use strict";
});