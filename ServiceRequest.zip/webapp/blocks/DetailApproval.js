sap.ui.define(["sap/uxap/BlockBase"], function (BlockBase) {
	return BlockBase.extend("sap.com.servicerequest.servicerequest.blocks.view.DetailApproval", {
		metadata: {}
	});
}, true);