sap.ui.define(["sap/com/servicerequest/servicerequest/controller/BaseController",
	"../../model/formatter",
	"sap/m/MessageBox",
	"../../controller/utilities",
	"sap/ui/model/Filter",
	"sap/ui/core/routing/History",
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/Text",
	"sap/m/Input",
	"sap/ui/core/Fragment",
	"sap/ui/model/Sorter",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/com/servicerequest/servicerequest/model/models"
], function (BaseController, formatter, MessageBox, Utilities, Filter, History, Button, Dialog, Text, Input, Fragment, Sorter,
	MessageToast,
	JSONModel, models) {
	"use strict";

	return BaseController.extend("sap.com.servicerequest.servicerequest.controller.Detail", {
		formatter: formatter,
		is_onReadSuccess_Excecuted: false,
		onInit: function () {
			//console.log("Inside DetailRequest OnInit");
			var timeLineControl = new JSONModel({
				count: 0
			});
			this.getView().setModel(timeLineControl, "timeLineControl");
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.subscribe("DetailRequest", "DetailRequestReadSuccess", this.onReadSuccess, this);
			oEventBus.subscribe("setServiceRequestScope", "setServiceRequestScopeSuccess", this.setServiceRequestScopeSuccess, this);
			oEventBus.subscribe("setFocusForCustContact", "setFocusForCustContactSuccess", this.setFocusForCustContact, this);
			oEventBus.subscribe("setFocusForSRInfo", "setFocusForSRInfoSuccess", this.setFocusForSRInfo, this);
			oEventBus.subscribe("setFocusForSurveyRecipient", "setFocusForSurveyRecipientSuccess", this.setFocusForSurveyRecipient, this);
			if (!this.is_onReadSuccess_Excecuted && this.getModel("servicerequestModel") && this.getModel("servicerequestModel").getProperty(
					"/ServiceRequestID")) {
				this.onReadSuccess();
			}
		},
		setFocusForCustContact: function () {
			models.setElementScroll(this, "srs_customerContact-input");
		},
		setFocusForSRInfo: function () {
			models.setElementScroll(this, "panelSRInfo");
		},
		setFocusForSurveyRecipient: function () {
			models.setElementScroll(this, "idSurveyRecipient");
		},
		onExit: function () {
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.unsubscribe("DetailRequest", "DetailRequestReadSuccess", this.onReadSuccess, this);
			oEventBus.unsubscribe("setServiceRequestScope", "setServiceRequestScopeSuccess", this.setServiceRequestScopeSuccess, this);
			oEventBus.unsubscribe("setFocusForCustContact", "setFocusForCustContactSuccess", this.setFocusForCustContact, this);
			oEventBus.unsubscribe("setFocusForSRInfo", "setFocusForSRInfoSuccess", this.setFocusForSRInfo, this);
			oEventBus.unsubscribe("setFocusForSurveyRecipient", "setFocusForSurveyRecipientSuccess", this.setFocusForSurveyRecipient, this);
		},
		onReadSuccess: function (channel, event, stepId) {
			this.is_onReadSuccess_Excecuted = true;
			//console.log("Inside DetailRequestReadSuccess");

			if (stepId === "ContactID") {
				this.setFocusForCustContact();
			} else if (stepId === "SRInfo") {
				this.setFocusForSRInfo();
			}
			
		},
		serviceRequestScopeChanged: function (oEvent) {
			this.getModel("serviceRequestScopeModel").setProperty("/isServiceRequestInfoChanged", "true");
			/*var value = oEvent.getSource().getValue();
			if(value && value.trim()){
				this.getModel("serviceRequestScopeModel").setProperty("/isServiceRequestInfoChanged", "true");
			}else{
				this.getModel("serviceRequestScopeModel").setProperty("/isServiceRequestInfoChanged", "false");
			}*/
		},
		/*
		setServiceRequestInfoTemplate: function () {
			var userProfile = this.getModel("SRS_Data_UserSet").getData();

			if (userProfile.isTQM && this.byId("sr-req-scope").getValue().trim() === "") {
				var sTemplateValue =
					"#Customer Expectations: \n#Delivery Address: \n#Skills Needed: \n#Previously discussed – COE Contact / Date: \n#Names of Planned Experts (optional):\n#Language / Citizenship Restrictions (optional):";
				this.byId("sr-req-scope").setValue(sTemplateValue);
			}
		},*/

		setTextAreaGrowing: function (oEvent) {
			models.toggleTextAreaGrowing(this, "sr-req-scope", oEvent);
		},

		setServiceRequestScopeSuccess: function () {
			var serviceRequestModel = this.getModel("serviceRequestScopeModel");
			var text = serviceRequestModel.getData().data[0].Text.trim();
			if(text){
				this.byId("sr-req-scope").setValue(text);
			}else{
				var userProfile = this.getModel("SRS_Data_UserSet").getData();
	 			models.setServiceRequestInfoTemplate(userProfile, serviceRequestModel);
			}
		},
		onCaseSearch: function () {
			var oView = this.getView();
			var dialog = oView.byId("CaseDialog");
			if (!dialog) {
				// create dialog via fragment factory
				dialog = sap.ui.xmlfragment(oView.getId(), "sap.com.servicerequest.servicerequest.fragment.CaseSearch", this);
				oView.addDependent(dialog);
			}
			dialog.open();
		},
		onCustomerContactSearch: function () {
			var oView = this.getView();
			var dialog = oView.byId("CustomerContactDialog");
			if (!dialog) {
				// create dialog via fragment factory
				dialog = sap.ui.xmlfragment(oView.getId(), "sap.com.servicerequest.servicerequest.fragment.CustomerContactSearch", this);
				oView.addDependent(dialog);
			}
			dialog.setTitle(this.getResourceBundle().getText("selectCustomerContact"));
			var title = this.getResourceBundle().getText("selectCustomerContact");
			this.byId("customerContactCounts").setText(title + " (0)");
			this.byId("invisibleTxtForDialogCustomerContact").setText("CC");
			dialog.open();
			this.byId("idLinkSurveyRecipientHelp").setVisible(false);
		},
		onPressCustomerContactSearch: function () {
			this.byId("srs_customerContactTable").setBusy(true);

			var sFirstName = this.byId("srs_firstName").getValue();
			var sLastName = this.byId("srs_lastName").getValue();
			var sEmail = this.byId("srs_email").getValue();
			var sCustomerId = this.getModel("servicerequestModel").getData().CustomerID;

			var customerContactModel = new JSONModel({
				caseString: "",
				data: [],
				total: 0,
				page: 0,
				current: 0
			});
			this.setModel(customerContactModel, "customerContactModel");

			var filterArr = [];
			if (sEmail) {
				filterArr.push(models.filterCondition_Contains("EmailAddr", sEmail));
			}

			if (sFirstName) {
				filterArr.push(models.filterCondition_Contains("Firstname", sFirstName));
			}

			if (sLastName) {
				filterArr.push(models.filterCondition_Contains("Lastname", sLastName));
			}

			filterArr.push(models.filterCondition_Equal("HasEmail", true));
		
			if(this.byId("invisibleTxtForDialogCustomerContact").getText()==="SR"){
				filterArr.push(models.filterCondition_Equal("IsSurveyRec", true));
			}
			this.byId("searchBtn").setEnabled(false);
			this.getModel("SRS_Data").read("/CustomerSet(CustomerID='" + sCustomerId + "')/toContacts", {
				filters: [models.filterComparison_AND(filterArr)],
				success: function (oData) {
					this.getModel("customerContactModel").setProperty("/data", oData.results);
					this.getModel("customerContactModel").setProperty("/total", oData.results.length);
					
					var title = this.getResourceBundle().getText("selectCustomerContact");
					if(this.byId("invisibleTxtForDialogCustomerContact").getText()==="SR"){
						title = this.getResourceBundle().getText("txtSurveyRcpts");
					}
					this.byId("customerContactCounts").setText(title + " ("+oData.results.length+")");
					
					this.byId("srs_customerContactTable").setBusy(false);
					this.byId("searchBtn").setEnabled(true);
				}.bind(this)
			});

		},
		onCloseCustomerContactSearch: function (oEvent) {
			if (oEvent.getSource().getId().indexOf("cancel") === -1) {
				var oSelectedItem = this.byId("srs_customerContactTable").getSelectedItem();
				if (oSelectedItem) {
					var oSelectedCase = oSelectedItem.getBindingContext("customerContactModel").getObject();

					if(this.byId("invisibleTxtForDialogCustomerContact").getText()==="CC"){
						if (oSelectedCase.Name) {
							this.byId("srs_customerContact-input").setValue(oSelectedCase.Name);
						} else {
							this.byId("srs_customerContact-input").setValue(oSelectedCase.Firstname + " " + oSelectedCase.Lastname);
						}
						this.getModel("servicerequestModel").getData().ContactID = oSelectedCase.ContactID;
						/*
						if(this.getModel("servicerequestModel").getProperty("/FeedbackEnabled") && !this.getModel("servicerequestModel").getProperty("/SurveyRecID")){
							this.setSurveyRecipient(oSelectedCase);
						}*/
						
					}else{
						this.setSurveyRecipient(oSelectedCase);
					}
				} else {
					if(this.byId("invisibleTxtForDialogCustomerContact").getText()==="CC"){
						sap.m.MessageToast.show(this.getResourceBundle().getText("contactEmpty"));
					}else{
						sap.m.MessageToast.show(this.getResourceBundle().getText("txtSREmpty"));
					}
					
					
					return;
				}
			}

			this.byId("srs_firstName").setValue();
			this.byId("srs_lastName").setValue();
			this.byId("srs_email").setValue();
			//reset Case Model and more button
			var customerContactModel = new JSONModel({
				caseString: "",
				data: [],
				total: 0,
				page: 0,
				current: 0
			});
			this.setModel(customerContactModel, "customerContactModel");

			this.byId("CustomerContactDialog").close();
		},
		setSurveyRecipient: function(oSelectedCase){
			if (oSelectedCase.Name) {
				this.byId("idSurveyRecipient").setValue(oSelectedCase.Name);
			} else {
				this.byId("idSurveyRecipient").setValue(oSelectedCase.Firstname + " " + oSelectedCase.Lastname);
			}
			this.getModel("servicerequestModel").getData().SurveyRecID = oSelectedCase.ContactID;
			models.onCreateValidate(this);
		},
		onAfterRendering: function () {
			this.byId("sr-req-scope-TextMode-Edit").setText(this.getResourceBundle().getText("showMore"));
			this.byId("sr-req-scope-TextMode-Edit").setTooltip(this.getResourceBundle().getText("showMore"));
			this.byId("sr-req-scope").setGrowing(false);
			this.byId("sr-req-scope").setRows(5);
		},
		handleValid: function (event) {
			var selectedKey = event.getSource().getSelectedKey();
			if (selectedKey) {
				event.getSource().setValueState("None");
				models.onCreateValidate(this);
			} else {
				event.getSource().setValueState("Error");
				models.onCreateValidate(this);
			}
		},
		isEmpty: function (value) {
			if (value === null || value == "") {
				return true;
			} else {
				return false;
			}
		},
		setGoLiveDate: function (oEvent) {
			this.getModel("servicerequestModel").setProperty("/GoLiveDate", oEvent.getSource().getDateValue());
			models.goLiveDate = oEvent.getSource().getDateValue();
		},
		onSurveyRcpySearch: function(oEvent){
			var oView = this.getView();
			var dialog = oView.byId("CustomerContactDialog");
			if (!dialog) {
				// create dialog via fragment factory
				dialog = sap.ui.xmlfragment(oView.getId(), "sap.com.servicerequest.servicerequest.fragment.CustomerContactSearch", this);
				oView.addDependent(dialog);
			}
			dialog.setTitle(this.getResourceBundle().getText("txtSearchSurveyRecipient"));
			this.byId("invisibleTxtForDialogCustomerContact").setText("SR");
			var title = this.getResourceBundle().getText("txtSurveyRcpts");
			this.byId("customerContactCounts").setText(title + " (0)");
			dialog.open();
			this.byId("idLinkSurveyRecipientHelp").setVisible(true);
			this.onPressCustomerContactSearch();
		},
		onSurveyRcptSwitchChange: function(oEvent){
			models.onCreateValidate(this);
		}
	});
}, true);