sap.ui.define(["sap/com/servicerequest/servicerequest/controller/BaseController",
	"../../model/formatter",
	"sap/m/MessageBox",
	"../../controller/utilities",
	"sap/ui/model/Filter",
	"sap/ui/core/routing/History",
	"sap/m/Button",
	"sap/m/Dialog",
	"sap/m/Text",
	"sap/m/Input",
	"sap/ui/model/Sorter",
	"sap/m/MessageToast",
	"sap/com/servicerequest/servicerequest/model/models",
	"sap/ui/model/json/JSONModel",
	'sap/ui/core/HTML',
	"sap/ui/core/Fragment"
], function (BaseController, formatter, MessageBox, Utilities, Filter, History, Button, Dialog, Text, Input, Sorter, MessageToast, models,
	JSONModel, HTML, Fragment) {
	"use strict";

	return BaseController.extend("sap.com.servicerequest.servicerequest.controller.Detail", {
		formatter: formatter,
		existingItem: null,
		isBatchExecuted: true,
		serviceDialog: false,
		reqDelDate: null,
		isItemsEdited: false,
		item_20_dateTime: null,
		shiftkeyPressed: false,
		is_onReadSuccess_Excecuted: false,
		soldToCustomerId: "",
		onInit: function () {
			//console.log("Inside DetailScope OnInit()");
			var oEventBus = sap.ui.getCore().getEventBus();
			this.setComboBoxContainsFilterScope();
			oEventBus.subscribe("DetailScope", "DetailScopeReadSuccess", this.onReadSuccess, this);
			oEventBus.subscribe("ScopeReset", "ScopeResetSuccess", this.scopeResetSuccess, this);
			oEventBus.subscribe("ScopeTableReset", "ScopeTableResetSuccess", this.scopeTableResetSuccess, this);
			oEventBus.subscribe("createSRItems", "createSRItemsSuccess", this.createSRItemsSuccess, this);
			oEventBus.subscribe("saveSRItems", "saveSRItemsSuccess", this.saveSRItemsSuccess, this);
			oEventBus.subscribe("contractItemValidation", "contractItemValidationSuccess", this.contractItemValidationSuccess, this);
			oEventBus.subscribe("setAgreedScope", "setAgreedScopeSuccess", this.setAgreedScopeSuccess, this);
			oEventBus.subscribe("loadScopeOnSRCopy", "loadScopeOnSRCopySuccess", this.loadScopeOnSRCopySuccess, this);
			oEventBus.subscribe("validateRDDWhenSaveSR", "validateRDDWhenSaveSRSuccess", this.validateRDDWhenSaveSRSuccess, this);
			oEventBus.subscribe("setDefaultReqDelDate", "setReqDelDateSuccess", this.setReqDelDateSuccess, this);
			oEventBus.subscribe("onCaseReset", "onCaseResetSuccess", this.onCaseResetSuccess, this);
			//oEventBus.subscribe("removeEOD", "removeEODSuccess", this.removeEODSuccess, this);
			oEventBus.subscribe("clearDeliveryTeams", "clearDeliveryTeamsSuccess", this.clearDeliveryTeamsSuccess, this);
			oEventBus.subscribe("setItem20_DateTime", "setItem20_DateTimeSuccess", this.setItem20_DateTimeSuccess, this);
			oEventBus.subscribe("setFocusForService", "setFocusForServiceSuccess", this.setFocusForService, this);
			oEventBus.subscribe("setFocusForSession", "setFocusForSessionSuccess", this.setFocusForSession, this);
			oEventBus.subscribe("setFocusForContract", "setFocusForContractSuccess", this.setFocusForContract, this);
			oEventBus.subscribe("setFocusForContractItem", "setFocusForContractItemSuccess", this.setFocusForContractItem, this);
			oEventBus.subscribe("setFocusForRDD", "setFocusForRDDSuccess", this.setFocusForRDD, this);
			oEventBus.subscribe("setFocusForAgreedScope", "setFocusForAgreedScopeSuccess", this.setFocusForAgreedScope, this);
			oEventBus.subscribe("eventSetNewServiceAndSession", "eventSetNewServiceAndSession", this.eventSetNewServiceAndSession, this);
			oEventBus.subscribe("validateSystemDuringCopySR", "validateSystemDuringCopySRSuccess", this.validateSystemDuringCopySRSuccess, this);
			oEventBus.subscribe("setFocusForSystem", "setFocusForSystemSuccess", this.setFocusForSystem, this);
			oEventBus.subscribe("resetSystem", "resetSystemSuccess", this.resetSystem, this);
			oEventBus.subscribe("RequestReset", "RequestResetSuccess", this.reloadSystems, this);
			oEventBus.subscribe("setSystem", "setSystemSuccess", this.setSystemSuccess, this);
			oEventBus.subscribe("OSPSystemSelection", "OSPSystemSelectionSuccess", this.OSPSystemSelection, this);
			oEventBus.subscribe("showOSPSystem", "showOSPSystemSuccess", this.showOSPSystem, this);
			oEventBus.subscribe("setServiceRequestScope", "setServiceRequestScopeSuccess", this.setServiceRequestScopeSuccess, this);
			oEventBus.subscribe("setFocusForCustContact", "setFocusForCustContactSuccess", this.setFocusForCustContact, this);
			oEventBus.subscribe("setFocusForSRInfo", "setFocusForSRInfoSuccess", this.setFocusForSRInfo, this);
			oEventBus.subscribe("setFocusForSurveyRecipient", "setFocusForSurveyRecipientSuccess", this.setFocusForSurveyRecipient, this);
			oEventBus.subscribe("removeCustomerContact", "removeCustomerContactSuccess", this.removeCustomerContact, this);
			oEventBus.subscribe("removeSurevyRecipient", "removeSurevyRecipientSuccess", this.removeSurevyRecipient, this);
			oEventBus.subscribe("setQualificationAndCallOffDaysForSession", "setQualificationAndCallOffDaysForSessionSuccess", this.setQualificationAndCallOffDaysForSession,
				this);

			var timeLineControl = new JSONModel({
				count: 0
			});
			this.getView().setModel(timeLineControl, "timeLineControl");
			if (!this.is_onReadSuccess_Excecuted && this.getModel("servicerequestModel") && this.getModel("servicerequestModel").getProperty(
					"/ServiceRequestID")) {
				this.onReadSuccess();
			}
			this._counteditscopeRow = 0;
		},

		setItem20_DateTimeSuccess: function (channel, event, date) {
			this.item_20_dateTime = date;
		},

		validateRDDWhenSaveSRSuccess: function (channel, event, msgArr) {
			var RDD = this.byId("reqdate-edit").getValue();
			var SRModel = this.getModel("servicerequestModel").getData();
			if (!SRModel.ServiceID && RDD) {
				msgArr.push({
					"msg": this.getResourceBundle().getText("warningRDDContactMsg")
				});
			}
		},

		setReqDelDateSuccess: function () {
			var defaultReqDelDate, minDate = new Date();
			defaultReqDelDate = new Date((new Date()).setDate(minDate.getDate() + models.DEFAULT_DAYS_TO_ADD_FOR_RDD));
			if (defaultReqDelDate.getDay() != 1) {
				defaultReqDelDate = new Date(models.findComingMonday(defaultReqDelDate.toString()));
			}
			this.byId("reqdate-edit").setDateValue(defaultReqDelDate);
			this.byId("reqdate-edit").setEnabled(true);
			this.reqDelDate = defaultReqDelDate;
			models.SRItemsStartDateValidationEditMode(this);
			this.getModel("buttonControlModel").setProperty("/showContractValidationMessageStrip", false);
			this.getModel("SRS_Data_UserSet").setProperty("/AvailableCallOffDays", "0");
			this.getModel("servicerequestModel").setProperty("/TotalCallOffDays", "0");
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.publish("showPotentialLeadTime", "showPotentialLeadTimeSuccess", defaultReqDelDate);
			this.resetSRItemDateMinMaxLimit();
		},

		loadScopeOnSRCopySuccess: function () {
			var serviceRequestModel = this.getModel("servicerequestModel").getData();
			models.existingService = serviceRequestModel.ServiceID;
			models.existingSession = serviceRequestModel.SessionID;
			models.existingSessionProductName = serviceRequestModel.SessionName;
			this.reqDelDate = this.byId("reqdate-edit").getDateValue();

			this.getModel("buttonControlModel").setProperty("/itemAddBtn", true);
			var SRitems = this.getModel("servicerequestItemsModel").getData();
			if (SRitems.length > 0) {
				var contractId = SRitems[0].ContractID;
				var contractIdItem = SRitems[0].ContractItemID;

				var contractSetModel = this.getModel("contractSetModel").getData();
				var contractItemModel = this.getModel("contractItemModel").getData();
				var scopeServiceModel = this.getModel("productSetModel").getData();

				var doesContractExist = false;
				var doesContractItemExist = false;
				var doesServiceExist = false;
				var doesSessionExist = false;

				var context = this;

				for (var i = 0; i < contractSetModel.length; i++) {
					if (contractId === contractSetModel[i].ContractID) {
						doesContractExist = true;
						break;
					}
				}

				for (var i = 0; i < contractItemModel.length; i++) {
					if (contractIdItem === contractItemModel[i].ContractItemID) {
						var callOffDays = serviceRequestModel.TotalCallOffDays;
						models.validateContractItemBasedOnCallOffDays(contractItemModel[i], callOffDays, this, "msgStripContractItemValidation");
						doesContractItemExist = true;
						break;
					}
				}

				for (var i = 0; i < scopeServiceModel.length; i++) {
					if (serviceRequestModel.ServiceID === scopeServiceModel[i].ProductID) {
						doesServiceExist = true;
						break;
					}
				}

				this.reloadContract(true, contractId, contractIdItem);
				if (!doesServiceExist) {
					this.byId("ServiceName-edit").setSelectedKey("");
					//	this.byId("ServiceText-edit").setText("");
					this.byId("SessionName-edit").setSelectedKey("");
					this.byId("SessionName-edit").setEnabled(false);
					//this.byId("SessionText-edit").setVisible(false);
					this.setModel(new JSONModel(), "servicerequestItemsModel");
					this.setModel(new JSONModel(), "contractSetModel");
					this.setModel(new JSONModel(), "contractItemModel");
					this.setModel(new JSONModel(), "scopeSessionModel");
					this.byId("contractId-edit").setSelectedKey("");
					this.byId("contractId-edit").setEnabled(false);
					this.byId("contractItemId-edit").setSelectedKey("");
					this.byId("contractItemId-edit").setEnabled(false);
				}

				models.SRItemsStartDateValidationEditMode(this);
				var oEventBus = sap.ui.getCore().getEventBus();
				if (doesServiceExist && serviceRequestModel.ServiceID) {
					this.setSession();
					if (serviceRequestModel.ServiceID === models.EOD_PRODUCT) {
						oEventBus.publish("OSPSystemSelection", "OSPSystemSelectionSuccess", "true");
					} else {
						oEventBus.publish("OSPSystemSelection", "OSPSystemSelectionSuccess", "false");
					}
				}
				models.overallBtnsAndFieldsValidations(this.getModel("servicerequestModel").getData().StatusCode, this);
				this.contractItemValidationSuccess();

				var items = this.byId("idProductsTable-edit").getItems();
				for (var i = 0; i < items.length; i++) {

					//Upon Copy SR, For all scope items remove Delivery Team value and make Delivery Team field read-only
					items[i].getCells()[7].getItems()[0].setSelectedKey("");
					items[i].getCells()[7].getItems()[0].setEnabled(false);

					var isItemDeleted = items[i].getCells()[0].getItems()[0].data("isDeleted");
					if (isItemDeleted === "false") {
						if (items[i].getCells()[5].getItems()[0].getValueState() === "Error" || items[i].getCells()[6].getItems()[0].getValueState() ===
							"Error") {
							this.byId("contractItemId-edit").setValueState("Error");
						}
					}
				}

			}
		},

		contractItemValidationSuccess: function () {
			models.contractItemsDurationValid = true;
			this.resetSRItemDateMinMaxLimit();
			var items = this.byId("idProductsTable-edit").getItems();
			var contractItem, selectedContractItem;
			selectedContractItem = this.byId("contractItemId-edit").getSelectedItem();
			this.byId("contractItemId-edit").setValueState(null);
			this.byId("contractItemId-edit").setValueStateText("");
			var SRStatus = this.getModel("servicerequestModel").getProperty("/StatusCode");
			if (selectedContractItem) {
				contractItem = selectedContractItem.data().contractItem;
				var contractItemStartDate = contractItem.ContractItemStart;
				contractItemStartDate = new Date(JSON.parse(JSON.stringify(contractItemStartDate)));
				contractItemStartDate.setMinutes(contractItemStartDate.getTimezoneOffset() - contractItemStartDate.getMinutes());
				contractItemStartDate.setHours(0, 0, 0, 0);
				var contractItemEndDate = contractItem.ContractItemEnd;
				contractItemEndDate = new Date(JSON.parse(JSON.stringify(contractItemEndDate)));
				contractItemEndDate.setMinutes(contractItemEndDate.getTimezoneOffset() - contractItemEndDate.getMinutes());
				contractItemEndDate.setHours(0, 0, 0, 0);
				for (var i = 0; i < items.length; i++) {
					var isItemDeleted = items[i].getCells()[0].getItems()[0].data("isDeleted");
					var itemNo = items[i].getCells()[0].data("item").ItemNo;
					if (isItemDeleted === "false" && itemNo != models.SR_ITEM_10) {
						var itemStartDateString = items[i].getCells()[5].getItems()[0].getValue();
						var itemStartDate;
						if (itemStartDateString) {
							itemStartDate = new Date(itemStartDateString);
						}
						if (itemStartDateString) {
							itemStartDate.setHours(0, 0, 0, 0);
						} else {
							models.contractItemsDurationValid = false;
							if (SRStatus !== models.STATUS_APPROVED) {
								items[i].getCells()[5].getItems()[0].setValueState("Error");
								items[i].getCells()[5].getItems()[0].setValueStateText("");
							}
						}

						var itemEndDateString = items[i].getCells()[6].getItems()[0].getValue();
						var itemEndDate;
						if (itemEndDateString) {
							itemEndDate = new Date(itemEndDateString);
						}
						if (itemEndDateString) {
							itemEndDate.setHours(0, 0, 0, 0);
						} else {
							models.contractItemsDurationValid = false;
							if (SRStatus !== models.STATUS_APPROVED) {
								items[i].getCells()[6].getItems()[0].setValueState("Error");
								items[i].getCells()[6].getItems()[0].setValueStateText("");
							}
						}

						if (itemStartDate > itemEndDate) {
							models.contractItemsDurationValid = false;
							items[i].getCells()[5].getItems()[0].setValueState("Error");
							items[i].getCells()[5].getItems()[0].setValueStateText(this.getResourceBundle().getText("txtStartDateLater"));
						}

						if (itemStartDate < contractItemStartDate) {
							models.contractItemsDurationValid = false;
							if (SRStatus !== models.STATUS_APPROVED) {
								items[i].getCells()[5].getItems()[0].setValueState("Error");
								items[i].getCells()[5].getItems()[0].setValueStateText(this.getResourceBundle().getText("txtMessageInvalidItemsDuration"));
							}
							this.byId("contractItemId-edit").setValueState("Error");
							this.byId("contractItemId-edit").setValueStateText(this.getResourceBundle().getText("txtMessageInvalidItemsDuration"));
						}

						if (itemStartDate > contractItemEndDate) {
							models.contractItemsDurationValid = false;
							if (SRStatus !== models.STATUS_APPROVED) {
								items[i].getCells()[5].getItems()[0].setValueState("Error");
								items[i].getCells()[5].getItems()[0].setValueStateText(this.getResourceBundle().getText("txtMessageInvalidItemsDuration"));
							}
							this.byId("contractItemId-edit").setValueState("Error");
							this.byId("contractItemId-edit").setValueStateText(this.getResourceBundle().getText("txtMessageInvalidItemsDuration"));
						}

						if (itemEndDate > contractItemEndDate) {
							models.contractItemsDurationValid = false;
							if (SRStatus !== models.STATUS_APPROVED) {
								items[i].getCells()[6].getItems()[0].setValueState("Error");
								items[i].getCells()[6].getItems()[0].setValueStateText(this.getResourceBundle().getText("txtMessageInvalidItemsDuration"));
							}
							this.byId("contractItemId-edit").setValueState("Error");
							this.byId("contractItemId-edit").setValueStateText(this.getResourceBundle().getText("txtMessageInvalidItemsDuration"));
						}

						items[i].getCells()[5].getItems()[0].setMinDate(contractItem.ContractItemStart);
						items[i].getCells()[5].getItems()[0].setMaxDate(contractItem.ContractItemEnd);
						items[i].getCells()[6].getItems()[0].setMinDate(contractItem.ContractItemStart);
						items[i].getCells()[6].getItems()[0].setMaxDate(contractItem.ContractItemEnd);
					}
				}
			}

			if (SRStatus === models.STATUS_APPROVED && !models.contractItemsDurationValid) {
				MessageBox.error("Selected Contract is not valid for given date range.");
				this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", false);
			} else {
				this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", true);
				models.onCreateValidate(this);
			}

		},

		setComboBoxContainsFilterScope: function () {
			this.getView().byId("ServiceName-edit").setFilterFunction(function (searchString, oItem) {
				if (!isNaN(searchString)) {
					searchString = searchString.trim();
				}
				return models.comboBoxContainsFilterFunction(oItem, searchString, true);
			});
			this.getView().byId("SessionName-edit").setFilterFunction(function (searchString, oItem) {
				if (!isNaN(searchString)) {
					searchString = searchString.trim();
				}
				return models.comboBoxContainsFilterFunction(oItem, searchString, true);
			});
			this.getView().byId("contractId-edit").setFilterFunction(function (searchString, oItem) {
				if (!isNaN(searchString)) {
					searchString = searchString.trim();
				}
				return models.comboBoxContainsFilterFunction(oItem, searchString, false);
			});
			this.getView().byId("contractItemId-edit").setFilterFunction(function (searchString, oItem) {
				if (!isNaN(searchString)) {
					searchString = searchString.trim();
				}
				return models.comboBoxContainsFilterFunction(oItem, searchString, false);
			});
		},

		scopeResetSuccess: function (context) {
			models.existingService = "";
			models.existingSession = "";
			models.existingSessionProductName = "";
			this.byId("ServiceName-edit").setSelectedKey("");
			this.byId("SessionName-edit").setSelectedKey("");
			this.byId("contractId-edit").setSelectedKey("");
			this.byId("contractItemId-edit").setSelectedKey("");
			this.byId("contractId-edit").setEnabled(false);
			this.byId("contractItemId-edit").setEnabled(false);
			this.deleteAllItems(null, 0);
			this.setModel(new JSONModel([]), "defaultItemsModel");
			this.setModel(new JSONModel({
				ProductID: null,
				ProductName: null
			}), "scopeSessionModel");
			this.setModel(new JSONModel({
				ProductID: null,
				ProductName: null
			}), "scopeServiceModel");
			this.disableRDD();
			//	this.setReqDelDateSuccess();

		},

		scopeTableResetSuccess: function (context) {
			//Added addition check on control because of console errors - Vivek
			if (this.byId("reqdate-edit")) {
				this.byId("reqdate-edit").setValueState("None");
			}
			/*
			if(this.byId("idInputEODService")){
				this.byId("idInputEODService").setTokens([]);
			}*/

			if (this.byId("contractId-edit")) {
				this.byId("contractId-edit").setSelectedKey("");
			}

			if (this.byId("contractItemId-edit")) {
				this.byId("contractItemId-edit").setSelectedKey("");
			}
			models.intializeCloudRefObjModels(this);

		},

		setAgreedScopeSuccess: function () {
			var text = this.getModel("agreedServiceRequestScopeModel").getData().data[0].Text.trim();
			if (text) {
				this.byId("sr-agreed-scope").setValue(text);
			} else {
				var userProfile = this.getModel("SRS_Data_UserSet").getData();
				var model = this.getModel("agreedServiceRequestScopeModel");
				models.setAgreedScopeTemplate(userProfile, model);
			}

		},
		onAfterRendering: function () {
			this.setModel(new sap.ui.model.json.JSONModel({
				"select": false
			}), "checkModel");

			// Reset Growing property of Text Area Agreed Scope upon Edit
			this.byId("sr-agreed-scope-TextMode-Edit").setText(this.getResourceBundle().getText("showMore"));
			this.byId("sr-agreed-scope-TextMode-Edit").setTooltip(this.getResourceBundle().getText("showMore"));
			this.byId("sr-agreed-scope").setGrowing(false);
			this.byId("sr-agreed-scope").setRows(5);

			var oView = this.getView();
			var dialog = oView.byId("dialogSystem");
			// create value help dialog
			if (!dialog) {
				dialog = sap.ui.xmlfragment(oView.getId(), "sap.com.servicerequest.servicerequest.fragment.SystemTableSuggestionDialog", this);
				oView.addDependent(dialog);
			}

			this.byId("sr-req-scope-TextMode-Edit").setText(this.getResourceBundle().getText("showMore"));
			this.byId("sr-req-scope-TextMode-Edit").setTooltip(this.getResourceBundle().getText("showMore"));
			this.byId("sr-req-scope").setGrowing(false);
			this.byId("sr-req-scope").setRows(5);

			var context = this;
			$(document).keydown(function (evt) {
				if (evt.shiftKey) {
					context.shiftkeyPressed = true;
				}
			});

			$(document).keyup(function (evt) {
				context.shiftkeyPressed = false;
			});

			this.showHideContractAndRelatedFieldsBasedOnContractMandatory();

		},

		onReadSuccess: function (channel, event, stepId) {
			this.is_onReadSuccess_Excecuted = true;
			if (stepId === "ContactID") {
				this.setFocusForCustContact();
			} else if (stepId === "SRInfo") {
				this.setFocusForSRInfo();
			}
			//console.log("Inside DetailScopeReadSuccess");
			var serviceRequestModel = this.getModel("servicerequestModel").oData;
			models.existingService = serviceRequestModel.ServiceID;
			models.existingSession = serviceRequestModel.SessionID;
			models.existingSessionProductName = serviceRequestModel.SessionName;
			this.byId("idSystemCombo").setTokens([]);
			var servicerequestModel = this.getModel("servicerequestModel").getData();
			var ReferenceSystemID = servicerequestModel.ReferenceSystemID;
			var ReferenceSystemName = servicerequestModel.ReferenceSystemName;
			if (ReferenceSystemID && ReferenceSystemID !== models.OSP_SYSTEM_REFERENCESYSTEMID) {
				var text = models.idAndNameFormatter(ReferenceSystemID, ReferenceSystemName);
				this.byId("idSystemCombo").addToken(new sap.m.Token({
					key: ReferenceSystemID,
					text: text
				}));
				models.showHideCloudRefObjSection(servicerequestModel.DeployMod, this);
			}
			this.byId("srs_customerContact-input").setTokens([]);
			this.byId("idSurveyRecipient").setTokens([]);
			if (servicerequestModel.ContactID) {
				this.setTokenForCustomerContact(servicerequestModel.ContactID, servicerequestModel.ContactName);
			}

			if (servicerequestModel.SurveyRecID) {
				this.setTokenForSurveyRecipient(servicerequestModel.SurveyRecID, servicerequestModel.SurveyRecName);
			}
			if (servicerequestModel.ShipToID && (servicerequestModel.CustomerID !== servicerequestModel.ShipToID)) {
				this.soldToCustomerId = servicerequestModel.ShipToID;
			}
			if (ReferenceSystemID === models.OSP_SYSTEM_REFERENCESYSTEMID) {
				this.getModel("buttonControlModel").setProperty("/enableOSPCheckbox", true);
			} else {
				this.getModel("buttonControlModel").setProperty("/enableOSPCheckbox", false);
			}

			this.byId("contractId-edit").setEnabled(false);
			this.byId("contractItemId-edit").setEnabled(false);

			if (serviceRequestModel && serviceRequestModel.ServiceRequestID) {
				if (serviceRequestModel.CustomerID && serviceRequestModel.ServiceID) {
					//	if(this.getModel("buttonControlModel").getProperty("/isEdit")){
					models.getContracts(this, "/ContractSet", {
						"CustomerID": serviceRequestModel.CustomerID,
						"ProductID": serviceRequestModel.ServiceID,
						"RecDelDate": serviceRequestModel.RequestedDeliveryDate
					}, "contractSetModel", "contractId-edit", false, null, null);
					//this.setSession(this, serviceRequestModel, []);
					//	}
				}
			} else {
				this.setModel(new JSONModel(), "contractSetModel");
				this.setModel(new JSONModel(), "contractItemModel");
			}
			this.loadItems(false, null, null, stepId);

			models.getCloudRefObj(this);

			this.byId("ShowMoreCloudRefObjEdit").setText("Show less");
			models.showHideMaxRowsForCloudRefObjs(this.byId("idTreeTableCloudRefEdit"), this.byId("ShowMoreCloudRefObjEdit"), this);

		},
		onCaseResetSuccess: function () {
			this.setModel(new JSONModel(), "contractSetModel");
			this.setModel(new JSONModel(), "contractItemModel");

			this.byId("contractId-edit").setSelectedKey("");
			this.byId("contractItemId-edit").setSelectedKey("");
			this.byId("contractItemId-edit").setEnabled(false);

			var serviceRequestModel = this.getModel("servicerequestModel").getData();
			if (serviceRequestModel.CustomerID && serviceRequestModel.ServiceID) {
				models.getContracts(this, "/ContractSet", {
					"CustomerID": serviceRequestModel.CustomerID,
					"ProductID": serviceRequestModel.ServiceID,
					"RecDelDate": serviceRequestModel.RequestedDeliveryDate
				}, "contractSetModel", "contractId-edit", true, null, null);
			}

			var items = this.byId("idProductsTable-edit").getItems();
			for (var i = 0; i < items.length; i++) {
				items[i].getCells()[7].getItems()[0].setValue("");
				items[i].getCells()[7].getItems()[0].setSelectedKey("");
				this.isItemsEdited = true;
				items[i].getCells()[0].data("item").DeliveryTeamID = "";
				items[i].getCells()[0].data("item").DeliveryTeamName = "";
				items[i].getCells()[0].data("item").DeliveryTeamChanged = true;
			}
		},

		loadItems: function (isDeleteAllTriggered, createdItem, index, stepId) {
			this.getModel("buttonControlModel").setProperty("/showContractValidationMessageStrip", false);
			this.getModel("buttonControlModel").setProperty("/showMsgForDatesValidationAgainstCurrentDate", false);
			this.byId("contractItemId-edit").setValueState(null);
			this.setModel(new JSONModel(), "contractItemsDateModel");
			this.setModel(new sap.ui.model.json.JSONModel([]), "servicerequestItemsModel");
			this.getModel("busyIndicatorModel").setProperty("/itemsTable", true);
			var oItems = this.getModel("servicerequestModel").getProperty("/toItems");
			var servicereqModel = this.getModel("servicerequestModel").getData();
			var sItemsURL = oItems.__deferred.uri.substring(oItems.__deferred.uri.indexOf("/ServiceRequestHeaderSet"));
			this.getModel("SRS_Data").read(sItemsURL, {
				filters: [],
				groupId: "SRItems",
				success: function (oData) {
					var srModel = this.getModel("servicerequestModel").getData();
					if (oData.results.length > 0) {
						var results = oData.results;
						results = results.sort(models.sortByProperty("ItemNo"));
						this.setModel(new sap.ui.model.json.JSONModel(results), "servicerequestItemsModel");
						this.getModel("buttonControlModel").setProperty("/itemAddBtn", true);
						var contractId = results[0].ContractID;
						var contractIdItem = results[0].ContractItemID;
						var productId = results[0].ProductID;
						var requestedDeliveryDate = results[0].RequestedDeliveryDate;
						this.reqDelDate = requestedDeliveryDate;
						if (results[1]) {
							models.isSessionSelected = true;
							this.item_20_dateTime = results[1].StartDate;
							if (models.doesSessionDescExist(this, results[1].ProductID)) {
								this.byId("SessionName-edit").setValueState(null);
								this.byId("SessionName-edit").setTooltip(this.getResourceBundle().getText("session"));
								this.byId("SessionName-edit").setValueStateText(this.getResourceBundle().getText("noComponentselected"));
							} else {
								this.byId("SessionName-edit").setValueState("Warning");
								this.byId("SessionName-edit").setTooltip(this.getResourceBundle().getText("txtMsgEnterSession"));
								this.byId("SessionName-edit").setValueStateText(this.getResourceBundle().getText("txtMsgEnterSession"));
							}
						}
						if (productId) {
							models.isServiceSelected = true;
						}
						var oEventBus = sap.ui.getCore().getEventBus();
						if (productId === models.EOD_PRODUCT) {
							oEventBus.publish("OSPSystemSelection", "OSPSystemSelectionSuccess", "true");
						} else {
							oEventBus.publish("OSPSystemSelection", "OSPSystemSelectionSuccess", "false");
						}

						if (contractId && contractIdItem && requestedDeliveryDate) {
							models.getContracts(this, "/ContractSet", {
								"RecDelDate": requestedDeliveryDate,
								"ProductID": productId,
								"ContractID": contractId
							}, "contractItemModel", "contractItemId-edit", true, null, contractIdItem);
						}
						this.byId("contractId-edit").setSelectedKey(contractId);
						this.byId("contractItemId-edit").setSelectedKey(contractIdItem);
						models.SRItemsStartDateValidationEditMode(this);
						this.setSession();
					} else {
						this.setModel(new sap.ui.model.json.JSONModel(), "servicerequestItemsModel");
						this.getModel("buttonControlModel").setProperty("/itemAddBtn", false);
					}
					if (!models.hasCreationOrDeletionTriggeredForCRO) {
						this.getModel("buttonControlModel").setProperty("/statusBtnEnabled", true);
					}
					var oEventBus = sap.ui.getCore().getEventBus();
					oEventBus.publish("enableCreateSOBtnInDialog", "enableCreateSOBtnInDialogSuccess");
					this.getModel("busyIndicatorModel").setProperty("/itemsTable", false);
					this.getModel("buttonControlModel").setProperty("/isCopyEnabled", true);
					models.overallBtnsAndFieldsValidations(this.getModel("servicerequestModel").getData().StatusCode, this);

					if (models.OPR_TYPE === "SAVE_OPR") {
						var msgTxt = "<div>Service Request <strong>" + srModel.ServiceRequestID +
							"</strong> Updated Successfully.<br/><br/> <strong>Note:</strong> This is not a Service Order! <br/> <strong>What's Next?</strong> Finalize Service Request and submit it for Scoping.</div>";
						var canBeSendForScoping = true;
						var missingMandFields = this.missinMandatoryFieldsOnSendToScoping();
						if (missingMandFields) {
							msgTxt = "<div>Service Request <strong>" + srModel.ServiceRequestID +
								"</strong> Updated Successfully.<br/><br/> <strong>Note:</strong> This is not a Service Order! <br/> <strong>What's Next?</strong> <ul><li>Finalize your Service Request and <strong><span>" +
								missingMandFields + "</span></strong></li><li>Submit Service Request for Scoping</li></ul></div>";
							canBeSendForScoping = false;
						}
						models.showSRCreationAndUpdateMessageForStatusNew(this, msgTxt, canBeSendForScoping, srModel.ServiceRequestID);
						models.OPR_TYPE = null;
						this.hideBusyDialog();
					}

					var oEventBus = sap.ui.getCore().getEventBus();
					var paramCreateSO = jQuery.sap.getUriParameters().get("paramCreateSO");
					if (paramCreateSO && paramCreateSO === "true" && srModel.StatusCode === models.STATUS_APPROVED && models.SO_CREATION_VALIDITY) {
						oEventBus.publish("onCreateSO", "onCreateSOSuccess");
					}
					models.SO_CREATION_VALIDITY = false;
					//	this.getModel("buttonControlModel").setProperty("/enableDeleteAllItems", this.setDeleteAllButtonEnabled());
					sap.ui.core.BusyIndicator.hide();
					oEventBus.publish("evaluateSRProgress", "evaluateSRProgressSuccess");
					if (stepId === "ServiceID") {
						this.setFocusForService();
					} else if (stepId === "SessionID") {
						this.setFocusForSession();
					} else if (stepId === "ContractID") {
						this.setFocusForContract();
					} else if (stepId === "RequestedDeliveryDate") {
						this.setFocusForContractItem();
					} else if (stepId === "ContractItemID") {
						this.setFocusForRDD();
					} else if (stepId === "AgreedScope") {
						this.setFocusForAgreedScope();
					} else if (stepId === "ReferenceSystemID") {
						this.setFocusForSystem();
					}
					this.showOSPSystemForLoadItems();
					//Workaround  current drop-down issue in scope section
					//models.tempSolutionforDropDownIssue();

				}.bind(this),
				error: function () {
					this.setModel(new sap.ui.model.json.JSONModel(), "servicerequestItemsModel");
					this.getModel("buttonControlModel").setProperty("/statusBtnEnabled", true);
					this.getModel("busyIndicatorModel").setProperty("/itemsTable", false);
					this.hideBusyDialog();
					sap.ui.core.BusyIndicator.hide();
				}.bind(this)
			});
		},

		setDeleteAllButtonEnabled: function () {
			var items = this.byId("idProductsTable-edit").getItems();
			var visibleItems = 0;
			for (var i = 0; i < items.length; i++) {
				if (items[i].getVisible()) {
					visibleItems++;
				}
			}
			if (visibleItems > 2) {
				return true;
			}
			return false;
		},

		missinMandatoryFieldsOnSendToScoping: function () {
			var SRHeaderModel = this.getModel("servicerequestModel");
			var serviceInfoModel = this.getModel("serviceRequestScopeModel");
			var SRItemsModel = this.getModel("servicerequestItemsModel");

			if (SRHeaderModel && SRHeaderModel.getData() && serviceInfoModel && serviceInfoModel.getData()) {
				var SRHeaderModelData = SRHeaderModel.getData();
				var serviceInfoModelData = serviceInfoModel.getData();
				var emptyFieldsArray = [];
				models.serviceRequestMandFieldsValidation(this, SRHeaderModelData, emptyFieldsArray);
				if (serviceInfoModelData && serviceInfoModelData.data.length === 0) {
					emptyFieldsArray.push("Service Request Info");
				}
				if (SRItemsModel && SRItemsModel.getData() && SRItemsModel.getData().length > 0) {
					var SRItemsModelData = SRItemsModel.getData();
					models.serviceRequestItemsMandFieldsValidation(this, SRItemsModelData, emptyFieldsArray);
				}
				return this.checkEmptyFieldsForStatus(emptyFieldsArray, models.STATUS_INSCOPING, "dialogTextSendForScoping");
			} else {
				return null;
			}
		},
		checkEmptyFieldsForStatus: function (emptyFieldsArray, statusCode, txtMessage) {
			var emptyFieldsArrayLength = emptyFieldsArray.length;
			var arrayIndexlength = emptyFieldsArray.length - 1;

			if (emptyFieldsArrayLength === 0) {
				return null;
			} else {
				var txtEmptyFields = "";
				for (var i = 0; i < emptyFieldsArrayLength; i++) {
					if (i === arrayIndexlength) {
						txtEmptyFields += emptyFieldsArray[i];
					} else {
						txtEmptyFields += emptyFieldsArray[i] + ", ";
					}
				}
				return "maintain required fields for Scoping: " + "<span style='color: #ff0000;'>" + txtEmptyFields + "</span>";
			}
		},
		setScopeSectionNonEditable: function () {
			var SRModel = this.getModel("servicerequestModel").getData();
			if (SRModel.StatusCode === models.STATUS_INEXCEPTION) {
				this.byId("contractId-edit").setEnabled(false);
				this.byId("contractItemId-edit").setEnabled(false);
				this.byId("reqdate-edit").setEnabled(false);
				var items = this.byId("idProductsTable-edit").getItems();
				for (var i = 0; i < items.length; i++) {
					this.byId("idProductsTable-edit").getItems()[i].getCells()[0].getItems()[0].setVisible(false);
					this.byId("idProductsTable-edit").getItems()[i].getCells()[2].getItems()[1].setEnabled(false);
					this.byId("idProductsTable-edit").getItems()[i].getCells()[3].getItems()[0].setEnabled(false);
					this.byId("idProductsTable-edit").getItems()[i].getCells()[4].getItems()[1].setEnabled(false);
					this.byId("idProductsTable-edit").getItems()[i].getCells()[5].getItems()[0].setEnabled(false);
					this.byId("idProductsTable-edit").getItems()[i].getCells()[6].getItems()[0].setEnabled(false);
					this.byId("idProductsTable-edit").getItems()[i].getCells()[7].getItems()[0].setEnabled(false);
				}
				this.getModel("editableFieldsModel").setProperty("/Service", false);
				this.getModel("editableFieldsModel").setProperty("/Session", false);
				this.getModel("buttonControlModel").setProperty("/itemAddBtn", false);
				models.onCreateValidate(this);
			}
		},

		createSRItemsSuccess: function (channel, event, serviceRequestModel) {
			models.existingService = serviceRequestModel.ServiceID;
			models.existingSession = serviceRequestModel.SessionID;
			models.existingSessionProductName = serviceRequestModel.SessionName;
			var items = this.byId("idProductsTable-edit").getItems();
			var context = this;
			var oModel = context.getModel("SRS_Data");
			var aDeferredGroup = oModel.getDeferredGroups();
			aDeferredGroup.push("batchCreate");
			oModel.setDeferredGroups(aDeferredGroup);
			context.isBatchExecuted = true;
			var mParameters = {
				groupId: "batchCreate",
				success: function (data) {
					if (context.isBatchExecuted && data && data.__batchResponses && data.__batchResponses.length > 0) {
						context.onCreateItemsSuccess(serviceRequestModel, context, models.STRING_SUCCESS);
					}
				},
				error: function (err) {
					if (context.isBatchExecuted) {
						context.isBatchExecuted = false;
						models.showErrorMessage(context, err);
						context.onCreateItemsSuccess(serviceRequestModel, context, models.STRING_ERROR);
					}
				}
			};

			var contractID = this.byId("contractId-edit").getSelectedKey();
			var contractItemID = this.byId("contractItemId-edit").getSelectedKey();

			if (items && items.length > 0) {
				for (var i = 0; i < items.length; i++) {
					var SRItem = items[i].getCells()[0].data("item");
					var isItemDeleted = items[i].getCells()[0].getItems()[0].data("isDeleted");
					if (isItemDeleted === "false") {
						delete SRItem["ItemGUID"];
						delete SRItem["ParentGUID"];
						SRItem.HeaderGUID = serviceRequestModel.HeaderGUID;
						if (SRItem.ItemNo === models.SR_ITEM_10) {
							this.reqDelDate = this.byId("reqdate-edit").getDateValue();
							this.setItemContractAndOtherAttr(SRItem, this.reqDelDate, models.goLiveDate, contractID, contractItemID);
						}
						oModel.create("/ServiceRequestItemSet", SRItem, mParameters);
					}
				}
				//submit changes and refresh the table and display message
				oModel.submitChanges(mParameters);
			} else {
				context.onCreateItemsSuccess(serviceRequestModel, context, models.STRING_SUCCESS);
			}
		},
		onCreateItemsSuccess: function (serviceRequestModel, context, responseType) {
			//success message 
			if (!models.ERROR_FLAG_NOTESET) {
				if (responseType === models.STRING_SUCCESS) {
					/*var msgTxt = "<div>Service Request <strong>" + serviceRequestModel.ServiceRequestID +
						"</strong> Created Successfully.<br/><br/> <strong>Note:</strong> This is not a Service Order! <br/> <strong>What's Next?</strong> Finalize Service Request and submit it for Scoping.</div>";
					models.showSRCreationAndUpdateMessageForStatusNew(this, msgTxt);*/
					context.getRouter().navTo("DetailView", {
						ServiceRequestID: serviceRequestModel.ServiceRequestID,
						CaseId: serviceRequestModel.CaseID !== "" ? serviceRequestModel.CaseID : "0"
					});
				} else {
					var oEventBus = sap.ui.getCore().getEventBus();
					oEventBus.publish("toggleEditDisplay", "toggleEditDisplaySuccess");
					context.hideBusyDialog();
				}
			}
			models.createTenantsAndModules(this);
		},

		saveSRItemsSuccess: function (channel, event) {

			if (!models.sessionValiation(this)) {

				return;
			}

			this.contractItemValidationSuccess();
			if (!models.contractItemsDurationValid) {
				models.showContractValidationMessage(this);
				return;
			}

			sap.ui.core.BusyIndicator.show();
			var serviceRequestModel = this.getModel("servicerequestModel").getData();
			var items = this.byId("idProductsTable-edit").getItems();
			var context = this;
			var oModel = context.getModel("SRS_Data");
			var aDeferredGroup = oModel.getDeferredGroups();
			aDeferredGroup.push("batchUpdate");
			oModel.setDeferredGroups(aDeferredGroup);
			context.isBatchExecuted = true;
			var oEventBus = sap.ui.getCore().getEventBus();
			//var errorMsgAppearedOnce = true;
			var mParameters = {
				groupId: "batchUpdate",
				success: function (data) {
					if (data && data.__batchResponses && data.__batchResponses.length > 0) {
						models.existingService = serviceRequestModel.ServiceID;
						models.existingSession = serviceRequestModel.SessionID;
						models.existingSessionProductName = serviceRequestModel.SessionName;
						if (context.isBatchExecuted) {
							context.isBatchExecuted = false;
							if (serviceRequestModel.StatusCode !== models.STATUS_NEW) {
								models.getSRHeaderByID(context, serviceRequestModel.ServiceRequestID, oEventBus);
							} else {
								oEventBus.publish("onSaveServiceRequest", "onSaveServiceRequestSuccess");
							}
						}
					}
				},
				error: function (err) {
					if (context.isBatchExecuted) {
						context.isBatchExecuted = false;
						models.showErrorMessage(context, err);
						sap.ui.core.BusyIndicator.hide();
					}
				}
			};
			var doesAnyBatchRequestExist = false;
			var contractID = "",
				contractItemID = "";
			if (this.byId("contractId-edit").getSelectedItem()) {
				contractID = this.byId("contractId-edit").getSelectedKey();
			}
			if (this.byId("contractItemId-edit").getSelectedItem()) {
				contractItemID = this.byId("contractItemId-edit").getSelectedKey();
			}
			var isParentItemDeleted = false;
			if (items && items.length > 0) {
				for (var i = 0; i < items.length; i++) {
					var SRItem = items[i].getCells()[0].data("item");
					var isItemDeleted = items[i].getCells()[0].getItems()[0].data("isDeleted");
					if (!SRItem.ItemGUID && isItemDeleted === "false") {
						doesAnyBatchRequestExist = true;
						delete SRItem["ItemGUID"];
						delete SRItem["ParentGUID"];
						SRItem.HeaderGUID = serviceRequestModel.HeaderGUID;
						if (SRItem.ItemNo === models.SR_ITEM_10) {
							this.reqDelDate = this.byId("reqdate-edit").getDateValue();
							this.setItemContractAndOtherAttr(SRItem, this.reqDelDate, models.goLiveDate, contractID, contractItemID);
						}
						oModel.create("/ServiceRequestItemSet", SRItem, mParameters);
					} else if (SRItem.ItemGUID && isItemDeleted === "true" && !isParentItemDeleted) {
						doesAnyBatchRequestExist = true;
						oModel.remove("/ServiceRequestItemSet(guid'" + SRItem.ItemGUID + "')", mParameters);
						if (SRItem.ItemNo === models.SR_ITEM_10 || SRItem.ItemNo === models.SR_ITEM_20) {
							isParentItemDeleted = true;
						}
					} else if (SRItem.ItemGUID && isItemDeleted === "false" && !isParentItemDeleted) {
						doesAnyBatchRequestExist = true;
						oModel.sDefaultUpdateMethod = "PUT";
						if (SRItem.ItemNo === models.SR_ITEM_10) {
							this.reqDelDate = this.byId("reqdate-edit").getDateValue();
							this.setItemContractAndOtherAttr(SRItem, this.reqDelDate, models.goLiveDate, contractID, contractItemID);
						}

						oModel.update("/ServiceRequestItemSet(guid'" + SRItem.ItemGUID + "')", SRItem, mParameters);
					}
				}
				if (doesAnyBatchRequestExist) {
					//submit changes and refresh the table and display message
					oModel.submitChanges(mParameters);
				} else {
					oEventBus.publish("onSaveServiceRequest", "onSaveServiceRequestSuccess");
				}
			} else {
				oEventBus.publish("onSaveServiceRequest", "onSaveServiceRequestSuccess");
			}

		},
		setItemContractAndOtherAttr: function (SRItem, reqDelDate, goLiveDate, contractID, contractItemID) {
			SRItem.RequestedDeliveryDate = reqDelDate;
			SRItem.GoLiveDate = goLiveDate;
			SRItem.ContractID = contractID;
			SRItem.ContractItemID = contractItemID;
			SRItem.StartDate = reqDelDate;
			SRItem.EndDate = reqDelDate;
		},
		createDefaultItemForSR: function (productId, productName, itemNo) {
			var requestDeliverDate = this.byId("reqdate-edit").getDateValue();
			var startDate, endDate;
			if (this.byId("reqdate-edit").getValue()) {
				startDate = new Date(requestDeliverDate);
				startDate.setHours(9, 0, 0, 0);
				endDate = new Date(requestDeliverDate);
				endDate.setHours(17, 0, 0, 0);
			} else {
				startDate = new Date();
				startDate.setHours(9, 0, 0, 0);
				endDate = new Date();
				endDate.setHours(17, 0, 0, 0);
			}

			var newItem = {
				"ServiceRequestID": "",
				"ParentGUID": "",
				"HeaderGUID": "",
				"ItemGUID": "",
				"ItemNo": itemNo,
				"ParentNo": "",
				"QualifiactionID": "",
				"QualificationName": "",
				"CallOffDays": "0",
				"StartDate": startDate,
				"EndDate": endDate,
				"ProductID": productId,
				"ProductName": productName,
				"DeliveryTeamID": "",
				"DeliveryTeamName": "",
				"RequestedDeliveryDate": requestDeliverDate,
				"GoLiveDate": null,
				"ContractID": "",
				"ContractName": "",
				"ContractItemID": "",
				"ContractItemName": "",
				"DeliveryTeamChanged": false
			};

			//Default the Item20 with TQM-Qualification (ROLE: PE TQM)
			if (itemNo === models.SR_ITEM_20) {
				newItem["QualifiactionID"] = "93200499";
				newItem["QualificationName"] = "ROLE: PE TQM Technical Quality Manager";
				this.item_20_dateTime = startDate;
			}

			return newItem;
		},
		onServiceIdChange: function (oEvent) {
			var oEventBus = sap.ui.getCore().getEventBus();
			if (!this.serviceDialog) {
				var context = this;
				var exstValue = context.getModel("servicerequestModel").getProperty("/ServiceID");
				var createdItem;
				var tableItems = context.byId("idProductsTable-edit").getItems();
				var productId, productName;
				if (oEvent.getSource().getSelectedItem()) {
					productId = oEvent.getSource().getSelectedItem().getKey();
					var fieldTxt = oEvent.getSource().getSelectedItem().getText();
					var fieldTxtSplitArr = fieldTxt.split("-");
					if (fieldTxtSplitArr.length > 2) {
						for (var k = 1; k < fieldTxtSplitArr.length; k++) {
							if (productName) {
								productName += "-" + fieldTxtSplitArr[k];
							} else {
								productName = fieldTxtSplitArr[k];
							}
						}
					} else if (fieldTxt) {
						productName = fieldTxtSplitArr[1].trim();
					}
				}

				// var itemIndex = 0;
				var reqDelDate = this.byId("reqdate-edit").getDateValue();
				var dialog = new Dialog({
					title: "Confirm",
					type: "Message",
					state: 'Warning',
					beginButton: new Button({
						text: "Yes",
						press: function () {
							models.existingService = null;
							models.existingSession = null;
							models.isServiceSelected = false;
							models.isSessionSelected = false;
							if (context.getModel("servicerequestModel").getData().ServiceRequestID) {
								context.deleteAllItems(createdItem, 0);
							} else {
								context.setModel(new sap.ui.model.json.JSONModel([]), "servicerequestItemsModel");
								context.getModel("buttonControlModel").setProperty("/itemAddBtn", false);
							}
							context.disableRDD();
							//context.byId("ServiceText-edit").setText("");
							context.byId("SessionName-edit").setSelectedKey("");
							context.getModel("editableFieldsModel").setProperty("/Session", false);
							context.byId("SessionText-edit").setVisible(false);
							context.setModel(new sap.ui.model.json.JSONModel([]), "contractSetModel");
							context.setModel(new sap.ui.model.json.JSONModel([]), "contractItemModel");
							context.byId("idTextContactType").setText("");
							context.getModel("editableFieldsModel").setProperty("/ContractItem", false);
							context.getModel("editableFieldsModel").setProperty("/Contract", false);
							context.byId("contractId-edit").setSelectedKey("");
							context.byId("contractItemId-edit").setSelectedKey("");
							context.serviceDialog = false;
							context.getModel("SRS_Data_UserSet").setProperty("/AvailableCallOffDays", "0");
							context.getModel("servicerequestModel").setProperty("/TotalCallOffDays", "0");
							context.getModel("buttonControlModel").setProperty("/enableDeleteAllItems", context.setDeleteAllButtonEnabled());
							oEventBus.publish("OSPSystemSelection", "OSPSystemSelectionSuccess", "false");
							context.getModel("buttonControlModel").setProperty("/showEODServiceControl", false);
							var dialogContentSid = dialog.getContent()[0].sId;
							if (dialogContentSid.includes("html")) {
								context.clearSelectedSystem();
								context.byId("idSystemCombo").setTokens([]);
							}
							context.showOSPSystem();
							models.onCreateValidate(context);
							context.byId("SessionName-edit").setRequired(false);
							context.byId("SessionName-edit").setValueState(null);
							context.showHideContractAndRelatedFieldsBasedOnContractMandatory();
							dialog.close();

						}.bind(this)
					}),
					endButton: new Button({
						text: "No",
						type: "Emphasized",
						press: function () {
							context.byId("ServiceName-edit").setSelectedKey(models.existingService);
							dialog.close();
							context.serviceDialog = false;
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});

				if (models.existingService) {
					var selectedKey = oEvent.getSource().getSelectedKey();
					if (selectedKey) {
						this.uponServiceReSelect(productName, selectedKey, productId, models.existingService);
						models.onCreateValidate(this);
						this.byId("SessionName-edit").setRequired(true);
						this.byId("SessionName-edit").setValueState(null);
						this.showHideContractAndRelatedFieldsBasedOnContractMandatory();
					} else {
						if (this.getModel("servicerequestModel").getProperty("/ReferenceSystemID") && this.getModel("servicerequestModel").getProperty(
								"/ReferenceSystemID") !== "0") {
							this.validateSelectedSystem(dialog, "SERVICE");
						} else {
							dialog.addContent(
								new Text({
									text: "Removing the service will remove all Items. Do you still want to continue?"
								})
							);
							dialog.open();
						}
						this.serviceDialog = true;
					}
					this.isItemsEdited = true;
				} else {
					this.setNewServiceAndSession(productId, createdItem, productName, context, oEvent.getSource().getSelectedItem(), null);
					models.onCreateValidate(this);
					this.byId("SessionName-edit").setRequired(true);
					this.byId("SessionName-edit").setValueState(null);
					this.showHideContractAndRelatedFieldsBasedOnContractMandatory();
				}
			}

		},
		uponServiceReSelect: function (productName, selectedKey, productId, previousSelectedService) {
			var oEventBus = sap.ui.getCore().getEventBus();
			//this.byId("ServiceText-edit").setText(productName);
			var srItems = this.byId("idProductsTable-edit").getItems();
			for (var i = 0; i < srItems.length; i++) {
				if (srItems[i].getVisible() && srItems[i].getCells()[0].data("item").ItemNo === models.SR_ITEM_10) {
					srItems[i].getCells()[0].data("item").ProductID = selectedKey;
					srItems[i].getCells()[0].data("item").ProductName = productName;
					srItems[i].getCells()[2].getItems()[0].setText(productName);
					models.existingService = selectedKey;
					//break;
				} else {
					if (selectedKey === models.SERVICE_ON_CALL_DUTY) {
						var callOffVal = srItems[i].getCells()[0].data("item").CallOffDays;
						var PC = parseFloat(callOffVal) / 1.5;
						if (PC >= 1) {
							PC = (Math.round(PC)).toString();
							srItems[i].getCells()[0].data("item").CallOffDays = PC;
							srItems[i].getCells()[4].getItems()[1].setValue(PC);
						} else if (PC > 0 && PC < 1) {
							srItems[i].getCells()[0].data("item").CallOffDays = "1";
							srItems[i].getCells()[4].getItems()[1].setValue(1);
						} else {
							srItems[i].getCells()[0].data("item").CallOffDays = "0";
							srItems[i].getCells()[4].getItems()[1].setValue(0);
						}
					} else if (previousSelectedService === models.SERVICE_ON_CALL_DUTY && selectedKey !== models.SERVICE_ON_CALL_DUTY) {
						var callOffVal = ((1.5 * parseFloat(srItems[i].getCells()[0].data("item").CallOffDays)).toFixed(1)).toString();
						srItems[i].getCells()[0].data("item").CallOffDays = callOffVal;
						srItems[i].getCells()[4].getItems()[1].setValue(callOffVal);
					}

				}
			}
			if (selectedKey === models.SERVICE_ON_CALL_DUTY) {
				MessageBox.information(this.getResourceBundle().getText("txtOnCallDutyServiceSelection"));
				this.recalculateCallOffDays();
			} else if (previousSelectedService === models.SERVICE_ON_CALL_DUTY && selectedKey !== models.SERVICE_ON_CALL_DUTY) {
				MessageBox.information(this.getResourceBundle().getText("txtSwitchServiceFromOnCallDutyService"));
				this.recalculateCallOffDays();
			}
			this.readSessionWhenServiceIsSwitched(selectedKey);
			if (productId === models.EOD_PRODUCT) {
				oEventBus.publish("OSPSystemSelection", "OSPSystemSelectionSuccess", "true");
			} else {
				oEventBus.publish("OSPSystemSelection", "OSPSystemSelectionSuccess", "false");
			}
			this.byId("idTextContactType").setText("");
			this.reloadContract(true, null, null);

		},
		validateSelectedSystem: function (dialog, type) {
			var context = this;
			var IbComponent = this.getModel("servicerequestModel").getProperty("/ReferenceSystemID");
			var SolmanComponent = this.getModel("servicerequestModel").getProperty("/SolmanComponent");
			var InstNo = this.getModel("servicerequestModel").getProperty("/InstNo");
			var Customer = this.getModel("servicerequestModel").getProperty("/CustomerID");
			var responseShowMessageForSystemInfoMsgStripBasedOnSystemAndSolman = this.showMessageForSystemInfoMsgStripBasedOnSystemAndSolman();
			/*
			if(dialog){
				sap.ui.core.BusyIndicator.show();
			}else{	
				context.byId("idSystemCombo").setBusy(true);
			}*/
			sap.ui.core.BusyIndicator.show(0);
			var arrFilter = [];
			var requestFilter;
			arrFilter.push(models.filterCondition_Equal("Customer", Customer));
			arrFilter.push(models.filterCondition_Equal("InstNo", InstNo));
			arrFilter.push(models.filterCondition_Equal("IbComponent", IbComponent));
			//	arrFilter.push(models.filterCondition_Equal("SolmanComponent", SolmanComponent));
			requestFilter = models.filterComparison_AND(arrFilter);

			this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", false);
			context.getModel("SRS_Data").read("/IBaseComponentSet", {
				filters: [requestFilter],
				success: function (oData) {
					//	context.byId("idSystemCombo").setBusy(false);
					sap.ui.core.BusyIndicator.hide();
					context.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", true);
					var response = oData.results;
					var doesSelectedSystemHasSolman = false;
					var iSCloudSystem = false;
					for (var i = 0; i < response.length; i++) {
						if (response[i].SolmanComponent === SolmanComponent) {
							if (response[i].DeployModT.toUpperCase() === "CLOUD") {
								doesSelectedSystemHasSolman = true;
								iSCloudSystem = true;
								break;
							} else {
								if (response[i].SolmanSid) {
									doesSelectedSystemHasSolman = true;
									break;
								} else {
									doesSelectedSystemHasSolman = false;
									break;
								}
							}
						}
					}

					if (responseShowMessageForSystemInfoMsgStripBasedOnSystemAndSolman.shallAppendSolmanAtBotton !== doesSelectedSystemHasSolman) {
						if (dialog) {
							sap.ui.core.BusyIndicator.hide();
							if (type === "SERVICE") {
								dialog.addContent(
									new HTML({
										content: "<div><ul><li>Removing the Service will remove all Items.</li><li>The selected System does no longer fulfill the requirement of the selected Service/Component combination and therefore it will be removed.</li></ul><p> Do you still want to comtinue?</p></div>"
									})
								);
							} else if (type === "SESSION") {
								dialog.addContent(
									new HTML({
										content: "<div><ul><li>Removing the Component will remove all Items 30+.</li><li>The selected System does no longer fulfill the requirement of the selected Service/Component combination and therefore it will be removed.</li></ul><p> Do you still want to comtinue?</p></div>"
									})
								);

							}
							dialog.open();
						} else {
							var serviceId = this.byId("ServiceName-edit").getSelectedKey();
							var sessionId = this.byId("SessionName-edit").getSelectedKey();
							if (serviceId && sessionId && iSCloudSystem) {
								return;
							}

							this.clearSelectedSystem();
							this.byId("idSystemCombo").setTokens([]);
							if (!this.getModel("buttonControlModel").getProperty("/enableOSPCheckbox")) {
								MessageBox.information(this.getResourceBundle().getText("txtMsgForSystemRemoval"), {
									styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer"
								});
							}
							this.showOSPSystem();
							var isSystemEnabled = this.getModel("editableFieldsModel").getProperty("/System");
							if (!isSystemEnabled) {
								this.getModel("editableFieldsModel").setProperty("/System", true);
								this.getModel("buttonControlModel").setProperty("/enableOSPCheckbox", false);
							}
						}
						return;
					}
					if (dialog) {
						sap.ui.core.BusyIndicator.hide();
						if (type === "SERVICE") {
							dialog.addContent(
								new Text({
									text: "Removing the Service will remove all Items. Do you still want to continue?"
								})
							);
						} else if (type === "SESSION") {
							dialog.addContent(
								new Text({
									text: "Removing the Component will remove all Items 30+. Do you still want to continue?"
								})
							);
						}
						dialog.open();
					}
					//context.byId("idSystemCombo").setBusy(false);
				}.bind(context),
				error: function (err) {
					context.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", true);
					sap.m.MessageToast.show(context.getResourceBundle().getText("errorText"));
					//	context.byId("idSystemCombo").setBusy(false);
					sap.ui.core.BusyIndicator.hide();
					models.applyBrowserAutoFillOff();
				}.bind(context)
			});
		},
		eventSetNewServiceAndSession: function (oEvent, channel, productParams) {
			var createdItem, productName;
			var productId = productParams[0];
			var sessionId = productParams[1];
			var productSetModel = this.getModel("productSetModel").getData();
			for (var i = 0; i < productSetModel.length; i++) {
				if (productId === productSetModel[i].ProductID) {
					productName = productSetModel[i].ProductText;
				}
			}
			this.byId("ServiceName-edit").setSelectedKey(productId);
			this.setNewServiceAndSession(productId, createdItem, productName, this, productId, sessionId);
			this.setQualificationAndCallOffDaysForSession();
			this.showHideContractAndRelatedFieldsBasedOnContractMandatory();
		},
		setNewServiceAndSession: function (productId, createdItem, productName, context, selectedService, sessionId) {
			var oEventBus = sap.ui.getCore().getEventBus();
			context.byId("idTextContactType").setText("");
			//set Default RDD 
			if (selectedService) {
				context.setReqDelDateSuccess();
			}
			this.isItemsEdited = true;
			models.existingService = productId;
			this.onServiceSelectionAndValidation(productId, createdItem, context, productName, sessionId);
			context.setModel(new sap.ui.model.json.JSONModel([]), "scopeServiceModel");
			context.getModel("scopeServiceModel").setData([{
				ProductID: productId,
				ProductName: productName
			}]);
			context.setModel(new sap.ui.model.json.JSONModel(), "sessionModel");
			if (productId === models.EOD_PRODUCT) {
				oEventBus.publish("OSPSystemSelection", "OSPSystemSelectionSuccess", "true");
			} else {
				oEventBus.publish("OSPSystemSelection", "OSPSystemSelectionSuccess", "false");
			}
		},
		/*
		setEODAttrEmpty: function(){
			this.getModel("servicerequestModel").setProperty("/ServiceContactID","");
			this.getModel("servicerequestModel").setProperty("/ServiceContactName","");
		},*/
		disableRDD: function () {
			this.byId("reqdate-edit").setEnabled(false);
			this.byId("reqdate-edit").setValue("");
			this.byId("reqdate-edit").setDateValue(null);
			this.byId("reqdate-edit").setValueState("None");
			this.reqDelDate = "";
		},
		onServiceSelectionAndValidation: function (productId, createdItem, context, productName, sessionIdParam) {
			if (productId) {
				models.isServiceSelected = true;

				createdItem = context.createDefaultItemForSR(productId, productName, models.SR_ITEM_10);
				if (jQuery.isEmptyObject(context.getModel("servicerequestItemsModel").getData())) {
					context.setModel(new sap.ui.model.json.JSONModel([createdItem]), "servicerequestItemsModel");
				} else {
					this.onAddNewScopeRowOnServiceChange(createdItem);
				}

				models.SRItemsStartDateValidationEditMode(this);
				//var oServiceText = context.byId("ServiceText-edit");
				//oServiceText.setText(productName);

				//context.byId("SessionName-edit").setValue(true);
				context.getModel("SRS_Data").read("/ProductSet('" + productId + "')/toProductComponents", {
					groupId: "SessionGroup",
					success: function (oData) {
						if (oData.results.length > 0) {
							context.setModel(new sap.ui.model.json.JSONModel(oData.results), "sessionModel");
							context.byId("SessionName-edit").setValueState("None");
							if (oData.results.length === 1) {
								var sessionID = oData.results[0].ComponentId;
								var sessionName = oData.results[0].ComponentText;
								context.selectDefaultSessionandCreateItem(sessionID, sessionName);
							} else {
								if (sessionIdParam) {
									var sessionName;
									for (var i = 0; i < oData.results.length; i++) {
										if (sessionIdParam === oData.results[i].ComponentId) {
											sessionName = oData.results[i].ComponentText;
										}
									}
									context.selectDefaultSessionandCreateItem(sessionIdParam, sessionName);
								} else {
									models.isSessionSelected = false;
									context.byId("SessionName-edit").setValue();
									context.byId("SessionText-edit").setVisible(false);
								}
							}
							context.setQualificationAndCallOffDaysForSession();
						} else {
							models.isSessionSelected = false;
							context.byId("SessionText-edit").setVisible(false);
						}
						if (this.getModel("servicerequestModel").getProperty("/ReferenceSystemID") && this.getModel("servicerequestModel").getProperty(
								"/ReferenceSystemID") !== "0") {
							this.validateSelectedSystem(null, "SESSION");
						}
						this.showOSPSystem();
						models.onCreateValidate(this);
						context.byId("SessionName-edit").setBusy(false);
						context.reloadContract(true, null, null);
						//Workaround  current drop-down issue in scope section
						//	models.tempSolutionforDropDownIssue();
					}.bind(context),
					error: function () {
						models.isSessionSelected = false;
						context.setModel(new sap.ui.model.json.JSONModel(), "sessionModel");
						// oServiceText.setValue("ServiceId not Found");
						context.byId("SessionName-edit").setValueState("Error");
						context.byId("SessionName-edit").setValue();
						context.byId("SessionText-edit").setVisible(false);
					}.bind(context)
				});
				this.getModel("editableFieldsModel").setProperty("/Session", true);
				this.getModel("editableFieldsModel").setProperty("/ReqDelDate", true);
			} else {
				models.isServiceSelected = false;
				context.setModel(new JSONModel(), "contractSetModel");
				context.setModel(new JSONModel(), "contractItemModel");
				context.byId("contractId-edit").setEnabled(false);
				context.byId("contractItemId-edit").setEnabled(false);
				this.getModel("editableFieldsModel").setProperty("/Session", false);
				this.getModel("editableFieldsModel").setProperty("/ReqDelDate", false);
			}
			//context.byId("reqdate-edit").setValue("");
			context.setModel(new sap.ui.model.json.JSONModel([]), "scopeServiceModel");
			context.getModel("scopeServiceModel").setData([{
				ProductID: productId,
				ProductName: productName
			}]);

			context.setModel(new sap.ui.model.json.JSONModel(), "sessionModel");

			context.getModel("buttonControlModel").setProperty("/itemAddBtn", false);

			return createdItem;
		},
		selectDefaultSessionandCreateItem: function (sessionID, sessionName) {
			this.getModel("scopeSessionModel").setData([{
				ProductID: sessionID,
				ProductName: sessionName
			}]);
			this.getModel("servicerequestModel").setProperty("/SessionID", sessionID);
			models.isSessionSelected = true;
			this.getModel("buttonControlModel").setProperty("/itemAddBtn", true);
			var createdItemSession = this.createDefaultItemForSR(sessionID, sessionName, models.SR_ITEM_20);
			this.onAddNewScopeRowOnServiceChange(createdItemSession);
			models.existingSession = sessionID;
			models.existingSessionProductName = sessionName;
			this.isItemsEdited = true;
		},
		showOSPSystem: function () {
			var showOSPContainer = this.showMessageForSystemInfoMsgStripBasedOnSystemAndSolman().shallAppendSolmanAtBotton;
			if (showOSPContainer) {
				this.showHideOSPBasedOnSystemAndServiceValidation();
			} else {
				var ReferenceSystemID = this.getModel("servicerequestModel").getProperty("/ReferenceSystemID");
				var SolmanComponent = this.getModel("servicerequestModel").getProperty("/SolmanComponent");
				var InstNo = this.getModel("servicerequestModel").getProperty("/InstNo");
				if (ReferenceSystemID === models.OSP_SYSTEM_REFERENCESYSTEMID && SolmanComponent === models.OSP_SYSTEM_SOLMAN && InstNo === models
					.OSP_SYSTEM_INSTNO) {
					this.disableOSPCheckbox();
				}
				this.getModel("buttonControlModel").setProperty("/enableOSPCheckbox", false);
				this.byId("idContainerOSPSystem").setVisible(false);
			}
		},
		showHideOSPBasedOnSystemAndServiceValidation: function () {
			var ReferenceSystemID = this.getModel("servicerequestModel").getProperty("/ReferenceSystemID");
			var SolmanComponent = this.getModel("servicerequestModel").getProperty("/SolmanComponent");
			var InstNo = this.getModel("servicerequestModel").getProperty("/InstNo");
			if ((ReferenceSystemID && ReferenceSystemID !== "0" && !formatter.showOSPSystemHBox(ReferenceSystemID, SolmanComponent, InstNo)) ||
				this.getModel("servicerequestModel").getProperty("/ServiceID") === models.EOD_PRODUCT) {
				this.byId("idContainerOSPSystem").setVisible(false);
			} else {
				this.byId("idContainerOSPSystem").setVisible(true);
			}
		},
		showOSPSystemForLoadItems: function () {
			var showOSPContainer = this.showMessageForSystemInfoMsgStripBasedOnSystemAndSolman().shallAppendSolmanAtBotton;
			if (showOSPContainer) {
				this.showHideOSPBasedOnSystemAndServiceValidation();
			} else {
				this.byId("idContainerOSPSystem").setVisible(false);
				var isSystemEnabled = this.getModel("editableFieldsModel").getProperty("/System");
				if (!isSystemEnabled) {
					this.getModel("editableFieldsModel").setProperty("/System", true);
				}

			}
		},
		selectSingleSession: function (srItems, oData, context) {
			var sessionID = oData.results[0].ComponentId;
			var sessionName = oData.results[0].ComponentText;
			context.getModel("scopeSessionModel").setData([{
				ProductID: sessionID,
				ProductName: sessionName
			}]);
			context.getModel("servicerequestModel").setProperty("/SessionID", sessionID);
			models.isSessionSelected = true;
			context.getModel("buttonControlModel").setProperty("/itemAddBtn", true);
			models.existingSession = sessionID;
			models.existingSessionProductName = sessionName;
			this.isItemsEdited = true;

			var doesItem20Exist = false;

			for (var i = 0; i < srItems.length; i++) {
				if (srItems[i].getVisible() && srItems[i].getCells()[0].data("item").ItemNo === models.SR_ITEM_20) {
					srItems[i].getCells()[0].data("item").ProductID = sessionID;
					srItems[i].getCells()[0].data("item").ProductName = sessionName;
					srItems[i].getCells()[2].getItems()[0].setText(sessionName);
					doesItem20Exist = true;
					break;
				}
			}
			if (!doesItem20Exist) {
				var createdItemSession = context.createDefaultItemForSR(sessionID, sessionName, models.SR_ITEM_20);
				context.onAddNewScopeRowOnServiceChange(createdItemSession);
			}
		},
		readSessionWhenServiceIsSwitched: function (productId) {
			var context = this;
			context.byId("SessionName-edit").setBusy(true);
			this.setModel(new JSONModel(), "sessionModel");
			this.getModel("SRS_Data").read("/ProductSet('" + productId + "')/toProductComponents", {
				success: function (oData) {
					var srItems = this.byId("idProductsTable-edit").getItems();
					if (oData.results.length > 0) {
						context.setModel(new sap.ui.model.json.JSONModel(oData.results), "sessionModel");
						context.byId("SessionName-edit").setValueState("None");
						if (oData.results.length === 1) {
							this.selectSingleSession(srItems, oData, context);
							this.setQualificationAndCallOffDaysForSession();
						} else {
							models.isSessionSelected = false;
							context.getModel("scopeSessionModel").setData([{
								ProductID: null,
								ProductName: null
							}]);
							context.byId("SessionName-edit").setSelectedKey("");
							//context.byId("SessionText-edit").setVisible(false);
							for (var i = 0; i < srItems.length; i++) {
								if (srItems[i].getVisible() && srItems[i].getCells()[0].data("item").ItemNo === models.SR_ITEM_20) {
									srItems[i].getCells()[0].data("item").ProductID = "";
									srItems[i].getCells()[0].data("item").ProductName = "";
									srItems[i].getCells()[2].getItems()[0].setText("");
									break;
								}
							}
						}
					} else {
						models.isSessionSelected = false;
						context.getModel("scopeSessionModel").setData([{
							ProductID: null,
							ProductName: null
						}]);
						context.byId("SessionName-edit").setSelectedKey("");
						//context.byId("SessionText-edit").setVisible(false);
						for (var i = 0; i < srItems.length; i++) {
							if (srItems[i].getVisible() && srItems[i].getCells()[0].data("item").ItemNo === models.SR_ITEM_20) {
								srItems[i].getCells()[0].data("item").ProductID = "";
								srItems[i].getCells()[0].data("item").ProductName = "";
								srItems[i].getCells()[2].getItems()[0].setText("");
								break;
							}
						}
					}
					if (this.getModel("servicerequestModel").getProperty("/ReferenceSystemID") && this.getModel("servicerequestModel").getProperty(
							"/ReferenceSystemID") !== "0") {
						this.validateSelectedSystem(null, "SESSION");
					}
					this.showOSPSystem();
					this.recalculateCallOffDays();
					context.byId("SessionName-edit").setBusy(false);
					models.onCreateValidate(this);

					//Workaround  current drop-down issue in scope section
					//models.tempSolutionforDropDownIssue();

				}.bind(context),
				error: function () {
					models.isSessionSelected = false;
					context.setModel(new sap.ui.model.json.JSONModel(), "sessionModel");
					context.byId("SessionName-edit").setValueState("Error");
					context.byId("SessionName-edit").setValue();
					//	context.byId("SessionText-edit").setVisible(false);
					context.byId("SessionName-edit").setBusy(false);
					this.recalculateCallOffDays();
				}.bind(context)
			});

		},
		onSessionIdChange: function (oEvent) {
			var productId, productName;
			var createdItem;
			var context = this;

			if (oEvent.getSource().getSelectedItem()) {
				productId = oEvent.getSource().getSelectedItem().getKey();
				var fieldTxt = oEvent.getSource().getSelectedItem().getText();
				var fieldTxtSplitArr = fieldTxt.split("-");
				if (fieldTxtSplitArr.length > 2) {
					for (var k = 1; k < fieldTxtSplitArr.length; k++) {
						if (productName) {
							productName += "-" + fieldTxtSplitArr[k];
						} else {
							productName = fieldTxtSplitArr[k];
						}
					}
				} else if (fieldTxt) {
					productName = fieldTxtSplitArr[1].trim();
				}
				if (productId === models.SESSION_READINESS_CHECK) {
					createdItem = this.createDefaultItemForSR(productId, productName, models.SR_ITEM_15);
				} else {
					createdItem = this.createDefaultItemForSR(productId, productName, models.SR_ITEM_20);
				}
				if (productId && productName) {
					this.byId("SessionName-edit").setValueState(null);
					this.byId("SessionName-edit").setTooltip(this.getResourceBundle().getText("session"));
					this.byId("SessionName-edit").setValueStateText(this.getResourceBundle().getText("noComponentselected"));
				} else {
					this.byId("SessionName-edit").setValueState("Warning");
					this.byId("SessionName-edit").setTooltip(this.getResourceBundle().getText("txtMsgEnterSession"));
					this.byId("SessionName-edit").setValueStateText(this.getResourceBundle().getText("txtMsgEnterSession"));
				}
			}

			var dialog = new Dialog({
				title: "Confirm",
				type: "Message",
				state: 'Warning',
				beginButton: new Button({
					text: "Yes",
					press: function () {
						models.existingSession = productId;
						models.existingSessionProductName = productName;
						context.deleteAllItems(createdItem, 1);
						models.isSessionSelected = false;
						context.getModel("buttonControlModel").setProperty("/enableDeleteAllItems", context.setDeleteAllButtonEnabled());
						var dialogContentSid = dialog.getContent()[0].sId;
						if (dialogContentSid.includes("html")) {
							this.clearSelectedSystem();
							this.byId("idSystemCombo").setTokens([]);
						}
						this.showOSPSystem();
						models.onCreateValidate(context);
						context.byId("SessionName-edit").setValueState("Error");
						context.byId("SessionText-edit").setVisible(false);
						context.setQualificationAndCallOffDaysForSession();
						dialog.close();
					}.bind(this)
				}),
				endButton: new Button({
					text: "No",
					type: "Emphasized",
					press: function () {
						context.byId("SessionName-edit").setSelectedKey(models.existingSession);
						context.byId("SessionText-edit").setVisible(true);
						context.byId("SessionText-edit").setHref(models.setSessionHREF(models.existingSession));
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});

			if (productId) {
				models.isSessionSelected = true;
				this.getModel("buttonControlModel").setProperty("/itemAddBtn", true);
			} else {
				models.isSessionSelected = false;
				//	this.getModel("buttonControlModel").setProperty("/itemAddBtn", false);
			}

			if (!models.existingSession) {
				if (productId) {
					this.onAddNewScopeRowOnServiceChange(createdItem);
					models.existingSession = productId;
					models.existingSessionProductName = productName;
					this.isItemsEdited = true;
				}
				if (this.getModel("servicerequestModel").getProperty("/ReferenceSystemID") && this.getModel("servicerequestModel").getProperty(
						"/ReferenceSystemID") !== "0") {
					this.validateSelectedSystem(null, "SESSION");
				}
				this.showOSPSystem();
				models.onCreateValidate(this);
				context.byId("SessionName-edit").setValueState(null);
				this.setQualificationAndCallOffDaysForSession();
			} else {
				var selectedKey = oEvent.getSource().getSelectedKey();
				if (selectedKey) {
					var srItems = this.byId("idProductsTable-edit").getItems();
					var visibleItemCount = 0;
					for (var i = 0; i < srItems.length; i++) {
						if (srItems[i].getVisible()) {
							visibleItemCount++;
						}
					}
					if (selectedKey === models.SESSION_READINESS_CHECK && visibleItemCount > 2) {
						context.byId("SessionName-edit").setSelectedKey(models.existingSession);
						//	context.byId("SessionText-edit").setVisible(true);
						context.byId("SessionName-edit").focus()
						MessageBox.information("Please remove item 30+ to select Readiness Check Session");
						return;
					}
					for (var i = 0; i < srItems.length; i++) {
						if (srItems[i].getVisible() && srItems[i].getCells()[0].data("item").ItemNo === models.SR_ITEM_20 || srItems[i].getVisible() &&
							srItems[i].getCells()[0].data("item").ItemNo === models.SR_ITEM_15) {
							if (productId === models.SESSION_READINESS_CHECK) {
								srItems[i].getCells()[1].getItems()[0].setText(formatter.removePrecedingZerosInItemNo(models.SR_ITEM_15));
								this.getModel("buttonControlModel").setProperty("/itemAddBtn", false);
							} else {
								srItems[i].getCells()[1].getItems()[0].setText(formatter.removePrecedingZerosInItemNo(models.SR_ITEM_20));
								this.getModel("buttonControlModel").setProperty("/itemAddBtn", true);
							}
							srItems[i].getCells()[0].data("item").ProductID = productId;
							srItems[i].getCells()[0].data("item").ProductName = productName;
							srItems[i].getCells()[2].getItems()[0].setText(productName);
							break;
						}
					}
					//this.byId("SessionText-edit").setVisible(true);
					models.isSessionSelected = true;
					this.isItemsEdited = true;
					models.existingSession = productId;
					models.existingSessionProductName = productName;
					if (this.getModel("servicerequestModel").getProperty("/ReferenceSystemID") && this.getModel("servicerequestModel").getProperty(
							"/ReferenceSystemID") !== "0") {
						this.validateSelectedSystem(null, "SESSION");
					}
					this.showOSPSystem();
					models.onCreateValidate(this);
					context.byId("SessionName-edit").setValueState(null);
					this.setQualificationAndCallOffDaysForSession();
				} else {
					if (this.getModel("servicerequestModel").getProperty("/ReferenceSystemID") && this.getModel("servicerequestModel").getProperty(
							"/ReferenceSystemID") !== "0") {
						this.validateSelectedSystem(dialog, "SESSION");
						models.onCreateValidate(this);
						context.byId("SessionName-edit").setValueState(null);
					} else {
						dialog.addContent(
							new Text({
								text: "Removing the Component will remove all Items 30+.  Do you still want to continue?"
							})
						);
						dialog.open();
					}
					this.isItemsEdited = true;
				}
			}

			if (!this.getModel("scopeSessionModel")) {
				this.setModel(new JSONModel([{
					ProductID: null,
					ProductName: null
				}]), "scopeSessionModel");
			}

			this.getModel("scopeSessionModel").setData([{
				ProductID: productId,
				ProductName: productName
			}]);
		},
		setQualificationAndCallOffDaysForSession: function () {
			var selectedService = this.getModel("servicerequestModel").getProperty("/ServiceID");
			if (selectedService === "9505690") {
				var items = this.byId("idProductsTable-edit").getItems();
				var selectedQualification = "93200422";
				if (items) {
					for (var i = 0; i < items.length; i++) {
						if (items[i].getVisible()) {
							var SRItem = items[i].getCells()[0].data("item");
							if (SRItem.ItemNo === models.SR_ITEM_20) {
								items[i].getCells()[3].getItems()[0].setSelectedKey(selectedQualification);
								items[i].getCells()[0].data("item").QualifiactionID = selectedQualification;
								items[i].getCells()[0].data("item").CallOffDays = "2";
								items[i].getCells()[4].getItems()[1].setValue("2");
								var startDate = items[i].getCells()[5].getItems()[0].getDateValue();
								if (startDate) {
									items[i].getCells()[6].getItems()[0].setDateValue(models.addDaysToDate(startDate, 1));
								}
								items[i].getCells()[0].data("item").EndDate = items[i].getCells()[6].getItems()[0].getDateValue();
								this.recalculateCallOffDays();
								if (this.getModel("qualificationModel")) {
									var qualifications = this.getModel("qualificationModel").getData();
									for (var k = 0; k < qualifications.length; k++) {
										if (qualifications[k].DdlbKey === selectedQualification) {
											items[i].getCells()[3].getItems()[0].setTooltip(qualifications[k].Value);
											items[i].getCells()[0].data("item").QualificationName = qualifications[k].Value;
											break;
										}
									}
								}
								break;

							}
						}
					}
				}
			}
		},
		deleteAllItems: function (createdItem, index) {
			var items = this.byId("idProductsTable-edit").getItems();
			if (index === 0) {
				for (var i = 0; i < items.length; i++) {
					items[i].getCells()[0].getItems()[0].data({
						"isDeleted": "true"
					});
					items[i].setVisible(false);
				}
				/*
				if (createdItem) {
					this.onAddNewScopeRowOnServiceChange(createdItem);
				}*/
				this.byId("SessionName-edit").setSelectedKey("");

			}

			if (index === 1) {
				for (var i = 0; i < items.length; i++) {
					var SRItem = items[i].getCells()[0].data("item");
					if (SRItem.ItemNo != models.SR_ITEM_10) {
						items[i].getCells()[0].getItems()[0].data({
							"isDeleted": "true"
						});
						items[i].setVisible(false);
					}
				}
				/*
				if (createdItem) {
					this.onAddNewScopeRowOnServiceChange(createdItem);
				}*/
			}
			this.getModel("buttonControlModel").setProperty("/itemAddBtn", false);
			this.recalculateCallOffDays();
			this.getModel("buttonControlModel").setProperty("/enableDeleteAllItems", this.setDeleteAllButtonEnabled());
		},

		setSession: function () {
			var doesSessionExist = false;
			this.byId("SessionName-edit").setBusy(true);
			var serviceID = this.getModel("servicerequestModel").getProperty("/ServiceID");
			var sessionID = this.getModel("servicerequestModel").getProperty("/SessionID");
			var sessionName = this.getModel("servicerequestModel").getProperty("/SessionName");
			var SRStatus = this.getModel("servicerequestModel").getProperty("/StatusCode");
			this.getModel("SRS_Data").read("/ProductSet('" + serviceID + "')/toProductComponents", {
				success: function (oData) {
					this.byId("SessionName-edit").setBusy(false);
					var sessions = oData.results;
					if (sessions.length) {
						this.setModel(new sap.ui.model.json.JSONModel(sessions), "sessionModel");
						for (var i = 0; i < sessions.length; i++) {
							if (sessionID === sessions[i].ComponentId) {
								doesSessionExist = true;

								this.setModel(new JSONModel([{
									ProductID: sessionID,
									ProductName: sessions[i].ComponentText
								}]), "scopeSessionModel");

								break;
							}
						}

						if (doesSessionExist) {
							this.byId("SessionText-edit").setHref(models.setSessionHREF(sessionID));

						} else {
							if (SRStatus !== models.STATUS_SOCREATED || SRStatus !== models.STATUS_CANCELED) {
								models.existingSession = "";
								models.existingSessionProductName = "";
								this.deleteAllItems(null, 1);
								models.isSessionSelected = false;
								this.getModel("buttonControlModel").setProperty("/enableDeleteAllItems", this.setDeleteAllButtonEnabled());
								this.showOSPSystem();
								models.onCreateValidate(this);
								this.byId("SessionName-edit").setValueState("Error");
								this.byId("SessionText-edit").setVisible(false);
								this.setQualificationAndCallOffDaysForSession();
								this.byId("SessionName-edit").setSelectedKey("");
								this.byId("SessionText-edit").setText("");
								if (this.getModel("buttonControlModel").getProperty("/isEdit")) {
									MessageBox.information('Component "' + sessionID + ' - ' + sessionName +
										'" does not exist any more. Please select a new component.');
								} else {
									MessageBox.information('Component "' + sessionID + ' - ' + sessionName +
										'" does not exist any more. Please switch to edit mode and select a new component.');
								}
								var oEventBus = sap.ui.getCore().getEventBus();
								oEventBus.publish("deleteSRItemsForDisplayScope", "setDeleteSRItemsForDisplayScope");
							}
						}
						models.tempSolutionforDropDownIssue();
						return doesSessionExist;
					}
				}.bind(this),
				error: function () {
					this.byId("SessionName-edit").setBusy(false);
					this.byId("SessionName-edit").setValue("");
					this.byId("SessionText-edit").setText("");
					return doesSessionExist;
				}.bind(this)
			});
		},

		pressDeleteAllItems: function () {
			var i18 = this.getResourceBundle();
			var context = this;
			var dialog = new Dialog({
				title: i18.getText("deleteAllItems"),
				type: "Message",
				state: 'Warning',
				content: new Text({
					text: i18.getText("txtPopupDeleteAllItems")
				}),
				beginButton: new Button({
					text: "Yes",
					press: function () {
						var items = context.byId("idProductsTable-edit").getItems();
						for (var i = 0; i < items.length; i++) {
							var SRItem = items[i].getCells()[0].data("item");
							if (!(SRItem.ItemNo === models.SR_ITEM_10 || SRItem.ItemNo === models.SR_ITEM_20)) {
								items[i].getCells()[0].getItems()[0].data({
									"isDeleted": "true"
								});
								items[i].setVisible(false);
							}
						}
						context.recalculateCallOffDays();
						context.getModel("buttonControlModel").setProperty("/enableDeleteAllItems", context.setDeleteAllButtonEnabled());
						dialog.close();
					}.bind(this)
				}),
				endButton: new Button({
					text: "No",
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();

		},

		handleDelete: function (oEvent) {
			var context = this;
			var itemEvent = oEvent.getSource().getParent().getParent();
			var itemIndex = this.byId("idProductsTable-edit").indexOfItem(itemEvent);
			var txt = "Are you sure you want to delete line item?\n\n" + this.getResourceBundle().getText("txtShiftDeleteTxt");
			var dialog = new Dialog({
				title: "Delete Row",
				type: "Message",
				state: 'Warning',
				content: new Text({
					text: txt
				}),
				beginButton: new Button({
					text: "Yes",
					press: function () {
						context.deleteSingleItemUponDeleteBtnPress(itemIndex);
						dialog.close();
					}.bind(this)
				}),
				endButton: new Button({
					text: "No",
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			if (this.shiftkeyPressed) {
				this.deleteSingleItemUponDeleteBtnPress(itemIndex);
			} else {
				dialog.open();
			}

		},
		deleteSingleItemUponDeleteBtnPress: function (itemIndex) {
			this.isItemsEdited = true;
			models.onCreateValidate(this);
			this.byId("idProductsTable-edit").getItems()[itemIndex].getCells()[0].getItems()[0].data({
				"isDeleted": "true"
			});
			this.byId("idProductsTable-edit").getItems()[itemIndex].setVisible(false);
			this.recalculateCallOffDays();
			this.getModel("buttonControlModel").setProperty("/enableDeleteAllItems", this.setDeleteAllButtonEnabled());
		},
		handleItemCopy: function (oEvent) {
			var itemEvent = oEvent.getSource().getParent().getParent();
			var product = itemEvent.getCells()[2].getItems()[1].getSelectedKey();
			var qualification = itemEvent.getCells()[3].getItems()[0].getSelectedKey();
			var callOffDays = itemEvent.getCells()[4].getItems()[0].getText();
			var startDate = itemEvent.getCells()[5].getItems()[0].getDateValue();
			var endDate = itemEvent.getCells()[6].getItems()[0].getDateValue();
			var deliveryTeam = itemEvent.getCells()[7].getItems()[0].getSelectedKey();
			var isDeliveryTeamModified = false;

			if (deliveryTeam) {
				isDeliveryTeamModified = true;
			}

			var newItem = {
				"ServiceRequestID": "",
				"HeaderGUID": "",
				"ItemNo": "",
				"QualifiactionID": qualification,
				"QualificationName": "",
				"CallOffDays": callOffDays,
				"StartDate": startDate,
				"EndDate": endDate,
				"ProductID": product,
				"ProductName": "",
				"DeliveryTeamID": deliveryTeam,
				"DeliveryTeamName": "",
				"ItemGUID": "",
				"ParentGUID": "",
				"RequestedDeliveryDate": null,
				"GoLiveDate": null,
				"ContractID": "",
				"ContractName": "",
				"ContractItemID": "",
				"ContractItemName": "",
				"DeliveryTeamChanged": isDeliveryTeamModified
			};

			var rowCount = this.getView().byId("idProductsTable-edit").getItems().length;
			this.getModel("servicerequestItemsModel").setProperty("/" + rowCount, newItem);
			MessageToast.show("Item is successfully Copied.", {
				duration: 1000
			});
			this.recalculateCallOffDays();

		},
		onAddNewScopeRow: function () {
			this.isItemsEdited = true;
			var rowCount = this.getView().byId("idProductsTable-edit").getItems().length;
			var requestDeliverDate = this.byId("reqdate-edit").getDateValue();
			var startDate, endDate;
			if (this.byId("reqdate-edit").getValue()) {
				startDate = new Date(requestDeliverDate);
				startDate.setHours(9, 0, 0, 0);
				endDate = new Date(requestDeliverDate);
				endDate.setHours(17, 0, 0, 0);
			} else {
				startDate = new Date();
				startDate.setHours(9, 0, 0, 0);
				endDate = new Date();
				endDate.setHours(17, 0, 0, 0);
			}
			var newItem = {
				"ServiceRequestID": "",
				"HeaderGUID": "",
				"ItemNo": "",
				"QualifiactionID": "",
				"QualificationName": "",
				"CallOffDays": "0",
				"StartDate": startDate,
				"EndDate": endDate,
				"ProductID": "",
				"ProductName": "",
				"DeliveryTeamID": "",
				"DeliveryTeamName": "",
				"ItemGUID": "",
				"ParentGUID": "",
				"RequestedDeliveryDate": null,
				"GoLiveDate": null,
				"ContractID": "",
				"ContractName": "",
				"ContractItemID": "",
				"ContractItemName": "",
				"DeliveryTeamChanged": false
			};

			this.getModel("servicerequestItemsModel").setProperty("/" + rowCount, newItem);
			models.onCreateValidate(this);
			models.SRItemsStartDateValidationEditMode(this);
			this.getModel("buttonControlModel").setProperty("/enableDeleteAllItems", this.setDeleteAllButtonEnabled());
			this.setDefaultItemDateLimit();
			this.recalculateCallOffDays();
		},

		setDefaultItemDateLimit: function () {
			var selectedContractItem = this.byId("contractItemId-edit").getSelectedKey();
			if (!selectedContractItem) {
				this.resetSRItemDateMinMaxLimit();
			}
		},

		onAddNewScopeRowOnServiceChange: function (item) {
			var rowCount = this.getView().byId("idProductsTable-edit").getItems().length;
			var requestDeliverDate = this.byId("reqdate-edit").getDateValue();
			var startDate, endDate;
			if (this.byId("reqdate-edit").getValue()) {
				startDate = requestDeliverDate;
				endDate = requestDeliverDate;
			} else {
				startDate = new Date();
				startDate.setHours(9, 0, 0, 0);
				endDate = new Date();
				endDate.setHours(17, 0, 0, 0);
			}

			this.getModel("servicerequestItemsModel").setProperty("/" + rowCount, item);
			models.SRItemsStartDateValidationEditMode(this);
			if (item.ItemNo === models.SR_ITEM_15) {
				this.getModel("buttonControlModel").setProperty("/itemAddBtn", false);
			} else {
				this.getModel("buttonControlModel").setProperty("/itemAddBtn", true);
			}
			this.getModel("buttonControlModel").setProperty("/enableDeleteAllItems", this.setDeleteAllButtonEnabled());
			this.setDefaultItemDateLimit();
		},

		onContractSelected: function (oEvent) {
			var serviceRequestModel = this.getModel("servicerequestModel").oData;
			var SRStatus = serviceRequestModel.StatusCode;
			var contractID = oEvent.getSource().getSelectedKey();
			if (!contractID && SRStatus === models.STATUS_APPROVED) {
				MessageBox.error("Contract cannot be empty");
				var SRItemsContract = this.getModel("servicerequestItemsModel").getData()[0].ContractID;
				this.byId("contractId-edit").setSelectedKey(SRItemsContract);
				return;
			}
			this.isItemsEdited = true;

			this.getModel("buttonControlModel").setProperty("/showContractValidationMessageStrip", false);
			this.byId("contractItemId-edit").setValueState(null);
			this.byId("idTextContactType").setText("");
			var tableItems = this.byId("idProductsTable-edit").getItems();
			for (var i = 0; i < tableItems.length; i++) {
				tableItems[i].getCells()[4].getItems()[1].setValueState("None");
			}
			var ServiceId = this.byId("ServiceName-edit").getSelectedKey();
			if (!ServiceId) {
				ServiceId = serviceRequestModel.ServiceID;
			}
			var reqDeliveryDate = this.byId("reqdate-edit").getDateValue();
			if (!reqDeliveryDate) {
				reqDeliveryDate = this.byId("reqdate-edit").getDateValue();
			}
			this.byId("contractItemId-edit").setSelectedKey("");
			this.byId("contractItemId-edit").setEnabled(false);
			this.getModel("SRS_Data_UserSet").setProperty("/AvailableCallOffDays", "0");
			this.getModel("buttonControlModel").setProperty("/showContractWorkAtRisk", false);

			if (contractID) {
				var SRItems = this.getModel("servicerequestItemsModel").getData();
				if (SRItems && SRItems.length > 0) {
					SRItems[0].ContractID = contractID;
				}
			}

			if (ServiceId && reqDeliveryDate && contractID) {
				models.getContracts(this, "/ContractSet", {
					"RecDelDate": reqDeliveryDate,
					"ProductID": ServiceId,
					"ContractID": contractID
				}, "contractItemModel", "contractItemId-edit", true, null, null);
			}

			this.setDefaultItemDateLimit();

		},
		setTimeForEndDate: function (selectedControl, servicerequestItemDate, dateShift) {
			var hoursDiff = selectedControl.getDateValue().getHours() - this.item_20_dateTime.getHours();
			var minutesDiff = selectedControl.getDateValue().getMinutes() - this.item_20_dateTime.getMinutes();

			var hoursToSet = new Date(servicerequestItemDate).getHours() + hoursDiff;
			var minutesToSet = new Date(servicerequestItemDate).getMinutes() + minutesDiff;
			var afterDateShift = models.dateShiftForItems(dateShift, servicerequestItemDate);
			if (afterDateShift) {
				afterDateShift.setHours(hoursToSet);
				afterDateShift.setMinutes(minutesToSet);
			}
			//if(selectedControl.getDateValue().getHours() === 0){
			//	afterDateShift.setDate(afterDateShift.getDate() + 1);
			//}
			return afterDateShift;
		},
		resetItemDatesBasedOnRDD: function (context, dateString, type, selectedControl) {

			var servicerequestItemsModel = context.getModel("servicerequestItemsModel").getData();
			var reqDelDate = new Date(dateString);
			var dateShift = 0;
			var sessionDate = dateString;
			for (var i = 0; i < servicerequestItemsModel.length; i++) {
				if (servicerequestItemsModel[i].ItemNo === models.SR_ITEM_10) {
					context.getModel("servicerequestItemsModel").setProperty("/" + i + "/RequestedDeliveryDate", reqDelDate);
				}
				if (servicerequestItemsModel[i].ItemNo === models.SR_ITEM_20 && servicerequestItemsModel[i].StartDate) {
					if (selectedControl.getId().includes("idProductsTable")) {
						if (this.item_20_dateTime.toDateString() !== reqDelDate.toDateString()) {
							dateShift = models.calculateDateShiftTime(this.item_20_dateTime.toString(), reqDelDate.toString(), true);
						}
					} else {
						dateShift = models.calculateDateShiftTime(this.item_20_dateTime.toString(), reqDelDate.toString(), true);
					}
					if (type === "SESSION") {
						if (selectedControl.getId().includes("idProductsTable")) {
							var endDateAfterDateShift = this.setTimeForEndDate(selectedControl, servicerequestItemsModel[i].EndDate, dateShift);
							context.getModel("servicerequestItemsModel").setProperty("/" + i + "/StartDate", new Date(dateString));
							context.getModel("servicerequestItemsModel").setProperty("/" + i + "/EndDate", endDateAfterDateShift);
						} else {
							if (servicerequestItemsModel[i].ItemNo === models.SR_ITEM_20) {
								var tempDate = models.dateShiftForItems(dateShift, servicerequestItemsModel[i].StartDate);
								sessionDate = tempDate;
								context.getModel("servicerequestItemsModel").setProperty("/" + i + "/StartDate", tempDate);
							} else {
								context.getModel("servicerequestItemsModel").setProperty("/" + i + "/StartDate", models.dateShiftForItems(dateShift,
									servicerequestItemsModel[i].StartDate));
							}

							context.getModel("servicerequestItemsModel").setProperty("/" + i + "/EndDate", models.dateShiftForItems(dateShift,
								servicerequestItemsModel[i].EndDate));
						}
					}
				}
			}

			if (type === "ALL") {
				for (var i = 0; i < servicerequestItemsModel.length; i++) {
					if (selectedControl.getId().includes("idProductsTable")) {
						if (servicerequestItemsModel[i].ItemNo === models.SR_ITEM_20) {
							context.getModel("servicerequestItemsModel").setProperty("/" + i + "/StartDate", new Date(dateString));
						} else {
							var startDateAfterDateShift = this.setTimeForEndDate(selectedControl, servicerequestItemsModel[i].StartDate, dateShift);
							context.getModel("servicerequestItemsModel").setProperty("/" + i + "/StartDate", new Date(startDateAfterDateShift));
							var table = this.byId("idProductsTable-edit");
							if (startDateAfterDateShift.getHours() === 0) {
								if (table.getItems()[i] && table.getItems()[i].getCells()[5].getItems()[0]) {
									table.getItems()[i].getCells()[5].getItems()[0].setDateValue(startDateAfterDateShift);
								}
							}

						}
						var endDateAfterDateShift = this.setTimeForEndDate(selectedControl, servicerequestItemsModel[i].EndDate, dateShift);
						context.getModel("servicerequestItemsModel").setProperty("/" + i + "/EndDate", endDateAfterDateShift);
					} else {
						if (servicerequestItemsModel[i].ItemNo === models.SR_ITEM_20) {
							var tempDate = models.dateShiftForItems(dateShift, servicerequestItemsModel[i].StartDate);
							sessionDate = tempDate;
							context.getModel("servicerequestItemsModel").setProperty("/" + i + "/StartDate", tempDate);
						} else {
							context.getModel("servicerequestItemsModel").setProperty("/" + i + "/StartDate", models.dateShiftForItems(dateShift,
								servicerequestItemsModel[i].StartDate));
						}
						context.getModel("servicerequestItemsModel").setProperty("/" + i + "/EndDate", models.dateShiftForItems(dateShift,
							servicerequestItemsModel[i].EndDate));
					}
				}
			}

			if (selectedControl.getId().includes("idProductsTable")) {
				this.item_20_dateTime = new Date(dateString);
			} else {
				this.item_20_dateTime = sessionDate;
			}
			models.SRItemsStartDateValidationEditMode(this);
		},
		requestDelDateOnChange: function (oEvent) {

			if (!oEvent.getParameter("valid")) {
				models.dateValidation(this.byId("reqdate-edit"), this.reqDelDate, this);
				return;
			}

			var eventValue = oEvent.getSource().getDateValue();

			/*
			var hasEnteredDateValid = new Date(oEvent.getSource().getValue());
			
			if(!hasEnteredDateValid instanceof Date){
				this.byId("reqdate-edit").setDateValue(this.reqDelDate);
				return;
			}
			*/
			if (!eventValue) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.information(
					"Requested Delivery date cannot be Empty", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
				this.byId("reqdate-edit").setDateValue(this.reqDelDate);
				return;
			}
			var exstValue = this.getModel("servicerequestItemsModel").getProperty("/0/RequestedDeliveryDate");
			this.reqDelDate = oEvent.getSource().getDateValue();
			var selectedControl = oEvent.getSource();
			var i18 = this.getResourceBundle();
			var dialogMsg = i18.getText("dialogForChangeReqgDDStatusText");
			var StartDateBtnMsg = i18.getText("dialogForChangeRDDSesssionSD");
			if (selectedControl.getId().includes("idProductsTable")) {
				dialogMsg = i18.getText("txtDialogMsgOnChangeStartDateForItem_20");
				StartDateBtnMsg = i18.getText("dialogForChangeRDDSesssionSDTime");
			}
			var context = this;
			if (exstValue) {
				var dialog = new Dialog({
					title: i18.getText("dialogForChangeStatusTitle"),
					type: 'Message',
					state: 'Warning',
					content: new Text({
						text: dialogMsg
					}),
					buttons: [
						new Button({
							text: i18.getText("dialogForChangeRDDAll"),
							press: function () {
								this.isItemsEdited = true;
								context.setRequestedDeliveryDate(context, eventValue, "ALL", selectedControl); //set to ALL
								dialog.close();
							},
						}),
						new Button({
							text: StartDateBtnMsg,
							press: function () {
								this.isItemsEdited = true;
								context.setRequestedDeliveryDate(context, eventValue, "SESSION", selectedControl);
								dialog.close();
							},
						}),
						new Button({
							text: i18.getText("dialogForChangeRDDCancel"),
							press: function () {
								context.getModel("servicerequestItemsModel").setProperty("/0/RequestedDeliveryDate", exstValue);
								context.byId("reqdate-edit").setDateValue(exstValue);
								if (selectedControl.getId().includes("idProductsTable")) {
									selectedControl.setDateValue(exstValue);
								}
								dialog.close();
							}
						})
					],
					afterClose: function () {
						dialog.destroy();
					}
				});
				var SRItems = context.byId("idProductsTable-edit").getItems();
				var doesMoreThanTwoItemsExist = false;
				var count = 0;
				for (var i = 0; i < SRItems.length; i++) {
					if (SRItems[i].getVisible()) {
						count++;
						if (count > 2) {
							doesMoreThanTwoItemsExist = true;
							break;
						}
					}
				}
				if (doesMoreThanTwoItemsExist) {
					dialog.open();
				} else {
					this.isItemsEdited = true;
					context.setRequestedDeliveryDate(context, eventValue, "ALL", selectedControl);
				}

			} else {
				this.isItemsEdited = true;
				context.setRequestedDeliveryDate(context, eventValue, "ALL", selectedControl);
			}
		},
		setRequestedDeliveryDate: function (context, eventValue, type, selectedControl) {
			context.getModel("servicerequestItemsModel").setProperty("/0/RequestedDeliveryDate", eventValue);
			var selectedContract = context.byId("contractId-edit").getSelectedKey();
			var selectedContractItem = context.byId("contractItemId-edit").getSelectedKey();
			this.resetSRItemDateMinMaxLimit();
			context.reloadContract(true, selectedContract, selectedContractItem);
			if (eventValue) {
				if (selectedControl.getId().includes("idProductsTable")) {
					context.resetItemDatesBasedOnRDD(context, eventValue.toString(), type, selectedControl);
				} else {
					context.resetItemDatesBasedOnRDD(context, eventValue.toDateString(), type, selectedControl);
				}
			} else {
				models.SRItemsStartDateValidationEditMode(this);
			}
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.publish("showPotentialLeadTime", "showPotentialLeadTimeSuccess", eventValue);
		},
		resetSRItemDateMinMaxLimit: function () {
			var items = this.byId("idProductsTable-edit").getItems();
			for (var i = 0; i < items.length; i++) {
				items[i].getCells()[5].getItems()[0].setMinDate(null);
				items[i].getCells()[5].getItems()[0].setMaxDate(null);
				items[i].getCells()[5].getItems()[0].setValueState(null);
				items[i].getCells()[5].getItems()[0].setValueStateText("");

				items[i].getCells()[6].getItems()[0].setMinDate(null);
				items[i].getCells()[6].getItems()[0].setMaxDate(null);
				items[i].getCells()[6].getItems()[0].setValueState(null);
				items[i].getCells()[6].getItems()[0].setValueStateText("");
			}
		},
		reloadContract: function (loadDefaultContract, selectedContract, selectedContractItem) {
			this.setModel(new JSONModel(), "contractSetModel");
			this.setModel(new JSONModel(), "contractItemModel");
			var serviceRequestModel = this.getModel("servicerequestModel").oData;
			var CustomerId = "";
			if (this.getModel("SRS_Data_UserSet").getData().customerId) {
				CustomerId = this.getModel("SRS_Data_UserSet").getData().customerId;
			} else if (serviceRequestModel && serviceRequestModel.CustomerID) {
				CustomerId = serviceRequestModel.CustomerID;
			}
			var serviceId = this.byId("ServiceName-edit").getSelectedKey();
			this.byId("contractId-edit").setSelectedKey("");
			this.byId("contractItemId-edit").setSelectedKey("");
			this.byId("contractId-edit").setEnabled(false);
			this.byId("contractItemId-edit").setEnabled(false);
			//add contract validate
			if (CustomerId && serviceId) {
				models.getContracts(this, "/ContractSet", {
					"CustomerID": CustomerId,
					"ProductID": serviceId,
					"RecDelDate": this.reqDelDate // added for validation 
				}, "contractSetModel", "contractId-edit", loadDefaultContract, selectedContract, selectedContractItem);
			}
		},
		CallOffDaysOnLiveChange: function (oEvent) {
			var val = oEvent.getSource().getValue();
			var selectedService = this.getModel("servicerequestModel").getProperty("/ServiceID");
			if (selectedService === "9500310") {
				if (val.includes(".")) {
					this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", false);
					oEvent.getSource().setValueState("Error");
					oEvent.getSource().setValueStateText("Value must be either 0 or a positive integer");
					return;
				}
			}

			if (parseInt(val) < 0) {
				this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", false);
				oEvent.getSource().setValueState("Error");
				oEvent.getSource().setValueStateText("Value must not be negative");
				return;
			} else {
				oEvent.getSource().setValueState("None");
				this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", true);
				models.onCreateValidate(this);
			}

			oEvent.getSource().getParent().getParent().getCells()[0].data("item").CallOffDays = val;
			this.recalculateCallOffDays();
			this.isItemsEdited = true;

			var selectedContractItem = this.byId("contractItemId-edit").getSelectedItem();
			if (selectedContractItem) {
				var contractItemData = selectedContractItem.data("contractItem");
				var callOffDays = this.byId("totalcalloff-Edit").getText();
				var validcheckFail = models.validateContractItemBasedOnCallOffDays(contractItemData, callOffDays, this,
					"msgStripContractItemValidation");
				if (validcheckFail) {
					oEvent.getSource().setValueState("Error");
					this.byId("contractItemId-edit").setValueState("Error");
				} else {
					oEvent.getSource().setValueState(null);
					this.byId("contractItemId-edit").setValueState(null);
				}
			}
		},
		callOffDaysOnChange: function (oEvent) {
			if (!oEvent.getSource().getValue()) {
				oEvent.getSource().setValue("0");
			}
		},
		recalculateCallOffDays: function () {
			var table = this.byId("idProductsTable-edit");
			var reCalculatedDays = 0;
			var isOK = true;
			for (var i = 0; i < table.getItems().length; i++) {
				if (table.getItems()[i].getVisible() && table.getItems()[i].getCells()[0].data("item") && table.getItems()[i].getCells()[0].data(
						"item").ItemNo !== models.SR_ITEM_10 && table.getItems()[i].getCells()[0].getItems()[0].data("isDeleted") === "false") {
					var tempValue = table.getItems()[i].getCells()[4].getItems()[1].getValue();
					if (tempValue) {
						if (!isNaN(tempValue) && parseInt(tempValue) >= 0) { // Allow only [0-9], float & .(dot) [No chars, spl chars, signs allowed].
							table.getItems()[i].getCells()[4].getItems()[1].setValueState("None");
							reCalculatedDays += parseFloat(table.getItems()[i].getCells()[4].getItems()[1].getValue());
						} else {
							isOK = false;
							table.getItems()[i].getCells()[4].getItems()[1].setValueState("Error");
							table.getItems()[i].getCells()[4].getItems()[1].setValueStateText("Invalid Value");
						}
					}
				}
			}

			if (isOK) {
				this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", true);
				models.onCreateValidate(this);
			} else {
				this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", false);
			}

			for (var i = 0; i < table.getItems().length; i++) {
				if (table.getItems()[i].getCells()[0].data("item") && table.getItems()[i].getCells()[0].data("item").ItemNo == models.SR_ITEM_10 &&
					table.getItems()[i].getCells()[0].getItems()[0].data("isDeleted") === "false") {
					table.getItems()[i].getCells()[4].getItems()[0].setText(reCalculatedDays);
				}
			}

			this.byId("totalcalloff-Edit").setText(reCalculatedDays);
			this.getModel("servicerequestModel").setProperty("/TotalCallOffDays", reCalculatedDays.toString());

		},
		comboProductOnChange: function (oEvent) {
			this.isItemsEdited = true;
			var key = "";
			var text = "";
			if (oEvent.getSource().getSelectedItem()) {
				key = oEvent.getSource().getSelectedItem().getKey();
				text = oEvent.getSource().getSelectedItem().getText();
			}
			oEvent.getSource().getParent().getParent().getCells()[0].data("item").ProductID = key;
			oEvent.getSource().getParent().getParent().getCells()[0].data("item").ProductName = text;
		},
		comboQualOnChange: function (oEvent) {
			this.isItemsEdited = true;
			var key = "";
			var text = "";
			if (oEvent.getSource().getSelectedItem()) {
				key = oEvent.getSource().getSelectedItem().getKey();
				text = oEvent.getSource().getSelectedItem().getText();
			}
			oEvent.getSource().getParent().getParent().getCells()[0].data("item").QualifiactionID = key;
			oEvent.getSource().getParent().getParent().getCells()[0].data("item").QualificationName = text;
		},
		comboDeliveryOnChange: function (oEvent) {
			this.isItemsEdited = true;
			var key = "";
			var text = "";
			if (oEvent.getSource().getSelectedItem()) {
				key = oEvent.getSource().getSelectedItem().getKey();
				text = oEvent.getSource().getSelectedItem().getText();
			}
			oEvent.getSource().getParent().getParent().getCells()[0].data("item").DeliveryTeamID = key;
			oEvent.getSource().getParent().getParent().getCells()[0].data("item").DeliveryTeamName = text;
			oEvent.getSource().getParent().getParent().getCells()[0].data("item").DeliveryTeamChanged = true;
		},
		handleChangeStartD: function (oEvent) {
			this.isItemsEdited = true;
			//Date Validation for Typo
			if (oEvent.getParameter("valid") !== undefined && !oEvent.getParameter("valid")) {
				models.dateValidationSRItems(oEvent.getSource(), oEvent.getSource().getDateValue(), formatter.dateTime(oEvent.getSource().getDateValue()),
					this);
				return;
			}

			var date = oEvent.getSource().getDateValue();
			var startDate = oEvent.getSource().getParent().getParent().getCells()[0].data("item").StartDate;
			if (!date && oEvent.getSource().data("itemNo") === models.SR_ITEM_20) {
				var msg = this.getResourceBundle().getText("txtDialogStartDateNotEmpty");
				MessageBox.error(msg);
				oEvent.getSource().setDateValue(startDate);
				return;
			}

			// Is entered date valid? (incase user had made a mistake while typing!)
			if (oEvent.getSource().isValidValue()) {
				if (date) {
					if (oEvent.getSource().data("itemNo") !== models.SR_ITEM_20) {

						//set end date based on Start Date
						startDate = oEvent.getSource().getParent().getParent().getCells()[0].data("item").StartDate;
						var hoursDiff = 0;
						var minutesDiff = 0;
						var dateShift = 0;
						if (startDate) {
							hoursDiff = date.getHours() - startDate.getHours();
							minutesDiff = date.getMinutes() - startDate.getMinutes();
							if (startDate.toDateString() !== date.toDateString()) {
								dateShift = models.calculateDateShiftTime(startDate.toString(), date.toString(), false);
							}
						}
						var afterDateShift = date;
						if (oEvent.getSource().getParent().getParent().getCells()[0].data("item").EndDate) {
							afterDateShift = models.dateShiftForItems(dateShift, oEvent.getSource().getParent().getParent().getCells()[0].data("item").EndDate);
							afterDateShift.setHours(afterDateShift.getHours() + hoursDiff);
							afterDateShift.setMinutes(afterDateShift.getMinutes() + minutesDiff);
						}

						oEvent.getSource().getParent().getParent().getCells()[0].data("item").EndDate = afterDateShift;
						oEvent.getSource().getParent().getParent().getCells()[6].getItems()[0].setDateValue(afterDateShift);

						oEvent.getSource().getParent().getParent().getCells()[0].data("item").StartDate = date;
						models.onCreateValidate(this);
						oEvent.getSource().setValueState("None");
						oEvent.getSource().getParent().getParent().getCells()[6].getItems()[0].setValueState("None");
					} else {
						this.requestDelDateOnChange(oEvent);
					}
				} else {
					oEvent.getSource().getParent().getParent().getCells()[0].data("item").StartDate = date;
					oEvent.getSource().getParent().getParent().getCells()[0].data("item").EndDate = date;
					this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", false);
					oEvent.getSource().setValueState("Error");
					oEvent.getSource().setValueStateText(this.getResourceBundle().getText("fieldValueEmpty"));
					oEvent.getSource().getParent().getParent().getCells()[6].getItems()[0].setDateValue(null);
					oEvent.getSource().getParent().getParent().getCells()[6].getItems()[0].setValueState("Error");
					oEvent.getSource().getParent().getParent().getCells()[6].getItems()[0].setValueStateText(this.getResourceBundle().getText(
						"fieldValueEmpty"));
				}
				models.SRItemsStartDateValidationEditMode(this);
				this.contractItemValidationSuccess();
			} else {
				oEvent.getSource().getParent().getParent().getCells()[0].data("item").StartDate = date;
				this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", false);
				oEvent.getSource().setValueState("Error");
				oEvent.getSource().setValueStateText(this.getResourceBundle().getText("txtInvalidDateTime"));
			}
		},
		handleChangeEndD: function (oEvent) {
			this.isItemsEdited = true;
			//Date Validation for Typo
			//Date Validation for Typo
			if (oEvent.getParameter("valid") !== undefined && !oEvent.getParameter("valid")) {
				models.dateValidationSRItems(oEvent.getSource(), oEvent.getSource().getDateValue(), formatter.dateTime(oEvent.getSource().getDateValue()),
					this);
				return;
			}
			// Is entered date valid? (incase user had made a mistake while typing!)
			if (oEvent.getSource().isValidValue()) {
				var date = oEvent.getSource().getDateValue();
				var startDate = oEvent.getSource().getParent().getParent().getCells()[0].data("item").StartDate;

				if (date) {
					if (date > startDate || (!startDate)) {
						oEvent.getSource().getParent().getParent().getCells()[0].data("item").EndDate = date;
						this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", true);
						models.onCreateValidate(this);
						oEvent.getSource().setValueState("None");
						if (startDate) {
							if (oEvent.getSource().getParent().getParent().getCells()[5].getItems()[0].getValueState() != "Warning") {
								oEvent.getSource().getParent().getParent().getCells()[5].getItems()[0].setValueState("None");
							}
							this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", true);
							models.onCreateValidate(this);
						} else {
							this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", false);
						}
					} else {
						oEvent.getSource().getParent().getParent().getCells()[0].data("item").EndDate = date;
						this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", false);
						oEvent.getSource().setValueState("Error");
						oEvent.getSource().setValueStateText(this.getResourceBundle().getText("txtEndDateEarlier"));
					}
				} else {
					oEvent.getSource().getParent().getParent().getCells()[0].data("item").EndDate = date;
					this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", false);
					oEvent.getSource().setValueState("Error");
					oEvent.getSource().setValueStateText(this.getResourceBundle().getText("fieldValueEmpty"));
				}
				this.contractItemValidationSuccess();
			} else {
				oEvent.getSource().getParent().getParent().getCells()[0].data("item").EndDate = date;
				this.getModel("buttonControlModel").setProperty("/createRequestButtonEnabled", false);
				oEvent.getSource().setValueState("Error");
				oEvent.getSource().setValueStateText(this.getResourceBundle().getText("txtInvalidDateTime"));
			}
		},
		setTextAreaGrowingAgreedScope: function (oEvent) {
			models.toggleTextAreaGrowing(this, "sr-agreed-scope", oEvent);
		},
		onContractItemSelected: function (oEvent) {
			this.getModel("buttonControlModel").setProperty("/showContractWorkAtRisk", false);
			var selectedKey = oEvent.getSource().getSelectedKey();
			var SRStatus = this.getModel("servicerequestModel").getProperty("/StatusCode");
			if (!selectedKey && SRStatus === models.STATUS_APPROVED) {
				MessageBox.error("Contract Item cannot be empty");
				var SRItemsContract = this.getModel("servicerequestItemsModel").getData()[0].ContractItemID;
				this.byId("contractItemId-edit").setSelectedKey(SRItemsContract);
				return;
			}

			if (selectedKey) {
				var workAtRisk = oEvent.getSource().getSelectedItem().data().contractItem.WorkAtRisk;
				this.getModel("SRS_Data_UserSet").setProperty("/AvailableCallOffDays", oEvent.getSource().getSelectedItem().data().contractItem.ContractItemAvailableDays);
				this.setModel(new JSONModel(oEvent.getSource().getSelectedItem().data().contractItem), "contractItemsDateModel");
				var callOffDays = this.byId("totalcalloff-Edit").getText();
				var validcheckFail = models.validateContractItemBasedOnCallOffDays(oEvent.getSource().getSelectedItem().data().contractItem,
					callOffDays, this, "msgStripContractItemValidation");
				if (validcheckFail) {
					oEvent.getSource().setValueState("Error");
				} else {
					oEvent.getSource().setValueState(null);
				}
				var SRItems = this.getModel("servicerequestItemsModel").getData();
				if (workAtRisk && workAtRisk.toUpperCase() === "X") {
					this.getModel("buttonControlModel").setProperty("/showContractWorkAtRisk", true);
					if (workAtRisk && workAtRisk.toUpperCase() === "X") {
						this.getModel("buttonControlModel").setProperty("/showContractWorkAtRisk", true);
						models.setTxtMsgWorkAtRisk(this, SRItems[0].ContractID, selectedKey);
					}
				}
				if (SRItems && SRItems.length > 0) {
					SRItems[0].ContractItemID = selectedKey;
				}
			} else {
				this.getModel("SRS_Data_UserSet").setProperty("/AvailableCallOffDays", "0");
				this.setModel(new JSONModel(), "contractItemsDateModel");
				oEvent.getSource().setValueState(null);
				this.getModel("buttonControlModel").setProperty("/showContractValidationMessageStrip", false);
			}

			this.contractItemValidationSuccess();

			this.setDefaultItemDateLimit();
		},
		agreedScopeChanged: function (oEvent) {
			//var value = oEvent.getSource().getValue();
			this.getModel("agreedServiceRequestScopeModel").setProperty("/isAgreedScopeChanged", "true");
			/*if(value && value.trim()){
				this.getModel("agreedServiceRequestScopeModel").setProperty("/isAgreedScopeChanged", "true");
			}else{
				this.getModel("agreedServiceRequestScopeModel").setProperty("/isAgreedScopeChanged", "false");
			}*/
		},
		onExit: function () {
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.unsubscribe("DetailScope", "DetailScopeReadSuccess", this.onReadSuccess, this);
			oEventBus.unsubscribe("ScopeReset", "ScopeResetSuccess", this.scopeResetSuccess, this);
			oEventBus.unsubscribe("ScopeTableReset", "ScopeTableResetSuccess", this.scopeTableResetSuccess, this);
			oEventBus.unsubscribe("createSRItems", "createSRItemsSuccess", this.createSRItemsSuccess, this);
			oEventBus.unsubscribe("saveSRItems", "saveSRItemsSuccess", this.saveSRItemsSuccess, this);
			oEventBus.unsubscribe("contractItemValidation", "contractItemValidationSuccess", this.contractItemValidationSuccess, this);
			oEventBus.unsubscribe("setAgreedScope", "setAgreedScopeSuccess", this.setAgreedScopeSuccess, this);
			oEventBus.unsubscribe("loadScopeOnSRCopy", "loadScopeOnSRCopySuccess", this.loadScopeOnSRCopySuccess, this);
			oEventBus.unsubscribe("validateRDDWhenSaveSR", "validateRDDWhenSaveSRSuccess", this.validateRDDWhenSaveSRSuccess, this);
			oEventBus.unsubscribe("setDefaultReqDelDate", "setReqDelDateSuccess", this.setReqDelDateSuccess, this);
			oEventBus.unsubscribe("onCaseReset", "onCaseResetSuccess", this.onCaseResetSuccess, this);
			//	oEventBus.unsubscribe("removeEOD", "removeEODSuccess", this.removeEODSuccess, this);
			oEventBus.unsubscribe("clearDeliveryTeams", "clearDeliveryTeamsSuccess", this.clearDeliveryTeamsSuccess, this);
			oEventBus.unsubscribe("setItem20_DateTime", "setItem20_DateTimeSuccess", this.setItem20_DateTimeSuccess, this);
			oEventBus.unsubscribe("setFocusForService", "setFocusForServiceSuccess", this.setFocusForService, this);
			oEventBus.unsubscribe("setFocusForSession", "setFocusForSessionSuccess", this.setFocusForSession, this);
			oEventBus.unsubscribe("setFocusForContract", "setFocusForContractSuccess", this.setFocusForContract, this);
			oEventBus.unsubscribe("setFocusForContractItem", "setFocusForContractItemSuccess", this.setFocusForContractItem, this);
			oEventBus.unsubscribe("setFocusForRDD", "setFocusForRDDSuccess", this.setFocusForRDD, this);
			oEventBus.unsubscribe("setFocusForAgreedScope", "setFocusForAgreedScopeSuccess", this.setFocusForAgreedScope, this);
			oEventBus.unsubscribe("eventSetNewServiceAndSession", "eventSetNewServiceAndSession", this.eventSetNewServiceAndSession, this);
			oEventBus.unsubscribe("validateSystemDuringCopySR", "validateSystemDuringCopySRSuccess", this.validateSystemDuringCopySRSuccess,
				this);
			oEventBus.unsubscribe("setFocusForSystem", "setFocusForSystemSuccess", this.setFocusForSystem, this);
			oEventBus.unsubscribe("resetSystem", "resetSystemSuccess", this.resetSystem, this);
			oEventBus.unsubscribe("RequestReset", "RequestResetSuccess", this.reloadSystems, this);
			oEventBus.unsubscribe("setSystem", "setSystemSuccess", this.setSystemSuccess, this);
			oEventBus.unsubscribe("OSPSystemSelection", "OSPSystemSelectionSuccess", this.OSPSystemSelection, this);
			oEventBus.unsubscribe("showOSPSystem", "showOSPSystemSuccess", this.showOSPSystem, this);
			oEventBus.unsubscribe("showPotentialLeadTime", "showPotentialLeadTimeSuccess", this.showPotentialLeadTime, this);
			oEventBus.unsubscribe("DetailRequest", "DetailRequestReadSuccess", this.onReadSuccess, this);
			oEventBus.unsubscribe("setServiceRequestScope", "setServiceRequestScopeSuccess", this.setServiceRequestScopeSuccess, this);
			oEventBus.unsubscribe("setFocusForCustContact", "setFocusForCustContactSuccess", this.setFocusForCustContact, this);
			oEventBus.unsubscribe("setFocusForSRInfo", "setFocusForSRInfoSuccess", this.setFocusForSRInfo, this);
			oEventBus.unsubscribe("setFocusForSurveyRecipient", "setFocusForSurveyRecipientSuccess", this.setFocusForSurveyRecipient, this);
			oEventBus.unsubscribe("removeCustomerContact", "removeCustomerContactSuccess", this.removeCustomerContact, this);
			oEventBus.unsubscribe("removeSurevyRecipient", "removeSurevyRecipientSuccess", this.removeSurevyRecipient, this);
			oEventBus.unsubscribe("setQualificationAndCallOffDaysForSession", "setQualificationAndCallOffDaysForSessionSuccess", this.setQualificationAndCallOffDaysForSession,
				this);
		},
		removeCustomerContact: function () {
			this.deleteTokenForCustomerContact();
		},
		removeSurevyRecipient: function () {
			this.deleteTokenForSurveyRecipient();
			this.getModel("servicerequestModel").setProperty("/FeedbackEnabled", true);
		},
		setFocusForService: function () {
			models.setElementScroll(this, "ServiceName-edit");
		},
		setFocusForSession: function () {
			models.setElementScroll(this, "SessionName-edit");
		},
		setFocusForContract: function () {
			models.setElementScroll(this, "contractId-edit");
		},
		setFocusForContractItem: function () {
			models.setElementScroll(this, "contractItemId-edit");
		},
		setFocusForRDD: function () {
			models.setElementScroll(this, "reqdate-edit");
		},
		setFocusForAgreedScope: function () {
			models.setElementScroll(this, "panelAgreedScope");
		},
		clearDeliveryTeamsSuccess: function () {
			var tableItems = this.byId("idProductsTable-edit").getItems();
			for (var i = 0; i < tableItems.length; i++) {
				if (tableItems[i].getVisible()) {
					tableItems[i].getCells()[7].getItems()[0].setSelectedKey("");
					tableItems[i].getCells()[0].data("item").DeliveryTeamID = "";
					tableItems[i].getCells()[0].data("item").DeliveryTeamName = "";
					tableItems[i].getCells()[0].data("item").DeliveryTeamChanged = false;
				}
			}
		},
		validateSystemDuringCopySRSuccess: function () {
			var servicerequestModel = this.getModel("servicerequestModel").getData();
			var CustomerID = servicerequestModel.CustomerID;
			var ReferenceSystemID = servicerequestModel.ReferenceSystemID;
			var ReferenceSystemName = servicerequestModel.ReferenceSystemName;
			var responseShowMessageForSystemInfoMsgStripBasedOnSystemAndSolman = this.showMessageForSystemInfoMsgStripBasedOnSystemAndSolman();

			if (CustomerID && ReferenceSystemID && ReferenceSystemID !== models.OSP_SYSTEM_REFERENCESYSTEMID) {
				models.getSystems(this, "/IBaseComponentSet", {
					"Customer": CustomerID,
					"ReferenceSystemID": ReferenceSystemID,
					"ReferenceSystemName": ReferenceSystemName
				}, "systemModel", "idSystemCombo", responseShowMessageForSystemInfoMsgStripBasedOnSystemAndSolman.shallAppendSolmanAtBotton);
			} else {
				this.resetSystem();
			}
		},
		setFocusForSystem: function () {
			models.setElementScroll(this, "idSystemCombo");
		},
		ospCheckboxOnSelect: function (oEvent) {
			if (oEvent.getSource().getSelected()) {
				this.byId("idSystemCombo").setTokens([]);
				this.byId("idSystemCombo").setEnabled(false);
				this.getModel("servicerequestModel").setProperty("/ReferenceSystemID", models.OSP_SYSTEM_REFERENCESYSTEMID);
				this.getModel("servicerequestModel").setProperty("/ReferenceSystemName", "");
				this.getModel("servicerequestModel").setProperty("/SolmanComponent", models.OSP_SYSTEM_SOLMAN);
				this.getModel("servicerequestModel").setProperty("/InstNo", models.OSP_SYSTEM_INSTNO);
				var ContactID = this.getModel("servicerequestModel").getProperty("/ContactID");
				var SurveyRecID = this.getModel("servicerequestModel").getProperty("/SurveyRecID");
				if (ContactID) {
					this.validateCustomerContact();
				}
				if (SurveyRecID) {
					this.validateSurveyRecipient();
				}
			} else {
				this.disableOSPCheckbox();
			}
		},
		disableOSPCheckbox: function () {
			this.byId("idSystemCombo").setEnabled(true);
			this.clearSelectedSystem();
			var ContactID = this.getModel("servicerequestModel").getProperty("/ContactID");
			var SurveyRecID = this.getModel("servicerequestModel").getProperty("/SurveyRecID");
			if (ContactID) {
				this.validateCustomerContact();
			}
			if (SurveyRecID) {
				this.validateSurveyRecipient();
			}
			if (!this.getModel("servicerequestModel").getProperty("/ServiceRequestID")) {
				var oEventBus = sap.ui.getCore().getEventBus();
				oEventBus.publish("clearDeliveryTeams", "clearDeliveryTeamsSuccess");
			}
		},
		modifySystemInServiceRequest: function (system) {
			if (system) {
				this.byId("idSystemCombo").setTokens([]);
				this.getModel("servicerequestModel").setProperty("/ReferenceSystemID", system.IbComponent);
				this.getModel("servicerequestModel").setProperty("/ReferenceSystemName", system.SysDescription);
				this.getModel("servicerequestModel").setProperty("/SolmanComponent", system.SolmanComponent);
				this.getModel("servicerequestModel").setProperty("/InstNo", system.InstNo);
				this.getModel("servicerequestModel").setProperty("/ReferenceProductID", system.ReferenceProductID);
				this.getModel("servicerequestModel").setProperty("/DeployMod", system.DeployModT);
				var text = models.idAndNameFormatter(system.IbComponent, system.SysDescription);
				this.byId("idSystemCombo").addToken(new sap.m.Token({
					key: system.IbComponent,
					text: text
				}));
				var SRCustomerId = this.getModel("servicerequestModel").getProperty("/CustomerID");
				if (system.Customer !== SRCustomerId) {
					this.soldToCustomerId = system.Customer;
				}
			}
		},
		okSystemDialogCloseCase: function (oEvent) {
			var selectedItemIndex = oEvent.getSource().getSelectedIndex();
			if (selectedItemIndex >= 0) {
				this.soldToCustomerId = "";
				var itemcontextPath = oEvent.getSource().getContextByIndex(selectedItemIndex);
				var system = this.getModel("systemModel").getProperty(itemcontextPath.getPath());
				var servicerequestModel = this.getModel("servicerequestModel").getData();
				var SRDeployModel = servicerequestModel.DeployMod;
				if(SRDeployModel){
					SRDeployModel = SRDeployModel.toUpperCase();
				}
				var systemDepModel = system.DeployModT;
				if(systemDepModel){
					systemDepModel = systemDepModel.toUpperCase();
				}
				if(servicerequestModel.ReferenceSystemID === system.IbComponent && servicerequestModel.SolmanComponent === system.SolmanComponent && servicerequestModel.InstNo === system.InstNo && servicerequestModel.ReferenceProductID===system.ReferenceProductID && SRDeployModel === systemDepModel){
					sap.m.MessageToast.show(this.getResourceBundle().getText("txtSystemAlreadySelected"));
				}else{
					var SystemMissingSolman = formatter.formatSystemIcon(system.SolmanSid, system.DeployModT, system.shallAppendSolmanAtBotton);
					if (SystemMissingSolman) {
						sap.m.MessageToast.show(this.getResourceBundle().getText("txtMissingSolman"));
						return;
					}
					if (system) {
						this.modifySystemInServiceRequest(system);
						var ContactID = this.getModel("servicerequestModel").getProperty("/ContactID");
						var SurveyRecID = this.getModel("servicerequestModel").getProperty("/SurveyRecID");
						if (ContactID) {
							this.validateCustomerContact();
						}
						if (SurveyRecID) {
							this.validateSurveyRecipient();
						}
						models.createDefaultTenantonSystemSelection(system,this);
					} else {
						sap.m.MessageToast.show(this.getResourceBundle().getText("No System Selected"));
						return;
					}
					oEvent.getSource().getParent().close();
					this.byId("idContainerOSPSystem").setVisible(false);
					models.showHideCloudRefObjSection(system.DeployModT, this);
				}
			}
		},
		onSystemDialogCloseCase: function (oEvent) {
			oEvent.getSource().getParent().close();
		},
		validateCustomerContact: function () {
			var CustomerId = this.getModel("servicerequestModel").getProperty("/CustomerID");
			var filterArr = [];
			filterArr.push(models.filterCondition_Equal("HasEmail", true));
			this.byId("srs_customerContact-input").setBusy(true);
			var context = this;
			this.getModel("SRS_Data").read("/CustomerSet(CustomerID='" + CustomerId + "')/toContacts", {
				filters: filterArr,
				groupId: "customerContactValidation",
				success: function (oData) {
					var results = oData.results;
					var ContactID = context.getModel("servicerequestModel").getProperty("/ContactID");
					var doesContactExist = false;
					for (var i = 0; i < results.length; i++) {
						if (results[i].ContactID === ContactID) {
							doesContactExist = true;
							break;
						}
					}
					if (!doesContactExist && this.soldToCustomerId) {
						this.getModel("SRS_Data").read("/CustomerSet(CustomerID='" + this.soldToCustomerId + "')/toContacts", {
							filters: filterArr,
							success: function (oData2) {
								var results2 = oData2.results;
								var doesContactExist = false;
								for (var i = 0; i < results2.length; i++) {
									if (results2[i].ContactID === ContactID) {
										doesContactExist = true;
										break;
									}
								}
								if (!doesContactExist) {
									this.removeCustomerContact();
									var msg = this.getResourceBundle().getText("txtCustomerContactValidationMsg");
									this.showMessageToastforCCandSR(msg);
								}
								context.byId("srs_customerContact-input").setBusy(false);
							}.bind(this)
						});
					} else if (!doesContactExist && !this.soldToCustomerId) {
						this.removeCustomerContact();
						var msg = this.getResourceBundle().getText("txtCustomerContactValidationMsg");
						this.showMessageToastforCCandSR(msg);
						context.byId("srs_customerContact-input").setBusy(false);
					} else {
						context.byId("srs_customerContact-input").setBusy(false);
					}

				}.bind(this)
			});
		},
		showMessageToastforCCandSR: function (msg) {
			MessageBox.information(msg);
		},
		validateSurveyRecipient: function () {
			var CustomerId = this.getModel("servicerequestModel").getProperty("/CustomerID");
			var filterArr = [];
			filterArr.push(models.filterCondition_Equal("HasEmail", true));
			filterArr.push(models.filterCondition_Equal("IsSurveyRec", true));
			this.byId("idSurveyRecipient").setBusy(true);
			var context = this;
			this.getModel("SRS_Data").read("/CustomerSet(CustomerID='" + CustomerId + "')/toContacts", {
				filters: [models.filterComparison_AND(filterArr)],
				groupId: "surveyRecipientValidation",
				success: function (oData) {
					var results = oData.results;
					var SurveyRecID = context.getModel("servicerequestModel").getProperty("/SurveyRecID");
					var doesContactExist = false;
					for (var i = 0; i < results.length; i++) {
						if (results[i].ContactID === SurveyRecID) {
							doesContactExist = true;
							break;
						}
					}

					if (!doesContactExist && this.soldToCustomerId) {
						this.getModel("SRS_Data").read("/CustomerSet(CustomerID='" + this.soldToCustomerId + "')/toContacts", {
							filters: [models.filterComparison_AND(filterArr)],
							success: function (oData2) {
								var results2 = oData2.results;
								var doesContactExist = false;
								for (var i = 0; i < results2.length; i++) {
									if (results2[i].ContactID === SurveyRecID) {
										doesContactExist = true;
										break;
									}
								}
								if (!doesContactExist) {
									this.removeSurevyRecipient();
									var msg = this.getResourceBundle().getText("txtSurveyRecipientValidationMsg");
									this.showMessageToastforCCandSR(msg);
								}
								context.byId("idSurveyRecipient").setBusy(false);
							}.bind(this)
						});
					} else if (!doesContactExist && !this.soldToCustomerId) {
						this.removeSurevyRecipient();
						var msg = this.getResourceBundle().getText("txtSurveyRecipientValidationMsg");
						this.showMessageToastforCCandSR(msg);
						context.byId("idSurveyRecipient").setBusy(false);
					} else {
						context.byId("idSurveyRecipient").setBusy(false);
					}

				}.bind(this)
			});
		},
		systemOnChange: function (oEvent) {
			if (oEvent.getParameter('type') === sap.m.Tokenizer.TokenUpdateType.Removed) {
				var context = this;
				var ContactID = this.getModel("servicerequestModel").getProperty("/ContactID");
				var SurveyRecID = this.getModel("servicerequestModel").getProperty("/SurveyRecID");
				this.soldToCustomerId = "";
				if (ContactID) {
					this.validateCustomerContact();
				}
				if (SurveyRecID) {
					this.validateSurveyRecipient();
				}
				context.clearSelectedSystem();
				context.showOSPSystem();
				models.showHideCloudRefObjSection("", this);
			} else {
				this.byId("idContainerOSPSystem").setVisible(false);
			}

		},
		clearSelectedSystem: function () {
			this.getModel("servicerequestModel").setProperty("/ReferenceSystemID", "");
			this.getModel("servicerequestModel").setProperty("/ReferenceSystemName", "");
			this.getModel("servicerequestModel").setProperty("/SolmanComponent", "");
			this.getModel("servicerequestModel").setProperty("/InstNo", "");
			this.getModel("servicerequestModel").setProperty("/ReferenceProductID", "");
			models.showHideCloudRefObjSection("", this);
			this.clearTenantModuleCreationModel();
		},
		clearTenantModuleCreationModel: function () {
			this.getModel("TenantsCreationModel").setData([]);
			this.getModel("ModulesCreationModel").setData([]);
			this.getModel("ModulesDeletionModel").setData([]);
			this.getModel("TenantsDeletionModel").setData([]);
		},
		handleValueHelpForSystemTableSuggestions: function (oController) {
			this.setModel(new JSONModel(), "systemModel");
			this.inputId = oController.oSource.sId;
			var dialog = this.byId("dialogSystem");
			dialog.open();

			var serviceRequestModel = this.getModel("servicerequestModel").getData();
			var CustomerId = "";
			if (this.getModel("SRS_Data_UserSet").getData().customerId) {
				CustomerId = this.getModel("SRS_Data_UserSet").getData().customerId;
			} else if (serviceRequestModel && serviceRequestModel.CustomerID) {
				CustomerId = serviceRequestModel.CustomerID;
			}
			this.byId("idCustomerInput").setValue(CustomerId);
			this.byId("comboRelatedPartner").setSelectedKey("Y");
			this.byId("idInstallationNumber").setValue("");
			this.byId("idSystemID").setValue("");
			this.byId("comboSystemRole").setSelectedKey("");
			var responseShowMessageForSystemInfoMsgStripBasedOnSystemAndSolman = this.showMessageForSystemInfoMsgStripBasedOnSystemAndSolman();
			this.byId("idMsgStripSystemDialogInfo").setText(responseShowMessageForSystemInfoMsgStripBasedOnSystemAndSolman.msgTxt);

			var context = this;

			if (CustomerId) {
				context.byId("idMsgStripFilterBarSystemDialog").setVisible(false);
				var relatedPartner = context.byId("comboRelatedPartner").getSelectedKey();
				models.getSystems(context, "/IBaseComponentSet", {
					"Customer": CustomerId,
					"relatedPartner": relatedPartner
				}, "systemModel", "systemTable", responseShowMessageForSystemInfoMsgStripBasedOnSystemAndSolman.shallAppendSolmanAtBotton);
			}

			context.byId("titleSystemTable").setText(context.getResourceBundle().getText("systemTableHeaderTitle"));
			context.clearAllSystemTableFilters();

			dialog.attachAfterOpen(function () {

				if (context.getView().byId("comboSystemRole")) {
					context.getView().byId("comboSystemRole").setFilterFunction(function (searchString, oItem) {
						if (!isNaN(searchString)) {
							searchString = searchString.trim();
						}
						return models.comboBoxContainsFilterFunction(oItem, searchString, true);
					});
				}
			});

		},
		showMessageForSystemInfoMsgStripBasedOnSystemAndSolman: function () {
			var selectedServiceSet = null,
				selectedSessionSet = null;

			if (this.byId("ServiceName-edit").getSelectedItem()) {
				selectedServiceSet = this.byId("ServiceName-edit").getSelectedItem().data("selectedProductSet");
			}
			if (this.byId("SessionName-edit").getSelectedItem()) {
				selectedSessionSet = this.byId("SessionName-edit").getSelectedItem().data("selectedSessionSet");
			}
			var msgTxt = "",
				shallAppendSolmanAtBotton = false;
			if (selectedServiceSet && selectedSessionSet) {
				var isSystemMandatory = false;
				if (selectedSessionSet.SystemRequired === "X" || selectedServiceSet.SystemMandatory) {
					isSystemMandatory = true;
				}

				var isSolmanMandatory = false;
				if (selectedSessionSet.SolmanRequired === "X" || selectedServiceSet.SolmanMandatory) {
					isSolmanMandatory = true;
				}

				if (isSystemMandatory && isSolmanMandatory) {
					shallAppendSolmanAtBotton = true;
					msgTxt = this.getResourceBundle().getText("txtSystemDialogInfo_A");
				} else if (!isSystemMandatory && isSolmanMandatory) {
					shallAppendSolmanAtBotton = true;
					msgTxt = this.getResourceBundle().getText("txtSystemDialogInfo_C");
				} else if (isSystemMandatory && !isSolmanMandatory) {
					msgTxt = this.getResourceBundle().getText("txtSystemDialogInfo_B");
				} else {
					msgTxt = this.getResourceBundle().getText("txtSystemDialogInfo_B");
				}
			} else {
				msgTxt = this.getResourceBundle().getText("txtSystemDialogInfo_D");
			}
			return {
				"msgTxt": msgTxt,
				"shallAppendSolmanAtBotton": shallAppendSolmanAtBotton
			};

		},
		onRelatedPartnerSelection: function (oEvent) {
			if (!oEvent.getSource().getSelectedKey()) {
				this.byId("comboRelatedPartner").setSelectedKey("");
			}
		},
		onSystemRoleSelection: function (oEvent) {
			if (!oEvent.getSource().getSelectedKey()) {
				this.byId("comboSystemRole").setSelectedKey("");
			}
		},
		onSystemSearchInDialog: function (oEvent) {
			var customerId = this.byId("idCustomerInput").getValue();
			var instNo = this.byId("idInstallationNumber").getValue();
			var sid = this.byId("idSystemID").getValue();
			var relatedPartner = this.byId("comboRelatedPartner").getSelectedKey();
			var systemRole = this.byId("comboSystemRole").getSelectedKey();

			this.setModel(new JSONModel(), "systemModel");
			var responseShowMessageForSystemInfoMsgStripBasedOnSystemAndSolman = this.showMessageForSystemInfoMsgStripBasedOnSystemAndSolman();

			if (customerId || instNo) {
				this.byId("idMsgStripFilterBarSystemDialog").setVisible(false);
				models.getSystems(this, "/IBaseComponentSet", {
					"Customer": customerId,
					"InstNo": instNo,
					"Sid": sid,
					"relatedPartner": relatedPartner,
					"CarSysRole": systemRole
				}, "systemModel", "systemTable", responseShowMessageForSystemInfoMsgStripBasedOnSystemAndSolman.shallAppendSolmanAtBotton);
			} else {
				this.byId("idMsgStripFilterBarSystemDialog").setVisible(true);
			}

			this.byId("titleSystemTable").setText(this.getResourceBundle().getText("systemTableHeaderTitle"));
			this.clearAllSystemTableFilters();
		},
		showRelatedPartnerHint: function (oEvent) {
			var oButton = oEvent.getSource();
			var that = this;
			if (!this._RelatedPartnerHintPopover) {
				this._RelatedPartnerHintPopover = Fragment.load({
					id: this.getView().getId(),
					name: "sap.com.servicerequest.servicerequest.fragment.RelatedPartnerPopover",
					controller: this
				}).then(function (oPopover) {
					that.getView().addDependent(oPopover);
					return oPopover;
				});
			}
			this._RelatedPartnerHintPopover.then(function (oPopover) {
				oPopover.openBy(oButton);
			});
		},
		handleRelatedPartnerHintPopoverClose: function (oEvent) {
			this.byId("idRelatedPartnerHintPopover").close();
		},
		clearAllSystemTableFilters: function () {
			var oTable = this.byId("systemTable");
			var aColumns = oTable.getColumns();
			for (var i = 0; i < aColumns.length; i++) {
				oTable.filter(aColumns[i], null);
				aColumns[i].setSorted(false);
			}
		},
		resetSystem: function () {
			if (this.byId("idSystemCombo")) {
				this.byId("idSystemCombo").setTokens([]);
			}
			this.getModel("buttonControlModel").setProperty("/enableOSPCheckbox", false);
			var ContactID = this.getModel("servicerequestModel").getProperty("/ContactID");
			var SurveyRecID = this.getModel("servicerequestModel").getProperty("/SurveyRecID");
			if (ContactID) {
				this.validateCustomerContact();
			}
			if (SurveyRecID) {
				this.validateSurveyRecipient();
			}
			models.intializeCloudRefObjModels(this);
		},
		reloadSystems: function (param) {
			this.setModel(new JSONModel(), "contractSetModel");
			this.setModel(new JSONModel(), "contractItemModel");
			this.resetSystem();
		},
		setSystemSuccess: function () {
			var servicerequestModel = this.getModel("servicerequestModel").getData();
			var text = models.idAndNameFormatter(servicerequestModel.ReferenceSystemID, servicerequestModel.ReferenceSystemName);
			this.byId("idSystemCombo").addToken(new sap.m.Token({
				key: servicerequestModel.ReferenceSystemID,
				text: text
			}));
		},
		OSPSystemSelection: function (channel, event, isEODSelectedAsService) {
			if (isEODSelectedAsService === "true") {
				this.getModel("editableFieldsModel").setProperty("/OSPSystem", false);
				if (this.getModel("buttonControlModel").getProperty("/enableOSPCheckbox")) {
					this.getModel("buttonControlModel").setProperty("/enableOSPCheckbox", false);
					this.getModel("editableFieldsModel").setProperty("/System", true);
					this.clearSelectedSystem();
				}
				this.byId("idContainerOSPSystem").setVisible(false);
			} else {
				this.getModel("editableFieldsModel").setProperty("/OSPSystem", true);
			}
		},
		setFocusForCustContact: function () {
			models.setElementScroll(this, "srs_customerContact-input");
		},
		setFocusForSRInfo: function () {
			models.setElementScroll(this, "panelSRInfo");
		},
		setFocusForSurveyRecipient: function () {
			models.setElementScroll(this, "idSurveyRecipient");
		},
		serviceRequestScopeChanged: function (oEvent) {
			this.getModel("serviceRequestScopeModel").setProperty("/isServiceRequestInfoChanged", "true");
			/*var value = oEvent.getSource().getValue();
			if(value && value.trim()){
				this.getModel("serviceRequestScopeModel").setProperty("/isServiceRequestInfoChanged", "true");
			}else{
				this.getModel("serviceRequestScopeModel").setProperty("/isServiceRequestInfoChanged", "false");
			}*/
		},
		/*
		setServiceRequestInfoTemplate: function () {
			var userProfile = this.getModel("SRS_Data_UserSet").getData();

			if (userProfile.isTQM && this.byId("sr-req-scope").getValue().trim() === "") {
				var sTemplateValue =
					"#Customer Expectations: \n#Delivery Address: \n#Skills Needed: \n#Previously discussed – COE Contact / Date: \n#Names of Planned Experts (optional):\n#Language / Citizenship Restrictions (optional):";
				this.byId("sr-req-scope").setValue(sTemplateValue);
			}
		},*/

		setTextAreaGrowing: function (oEvent) {
			models.toggleTextAreaGrowing(this, "sr-req-scope", oEvent);
		},

		setServiceRequestScopeSuccess: function () {
			var serviceRequestModel = this.getModel("serviceRequestScopeModel");
			var text = serviceRequestModel.getData().data[0].Text.trim();
			if (text) {
				this.byId("sr-req-scope").setValue(text);
			} else {
				var userProfile = this.getModel("SRS_Data_UserSet").getData();
				models.setServiceRequestInfoTemplate(userProfile, serviceRequestModel);
			}
		},
		onCaseSearch: function () {
			var oView = this.getView();
			var dialog = oView.byId("CaseDialog");
			if (!dialog) {
				// create dialog via fragment factory
				dialog = sap.ui.xmlfragment(oView.getId(), "sap.com.servicerequest.servicerequest.fragment.CaseSearch", this);
				oView.addDependent(dialog);
			}
			dialog.open();
		},
		onCustomerContactSearch: function () {
			var oView = this.getView();
			var dialog = oView.byId("CustomerContactDialog");
			if (!dialog) {
				// create dialog via fragment factory
				dialog = sap.ui.xmlfragment(oView.getId(), "sap.com.servicerequest.servicerequest.fragment.CustomerContactSearch", this);
				oView.addDependent(dialog);
			}
			dialog.setTitle(this.getResourceBundle().getText("selectCustomerContact"));
			var title = this.getResourceBundle().getText("selectCustomerContact");
			this.byId("customerContactCounts").setText(title + " (0)");
			this.byId("invisibleTxtForDialogCustomerContact").setText("CC");
			dialog.open();
			this.byId("idLinkSurveyRecipientHelp").setVisible(false);
		},
		onPressCustomerContactSearch: function () {
			this.byId("srs_customerContactTable").setBusy(true);

			var sFirstName = this.byId("srs_firstName").getValue();
			var sLastName = this.byId("srs_lastName").getValue();
			var sEmail = this.byId("srs_email").getValue();
			var sCustomerId = this.getModel("servicerequestModel").getData().CustomerID;

			var customerContactModel = new JSONModel({
				caseString: "",
				data: [],
				total: 0,
				page: 0,
				current: 0
			});
			this.setModel(customerContactModel, "customerContactModel");

			var filterArr = [];
			if (sEmail) {
				filterArr.push(models.filterCondition_Contains("EmailAddr", sEmail));
			}

			if (sFirstName) {
				filterArr.push(models.filterCondition_Contains("Firstname", sFirstName));
			}

			if (sLastName) {
				filterArr.push(models.filterCondition_Contains("Lastname", sLastName));
			}

			filterArr.push(models.filterCondition_Equal("HasEmail", true));

			if (this.byId("invisibleTxtForDialogCustomerContact").getText() === "SR") {
				filterArr.push(models.filterCondition_Equal("IsSurveyRec", true));
			}
			this.byId("searchBtn").setEnabled(false);
			this.getModel("SRS_Data").read("/CustomerSet(CustomerID='" + sCustomerId + "')/toContacts", {
				filters: [models.filterComparison_AND(filterArr)],
				success: function (oData) {
					var results = oData.results;
					var resultsLength = oData.results.length;
					if (this.soldToCustomerId) {
						this.getModel("SRS_Data").read("/CustomerSet(CustomerID='" + this.soldToCustomerId + "')/toContacts", {
							filters: [models.filterComparison_AND(filterArr)],
							success: function (oData2) {
								results = results.concat(oData2.results);
								resultsLength = resultsLength + oData2.results.length;
								this.getModel("customerContactModel").setProperty("/data", results);
								this.getModel("customerContactModel").setProperty("/total", resultsLength);

								var title = this.getResourceBundle().getText("selectCustomerContact");
								if (this.byId("invisibleTxtForDialogCustomerContact").getText() === "SR") {
									title = this.getResourceBundle().getText("txtSurveyRcpts");
								}
								this.byId("customerContactCounts").setText(title + " (" + resultsLength + ")");

								this.byId("srs_customerContactTable").setBusy(false);
								this.byId("searchBtn").setEnabled(true);
							}.bind(this)
						});
					} else {
						this.getModel("customerContactModel").setProperty("/data", results);
						this.getModel("customerContactModel").setProperty("/total", resultsLength);

						var title = this.getResourceBundle().getText("selectCustomerContact");
						if (this.byId("invisibleTxtForDialogCustomerContact").getText() === "SR") {
							title = this.getResourceBundle().getText("txtSurveyRcpts");
						}
						this.byId("customerContactCounts").setText(title + " (" + resultsLength + ")");

						this.byId("srs_customerContactTable").setBusy(false);
						this.byId("searchBtn").setEnabled(true);
					}

				}.bind(this)
			});

		},
		setTokenForCustomerContact: function (contactId, contactName) {
			this.byId("srs_customerContact-input").setTokens([]);
			this.byId("srs_customerContact-input").addToken(new sap.m.Token({
				key: contactId,
				text: contactName
			}));
			this.getModel("servicerequestModel").setProperty("/ContactID", contactId);
			this.getModel("servicerequestModel").setProperty("/ContactName", contactName);
		},
		deleteTokenForCustomerContact: function () {
			this.byId("srs_customerContact-input").setTokens([]);
			this.getModel("servicerequestModel").setProperty("/ContactID", "");
			this.getModel("servicerequestModel").setProperty("/ContactName", "");
		},
		contactTokenUpdate: function (oEvent) {
			if (oEvent.getParameter('type') === sap.m.Tokenizer.TokenUpdateType.Removed) {
				this.deleteTokenForCustomerContact();
			}
		},
		setTokenForSurveyRecipient: function (SRId, SRName) {
			this.byId("idSurveyRecipient").setTokens([]);
			this.byId("idSurveyRecipient").addToken(new sap.m.Token({
				key: SRId,
				text: SRName
			}));
			this.getModel("servicerequestModel").setProperty("/SurveyRecID", SRId);
			this.getModel("servicerequestModel").setProperty("/SurveyRecName", SRName);
		},
		deleteTokenForSurveyRecipient: function () {
			this.byId("idSurveyRecipient").setTokens([]);
			this.getModel("servicerequestModel").setProperty("/SurveyRecID", "");
			this.getModel("servicerequestModel").setProperty("/SurveyRecName", "");
		},
		surveyRecipientTokenUpdate: function (oEvent) {
			if (oEvent.getParameter('type') === sap.m.Tokenizer.TokenUpdateType.Removed) {
				this.deleteTokenForSurveyRecipient();
			}
		},
		onCloseCustomerContactSearch: function (oEvent) {
			if (oEvent.getSource().getId().indexOf("cancel") === -1) {
				var oSelectedItem = this.byId("srs_customerContactTable").getSelectedItem();
				if (oSelectedItem) {
					var oSelectedCase = oSelectedItem.getBindingContext("customerContactModel").getObject();
					if (this.byId("invisibleTxtForDialogCustomerContact").getText() === "CC") {
						var value = "";
						if (oSelectedCase.Name) {
							value = oSelectedCase.Name;
						} else {
							value = oSelectedCase.Firstname + " " + oSelectedCase.Lastname;
						}
						this.setTokenForCustomerContact(oSelectedCase.ContactID, value);

					} else {
						this.setSurveyRecipient(oSelectedCase);
					}
				} else {
					if (this.byId("invisibleTxtForDialogCustomerContact").getText() === "CC") {
						sap.m.MessageToast.show(this.getResourceBundle().getText("contactEmpty"));
					} else {
						sap.m.MessageToast.show(this.getResourceBundle().getText("txtSREmpty"));
					}
					return;
				}
			}

			this.byId("srs_firstName").setValue();
			this.byId("srs_lastName").setValue();
			this.byId("srs_email").setValue();
			//reset Case Model and more button
			var customerContactModel = new JSONModel({
				caseString: "",
				data: [],
				total: 0,
				page: 0,
				current: 0
			});
			this.setModel(customerContactModel, "customerContactModel");

			this.byId("CustomerContactDialog").close();
		},
		setSurveyRecipient: function (oSelectedCase) {
			var value = "";
			if (oSelectedCase.Name) {
				value = oSelectedCase.Name;
			} else {
				value = oSelectedCase.Firstname + " " + oSelectedCase.Lastname;
			}
			this.setTokenForSurveyRecipient(oSelectedCase.ContactID, value);
			models.onCreateValidate(this);
		},
		handleValid: function (event) {
			var selectedKey = event.getSource().getSelectedKey();
			if (selectedKey) {
				event.getSource().setValueState("None");
				models.onCreateValidate(this);
			} else {
				event.getSource().setValueState("Error");
				models.onCreateValidate(this);
			}
		},
		isEmpty: function (value) {
			if (value === null || value == "") {
				return true;
			} else {
				return false;
			}
		},
		onSurveyRcpySearch: function (oEvent) {
			var oView = this.getView();
			var dialog = oView.byId("CustomerContactDialog");
			if (!dialog) {
				// create dialog via fragment factory
				dialog = sap.ui.xmlfragment(oView.getId(), "sap.com.servicerequest.servicerequest.fragment.CustomerContactSearch", this);
				oView.addDependent(dialog);
			}
			dialog.setTitle(this.getResourceBundle().getText("txtSearchSurveyRecipient"));
			this.byId("invisibleTxtForDialogCustomerContact").setText("SR");
			var title = this.getResourceBundle().getText("txtSurveyRcpts");
			this.byId("customerContactCounts").setText(title + " (0)");
			dialog.open();
			this.byId("idLinkSurveyRecipientHelp").setVisible(true);
			this.onPressCustomerContactSearch();
		},
		onSurveyRcptSwitchChange: function (oEvent) {
			models.onCreateValidate(this);
		},
		showHideContractAndRelatedFieldsBasedOnContractMandatory: function () {
			var selectedService = this.getModel("servicerequestModel").getProperty("/ServiceID");
			if (selectedService) {
				var serviceDropDownItems = this.byId("ServiceName-edit").getItems();
				if (jQuery.isEmptyObject(serviceDropDownItems)) {
					this.getModel("SRS_Data").read("/ProductSet('" + selectedService + "')", {
						groupId: "grpGetServiceByIdEditMode",
						success: function (oData) {
							if (oData) {
								var isContractMandatory = oData.ContractMandatory;
								this.getModel("buttonControlModel").setProperty("/showContractFieldsBasedOnSelectedService", isContractMandatory);
								if (!isContractMandatory) {
									this.resetSRItemDateMinMaxLimit();
								}
							}
						}.bind(this),
						error: function (err) {
							sap.ui.core.BusyIndicator.hide();
							models.showErrorMessage(this, err);
						}.bind(this)
					});
				} else {
					var selectedServiceItem = this.byId("ServiceName-edit").getSelectedItem();
					if (selectedServiceItem) {
						var isContractMandatory = this.byId("ServiceName-edit").getSelectedItem().data("selectedProductSet").ContractMandatory;
						this.getModel("buttonControlModel").setProperty("/showContractFieldsBasedOnSelectedService", isContractMandatory);
						if (!isContractMandatory) {
							this.resetSRItemDateMinMaxLimit();
						}
					}
				}
			}
		},
		onPressAddTenant: function () {
			var oView = this.getView();
			var dialog = oView.byId("addTenantsDialog");
			//check if the input owner is null, if null set 
			if (!dialog) {
				// create dialog via fragment factory
				dialog = sap.ui.xmlfragment(oView.getId(), "sap.com.servicerequest.servicerequest.fragment.AddTenants", this);
				oView.addDependent(dialog);
			}
			dialog.open();
			this.getAllTenantsByTenantId();
		},
		onCancelTenantPopup: function () {
			this.byId("addTenantsDialog").close();
		},
		getAllTenantsByTenantId: function () {
			this.setModel(new JSONModel(), "tenantModel");
			var tenantId = this.getModel("servicerequestModel").getProperty("/ReferenceProductID");
			this.byId("idSelectTenant").setEnabled(false);
			this.byId("idTenantTable").setBusy(true);
			this.getModel("SRS_Data").read("/RelatedTenantVHSet", {
				filters: [models.filterCondition_Equal("Tenantid", tenantId)],
				groupId: "batchAddTenant",
				success: function (oData) {
					var results = oData.results;
					var CloudReferenceObjectSetModel = this.getModel("CloudReferenceObjectSetModel").getData();
					var arrTenantsAfterRemovingAlreadyAddedTenantsWihtinCloudObjs = [];
					if (CloudReferenceObjectSetModel && CloudReferenceObjectSetModel.objects && CloudReferenceObjectSetModel.objects.length > 0) {
						var objects = CloudReferenceObjectSetModel.objects;
						for (var i = 0; i < results.length; i++) {
							var tenantAlreadyExistWithinCloudObj = false;
							for (var j = 0; j < objects.length; j++) {
								if (results[i].Addtenantid === objects[j].ProductID) {
									tenantAlreadyExistWithinCloudObj = true;
									break;
								}
							}
							if (!tenantAlreadyExistWithinCloudObj) {
								arrTenantsAfterRemovingAlreadyAddedTenantsWihtinCloudObjs.push(results[i]);
							}
						}
					}
					this.getModel("tenantModel").setData(arrTenantsAfterRemovingAlreadyAddedTenantsWihtinCloudObjs);

					this.byId("idTenantTable").setBusy(false);
				}.bind(this),
				error: function (err) {
					models.showErrorMessage(this, err);
				}.bind(this)
			});
		},
		selectedCloudObj: null,
		onPressAddModule: function (oEvent) {
			var ServiceID = this.getModel("servicerequestModel").getProperty("/ServiceID");
			if (!ServiceID) {
				MessageBox.alert("Please select a Service to add Modules", {
					title: "No Service Selected !",
				});
				return;
			}

			this.selectedCloudObj = oEvent.getSource().data("selectedCloudObj");
			var oView = this.getView();
			var dialog = oView.byId("addModuleDialog");
			//check if the input owner is null, if null set 
			if (!dialog) {
				// create dialog via fragment factory
				dialog = sap.ui.xmlfragment(oView.getId(), "sap.com.servicerequest.servicerequest.fragment.AddModule", this);
				oView.addDependent(dialog);
			}
			dialog.open();
			this.getAllModules();
		},
		getAllModules: function () {
			this.setModel(new JSONModel(), "moduleModel");
			this.byId("idSelectModule").setEnabled(false);
			var ServiceID = this.getModel("servicerequestModel").getProperty("/ServiceID");
			this.byId("idModuleTable").setBusy(true);
			this.getModel("SRS_Data").read("/CloudModuleVHSet", {
				filters: [models.filterComparison_AND([models.filterCondition_Equal("Tenantid", this.selectedCloudObj.ProductID), models.filterCondition_Equal(
					"Serviceproductid", ServiceID)])],
				groupId: "batchAddModule",
				success: function (oData) {
					var results = oData.results;
					//results = this.removeDuplicateModules(results);
					var CloudReferenceObjectSetModel = this.getModel("CloudReferenceObjectSetModel").getData();

					var arrModulesAfterRemovingAlreadyAddedModulesWihtinCloudObjs = [];
					if (CloudReferenceObjectSetModel && CloudReferenceObjectSetModel.objects && CloudReferenceObjectSetModel.objects.length > 0) {
						var objects = CloudReferenceObjectSetModel.objects;
						for (var i = 0; i < results.length; i++) {
							var moduleAlreadyExistWithinCloudObj = false;
							for (var j = 0; j < objects.length; j++) {
								if (this.selectedCloudObj.IbComponent === objects[j].IbComponent) {

									if (objects[j].objects && objects[j].objects.length > 0) {
										for (var k = 0; k < objects[j].objects.length; k++) {
											if (objects[j].objects[k].ProductID === results[i].Ppmspvproductid) {
												moduleAlreadyExistWithinCloudObj = true;
												break;
											}
										}
									}
									if (moduleAlreadyExistWithinCloudObj) {
										break;
									}

								}
							}
							if (!moduleAlreadyExistWithinCloudObj) {
								arrModulesAfterRemovingAlreadyAddedModulesWihtinCloudObjs.push(results[i]);
							}
						}
					}

					this.getModel("moduleModel").setData(arrModulesAfterRemovingAlreadyAddedModulesWihtinCloudObjs);

					this.byId("idModuleTable").setBusy(false);
				}.bind(this),
				error: function (err) {
					models.showErrorMessage(this, err);
				}.bind(this)
			});
		},
		removeDuplicateModules: function (arr) {
			var filteredArray = [];
			var doesModuleExist = false;
			for (var i = 0; i < arr.length; i++) {
				doesModuleExist = false;
				if (filteredArray.length === 0) {
					filteredArray.push(arr[i]);
				} else {
					for (var j = 0; j < filteredArray.length; j++) {
						if (filteredArray[j].Ppmsproductid === arr[i].Ppmsproductid && filteredArray[j].Ppmspvproductid === arr[i].Ppmspvproductid) {
							doesModuleExist = true;
							break;
						}
					}
					if (!doesModuleExist) {
						filteredArray.push(arr[i]);
					}
				}
			}
			return filteredArray;
		},
		onCancelModulePopup: function () {
			this.byId("addModuleDialog").close();
		},
		onSelectTenant: function (oEvent) {
			var selectedItems = this.byId("idTenantTable").getSelectedItems();
			var CloudReferenceObjectSetModel = this.getModel("CloudReferenceObjectSetModel").getData();
			var RawCloudReferenceObjectSetModel = this.getModel("RawCloudReferenceObjectSetModel").getData();
			var ServiceRequestId = this.getModel("servicerequestModel").getProperty("/ServiceRequestID");
			var TenantsCreationModel = this.getModel("TenantsCreationModel").getData();
			var TenantsDeletionModel = this.getModel("TenantsDeletionModel").getData();
			for (var i = 0; i < selectedItems.length; i++) {
				var selectedTenant = selectedItems[i].getCells()[0].data("selectedTenant");
				//check if selectedTenant already has GuidObject and added to TenantsDeletionModel
				var selectedTenantExistinDeletionModel = false;
				for (var m = 0; m < TenantsDeletionModel.length; m++) {
					if (TenantsDeletionModel[m].IbComponent === selectedTenant.SystemNumber) {
						selectedTenantExistinDeletionModel = true;
						TenantsDeletionModel.splice(m, 1);
						break;
					}
				}
				var selectedTenantExistInBackend = false;
				var CloudRefObj;
				//check if selected Tenant already exist in the backend
				for (var h = 0; h < RawCloudReferenceObjectSetModel.length; h++) {
					if (RawCloudReferenceObjectSetModel[h].IbComponent === selectedTenant.SystemNumber) {
						selectedTenantExistInBackend = true;
						CloudRefObj = RawCloudReferenceObjectSetModel[h];
						if(CloudRefObj.objects){
							CloudRefObj.objects=[];
						}
						break;
					}
				}

				if (!selectedTenantExistinDeletionModel && !selectedTenantExistInBackend) {
					var createdTenant = {
						"ObjectID": ServiceRequestId,
						"IbComponent": selectedTenant.SystemNumber
					};
					TenantsCreationModel.push(createdTenant);
				}

				if (!selectedTenantExistInBackend) {
					CloudRefObj = {
						"GuidObject": "",
						"ProductText": selectedTenant.Addtenantdescription,
						"ObjectID": ServiceRequestId,
						"RefGuid": "",
						"ComponentText": "",
						"IbaseText": "",
						"IbComponent": selectedTenant.SystemNumber,
						"CarSystemRole": selectedTenant.CarRole,
						"Ibase": selectedTenant.Ibase,
						"CarSystemRoleT": selectedTenant.CarRoleT,
						"ParentComponent": "0",
						"ZzsDescr1": "",
						"ProductID": selectedTenant.Addtenantid,
						"ZzsDescr2": "",
						"MainObject": "",
						"ZzsDescr3": "",
						"ZzsDescr4": "",
						"ZzsDescr5": ""
					};
				}

				CloudReferenceObjectSetModel.objects.push(CloudRefObj);
				//models.rowCountCloudRefObjectoData++;
				this.getModel("CloudReferenceObjectSetModel").setData(CloudReferenceObjectSetModel);
			}
			this.getModel("TenantsCreationModel").setData(TenantsCreationModel);
			this.byId("addTenantsDialog").close();
			models.hideEmpltyRowsOnTenantAndModuleCreation(CloudReferenceObjectSetModel, this);
		},
		onSelectModule: function (oEvent) {
			this.getModel("buttonControlModel").setProperty("/isShowMoreCloudRefObjVisible", true);
			var selectedItems = this.byId("idModuleTable").getSelectedItems();
			var ModulesCreationModel = this.getModel("ModulesCreationModel").getData();
			var ServiceRequestId = this.getModel("servicerequestModel").getProperty("/ServiceRequestID");
			var RawCloudReferenceObjectSetModel = this.getModel("RawCloudReferenceObjectSetModel").getData();
			var CloudReferenceObjectSetModel = this.getModel("CloudReferenceObjectSetModel").getData();
			var tenantObjects = CloudReferenceObjectSetModel.objects;
			var parentId = this.selectedCloudObj.IbComponent;
			var ModuleDeletionModel = this.getModel("ModulesDeletionModel").getData();
			for (var i = 0; i < selectedItems.length; i++) {
				var selectedModule = selectedItems[i].getCells()[0].data("selectedModule");

				//check if selectedTenant already has GuidObject and added to TenantsDeletionModel
				var selectedModuleExistinDeletionModel = false;
				for (var m = 0; m < ModuleDeletionModel.length; m++) {
					if (ModuleDeletionModel[m].ProductID === selectedModule.Ppmspvproductid && ModuleDeletionModel[m].ParentComponent === parentId) {
						selectedModuleExistinDeletionModel = true;
						ModuleDeletionModel.splice(m, 1);
						break;
					}
				}

				var selectedModuleExistInBackend = false;
				var CloudRefObj;
				//check if selected Tenant already exist in the backend
				for (var h = 0; h < RawCloudReferenceObjectSetModel.length; h++) {
					if (RawCloudReferenceObjectSetModel[h].ProductID === selectedModule.Ppmspvproductid && RawCloudReferenceObjectSetModel[h].ParentComponent === parentId) {
						selectedModuleExistInBackend = true;
						CloudRefObj = RawCloudReferenceObjectSetModel[h];
						break;
					}
				}

				if (!selectedModuleExistinDeletionModel && !selectedModuleExistInBackend) {
					var createdModule = {
						"ObjectID": ServiceRequestId,
						"ProductID": selectedModule.Ppmspvproductid,
						"ParentComponent": parentId
					};
					ModulesCreationModel.push(createdModule);
					//models.rowCountCloudRefObjectoData++;
				}

				if (!selectedModuleExistInBackend) {
					CloudRefObj = {
						"GuidObject": "",
						"ProductText": selectedModule.Ppmsproductname,
						"ObjectID": ServiceRequestId,
						"RefGuid": "",
						"ComponentText": "",
						"IbaseText": "",
						"IbComponent": "",
						"CarSystemRole": "",
						"Ibase": "",
						"CarSystemRoleT": "",
						"ParentComponent": parentId,
						"ZzsDescr1": "",
						"ProductID": selectedModule.Ppmspvproductid,
						"ZzsDescr2": "",
						"MainObject": "",
						"ZzsDescr3": "",
						"ZzsDescr4": "",
						"ZzsDescr5": ""
					};
				}

				for (var j = 0; j < tenantObjects.length; j++) {
					if (parentId === tenantObjects[j].IbComponent) {
						if (!Array.isArray(tenantObjects[j].objects)) {
							tenantObjects[j].objects = [];
						}
						tenantObjects[j].objects.push(CloudRefObj);
					}

				}

			}
			this.getModel("ModulesCreationModel").setData(ModulesCreationModel);
			this.getModel("CloudReferenceObjectSetModel").setData({
				"objects": tenantObjects
			});
			this.byId("addModuleDialog").close();
			models.hideEmpltyRowsOnTenantAndModuleCreation(CloudReferenceObjectSetModel, this);
		},
		pressShowMoreCloudRefObjBtn: function (oEvent) {
			this.byId("panelCloudRefObjEdit").setExpanded(true);
			models.showHideMaxRowsForCloudRefObjs(this.byId("idTreeTableCloudRefEdit"), this.byId("ShowMoreCloudRefObjEdit"), this);
		},
		onPressDeleteTenatAndModule: function (oEvent) {
			var selectedObject = oEvent.getSource().data("selectedCloudObj");
			var txtDeleltionMsg = "";
			if (selectedObject.ProductID.includes("S_0")) {
				txtDeleltionMsg = "Tenant " + selectedObject.ProductID.split("S_0")[1];
			}
			if (selectedObject.ParentComponent !== "0") {
				txtDeleltionMsg = "Module " + selectedObject.ProductID;
			}
			var context = this;

			if (this.shiftkeyPressed) {
				this.deleteTenantsOrModule(selectedObject);
			} else {
				MessageBox.confirm("Are you sure you want to delete the " + txtDeleltionMsg + ".\n\n" + this.getResourceBundle().getText(
					"txtShiftDeleteTxt"), {
					actions: ["Yes", "No"],
					onClose: function (sAction) {
						if (sAction.toUpperCase() === "YES") {
							context.deleteTenantsOrModule(selectedObject);
						}
					}
				});
			}
		},
		onCloudRefObjectInfoButton: function (oEvent) {
			models.showCloudRefObjInfo(oEvent, this);
		},
		deleteTenantsOrModule: function (selectedObject) {
			var CloudReferenceObjectSetModel = this.getModel("CloudReferenceObjectSetModel").getData();
			var objects = CloudReferenceObjectSetModel.objects;
			var arrDeletedTenants = this.getModel("TenantsDeletionModel").getData();
			var arrDeletedModules = this.getModel("ModulesDeletionModel").getData();
			var arrTenantsCreationModel = this.getModel("TenantsCreationModel").getData();
			var arrModulesCreationModel = this.getModel("ModulesCreationModel").getData();
			
			var doesAnyModuleExist = false;
			//remove selected object from cloud reference objects tree
			for (var i = 0; i < objects.length; i++) {

				//remove tenant and its modules
				if (objects[i].ProductID === selectedObject.ProductID) {

					if (objects[i].objects) {
						for (var k = 0; k < objects[i].objects.length; k++) {
							//	models.rowCountCloudRefObjectoData--;

							for (var n = 0; n < arrModulesCreationModel.length; n++) {
								if (objects[i].objects[k].ProductID === arrModulesCreationModel[n].ProductID) {
									arrModulesCreationModel.splice(n, 1);
									break;
								}
							}
							
							if (objects[i].objects[k].GuidObject) {
								arrDeletedModules.push(objects[i].objects[k]);
							}
						}
					}

					if (selectedObject.GuidObject) {
						arrDeletedTenants.push(selectedObject);
					}
				
					objects.splice(i, 1);

					for (var m = 0; m < arrTenantsCreationModel.length; m++) {
						if (selectedObject.IbComponent === arrTenantsCreationModel[m].IbComponent) {
							arrTenantsCreationModel.splice(m, 1);
							break;
						}
					}

					//	models.rowCountCloudRefObjectoData--;
					break;
				}

				//remove module
				if (selectedObject.ParentComponent === objects[i].IbComponent) {
					var modules = objects[i].objects;
					for (var j = 0; j < modules.length; j++) {
						if (modules[j].ProductID === selectedObject.ProductID) {
							if (selectedObject.GuidObject) {
								arrDeletedModules.push(selectedObject);
							}
							modules.splice(j, 1);

							for (var n = 0; n < arrModulesCreationModel.length; n++) {
								if (selectedObject.ProductID === arrModulesCreationModel[n].ProductID) {
									arrModulesCreationModel.splice(n, 1);
									break;
								}
							}

							break;
						}
					}
					objects[i].objects = modules;
					//	models.rowCountCloudRefObjectoData--;
					break;
				}
			}
			this.getModel("CloudReferenceObjectSetModel").setData({
				"objects": objects
			});
			CloudReferenceObjectSetModel = this.getModel("CloudReferenceObjectSetModel").getData();
			for (var j = 0; j < CloudReferenceObjectSetModel.objects.length; j++) {
				if(CloudReferenceObjectSetModel.objects[j].objects && CloudReferenceObjectSetModel.objects[j].objects.length>0){
					doesAnyModuleExist = true;
					break;
				}
			}
			this.getModel("buttonControlModel").setProperty("/isShowMoreCloudRefObjVisible", doesAnyModuleExist);
			
			if (arrDeletedTenants.length > 0) {
				this.getModel("TenantsDeletionModel").setData(arrDeletedTenants);
			}
			if (arrDeletedModules.length > 0) {
				this.getModel("ModulesDeletionModel").setData(arrDeletedModules);
			}
			this.deleteEmptyRowsOnModuleAndTenantDeletion();
			
		},
		deleteEmptyRowsOnModuleAndTenantDeletion: function (oEvent) {
			var currentVisibleRowCount = this.getModel("buttonControlModel").getProperty("/visibleRowCount");
			var bindingLength = this.byId("idTreeTableCloudRefEdit").getBinding().getLength();
			this.getModel("buttonControlModel").setProperty("/visibleRowCount", bindingLength);
			/*
			if(bindingLength<currentVisibleRowCount){
				this.getModel("buttonControlModel").setProperty("/visibleRowCount",bindingLength);
			}*/
		},
		selectTenantRow: function () {
			var items = this.byId("idTenantTable").getSelectedItems();
			if (items.length > 0) {
				this.byId("idSelectTenant").setEnabled(true);
			} else {
				this.byId("idSelectTenant").setEnabled(false);
			}
		},
		selectModuleRow: function () {
			var items = this.byId("idModuleTable").getSelectedItems();
			if (items.length > 0) {
				this.byId("idSelectModule").setEnabled(true);
			} else {
				this.byId("idSelectModule").setEnabled(false);
			}
		},
		toggleOpenStateForCROTreeTable: function (oEvent) {
			models.toggleOpenStateForCROTreeTable(oEvent, this);
		},
		deleteAllTenantAndModules: function(){
			var CloudReferenceObjectSetModel = this.getModel("CloudReferenceObjectSetModel").getData();
			if(CloudReferenceObjectSetModel && CloudReferenceObjectSetModel.objects){
				for(var i=0;i<CloudReferenceObjectSetModel.objects.length;i++){
					if(CloudReferenceObjectSetModel.objects[i].MainObject==="X"){
						this.deleteTenantsOrModule(CloudReferenceObjectSetModel.objects[i]);
						break;
					}
				}
			}
		}

	});
}, true);