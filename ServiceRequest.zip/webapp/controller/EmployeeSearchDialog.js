sap.ui.define(['sap/ui/core/XMLComposite', 'sap/ui/model/json/JSONModel'],
	function (XMLComposite, JSONModel) {
		"use strict";

		// var EmployeeSearchDialog = XMLComposite.extend("sapit.controls.EmployeeSearchDialog", {
		var EmployeeSearchDialog = XMLComposite.extend("sap.com.servicerequest.servicerequest.controller.EmployeeSearchDialog", {
			////////////////////////////////////////////////////////////////////////////////////////////////////
			// Definition
			////////////////////////////////////////////////////////////////////////////////////////////////////

			/* eslint-disable no-undef */
			metadata: {
				library: "sapit",
				properties: {
					multiSelect: {
						type: "boolean",
						defaultValue: false
					},
					contentWidth: {
						type: "sap.ui.core.CSSSize",
						defaultValue: sapit.DialogWidth.SMALL
					},
					contentHeight: {
						type: "sap.ui.core.CSSSize",
						defaultValue: sapit.DialogHeight.MEDIUM
					},
					title: {
						type: "string",
						defaultValue: "Employee Search"
					},
					noDataText: {
						type: "string",
						defaultValue: ""
					}
				},
				aggregations: {},
				events: {
					confirm: {
						parameters: {
							value: {
								type: "string"
							}
						}
					},
					cancel: {
						parameters: {}
					}
				}
			},

			/* eslint-enable no-undef */

			////////////////////////////////////////////////////////////////////////////////////////////////////
			// Lifecycle
			////////////////////////////////////////////////////////////////////////////////////////////////////

			init: function () {
				var oDialog = sap.ui.core.Fragment.byId(this.getId(), "dialog");
				oDialog.setModel(new JSONModel());
				this._oDialog = oDialog;
			},

			////////////////////////////////////////////////////////////////////////////////////////////////////
			// Public
			////////////////////////////////////////////////////////////////////////////////////////////////////

			setMultiSelect: function (bValue) {
				this.setProperty("multiSelect", bValue, true);
				this._oDialog.setMultiSelect(this.getProperty("multiSelect"));
			},

			open: function () {
				this._oDialog.open();
				this._oDialog.getModel().setData({});
			},

			close: function () {
				this._oDialog.close();
			},

			////////////////////////////////////////////////////////////////////////////////////////////////////
			// Dialog Callbacks
			////////////////////////////////////////////////////////////////////////////////////////////////////

			onSearch: function (oEvt) {
				var sNewValue = oEvt.getParameter("value");
				this._fetchUserInfo(sNewValue);
			},

			onConfirm: function (oEvt) {
				if (this.getProperty("multiSelect")) {
					var aUsers = [];
					oEvt.getParameter("selectedContexts").forEach(function (user) {
						aUsers.push(user.getObject());
					});
					this.fireConfirm({
						value: aUsers
					});
				} else {
					var users = oEvt.getParameter("selectedContexts")[0].getObject(); // We only support singe select
					this.fireConfirm({
						value: users
					});
				}
			},
			onCancel: function () {
				this.fireCancel({});
			},

			////////////////////////////////////////////////////////////////////////////////////////////////////
			// Protected
			////////////////////////////////////////////////////////////////////////////////////////////////////
			_fetchUserInfo: function (sQuery) {
				this._oDialog.setBusy(true);
				$.ajax({
						url: jQuery.sap.getModulePath("sapit") + "/sapitapi/user-info?q=" + sQuery + "&limit=100"
					})
					.done(this._fetchUserInfoDone.bind(this))
					.fail(this._fetchUserInfoFail.bind(this));
			},

			_fetchUserInfoDone: function (oData) {
				this._oDialog.setBusy(false);
				this._oDialog.getModel().setData({
					items: oData
				});
			},

			_fetchUserInfoFail: function (jqXHR, textStatus, errorThrown) {
				jQuery.sap.log.warning("Failed to fetch UserInfo", "jqXHR=[" + jqXHR + "], textStatus=[" + textStatus + "], errorThrown=[" +
					errorThrown + "]", "sapit");
			}
		});

		return EmployeeSearchDialog;
	});