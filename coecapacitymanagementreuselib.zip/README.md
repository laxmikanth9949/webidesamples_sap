# CoE Capacity Management Reuselib
Global CoE Resource Supply Planning Apps - Reuse Library used across the Resource Planning applications:

- Capacity Analysis
- Planning Calendar
- Resource Planning

## Technical Names
**Repository Name:** coecapacitymanagementreuselib

**Name in sapitcloudt:** capacitymanagementreuselib

## Deployments
Deployed Version No: 1.12

Ver 1.12 - Bugfix - Retrieve User Info in the CFLP

Ver 1.8 - Bugfix - Couldn't delete qualification tokens in Capacity Analysis app

Ver 1.7 - Bugfix - i18n file for public holidays in calendar

Ver 1.6 - Add usage tracking event for Calendar p13n settings

Ver 1.3 - Bugfix - Repopulation of filter values after removal when searching
