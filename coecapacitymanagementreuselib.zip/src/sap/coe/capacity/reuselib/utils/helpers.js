sap.ui.define([
    "sap/coe/capacity/reuselib/utils/baseclasses/Helpers"
    ], function(HelpersBaseClass) {
    "use strict";

    return new HelpersBaseClass();

});
