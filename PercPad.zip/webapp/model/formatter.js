sap.ui.define(
	[
		"sap/support/PercPad/model/models",
	],
	function (models) {
		"use strict";

		return {
			/**
			 * Defines a value state based on the favorite
			 *
			 * @public
			 * @param {number} isFav the statue of a post
			 * @returns {string} sValue the state for the favorite
			 */
			formatRating: function (sRate) {
				var sRateDesc = "";
				switch (sRate) {
				case 'R':
					sRateDesc = "Red";
					break;
				case 'Y':
					sRateDesc = "Yellow";
					break;
				case 'G':
					sRateDesc = "Green";
					break;

				}
				return sRateDesc;
			},
			dateFormatting: function (day) {

				var month = (day.getMonth() + 1).toString();
				var dd = day.getDate().toString();

				if (month.length == 1)
					month = "0" + month;

				if (dd.length == 1)
					dd = "0" + dd;

				return day.getFullYear().toString() + month + dd;

			},

		};
	});