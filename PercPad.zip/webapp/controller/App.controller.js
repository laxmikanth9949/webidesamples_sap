sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	'sap/support/PercPad/model/formatter'
], function (Controller, JSONModel, Filter, formatter) {
	"use strict";

	return Controller.extend("sap.support.PercPad.controller.App", {
		formatter: formatter,
		onInit: function () {
			var oView = this.getView();
			this.listTasks = [];
			this.TASK_Note = [];
			this.oTaskModel = new JSONModel();
			this.url = jQuery.sap.getUriParameters().get("param");
			this.noteString = "";
			this.htmlString = "";
			oView.setModel(new JSONModel(), "TaskList");
			oView.setModel(new JSONModel(), "StatusModel");
			oView.setModel(new JSONModel(), "PrioModel");
			oView.setModel(new JSONModel(), "ActivityList");
			//emma
			oView.setModel(new JSONModel(), "ActivityNotesList");
			//emma
			this.getStatusList();
			this.getPrioList();
			//emma7.27 trigger EnabledModel
			this.getEnabled();
			this.changeBtn();
		},
		getEnabled: function () {
			this.getView().setModel(new JSONModel({
				enabled: false,
				enabled2: false
			}), "EnableModel");
		},
		changeBtn: function () {
			this.getView().setModel(new JSONModel({
				isSave: false,
				isEdit: false,
				isPopUp: false,
				vBox: true,
				searchList: false
			}), "changeBtn");
		},
		////emma7.27 create EnabledModel
		getStatusList: function () {
			var oView = this.getView();
			sap.support.PercPad.DashBoardModel.read("/SettingList", {
				filters: [new Filter("key", "EQ", "status"),
					new Filter("value1", "EQ", "ZS88")
				],
				success: function (oData) {
					var oData2 = {
						"results": []
					};
					var obj = {};
					oData.results.forEach(function (oItem) {
						obj = {};
						obj.key = oItem.value2;
						obj.text = oItem.value3;
						oData2.results.push(obj);
					});
					oView.getModel("StatusModel").setData(oData2);
				},
				error: function () {
					sap.m.MessageToast.show("Get error when load service ZS_AGS_DASHBOARDS_SRV");
				}
			});
		},
		getPrioList: function () {
			var oView = this.getView();
			sap.support.PercPad.DashBoardModel.read("/SettingList", {
				filters: [new Filter("key", "EQ", "PRIORITY")],
				success: function (oData) {
					oView.getModel("PrioModel").setData(oData);
				},
				error: function () {
					sap.m.MessageToast.show("Get error when load service ZS_ESCALATIONS");
				}
			});
		},
		onChangeNotes: function (oEvent) {
			var $ta = jQuery(oEvent.getSource().getFocusDomRef());
			if (!$ta.data("first")) {
				$ta.data("first", true).css({
					"min-height": $ta.outerHeight(),
					"overflow-y": "hidden"
				});
			}
			$ta.height(0).height($ta[0].scrollHeight);
		},
		onPopup: function () {
			var oView = this.getView();
			if (!this.oNotesDialog) {
				this.oNotesDialog = new sap.ui.xmlfragment("sNotesDialog", "sap.support.PercPad.view.NotesDialog", this);
				this.getView().addDependent(this.oNotesDialog);
			}
			this.oNotesDialog.open();
			sap.ui.core.Fragment.byId("sNotesDialog", "popUphtml").setVisible(true);
			sap.ui.core.Fragment.byId("sNotesDialog", "popUptext").setVisible(false);
			sap.ui.core.Fragment.byId("sNotesDialog", "popUpNotes").setValue(oView.byId("percNotes").getValue());
		},
		onEditClose: function (oEvent) {
			var oView = this.getView();
			var percTableHeader = oView.byId("percTableForm").getTitle();
			//emma 7.27 modify property JSONModels
			var changeBtn = this.getView().getModel("changeBtn");
			var EnableModel = this.getView().getModel("EnableModel");

			var sTitle = oView.byId("SFB1").getValue();
			var resultSessionMinutes = this.getSessionMinutes(sTitle);
			oView.byId("percNotes").setValue(this.resultSMForNotes(resultSessionMinutes));

			//emma 7.27 modify property JSONModels
			if (oEvent.getSource().getText() === "Edit") {
				this.getView().byId("edit_close").setText("Close");
				//emma 7.27 注释 and modify property JSONModel start
				// this.getView().byId("edit_save").setVisible(true);
				// this.getView().byId("percRating").setEnabled(true);
				// this.getView().byId("percStatus").setEnabled(true);
				// this.getView().byId("pop_up").setVisible(true);

				//emma 7.27 注释 and modify property JSONModel end
				this.getView().byId("percNotes").setEditable(true);
				if (percTableHeader && percTableHeader.substring(percTableHeader.indexOf(":") + 1).length > 2) {
					this.listTasks[this.listTasks.length] = {};
					this.listTasks[this.listTasks.length - 1].task_id = "";
					this.listTasks[this.listTasks.length - 1].title = "";
					this.listTasks[this.listTasks.length - 1].description = "";

					this.listTasks[this.listTasks.length - 1].prio = "";
					this.listTasks[this.listTasks.length - 1].dueDate = "";
					this.listTasks[this.listTasks.length - 1].respName = "";
					this.listTasks[this.listTasks.length - 1].respID = "";

					this.lastEditableCell++;
					oView.getModel("TaskList").setData({
						results: this.listTasks
					});

					changeBtn.setData({
						isSave: true,
						isEdit: true,
						isPopUp: true,
						searchList: false
					});
					EnableModel.setData({
						enabled: true
					});
					//emma to set the description which filled with data uneditable start
					for (var c = 0; c < this.listTasks.length - 1; c++)
						if (this.listTasks[c].title) {
							this.listTasks[c].editabledInput = false;
						}
					this.listTasks[c].editabledInput = true;
				}
				oView.getModel("TaskList").setData({
					results: this.listTasks
				});
			} else {
				oView.byId("edit_close").setText("Edit");
				//emma 7.27 注释 and modify property JSONModel start
				// oView.byId("edit_save").setVisible(false);
				// oView.byId("percRating").setEnabled(false);
				// oView.byId("percStatus").setEnabled(false);
				// oView.byId("percNotes").setEditable(false);
				// oView.byId("pop_up").setVisible(false);
				changeBtn.setData({
					isSave: false,
					isEdit: false,
					isPopUp: false,
					searchList: false,
					vBox: true
				});
				EnableModel.setData({
					enabled: false,
					enabled2: false
				});
				//emma 7.27 注释 and modify property JSONModel end
				if (percTableHeader.substring(percTableHeader.indexOf(":") + 1).length > 2)
					this.setDetailForAct(this.getDetailForAct(percTableHeader.substring(percTableHeader.indexOf(":") + 2),
						"ZS88"));
				else {
					this.listTasks = [];
					oView.getModel("TaskList").setData({
						results: this.listTasks
					});
				}

			}
		},
		newEditableCell: function (i) {
			if (this.lastEditableCell === i || this.lastEditableCell === -1) {

				if (this.lastEditableCell === -1)
					this.lastEditableCell = 0;

				this.listTasks[this.lastEditableCell + 1] = {};
				this.listTasks[this.lastEditableCell + 1].task_id = "";
				this.listTasks[this.lastEditableCell + 1].title = "";
				this.listTasks[this.lastEditableCell + 1].description = "";

				// this.listTasks[this.lastEditableCell+1].prio = sap.ui.getCore().byId("percPrio");
				this.listTasks[this.lastEditableCell + 1].prio = "";
				this.listTasks[this.lastEditableCell + 1].dueDate = "";
				this.listTasks[this.lastEditableCell + 1].respName = "";
				this.listTasks[this.lastEditableCell + 1].respID = "";
				this.getView().getModel("TaskList").setData({
					"results": this.listTasks
				});
				// this.oTaskModel.setData({
				// 	modelData: this.listTasks
				// });
				// table.setModel(this.oTaskModel);
				// table.bindRows("/modelData");

				this.lastEditableCell++;
			}
		},

		clickbuttonTextConvert: function () {
			this.saveNewNoteString();
			var noteString = sap.ui.core.Fragment.byId("sNotesDialog", "popUpNotes").getValue();
			sap.ui.core.Fragment.byId("sNotesDialog", "popUpNotes").setValue(noteString);
			sap.ui.core.Fragment.byId("sNotesDialog", "popUphtml").setVisible(true);
			sap.ui.core.Fragment.byId("sNotesDialog", "popUptext").setVisible(false);
		},
		clickbuttonHtmlConvert: function () {
			this.htmlConvert();
			sap.ui.core.Fragment.byId("sNotesDialog", "popUpNotes").setValue(this.htmlString);
			sap.ui.core.Fragment.byId("sNotesDialog", "popUphtml").setVisible(false);
			sap.ui.core.Fragment.byId("sNotesDialog", "popUptext").setVisible(true);
		},
		onApplyNotesChange: function () {
			this.saveNewNoteString();
			var noteString = sap.ui.core.Fragment.byId("sNotesDialog", "popUpNotes").getValue();
			this.getView().byId("percNotes").setValue(noteString);
			this.oNotesDialog.close();
		},
		onCloseNotesDialog: function () {
			this.oNotesDialog.close();
		},
		onSave: function () {
			// this.save();
			var oView = this.getView();
			oView.setBusy(true);
			//emma 7.27注释 and set JSONModel property start
			// this.getView().byId("edit_save").setVisible(true);
			var changeBtn = this.getView().getModel("changeBtn");
			var EnableModel = this.getView().getModel("EnableModel");
			var percTableHeader = oView.byId("percTableForm").getTitle();
			//emma 7.27注释 and set JSONModel property end
			var sUrl = sap.support.PercPad.CCSModelUrl; //"/sap/opu/odata/sap/ZS_AGS_DASHBOARDS_SRV/";
			// 0000101296
			// sCollection = sUrl+"ActivityList('0000254986')";
			var sCollection = sUrl + "ActivityList('" + this.PERC_Act[0].activity_id + "')";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, {
				metadataUrlParams: {
					"sap-language": "en"
				},
				json: true
			});
			this.getView().setModel(oModel);

			oModel.refreshSecurityToken();
			var oModelHeaders = oModel.getHeaders();

			var oHeaders = {
				"x-csrf-token": oModelHeaders['x-csrf-token'],
				"Content-Type": "application/json; charset=utf-8",
				"x-http-method": "MERGE"
			};

			var percApp_status = "";
			if (oView.byId("percStatus").getSelectedKey() !== "0")
				percApp_status = oView.byId("percStatus").getSelectedKey();

			var percApp_rating = "";
			if (oView.byId("percRating").getSelectedItem().getKey() !== "0")
				percApp_rating = oView.byId("percRating").getSelectedKey();

			if (this.PERC_Note !== oView.byId("percNotes").getValue()) {
				var encodeDecode = "";
				var countlist = 1;

				while (encodeURI(oView.byId("percNotes").getValue()).indexOf("%20-") > -1) {
					encodeDecode = encodeURI(oView.byId("percNotes").getValue()).replace("%20-", "-");
					oView.byId("percNotes").setValue(decodeURI(encodeDecode));
				}

				while (encodeURI(oView.byId("percNotes").getValue()).indexOf("%09-") > -1) {
					encodeDecode = encodeURI(oView.byId("percNotes").getValue()).replace("%09-", "-");
					oView.byId("percNotes").setValue(decodeURI(encodeDecode));
				}

				while (encodeURI(oView.byId("percNotes").getValue()).indexOf("%20" + countlist + ".") > -1) {
					encodeDecode = encodeURI(oView.byId("percNotes").getValue()).replace("%20" + countlist + ".", countlist + ".");

					if (encodeDecode.indexOf("%20" + countlist + ".") < 0) {
						countlist++;
					}
					oView.byId("percNotes").setValue(decodeURI(encodeDecode));
				}
				countlist = 1;

				while (encodeURI(oView.byId("percNotes").getValue()).indexOf("%09" + countlist + ".") > -1) {
					encodeDecode = encodeURI(oView.byId("percNotes").getValue()).replace("%09" + countlist + ".", countlist + ".");
					oView.byId("percNotes").setValue(decodeURI(encodeDecode));
					if (encodeDecode.indexOf("%09" + countlist + ".") < 0) {
						countlist++;
					}
					oView.byId("percNotes").setValue(decodeURI(encodeDecode));

				}

				var oModel2 = new sap.ui.model.json.JSONModel({
					PERC_ActivityList: [{
						activity_status: percApp_status,
						activity_rating: percApp_rating,
						Notes: oView.byId("percNotes").getValue()

					}]
				});

			} else {
				var oModel2 = new sap.ui.model.json.JSONModel({
					PERC_ActivityList: [{
						activity_status: percApp_status,
						activity_rating: percApp_rating
							//Notes : oView.byId("percNotes").mProperties.value
					}]
				});
			}

			jQuery.ajax({
				async: true,
				url: sCollection,
				type: "POST",
				dataType: "json",
				headers: oHeaders,
				data: JSON.stringify(oModel2.getData().PERC_ActivityList[0]),
				success: function (data) {
					sap.m.MessageToast.show("PERC Activity saved succesfully");
					oView.setBusy(false);

				},
				error: function () {
					sap.m.MessageToast.show("Error during PERC Activity saving");
					oView.setBusy(false);
				}
			});

			// read out editable Task Activity Informaion and save the information
			var taskList = oView.byId("table_task").getBinding().oList;

			for (var i = 0; i < taskList.length; i++) {

				if (!taskList[i].task_id) {
					if (taskList[i].description)
						this.createTask(taskList, i);
				} else
					this.updateTask(taskList, i);
			}

			//emma 8.2注释状态
			// changeBtn.setData({
			// 	isSave: true,
			// 	isEdit: true,
			// 	isPopUp: true,
			// 	searchList: false,
			// 	vBox: true
			// });
			// EnableModel.setData({
			// 	enabled: false,
			// 	enabled2: false
			// });
			if (oView.byId("edit_close").getText() === "Close")
				oView.byId("edit_close").setText("Edit");
			//emma 7.27 注释 and modify property JSONModel start
			// oView.byId("edit_save").setVisible(false);
			// oView.byId("percRating").setEnabled(false);
			// oView.byId("percStatus").setEnabled(false);
			// oView.byId("percNotes").setEditable(false);
			// oView.byId("pop_up").setVisible(false);
			changeBtn.setData({
				isSave: false,
				isEdit: true,
				isPopUp: false,
				searchList: false,
				vBox: true
			});
			EnableModel.setData({
				enabled: false,
				enabled2: false
			});
			//emma 7.27 注释 and modify property JSONModel end
			if (percTableHeader.substring(percTableHeader.indexOf(":") + 1).length > 2)
				this.setDetailForAct(this.getDetailForAct(percTableHeader.substring(percTableHeader.indexOf(":") + 2),
					"ZS88"));
			else {
				this.listTasks = [];
				oView.getModel("TaskList").setData({
					results: this.listTasks
				});
			}

			// ---------------
			// create Task
			// ---------------

			// for (var k = 0; k < listCreateTask.length; k++)
			// {
			// if(listCreateTask[k].description != "" || listCreateTask[k].prio != "" || listCreateTask[k].respID != ""
			// || listCreateTask[k].title != "" )
			// {
			// this.createTask(listCreateTask, k);
			// }
			//
			//
			// }

			// ---------------
			// Update Task
			// ---------------

			// for (var l = 0; l < listUpdateTask.length; l++)
			// {
			//
			// }
		},
		onSearch: function () {
			var oView = this.getView();
			this._searchFields_activity = {};
			var sSearchMeth = oView.byId("percSearch").getSelectedKey();
			//emma7.27 注释 and modify property of JSONModel start
			var changeBtn = this.getView().getModel("changeBtn");
			changeBtn.setData({
				isSave: false,
				isEdit: false,
				isPopUp: false
			});
			// oView.byId("pop_up").setVisible(false);
			oView.byId("edit_close").setText("Edit");
			// oView.byId("edit_close").setVisible(false);
			// oView.byId("edit_save").setVisible(false);
			//emma7.27 注释 and modify property of JSONModel end
			if (!oView.byId("SFB1").getValue()) {
				//emma7.27 注释 and modify property of JSONModel start 
				//oView.byId("VBox1").setVisible(false);
				//oView.byId("searchList").setVisible(true);
				changeBtn.setData({
					vBox: false,
					searchList: true,
					isSave: false,
					isEdit: false,
					isPopUp: false
				});
				//emma7.27 注释 and modify property of JSONModel end
				oView.getModel("TaskList").setData({
					"results": []
				});
				oView.getModel("ActivityList").setData({
					"results": []
				});
				return;
			} else {
				//emma7.27 注释 and modify property of JSONModel start
				// oView.byId("VBox1").setVisible(false);
				// oView.byId("searchList").setVisible(true);
				changeBtn.setData({
					vBox: false,
					searchList: true,
					isSave: false,
					isEdit: false,
					isPopUp: false
				});
				//emma7.27 注释 and modify property of JSONModel end
			}
			if (sSearchMeth === "0") {
				this._searchFields_activity.erpCustNo = "";
				this._searchFields_activity.activityID = this.getView().byId("SFB1").getValue();
				this._searchFields_activity.process_type = "ZS88";
				this.searchActivities(this._searchFields_activity);
			} else if (sSearchMeth === "1") {
				this._searchFields_activity.activityID = "";
				this._searchFields_activity.erpCustNo = this.getView().byId("SFB1").getValue();
				this._searchFields_activity.process_type = "ZS88";
				this.searchActivities(this._searchFields_activity);
			}
			// else if (!oView.byId("SFB1").getValue()) {
			// 	oView.byId("VBox1").setVisible(true);
			// }
		},
		searchActivities: function (searchFields) {
			var oView = this.getView();
			var aFilter = [];
			if (searchFields.erpCustNo && searchFields.erpCustNo !== "0") {
				aFilter.push(new Filter("activity_activity_partner", "EQ", searchFields.erpCustNo));
			}
			if (searchFields.activityID && searchFields.activityID !== "0") {
				aFilter.push(new Filter("activity_id", "EQ", searchFields.activityID));
			}
			aFilter.push(new Filter("activity_process_type", "EQ", searchFields.process_type));
			if (aFilter === []) {
				return;
			}
			oView.setBusy(true);
			sap.support.PercPad.DashBoardModel.read("/ActivityList", {
				filters: aFilter,
				success: function (oData) {
					var oData2 = {
						"results": []
					};
					var obj = {};
					oData.results.forEach(function (oItem) {
						obj = {};
						obj.Description = "Activity Description: " + oItem.activity_description;
						obj.StatusRate = "Status / Rating: " + oItem.activity_status_desc + " / " + formatter.formatRating(oItem.activity_rating);
						obj.BPNo = "BP No: " + oItem.activity_activity_partner;
						obj.ActivityID = oItem.activity_id;
						oData2.results.push(obj);

					});
					oView.getModel("ActivityList").setData(oData2);
					oView.setBusy(false);
				},
				error: function () {
					sap.m.MessageToast.show("Get error when load activcity list");
					oView.setBusy(false);
				}
			});

		},
		onActivityDetail: function (oEvent) {
			var oView = this.getView();
			var sTitle = oEvent.getSource().getTitle();
			var changeBtn = this.getView().getModel("changeBtn");
			var EnableModel = this.getView().getModel("EnableModel");
			this.setDetailForAct(this.getDetailForAct(sTitle, "ZS88"));

			//original getSessionMinutes to return data emma start
			// var resultSessionMinutes = this.getSessionMinutes(sTitle);
			// oView.byId("percNotes").setValue(resultSessionMinutes);
			//original getSessionMinutes emma end
			//emma to set session minutes to notes start
			var resultSessionMinutes = this.getSessionMinutes(sTitle);
			oView.byId("percNotes").setValue(this.resultSMForNotes(resultSessionMinutes));
			//emma to set session minutes to notes end
			//emma
			//7.29 emma start
			// this.setDetailForActNote(this.getSessionMinutes(sTitle));
			//emma 7.27注释 and modify property JSONModel start
			oView.byId("edit_close").setText("Edit");
			// oView.byId("edit_close").setVisible(true);
			// oView.byId("edit_save").setVisible(false);
			changeBtn.setData({
				isSave: false,
				isEdit: true,
				isPopUp: false,
				searchList: false
			});
			EnableModel.setData({
				enabled: false,
				enabled2: false
			});
			// oView.byId("percRating").setEnabled(false);
			// oView.byId("percStatus").setEnabled(false);
			// oView.byId("percNotes").setEditable(false);
			//emma 7.27注释 and modify property JSONModel start

			//emma
			//for multiple i
			// var resultList = this.getSessionMinutes(sTitle);
			// var resultStr = "";
			// for (var i = 0; i < resultList.length; i++) {
			// 	resultStr += resultList[i].tdline + "\n";
			// }
			// oView.byId("percNotes").setValue(resultStr);

			// for single i
			//var resultSessionMinutes = this.getSessionMinutes(sTitle)[0].tdline;

		},
		getDetailForAct: function (actID, process_Type) {
			var oActivity = {};
			var custURL = sap.support.PercPad.CCSModelUrl + "ActivityList?$filter=activity_id%20eq%20'" + actID + "'%20" +
				"and%20activity_process_type%20eq%27" + process_Type + "%27&$expand=ActivityNotes&$format=json&sap-language=en";
			jQuery.ajax({
				async: false,
				url: custURL,
				type: "get",
				dataType: "json",
				success: function (data) {
					oActivity = data.d.results;
				},
				error: function () {
					sap.m.MessageToast.show("Error during reading Activity Details");
				}
			});

			return oActivity;
			// sap.support.PercPad.DashBoardModel.read("/ActivityList", {
			// 	filters: [new Filter("activity_id", "EQ", actID),
			// 		new Filter("activity_process_type", "EQ", process_Type),
			// 		new Filter("activity_id", "EQ", actID)
			// 	],
			// 	urlParameters: {
			// 		$expand: "ActivityNotes"
			// 	},
			// 	success: function (oData) {
			// 		oActivity = oData.results;
			// 	},
			// 	error: function () {
			// 		sap.m.MessageToast.show("Get Error when load activity details");
			// 	}
			// });
			// return oActivity;
		},
		//emma sessionminutes-notes result directly
		// getSessionMinutes: function (actID) {
		// 	var oView = this.getView();
		// 	var resultSessionMinutes = {};
		// 	var smURL = sap.support.PercPad.CCSModelUrl + "ActivityNotesList?$filter=activity_id%20eq%20'" + actID + "'%20";
		// 	// +"&$expand=tdline&$format=json&sap-language=en";
		// 	jQuery.ajax({
		// 		async: false,
		// 		url: smURL,
		// 		type: "get",
		// 		dataType: "json",
		// 		success: function (data) {
		// 			var oData3 = {
		// 				"sessionMinutesResults": []
		// 			};
		// 			var obj3 = "";
		// 			data.d.results.forEach(function (oItem) {
		// 				obj3 += oItem.tdline + "\r\n";
		// 			});
		// 			oData3.sessionMinutesResults.push(obj3);
		// 			resultSessionMinutes = obj3;
		// 			oView.getModel("ActivityNotesList").setData(oData3);
		// 		},
		// 		error: function () {
		// 			sap.m.MessageToast.show("Error during reading Session Minutes");
		// 		}
		// 	});
		// 	return resultSessionMinutes;
		// },
		//emma activitynoteslist all result start 7.29:
		getSessionMinutes: function (actID) {
			var smURL = sap.support.PercPad.CCSModelUrl + "ActivityNotesList?$filter=activity_id%20eq%20'" + actID + "'%20";
			// +"&$expand=tdline&$format=json&sap-language=en";
			var resultSM = new Object();
			jQuery.ajax({
				async: false,
				url: smURL,
				type: "get",
				dataType: "json",
				success: function (data) {
					resultSM = data.d.results;
				},
				error: function () {
					sap.m.MessageToast.show("Error during reading Session Minutes");
				}
			});
			return resultSM;
		},
		//emma tdline for big Notes
		resultSMForNotes: function (resultSM) {
			var oView = this.getView();
			var resultSessionMinutes = {};
			var oData3 = {
				"sessionMinutesResults": []
			};
			var obj3 = "";
			resultSM.forEach(function (oItem) {
				obj3 += oItem.tdline + "\r\n";
			});
			oData3.sessionMinutesResults.push(obj3);
			resultSessionMinutes = obj3;
			oView.getModel("ActivityNotesList").setData(oData3);
			return resultSessionMinutes;
		},
		//emma activitynoteslist all result for task list notes end 7.29:
		setDetailForAct: function (percActInfo) {
			var that = this;
			var oView = this.getView();
			//emma注释 and set property JSONModel start
			var changeBtn = this.getView().getModel("changeBtn");
			changeBtn.setData({
				isSave: false,
				isEdit: true,
				isPopUp: false,
				vBox: true,
				searchList: false
			});
			// oView.byId("VBox1").setVisible(true);
			// oView.byId("searchList").setVisible(false);
			//emma注释 and set property JSONModel end
			this.PERC_Act = percActInfo;
			oView.byId("percTableForm").setTitle("PERC Activity Number: " + percActInfo[0].activity_id);
			oView.byId("percCustomerNameNumber").setText(percActInfo[0].account_name_F + " / " + percActInfo[0].activity_activity_partner);

			oView.byId("percStatus").setSelectedKey(percActInfo[0].activity_status);
			oView.byId("percRating").setSelectedKey(percActInfo[0].activity_rating);

			this.noteString = "";
			var uriHelp = "";
			var countlist = 1;

			for (var i = 0; i < percActInfo[0].ActivityNotes.results.length; i++) {
				if (percActInfo[0].ActivityNotes.results[i].tdformat == "*" && i > 0) {
					that.noteString += "\n";
				}

				if (percActInfo[0].ActivityNotes.results[i].tdline.trimLeft().indexOf("-") === 0) {
					countlist = 1;
					uriHelp = encodeURI(percActInfo[0].ActivityNotes.results[i].tdline);
					if (uriHelp && i > 6) {
						uriHelp = uriHelp + "%20";
					}
					uriHelp = decodeURI(uriHelp);

					if (uriHelp.indexOf("- ") > -1) {
						that.noteString += uriHelp;
					} else {
						that.noteString += uriHelp.replace("-", "- ");
					}
					countlist = 1;
				} else if (percActInfo[0].ActivityNotes.results[i].tdline.trimLeft().indexOf(countlist + ".") === -1) {
					uriHelp = encodeURI(percActInfo[0].ActivityNotes.results[i].tdline);
					if (uriHelp && i > 6) {
						uriHelp = uriHelp + "%20";
					}
					uriHelp = decodeURI(uriHelp);

					if (uriHelp.indexOf(countlist + ". ") > -1) {
						that.noteString += uriHelp;
					} else {
						that.noteString += uriHelp.replace(countlist + ".", countlist + ". ");
					}
					countlist++;
				} else {
					countlist = 1;

					if (percActInfo[0].ActivityNotes.results[i].tdline.indexOf(percActInfo[0].ActivityNotes.results[i].tdline.length - 1) != " ") {
						that.noteString += percActInfo[0].ActivityNotes.results[i].tdline + " ";
					} else {
						that.noteString += percActInfo[0].ActivityNotes.results[i].tdline;
					}

				}
			}

			oView.byId("percNotes").setValue(that.noteString);
			this.PERC_Note = that.noteString;

			// get Task Information
			this.relatedAct = this.getRelatedAct(percActInfo[0].activity_id);
			//var table = oView.byId("table_task");

			var taskAct;
			this.listTasks = [];
			var sTitle = oView.byId("SFB1").getValue();
			var Notes = this.setDetailForActNote(this.getSessionMinutes(sTitle));
			for (var k = 0; k < this.relatedAct.length; k++) {
				//emma注释
				// taskAct = this.getDetailForAct(this.relatedAct[k].ActivityId, "ZS35");
				//emma注释结束
				//emma
				taskAct = this.getDetailForAct(this.relatedAct[k].ActivityId, "ZS46");
				//emma end
				this.listTasks[k] = {};
				this.TASK_Note[k] = {};
				this.listTasks[k].title = taskAct[0].activity_description;
				this.TASK_Note[k].title = taskAct[0].activity_description;

				//emma start 7.28
				//this.listTasks[k].description = taskAct[0].activity_description;
				//this.TASK_Note[k].description = taskAct[0].activity_description;
				this.listTasks[k].description = Notes[k];
				this.TASK_Note[k].description = Notes[k];
				//emma end 7.28
				this.listTasks[k].task_id = taskAct[0].activity_id;
				this.TASK_Note[k].task_id = taskAct[0].activity_id;
				//emma注释
				// var taskNote = "";

				// for (var j = 0; j < taskAct[0].ActivityNotes.results.length; j++) {
				// 	// if(j > 3)
				// 	// {
				// 	// if(taskAct[0].ActivityNotes.results[j].tdline == "____________________")
				// 	// break;
				// 	taskNote += taskAct[0].ActivityNotes.results[j].tdline;
				// 	// }
				// }

				// this.listTasks[k].description = taskNote;
				// this.TASK_Note[k].description = taskNote;
				//emma注释以上

				// this.listTasks[k].prio = oView.byId("percPrio");

				this.listTasks[k].prio = taskAct[0].activity_priority_desc;
				this.TASK_Note[k].prio = taskAct[0].activity_priority_desc;

				this.listTasks[k].prioKey = taskAct[0].activity_priority;
				this.TASK_Note[k].prioKey = taskAct[0].activity_priority;

				var dueTime = new Date();
				dueTime.setTime(taskAct[0].to_date.substring(6, 16) * 1000);

				this.listTasks[k].dueDate = formatter.dateFormatting(dueTime);
				this.TASK_Note[k].dueDate = formatter.dateFormatting(dueTime);

				// this.listTasks[k].dueDate = dueTime.getFullYear().toString()+(dueTime.getMonth()+1).toString()+dueTime.getDate().toString();

				this.listTasks[k].respName = taskAct[0].activity_person_name;
				this.TASK_Note[k].respName = taskAct[0].activity_person_name;
				this.listTasks[k].respID = taskAct[0].activity_person_user_id;
				this.TASK_Note[k].respID = taskAct[0].activity_person_user_id;
			}

			this.lastEditableCell = this.listTasks.length - 1;
			oView.getModel("TaskList").setData({
				results: this.listTasks
			});
			// this.oTaskModel.setData({
			// 	modelData: this.listTasks
			// });
			// table.setModel(this.oTaskModel);
			// table.bindRows("/modelData");
			//emma start 7.24
			// var lengthTaskList = this.listTasks.length;
			// table.setVisibleRowCount(lengthTaskList);
			//emma end 7.24

		},
		//emma 7.29 new  model for notes setting start 
		setDetailForActNote: function (percActInfo2) {
			var oView = this.getView();
			this.PERC_Act2 = percActInfo2;
			this.relatedAct2 = this.getRelatedAct(percActInfo2[0].activity_id);
			var taskAct2;
			this.listTasks2 = [];
			this.TASK_Note2 = [];
			for (var k = 0; k < this.relatedAct2.length; k++) {
				var allActID = this.relatedAct2[k].ActivityId;
				taskAct2 = this.getSessionMinutes(allActID);

				this.listTasks2[k] = {};
				//this.TASK_Note2[k] = {};

				this.listTasks2[k] = taskAct2[0].tdline;
				//this.TASK_Note2[k]= taskAct2[0].tdline;
			}

			return this.listTasks2;
		},
		//emma 7.29 new  model for notes setting end
		getRelatedAct: function (actID) {
			//emma注释
			// var custURL = sap.support.PercPad.CCSModelUrl + "ActivityTransactionHistorySet?$filter=ActivityId%20eq%20'" + actID +
			// 	"'%20and%20ProcessType%20eq%27ZS35%27&$format=json&sap-language=en";
			//emma注释结束
			//emma
			var custURL = sap.support.PercPad.CCSModelUrl + "ActivityTransactionHistorySet?$filter=ActivityId%20eq%20'" + actID +
				"'%20and%20ProcessType%20eq%27ZS46%27&$format=json&sap-language=en";
			//emma end
			var oRelActivity = new Object();

			jQuery.ajax({
				async: false,
				url: custURL,
				type: "get",
				dataType: "json",
				success: function (data) {
					oRelActivity = data.d.results;
				},
				error: function () {
					sap.m.MessageToast.show("Error during reading Activity Details");
				}
			});

			return oRelActivity;
		},
		saveNewNoteString: function () {

			var countlist = 1;
			var encodeDecode = "";
			var oNoteCtrl = sap.ui.core.Fragment.byId("sNotesDialog", "popUpNotes");
			var sNotes = oNoteCtrl.getValue();

			//emma
			//while (sNotes.indexOf("<p>") > -1) {
			if (sNotes.indexOf("<p>") > -1 || sNotes.indexOf("</p>") > -1) {
				sNotes = sNotes.replace(/<p>/g, "");
				sNotes = sNotes.replace(/<\/p>/g, "");
				oNoteCtrl.setValue(sNotes);
				// oNoteCtrl.setValue(sNotes.replace("<p>"", ""));
				// oNoteCtrl.setValue(sNotes.replace("</p>", ""));
			}
			//emma
			while (sNotes.indexOf("<ul>") > -1 || sNotes.indexOf("<ol>") > -1) {
				var ulList = sNotes.indexOf("<ul>");
				var ulListend = sNotes.indexOf("</ul>");
				var olList = sNotes.indexOf("<ol>");
				var olListend = sNotes.indexOf("</ol>");
				if (ulList < olList && ulList > -1 || olList < 0) {
					sNotes = sNotes.replace("<ul>", "");
					sNotes = sNotes.replace("</ul>", "");
					oNoteCtrl.setValue(sNotes);
					ulList = ulList - 4;
					ulListend = ulListend - 9;
					while (sNotes.indexOf("<li>") > -1 && ulList <= sNotes.indexOf("<li>") && ulListend > sNotes.indexOf("<li>")) {
						sNotes = sNotes.replace("<li>", "-");
						sNotes = sNotes.replace("</li>", "");
						oNoteCtrl.setValue(sNotes);
						ulListend = ulListend - 8 + countlist.toString().length;
					}
				} else if (olList < ulList && olList > -1 || ulList < 0) {
					sNotes = sNotes.replace("<ol>", "");
					sNotes = sNotes.replace("</ol>", "");
					oNoteCtrl.setValue(sNotes);
					olList = olList - 4;
					olListend = olListend - 9;
					countlist = 1;
					while (sNotes.indexOf("<li>") > -1 && olList <= sNotes.indexOf("<li>") && olListend > sNotes.indexOf("<li>")) {
						sNotes = sNotes.replace("<li>", countlist + ".");
						sNotes = sNotes.replace("</li>", "");
						oNoteCtrl.setValue(sNotes);
						countlist++;
						olListend = olListend - 8 + countlist.toString().length;
						//olListend = olListend - 9;
					}
				}
			}
			//emma end

			//original start
			//         	while (sNotes.indexOf("<ul>") > -1 || sNotes.indexOf("<ol>") > -1) {
			// 	var ulList = sNotes.indexOf("<ul>");
			// 	var ulListend = sNotes.indexOf("</ul>");

			// 	var olList = sNotes.indexOf("<ol>");
			// 	var olListend = sNotes.indexOf("</ol>");

			// 	var list = "";
			// 	if (ulList < olList && ulList > -1 || olList < 0) {
			// 	// 1. <ol> doesn't exist  OR 2. both <ol> <ul> exist and <ul><ol></ol></ul>
			// 		list = "ulist";
			// 		countlist = 1;
			// 		encodeDecode = sNotes;
			// 		encodeDecode = encodeURI(encodeDecode).replace("%0A%3Cul%3E", "");
			// 		oNoteCtrl.setValue(decodeURI(encodeDecode));

			// 		encodeDecode = sNotes;
			// 		encodeDecode = encodeURI(encodeDecode).replace("%0A%3C/ul%3E", "");
			// 		oNoteCtrl.setValue(decodeURI(encodeDecode));

			// 	} else if (olList < ulList && olList > -1 || ulList < 0) {
			// 		list = "olist";
			// 		countlist = 1;
			// 		encodeDecode = sNotes;
			// 		encodeDecode = encodeURI(encodeDecode).replace("%0A%3Col%3E", "");
			// 		oNoteCtrl.setValue(decodeURI(encodeDecode));

			// 		encodeDecode = sNotes;
			// 		encodeDecode = encodeURI(encodeDecode).replace("%0A%3C/ol%3E", "");
			// 		oNoteCtrl.setValue(decodeURI(encodeDecode));
			// 	}
			// 	// sNotes = sNotes.replace("<", "&lt;");
			// 	// sNotes = sNotes.replace(">", "&gt;");
			// 	ulListend = ulListend - 9;
			// 	olListend = olListend - 9;

			// 	while (sNotes.indexOf("<li>") > -1 && ((list === "ulist" && ulListend > sNotes.indexOf("<li>")) || (list === "olist" && olListend >
			// 			sNotes.indexOf("<li>")))) {
			// 		if (list === "ulist" && ulListend > sNotes.indexOf("<li>")) {
			// 			oNoteCtrl.setValue(sNotes.replace("<li>", "-"));
			// 			oNoteCtrl.setValue(sNotes.replace("</li>", ""));
			// 			ulListend = ulListend - 7;
			// 		} else if (list === "olist" && olListend > sNotes.indexOf("<li>")) {
			// 			oNoteCtrl.setValue(sNotes.replace("<li>", countlist + "."));
			// 			oNoteCtrl.setValue(sNotes.replace("</li>", ""));
			// 			olListend = olListend - 7;
			// 			countlist++;
			// 		}
			// 	}
			// }
			//original end

			//while (sNotes.indexOf("<br/>") > -1) {
			//	oNoteCtrl.setValue(sNotes.replace("<br/>", ""));
			//sap.ui.getCore().byId("popUpNotes").mProperties.value = encodeURI(sap.ui.getCore().byId("popUpNotes").mProperties.value).replace("%3Cbr/%3E", "%0Abr");
			//sap.ui.getCore().byId("popUpNotes").mProperties.value = decodeURI(sap.ui.getCore().byId("popUpNotes").mProperties.value);
			//	}

			// while (encodeURI(sNotes).indexOf("%0A%0Abr") > -1) {
			// 	oNoteCtrl.setValue(encodeURI(sNotes).replace(
			// 		"%0A%0Abr", "%0Abr"));
			// 	oNoteCtrl.setValue(decodeURI(sNotes));
			// }

			// while (sNotes.indexOf("<br>") > -1) {
			// 	oNoteCtrl.setValue(sNotes.replace("<br>", ""));
			// }
			//emma
			if (sNotes.indexOf("<br>") > -1 || sNotes.indexOf("<br/>") > -1) {
				sNotes = sNotes.replace(/<br>/g, "");
				sNotes = sNotes.replace(/<br\/>/g, "");
				oNoteCtrl.setValue(sNotes);
			}
			//emma 注释开始--this is modified based on previous version by Emma and now is removed unless further requirement is needed
			// var sNotesEncodeDecode = decodeURI(encodeURI(sNotes).replace("%0A%0Abr", "%0Abr"));
			// oNoteCtrl.setValue(sNotesEncodeDecode);
			//emma 注释结束

			var sNotesEncodeDecode2 = decodeURI(sNotes);
			oNoteCtrl.setValue(sNotesEncodeDecode2);

		},
		updateTask: function (listTask, i) {

			var that = this;
			var oView = this.getView();
			// var oPicker = new sap.m.DatePicker();
			// var oDate = new Date();
			var sDueDate = listTask[i].dueDate;
			var sNewDate = sDueDate.substr(0, 4) + "-" + sDueDate.substr(4, 2) + "-" + sDueDate.substr(6, 2) + " 23:59:59";
			var oDate = new Date(sNewDate);
			var sUrl = sap.support.PercPad.CCSModelUrl;

			var sCollection = sUrl + "ActivityList('" + listTask[i].task_id + "')";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, {
				metadataUrlParams: {
					"sap-language": "en"
				},
				json: true
			});
			sap.ui.getCore().setModel(oModel);
			oModel.refreshSecurityToken();
			var oModelHeaders = oModel.getHeaders();
			var oHeaders = {
				"x-csrf-token": oModelHeaders['x-csrf-token'],
				"Content-Type": "application/json; charset=utf-8",
				"x-http-method": "MERGE"
			};

			// oDate = new Date(oPicker.setValue(listUpdateTask[l].dueDate).getValue());
			// oPicker.setYyyymmdd(listTask[i].dueDate);
			// oDate.setYear(oPicker.getYyyymmdd().substring(0, 4));
			// oDate.setMonth(oPicker.getYyyymmdd().substring(4, 6) * 1 - 1);
			// oDate.setDate(oPicker.getYyyymmdd().substring(6, 8));

			// oDate.setHours(23);
			// oDate.setMinutes(59);
			// oDate.setSeconds(59);

			if (listTask[i].prio.length < 2)
				listTask[i].prioKey = listTask[i].prio;
			var prioGW;
			switch (listTask[i].prio) {
			case "Very High":
				prioGW = "1";
				break;
			case "High":
				prioGW = "3";
				break;
			case "Medium":
				prioGW = "5";
				break;
			case "Low":
				prioGW = "9";
				break;
			default:
				prioGW = "3";
			}

			// check if descirption was updated
			var stringTMP, stringTMP2;
			for (var c = 0; c < this.TASK_Note.length; c++) {

				stringTMP = listTask[i].description + listTask[i].dueDate + listTask[i].prioKey + listTask[i].respID + listTask[i].task_id +
					listTask[i].title;
				stringTMP2 = this.TASK_Note[i].description + this.TASK_Note[i].dueDate + this.TASK_Note[i].prioKey + this.TASK_Note[i].respID +
					this.TASK_Note[i].task_id + this.TASK_Note[i].title;

				if (stringTMP !== stringTMP2) {

					if (listTask[i].task_id == this.TASK_Note[c].task_id) {

						if (listTask[i].description == this.TASK_Note[c].description) {
							var oModel2 = new sap.ui.model.json.JSONModel({
								TASK_UpdateActivityList: [{
									activity_planned_date_to: oDate.toJSON().substring(0, oDate.toJSON().length - 2),
									activity_priority: prioGW,
									activity_person_user_id: listTask[i].respID,
									//emma注释
									activity_description: listTask[i].title
										//emma注释结束
										//emma start 7.23
										//activity_description: listTask[i].description,
										//emma end
								}]
							});

						} else {
							var oModel2 = new sap.ui.model.json.JSONModel({
								TASK_UpdateActivityList: [{
									//emma注释
									Notes: listTask[i].description,
									//emma注释结束
									activity_planned_date_to: oDate.toJSON().substring(0, oDate.toJSON().length - 2),
									activity_priority: prioGW,
									activity_person_user_id: listTask[i].respID,
									activity_description: listTask[i].title
										//emma start 7.23
										//activity_description: listTask[i].description,
										//emma end
								}]
							});
						}
						// oView.setBusy(true);
						jQuery.ajax({
							async: true,
							url: sCollection,
							type: "POST",
							dataType: "json",
							headers: oHeaders,
							data: JSON.stringify(oModel2.getData().TASK_UpdateActivityList[0]),
							success: function (oData) {
								sap.m.MessageToast.show("Task Updated succesfully");
								// oView.setBusy(false);
								//emma注释
								// var act = that.getDetailForAct(listTask[i].task_id, "ZS35");
								//emma注释
								//emma start
								var act = that.getDetailForAct(listTask[i].task_id, "ZS46");
								//emma end
								listTask[i].respName = act[0].activity_person_name;
								listTask[i].respID = act[0].activity_person_user_id;
								oView.getModel("TaskList").setData({
									"results": listTask
								});
							},
							error: function (XMLHttpRequest, textStatus, errorThrown) {
								// oView.setBusy(false);
								sap.m.MessageToast.show("Task Update failed: " + XMLHttpRequest.responseJSON.error.message.value);
							}
						});
					}

				}
			}

		},
		createTask: function (listTask, i) {
			var that = this,
				oView = this.getView();
			// var oPicker = new sap.m.DatePicker();
			var sDueDate = listTask[i].dueDate;
			var sNewDate = sDueDate.substr(0, 4) + "-" + sDueDate.substr(4, 2) + "-" + sDueDate.substr(6, 2) + " 23:59:59";
			var oDate = new Date(sNewDate);

			var sUrl = sap.support.PercPad.CCSModelUrl;
			var sCollection = sUrl + "ActivityList";
			var EnableModel = this.getView().getModel("EnableModel");
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, {
				metadataUrlParams: {
					"sap-language": "en"
				},
				json: true
			});
			sap.ui.getCore().setModel(oModel);

			oModel.refreshSecurityToken();
			var oModelHeaders = oModel.getHeaders();

			var oHeaders = {
				"x-csrf-token": oModelHeaders['x-csrf-token'],
				"Content-Type": "application/json; charset=utf-8"
			};

			// oDate = new Date(oPicker.setValue(listCreateTask[k].dueDate).getValue());
			// oPicker.setYyyymmdd(listTask[i].dueDate);
			// oDate.setYear(oPicker.getYyyymmdd().substring(0, 4));
			// oDate.setMonth(oPicker.getYyyymmdd().substring(4, 6) * 1 - 1);
			// oDate.setDate(oPicker.getYyyymmdd().substring(6, 8));
			// oDate.setHours(23);
			// oDate.setMinutes(59);
			// oDate.setSeconds(59);
			var prioGW;
			switch (listTask[i].prio) {
			case "Very High":
				prioGW = "1";
				break;
			case "High":
				prioGW = "3";
				break;
			case "Medium":
				prioGW = "5";
				break;
			case "Low":
				prioGW = "9";
				break;
			default:
				prioGW = "3";
			}
			listTask[i].prioKey = prioGW;

			var oModel2 = new sap.ui.model.json.JSONModel({
				TASK_CreateActivityList: [{
					//emma注释
					Notes: listTask[i].description,
					//emma注释结束
					activity_planned_date_to: oDate.toJSON().substring(0, oDate.toJSON().length - 2),
					// to_time : "23:59:59",
					activity_priority: prioGW,
					activity_person_user_id: listTask[i].respID,
					//emma注释
					activity_description: listTask[i].title,
					//emma注释结束
					//emma start
					// activity_description: listTask[i].description,
					//emma end
					activity_id: this.PERC_Act[0].activity_id,
					//emma注释
					// activity_process_type: "ZS35",
					//emma注释结束
					//emma start 7.23
					activity_process_type: "ZS46",
					activity_cat: "ZYR"
						//emma end
				}]
			});

			// oView.setBusy(true);
			jQuery.ajax({
				async: false,
				url: sCollection,
				type: "POST",
				dataType: "json",
				headers: oHeaders,
				data: JSON.stringify(oModel2.getData().TASK_CreateActivityList[0]),
				success: function (data) {
					sap.m.MessageToast.show("Task created succesfully");
					listTask[i].task_id = data.d.activity_id;
					//emma注释
					// var act = that.getDetailForAct(listTask[i].task_id, "ZS35");
					//emma注释
					//emma start
					var act = that.getDetailForAct(listTask[i].task_id, "ZS46");
					//emma end
					listTask[i].respName = act[0].activity_person_name;
					listTask[i].respID = act[0].activity_person_user_id;
					oView.getModel("TaskList").setData({
						"results": listTask
					});
					// oView.setBusy(false);
				},
				error: function (XMLHttpRequest, textStatus, errorThrown) {
					// oView.setBusy(false);
					sap.m.MessageToast.show("Task Creation failed: " + XMLHttpRequest.responseJSON.error.message.value);
				}
			});

			//emma uneditable setting
			EnableModel.setData({
				enabled: false,
				enabled2: false
			});
		},
		htmlConvert: function () {
			var htmlArray = new Array();
			var count = 0;
			var countlist = 1;
			htmlArray[count] = {};
			this.htmlString = encodeURI(sap.ui.core.Fragment.byId("sNotesDialog", "popUpNotes").getValue());
			//emma注释
			//this.htmlString = "%20" + countlist + ".";
			//emma注释
			//emma start
			this.htmlString2 = "%20" + countlist + ".";
			//emma end
			var htmlString = this.htmlString;
			while (htmlString.indexOf("%20" + countlist + ".") > -1) {
				htmlString = htmlString.replace("%20" + countlist + ".", countlist + ".");
				if (htmlString.indexOf("%20" + countlist + ".") < 0) {
					countlist++;
				}
			}
			countlist = 1;

			while (htmlString.indexOf(+countlist + ".%20") > -1) {
				htmlString = htmlString.replace(+countlist + ".%20", countlist + ".");
				if (htmlString.indexOf(+countlist + ".%20") < 0) {
					countlist++;
				}
			}
			countlist = 1;
			while (htmlString.indexOf("%09" + countlist + ".") > -1) {
				htmlString = htmlString.replace("%09" + countlist + ".", countlist + ".");
				if (htmlString.indexOf("%09" + countlist + ".") < 0) {
					countlist++;
				}
			}
			countlist = 1;

			while (htmlString.indexOf("%20-") > -1) {
				htmlString = htmlString.replace("%20-", "-");

			}
			while (htmlString.indexOf("-%20") > -1) {
				htmlString = htmlString.replace("-%20", "-");
			}

			while (htmlString.indexOf("%09-") > -1) {
				htmlString = htmlString.replace("%09-", "-");

			}

			while (htmlString.indexOf("%0A") > -1) {

				htmlArray[count] = decodeURI(htmlString.substring(0, htmlString.indexOf("%0A")));
				htmlString = htmlString.substring(htmlString.indexOf("%0A") + 3);
				count++;
			}

			htmlArray[count] = decodeURI(htmlString);

			var liHelp = "";
			htmlString = "";
			var countlist = 1;
			var orderedLiHelp = "";
			for (var i = 0; i < htmlArray.length; i++) {
				if (i > 0) {
					htmlString += "\n";
				}

				if (htmlArray[i].length > 0) {

					var help = htmlArray[i];

					if (help.indexOf("-") > -1 && help.substring(0, 1) === "-") {

						if (orderedLiHelp === "x") {
							htmlString += "</ol>" + "\n";
							orderedLiHelp = "";
							countlist = 1;
						}
						while (help.substring(0, 2) === "--") {
							htmlArray[i] = htmlArray[i].replace("--", "-");
							help = htmlArray[i];
						}
						if (liHelp === "") {
							liHelp = "x";
							htmlString += "<ul>" + "\n";
						}
						htmlString += htmlArray[i].replace("-", "<li>") + "</li>";
					} else if (htmlArray[i].indexOf(countlist + ".") > -1) {
						if (liHelp === "x") {
							htmlString += "</ul>" + "\n";
							liHelp = "";

							if (countlist === 1) {
								htmlString += "<ol>" + "\n";
								orderedLiHelp = "x";
							}
							htmlString += htmlArray[i].replace(countlist + ".", "<li>") + "</li>";
							countlist++;
						} else {
							if (countlist === 1) {
								htmlString += "<ol>" + "\n";
								orderedLiHelp = "x";
							}

							htmlString += htmlArray[i].replace(countlist + ".", "<li>") + "</li>";
							countlist++;
						}

					} else {
						if (liHelp === "x" || orderedLiHelp === "x") {
							if (liHelp === "x") {
								htmlString += "</ul>" + "\n";
								liHelp = "";
							}
							if (orderedLiHelp === "x") {
								htmlString += "</ol>" + "\n";
								orderedLiHelp = "";
								countlist = 1;
							}
						}

						htmlString += "<p>" + htmlArray[i] + "</p>";
					}
				} else {
					if (liHelp === "x" || orderedLiHelp === "x") {
						if (liHelp === "x") {
							htmlString += "</ul>" + "\n";
							liHelp = "";
							htmlString += "<br/>";
						}
						if (orderedLiHelp === "x") {
							htmlString += "</ol>" + "\n";
							orderedLiHelp = "";
							countlist = 1;
							htmlString += "<br/>";
						}
					} else {
						htmlString += "<br/>";
					}
				}
			}
			if (liHelp === "x") {
				htmlString += "\n" + "</ul>";
			}

			if (orderedLiHelp === "x") {
				htmlString += "\n" + "</ol>";
				countlist = 1;
			}

		},

		clickCellTaskTable: function (oEvent) {
			var oView = this.getView();
			if (!this.oDescDialog) {
				this.oDescDialog = new sap.ui.xmlfragment("sDescDialog", "sap.support.PercPad.view.DescDialog", this);
				oView.addDependent(this.oDescDialog);
			}
			this.rowIndex = oEvent.mParameters.rowIndex;
			var columnIndex = oEvent.mParameters.columnIndex;
			var rowIndex = this.rowIndex;
			if (oView.byId("edit_close").getText() === "Close" && columnIndex === "2") {
				this.newEditableCell(rowIndex);
				this.oDescDialog.open();

				//oView.byId("descriptionPopUp").setValue(oView.byId("__field1-col2-row"+row).getValue());
				var sValue = oEvent.getSource().getAggregation("rows")[rowIndex].getAggregation("cells")[columnIndex].getText();
				sap.ui.core.Fragment.byId("sDescDialog", "descriptionPopUp").setValue(sValue);
			}
		},
		onCloseDescDialog: function () {
			this.oDescDialog.close();
		},

		onApplyDescChange: function () {
				var row = this.rowIndex;
				var oView = this.getView();
				var sValue = sap.ui.core.Fragment.byId("sDescDialog", "descriptionPopUp").getValue();
				//emma注释开始
				oView.byId("table_task").getAggregation("rows")[row].getAggregation("cells")[2].setText(sValue);
				//emma注释结束
				//emma start
				//oView.byId("table_task").getAggregation("rows")[row].getAggregation("cells")[1].setText(sValue);
				//emma end
				// set editable rows before insert the tasklist - Emma 7.24
				// var editableRow = oView.byId("table_task").getAggregation("rows").length
				// var insertRow = editableRow + 1
				// oView.byId("table_task").setVisibleRowCount(insertRow)
				// set editable rows before insert the tasklist - Emma 7.24
				this.oDescDialog.close();
			}
			//emme title-formatter
			// isEnabledInput: function( sText ) {
			// 	if ( sText ) return false;
			// 	return true;
			// }

	});
});