sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"sap/support/PercPad/model/models",
	'sap/ui/model/odata/v2/ODataModel'
], function (UIComponent, Device, models, ODataModel) {
	"use strict";

	return UIComponent.extend("sap.support.PercPad.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			this.initODataModel();
			UIComponent.prototype.init.apply(this, arguments);
			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		},
			initODataModel: function (){ 
			sap.support.PercPad.DashBoardModel = new ODataModel({
				json: true,
				useBatch: false,
				serviceUrl: "/sap/opu/odata/sap/ZS_CX_CCS_SRV",
				defaultUpdateMethod: "Put"
			});
			sap.support.PercPad.CCSModelUrl = "/sap/opu/odata/sap/ZS_CX_CCS_SRV/";
			// sap.support.PercPad.EscalationModel = new ODataModel({
			// 	json: true,
			// 	useBatch: false,
			// 	serviceUrl: "/sap/opu/odata/sap/ZS_ESCALATIONS",
			// 	defaultUpdateMethod: "Put"
			// });
			// sap.support.PercPad.MDFModel = new ODataModel({
			// 	json: true,
			// 	useBatch: false,
			// 	serviceUrl: "/sap/opu/odata/svx/MDF_SRV",
			// 	defaultUpdateMethod: "Put"
			// });
			}
	});
});