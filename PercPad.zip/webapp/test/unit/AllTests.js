sap.ui.define([
	"sap/support/PercPad/test/unit/controller/App.controller"
], function () {
	"use strict";
});